import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/components/ui/use-toast";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { format, differenceInDays } from "date-fns";
import { ArrowLeft, Download, Edit, CheckCircle, User, CreditCard, Building2, ChevronDown, ChevronUp, Save, X, FileText, FileImage, Plus, Info, ChevronLeft, ChevronRight, AlertCircle, CalendarIcon, CheckCircle2, ClipboardCheck, ZoomIn, ZoomOut, RotateCcw, RotateCw, Flag, Maximize2, Receipt, Calculator, Trash2, Pencil, Check, ChevronsUpDown, ExternalLink, Keyboard } from 'lucide-react';
import { cn } from "@/lib/utils";
import { Link, useNavigate } from 'react-router-dom';
import { BillEntryExpandable, BillEntryExpandableHandle } from '@/components/BillEntryExpandable';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import PatientIdentificationStep from '@/components/claim-registration/PatientIdentificationStep';

interface ClaimDetailViewProps {
  claimId: string;
  onBack: () => void;
}

const ClaimDetailView: React.FC<ClaimDetailViewProps> = ({
  claimId,
  onBack
}) => {
  const navigate = useNavigate();
  const [isClaimDetailsOpen, setIsClaimDetailsOpen] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isPolicyEditing, setIsPolicyEditing] = useState(false);
  const [isPatientEditing, setIsPatientEditing] = useState(false);
  const [isHospitalEditing, setIsHospitalEditing] = useState(false);
  const [isBankEditing, setIsBankEditing] = useState(false);
  const [editingHospitalIndex, setEditingHospitalIndex] = useState<number | null>(null);
  const [isKeyboardShortcutsOpen, setIsKeyboardShortcutsOpen] = useState(false);
  const [lastSavedTime, setLastSavedTime] = useState<Date | null>(null);
  const [isDownloadDialogOpen, setIsDownloadDialogOpen] = useState(false);
  const [selectedExtension, setSelectedExtension] = useState<string>('');
  const [isRaiseQueryDialogOpen, setIsRaiseQueryDialogOpen] = useState(false);
  const [queryReasons, setQueryReasons] = useState<string[]>([]);
  const [queryFreeText, setQueryFreeText] = useState('');
  const { toast } = useToast();
  
  // Patient & Policy Modal states
  const [isPatientPolicyModalOpen, setIsPatientPolicyModalOpen] = useState(false);
  const [selectedPolicy, setSelectedPolicy] = useState<any>(null);
  const [selectedMember, setSelectedMember] = useState<any>(null);
  
  // Hospital management states
  const [selectedHospitals, setSelectedHospitals] = useState([
    {
      hospitalName: 'Apollo Hospital',
      hospitalLocation: 'Delhi',
      networkType: 'Network',
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 11 2692 5858',
      hospitalAddress: 'Sarita Vihar, Delhi Mathura Road, New Delhi - 110076',
      isApproved: true
    }
  ]);
  const [isAddingHospital, setIsAddingHospital] = useState(false);
  const [hospitalSearchTerm, setHospitalSearchTerm] = useState('');
  const [showHospitalNotFound, setShowHospitalNotFound] = useState(false);
  const [isAdvancedSearch, setIsAdvancedSearch] = useState(false);
  const [advancedSearchFilters, setAdvancedSearchFilters] = useState({
    city: '',
    state: '',
    pincode: ''
  });
  const [newHospitalData, setNewHospitalData] = useState({
    hospitalName: '',
    hospitalLocation: '',
    networkType: 'Network',
    hospitalContact: '',
    hospitalAddress: '',
    city: '',
    state: '',
    pincode: '',
    rohini: ''
  });
  const [isAddHospitalDialogOpen, setIsAddHospitalDialogOpen] = useState(false);
  const [hospitalSearchOpen, setHospitalSearchOpen] = useState<{[key: number]: boolean}>({});
  const hospitalInputRefs = useRef<{ [key: number]: HTMLInputElement | null }>({});
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [addSubCategoryOpen, setAddSubCategoryOpen] = useState(false);
  const [nonMedicalExpensesCovered, setNonMedicalExpensesCovered] = useState(true);
  const [editingRowIndex, setEditingRowIndex] = useState<number | null>(null);
  const [editingDetailIndex, setEditingDetailIndex] = useState<number | null>(null);
  const [currentDocumentIndex, setCurrentDocumentIndex] = useState(0);
  const [addLineItemOpen, setAddLineItemOpen] = useState(false);
  const [newLineItem, setNewLineItem] = useState({
    category: '',
    tariffAmount: '',
    discount: '',
    billAmount: '',
    payableAmount: ''
  });
  const [newSubCategory, setNewSubCategory] = useState({
    name: '',
    days: '1',
    tariffAmount: '',
    discount: '',
    deductions: '',
    billAmount: '',
    payableAmount: ''
  });

  // Document zoom state
  const [documentZoom, setDocumentZoom] = useState(100);
  
  // Document rotation state
  const [documentRotation, setDocumentRotation] = useState(0);
  
  // Document overlay state
  const [documentOverlayOpen, setDocumentOverlayOpen] = useState(false);
  
  // Selected document state for dropdown
  const [selectedDocument, setSelectedDocument] = useState('0');
  
  // Document preview modal state
  const [isDocumentPreviewOpen, setIsDocumentPreviewOpen] = useState(false);
  const [previewDocumentIndex, setPreviewDocumentIndex] = useState(0);
  
  // Notes editing state
  const [isEditingNotes, setIsEditingNotes] = useState(false);
  const [originalNotes, setOriginalNotes] = useState('');
  const [tempNotes, setTempNotes] = useState('');

  // Agent checklist state
  const [checklist, setChecklist] = useState({
    claimType: false,
    dateOfAdmission: false,
    dateOfDischarge: false,
    policyDetails: false,
    uhid: false,
    hospitalName: false,
    bankAccount: false,
    billEntryUpdate: false,
    documentTagging: false
  });

  // Bill entry expandable state for each sub-category
  const [expandedBillEntries, setExpandedBillEntries] = useState<{ [key: number]: boolean }>({});
  
  // Store detailed bills and deductions for each saved entry
  const [savedBillDetails, setSavedBillDetails] = useState<{ [key: string]: { bills: any[], deductions: any[] } }>({});
  
  // Store intermediate saved bills/deductions for temp item (before final save)
  const [tempSavedBills, setTempSavedBills] = useState<any[]>([]);
  const [tempSavedDeductions, setTempSavedDeductions] = useState<any[]>([]);
  
  const billEntryRef = useRef<BillEntryExpandableHandle>(null);
  
  // Summary modal state
  const [summaryModalOpen, setSummaryModalOpen] = useState(false);
  
  // Review screen state
  const [isReviewScreenOpen, setIsReviewScreenOpen] = useState(false);

  // Preview resize state
  const [previewHeight, setPreviewHeight] = useState(600);
  const [isResizing, setIsResizing] = useState(false);

  // Document tagging dialog state
  const [showDocumentTagDialog, setShowDocumentTagDialog] = useState(false);
  const [hasOtherClaimDocuments, setHasOtherClaimDocuments] = useState(false);
  const [showOtherPersonBillDialog, setShowOtherPersonBillDialog] = useState(false);
  const [isCreatingExtension, setIsCreatingExtension] = useState(false);
  const [showBackToLookup, setShowBackToLookup] = useState(false);

  // Workflow stage state (Stage 1: Review, Stage 2: Bill Entry)
  const [workflowStage, setWorkflowStage] = useState<'review' | 'billEntry'>('review');
  
  // Review step state (1: Patient & Policy, 2: Claim Details, 3: Hospital Details, 4: Bank Details)
  const [reviewStep, setReviewStep] = useState(1);

  const handleNewSubCategoryChange = (field: string, value: string) => {
    setNewSubCategory(prev => {
      const updated = { ...prev, [field]: value };
      
      // Auto-calculate bill amount and payable amount
      if (field === 'tariffAmount' || field === 'discount' || field === 'deductions' || field === 'days') {
        const tariff = parseFloat(updated.tariffAmount) || 0;
        const discount = parseFloat(updated.discount) || 0;
        const deductions = parseFloat(updated.deductions) || 0;
        const days = parseFloat(updated.days) || 1;
        const billAmount = tariff * days;
        const payableAmount = billAmount - deductions - discount;
        
        updated.billAmount = billAmount.toString();
        updated.payableAmount = payableAmount.toString();
      }
      
      return updated;
    });
  };

  const handleAddSubCategory = () => {
    // Add the new sub-category to the existing list
    const tariff = parseFloat(newSubCategory.tariffAmount) || 0;
    const discount = parseFloat(newSubCategory.discount) || 0;
    const days = parseFloat(newSubCategory.days) || 1;
    const billAmount = tariff * days;
    const payableAmount = billAmount - discount;
    
    const newCategory = {
      id: Date.now(),
      name: newSubCategory.name,
      days: newSubCategory.days,
      tariffAmount: newSubCategory.tariffAmount,
      discount: newSubCategory.discount,
      deductions: newSubCategory.deductions,
      billAmount: billAmount.toLocaleString(),
      payableAmount: payableAmount.toLocaleString()
    };
    
    setSubCategories(prev => [...prev, newCategory]);
    
    // Reset form and close modal
    setNewSubCategory({
      name: '',
      days: '1',
      tariffAmount: '',
      discount: '',
      deductions: '',
      billAmount: '',
      payableAmount: ''
    });
    setAddSubCategoryOpen(false);
  };

  const [documents, setDocuments] = useState([
    {
      id: 1,
      name: 'Medical_Report_001.pdf',
      type: 'PDF',
      size: '2.4 MB',
      uploadDate: '30 Mar 2025, 09:15 AM',
      status: 'Approved',
      icon: FileText,
      content: `DISCHARGE SUMMARY
Patient: Priya Sharma | Age: 34F | UHID: 12345
Admission: 28/03/2025 | Discharge: 30/03/2025

DIAGNOSIS: Acute Appendicitis with Laparoscopic Appendectomy
TREATMENT: Successful laparoscopic removal of inflamed appendix
MEDICATIONS: Antibiotics, Pain management
CONDITION: Stable, healing well
FOLLOW-UP: 7 days post-op visit scheduled`,
      category: 'Discharge Summary',
      readability: true,
      suspicious: false,
      irrelevant: false,
      isComplete: true,
      agentNotes: '',
      systemRecommendation: 'Document is clear and contains all required medical information. Recommend approval.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    },
    {
      id: 5,
      name: 'query_response1_merged_view',
      type: 'View',
      size: '0 KB',
      uploadDate: '30 Mar 2025, 10:00 AM',
      status: 'Available',
      icon: FileText,
      content: `QUERY RESPONSE - MERGED VIEW
Query ID: QR-2025-0328-001
Status: Resolved

Original Query: "Please clarify room category and justify ICU charges"
Response Date: 29/03/2025

RESPONSE SUMMARY:
✓ ICU charges justified - patient required post-op monitoring
✓ Room category: Semi-private as per policy coverage
✓ All supporting documents attached
✓ No additional clarification needed`,
      category: 'Query Response',
      readability: true,
      suspicious: false,
      irrelevant: false,
      isComplete: true,
      agentNotes: '',
      systemRecommendation: 'Query response merged view is available for review.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    },
    {
      id: 2,
      name: 'Prescription_Scan.jpg',
      type: 'Image',
      size: '1.8 MB',
      uploadDate: '30 Mar 2025, 09:20 AM',
      status: 'Pending',
      icon: FileImage,
      content: `PRESCRIPTION
Dr. Rajesh Kumar | MD General Surgery
Apollo Hospital, Delhi

Patient: Priya Sharma | Date: 28/03/2025

Rx:
1. Tab Ciprofloxacin 500mg - BD x 7 days
2. Tab Paracetamol 650mg - TDS x 5 days  
3. Tab Pantoprazole 40mg - OD x 10 days
4. Syp Lactulose 15ml - BD PRN

[Note: Image quality needs improvement for full verification]`,
      category: 'Prescription',
      readability: false,
      suspicious: false,
      irrelevant: false,
      isComplete: false,
      agentNotes: '',
      systemRecommendation: 'Image quality is poor. Request clearer scan for better readability before approval.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    },
    {
      id: 3,
      name: 'Lab_Results.pdf',
      type: 'PDF',
      size: '956 KB',
      uploadDate: '30 Mar 2025, 09:25 AM',
      status: 'Approved',
      icon: FileText,
      content: `LABORATORY REPORT
Apollo Diagnostics | Report Date: 28/03/2025
Patient: Priya Sharma | Age: 34F

PRE-OPERATIVE INVESTIGATIONS:
• Hemoglobin: 12.8 g/dL (Normal: 12-15)
• Total WBC Count: 8,500/μL (Normal: 4,000-11,000)
• Platelets: 2,85,000/μL (Normal: 1.5-4.5 lakh)
• Blood Sugar (Fasting): 95 mg/dL (Normal: <100)
• Serum Creatinine: 0.9 mg/dL (Normal: 0.6-1.2)

INTERPRETATION: All parameters within normal limits`,
      category: 'Lab Reports',
      readability: true,
      suspicious: false,
      irrelevant: false,
      isComplete: true,
      agentNotes: '',
      systemRecommendation: 'Lab results are within normal ranges and clearly documented. Safe to approve.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    },
    {
      id: 4,
      name: 'Old_Discharge_Summary.pdf',
      type: 'PDF',
      size: '1.2 MB',
      uploadDate: '28 Mar 2025, 01:00 PM',
      status: 'Rejected',
      icon: FileText,
      content: `DISCHARGE SUMMARY [REJECTED]
Patient: Unknown | Age: 35F | UHID: XXXXX
Admission: 15/02/2025 | Discharge: 17/02/2025

⚠️ DOCUMENT INCONSISTENCIES DETECTED:
- Date mismatch with current claim period
- Missing pages 2-3 (incomplete document)
- Hospital seal/signature unclear
- Patient details don't match claim

STATUS: REJECTED - Requires verification`,
      category: 'Discharge Summary',
      readability: true,
      suspicious: true,
      irrelevant: false,
      isComplete: false,
      agentNotes: 'Pages 2-3 appear to be missing from this document. Need complete discharge summary.',
      systemRecommendation: 'Document dates do not match claim period. Potential fraud risk - recommend further investigation.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: 'date-mismatch',
      suspiciousDetails: 'Document dates do not match claim period',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: 'missing-pages',
      missingDetails: 'Pages 2-3 appear to be missing'
    },
    {
      id: 6,
      name: 'Additional_Information.txt',
      type: 'Text',
      size: '2 KB',
      uploadDate: '30 Mar 2025, 09:30 AM',
      status: 'Approved',
      icon: FileText,
      content: `ADDITIONAL INFORMATION PROVIDED BY USER

Patient requested early discharge due to family emergency. All medications and follow-up instructions have been clearly understood and documented.

Note: Patient will be available for follow-up consultation via telemedicine if needed during recovery period.`,
      category: 'Additional Information',
      readability: true,
      suspicious: false,
      irrelevant: false,
      isComplete: true,
      agentNotes: '',
      systemRecommendation: 'Additional information provided by user during claim registration.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    }
  ]);

  // Document category options
  const documentCategories = [
    'Prescription',
    'Medicine Bills',
    'Lab Reports',
    'Discharge Summary',
    'ID Proof',
    'Additional Information'
  ];

  // Hierarchical category structure
  const categoryHierarchy = {
    "Room & Nursing Charges": {
      "Room Charges": ["Room Rent", "ICU Charges", "ICCU Charges", "NICU Charges", "PICU Charges", "HDU Charges", "Special Room Charges"],
      "Nursing Charges": ["Nursing fees", "Dressing", "Nebulization", "Injection charges", "Infusion pump charges", "Aya Charges", "Blood Transfusion Charges"]
    },
    "Surgery Charges": {
      "Surgeon Fees": [],
      "Anesthesia Charges": [],
      "OT Charges": []
    },
    "Investigations": {
      "Laboratory": [],
      "Radiology": [],
      "Pathology": []
    }
  };

  // Flat list of selected bill items
  const [selectedBillItems, setSelectedBillItems] = useState<Array<{
    id: string;
    fullPath: string;
    level1: string;
    level2: string;
    level3: string;
    documentId: number;
    documentName: string;
    days: string;
    tariffAmount: string;
    billAmount: string;
    eligibleAmount: string;
    discount: string;
    payableAmount: string;
  }>>([]);
  
  const [categorySearchOpen, setCategorySearchOpen] = useState(false);
  const [categorySearchValue, setCategorySearchValue] = useState("");
  
  // Keep old subcategories for summary calculations (backward compatibility)
  const [subCategories, setSubCategories] = useState([{
    id: 0,
    name: "Room Charges",
    tariffAmount: "8000",
    days: "3",
    discount: "0",
    deductions: "0",
    billAmount: "24,000",
    payableAmount: "24,000"
  }, {
    id: 1,
    name: "Nursing charges",
    type: "Medical",
    tariffAmount: "5000",
    discount: "0",
    deductions: "0",
    billAmount: "5,000",
    payableAmount: "5,000"
  }, {
    id: 2,
    name: "Duty Doctor fee",
    type: "Medical",
    tariffAmount: "3500",
    discount: "0",
    deductions: "0",
    billAmount: "3,500",
    payableAmount: "3,500"
  }, {
    id: 3,
    name: "Monitor charges",
    type: "Medical",
    tariffAmount: "2000",
    discount: "0",
    deductions: "0",
    billAmount: "2,000",
    payableAmount: "2,000"
  }]);

  // Room charge detail types
  const roomChargeTypes = [
    'General Ward charges',
    'Semi-private room charges',
    'Single Room charges',
    'Single Deluxe room charges',
    'Deluxe room charges',
    'Suite charges',
    'Electricity charges',
    'Bed sheet charges',
    'Hot water charges',
    'Establishment Charges',
    'Alpha/Water Bed Charges',
    'Attendant Bed Charges'
  ];

  // Nursing charge detail types
  const nursingChargeTypes = [
    'Nursing fees',
    'Dressing',
    'Nebulization',
    'Injection charges',
    'Infusion pump charges',
    'Aya Charges',
    'Blood Transfusion Charges'
  ];

  // Detail items for each sub-category (e.g., Room Charges details)
  const [roomChargeDetails, setRoomChargeDetails] = useState<Array<{
    id: number;
    type: string;
    days: string;
    tariffAmount: string;
    billAmount: string;
    deductions: string;
    discount: string;
  }>>([]);

  // Nursing charge details
  const [nursingChargeDetails, setNursingChargeDetails] = useState<Array<{
    id: number;
    type: string;
    days: string;
    tariffAmount: string;
    billAmount: string;
    deductions: string;
    discount: string;
  }>>([]);

  // Track which sub-category's details are expanded
  const [expandedSubCategoryDetails, setExpandedSubCategoryDetails] = useState<{[key: number]: boolean}>({});

  const handleEditRow = (index: number) => {
    // Toggle bill entry view for specific sub-category
    setExpandedBillEntries(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const handleSaveRow = (index: number) => {
    setEditingRowIndex(null);
  };

  const handleCancelEdit = () => {
    setEditingRowIndex(null);
  };

  // Helper function to generate search options
  const getSearchOptions = () => {
    const options: Array<{ value: string; label: string; level1: string; level2: string; level3: string }> = [];
    
    Object.entries(categoryHierarchy).forEach(([level1, level2Obj]) => {
      // Add L1 option
      options.push({
        value: `${level1}`,
        label: level1,
        level1,
        level2: "",
        level3: ""
      });
      
      Object.entries(level2Obj).forEach(([level2, level3Array]) => {
        // Add L2 option
        options.push({
          value: `${level1} -> ${level2}`,
          label: `${level1} -> ${level2}`,
          level1,
          level2,
          level3: ""
        });
        
        // Add L3 options
        level3Array.forEach((level3) => {
          options.push({
            value: `${level1} -> ${level2} -> ${level3}`,
            label: `${level1} -> ${level2} -> ${level3}`,
            level1,
            level2,
            level3
          });
        });
      });
    });
    
    return options;
  };

  const handleCategorySelect = (value: string) => {
    const option = getSearchOptions().find(opt => opt.value === value);
    if (!option) return;
    
    // Remove any existing temp entry first
    const filteredItems = selectedBillItems.filter(item => item.id !== 'temp');
    
    const currentDocument = documents[currentDocumentIndex];
    
    const newItem = {
      id: 'temp',
      fullPath: value,
      level1: option.level1,
      level2: option.level2,
      level3: option.level3,
      documentId: currentDocument.id,
      documentName: currentDocument.name,
      days: "",
      tariffAmount: "",
      billAmount: "",
      eligibleAmount: "",
      discount: "",
      payableAmount: ""
    };
    
    setSelectedBillItems([...filteredItems, newItem]);
    setCategorySearchOpen(false);
  };

  // Check if category is room-related
  const isRoomCategory = (item: any) => {
    const searchText = `${item.level1} ${item.level2} ${item.level3}`.toLowerCase();
    return searchText.includes('room') || searchText.includes('rent');
  };

  // Calculate auto-filled days between admission and discharge
  const getAutoCalculatedDays = () => {
    if (formData.admissionDate && formData.dischargeDate) {
      return differenceInDays(formData.dischargeDate, formData.admissionDate);
    }
    return 0;
  };

  // Calculate bill amount for a specific item
  const getAutoCalculatedBillAmount = (item: any) => {
    const days = parseFloat(item.days) || getAutoCalculatedDays();
    const tariff = parseFloat(item.tariffAmount) || 0;
    return days * tariff;
  };

  const handleBillItemChange = (id: string, field: string, value: string) => {
    setSelectedBillItems(items => items.map(item => {
      if (item.id !== id) return item;
      
      const updated = { ...item, [field]: value };
      
      // Auto-calculate billAmount when days or tariffAmount changes
      if (field === 'days' || field === 'tariffAmount') {
        const days = parseFloat(field === 'days' ? value : updated.days) || 0;
        const tariff = parseFloat(field === 'tariffAmount' ? value : updated.tariffAmount) || 0;
        updated.billAmount = (days * tariff).toString();
      }
      
      // Auto-calculate payableAmount
      const billAmt = parseFloat(updated.billAmount) || 0;
      const eligible = parseFloat(updated.eligibleAmount) || billAmt;
      const discount = parseFloat(updated.discount) || 0;
      updated.payableAmount = (eligible - discount).toString();
      
      return updated;
    }));
  };

  const handleDeleteBillItem = (id: string) => {
    setSelectedBillItems(items => items.filter(item => item.id !== id));
    const key = id;
    setExpandedBillEntries(prev => {
      const newObj = { ...prev };
      delete newObj[key as any];
      return newObj;
    });
  };

  const handleToggleBillEntry = (id: string) => {
    setExpandedBillEntries(prev => ({
      ...prev,
      [id as any]: !prev[id as any]
    }));
  };

  // Calculate bill summary from saved bill details
  const getBillSummary = (itemId: string) => {
    const billData = savedBillDetails[itemId];
    if (!billData) {
      return { totalDays: 0, totalRent: 0, totalBillAmount: 0, totalDeductions: 0, billAmountPostDeductions: 0 };
    }

    const totalDays = billData.bills.reduce((sum, bill) => sum + bill.days, 0);
    const totalRent = billData.bills.reduce((sum, bill) => sum + bill.rent, 0);
    const totalBillAmount = billData.bills.reduce((sum, bill) => sum + bill.amount, 0);
    const totalDeductions = billData.deductions?.reduce((sum, deduction) => sum + deduction.amount, 0) || 0;
    const billAmountPostDeductions = totalBillAmount - totalDeductions;

    return { totalDays, totalRent, totalBillAmount, totalDeductions, billAmountPostDeductions };
  };

  // Calculate eligible amount based on policy limit
  const getEligibleAmount = (itemId: string) => {
    const summary = getBillSummary(itemId);
    const billAmountPostDeductions = summary.billAmountPostDeductions;
    
    // Parse sum insured (remove ₹ and commas)
    const sumInsuredStr = formData.sumInsured.replace(/[₹,]/g, '');
    const policyCapping = parseFloat(sumInsuredStr) || 0;
    
    // Eligible is the lower of bill amount post deductions and policy capping
    const eligible = Math.min(billAmountPostDeductions, policyCapping);
    
    return {
      eligible,
      billAmountPostDeductions,
      policyCapping,
      reason: billAmountPostDeductions <= policyCapping 
        ? 'Bill amount is within policy limit' 
        : `Bill amount post deductions (₹${billAmountPostDeductions.toLocaleString()}) exceeds policy limit (₹${policyCapping.toLocaleString()})`
    };
  };

  const handleSaveBillEntry = (data: { bills: any[], deductions: any[] }) => {
    // In add mode, this handles intermediate saves
    // Add new entries to temp saved state
    setTempSavedBills(prev => [...prev, ...data.bills]);
    setTempSavedDeductions(prev => [...prev, ...data.deductions]);
  };

  const handleFinalSaveBillEntry = () => {
    // Get the current temp item (the one being edited)
    const tempItem = selectedBillItems.find(item => item.id === 'temp');
    if (!tempItem) return;

    // Flush any in-progress inputs from BillEntryExpandable
    const flushed = billEntryRef.current?.flushPending() ?? { bills: [], deductions: [] };

    // Combine with any previously temp-saved items
    const combinedBills = [...tempSavedBills, ...flushed.bills];
    const combinedDeductions = [...tempSavedDeductions, ...flushed.deductions];

    // Check if there's data to save
    if (combinedBills.length === 0 && combinedDeductions.length === 0) {
      toast({
        title: "No Data",
        description: "Please add at least one bill or deduction before saving.",
        variant: "destructive"
      });
      return;
    }

    // Create a new permanent entry with a unique ID
    const newId = `bill_${Date.now()}`;
    const newEntry = {
      ...tempItem,
      id: newId
    };

    // Save all bills and deductions to the new permanent entry
    setSavedBillDetails(prev => ({
      ...prev,
      [newId]: {
        bills: combinedBills,
        deductions: combinedDeductions
      }
    }));

    // Replace temp item with saved entry
    setSelectedBillItems(items => items.map(item => 
      item.id === 'temp' ? newEntry : item
    ));

    // Clear temp saved state
    setTempSavedBills([]);
    setTempSavedDeductions([]);

    toast({
      title: "Entry Saved",
      description: "Bill entry has been saved successfully and moved to Saved Entries."
    });
  };

  const handleUpdateSavedEntry = (itemId: string, data: { bills: any[], deductions: any[] }) => {
    // Add new bills and deductions to an already saved entry
    setSavedBillDetails(prev => {
      const existingData = prev[itemId] || { bills: [], deductions: [] };
      return {
        ...prev,
        [itemId]: {
          bills: [...existingData.bills, ...data.bills],
          deductions: [...existingData.deductions, ...data.deductions]
        }
      };
    });

    toast({
      title: "Entry Updated",
      description: "Bill and deduction entries have been added to this saved entry."
    });
  };
  
  const handleSubCategoryInputChange = (index: number, field: string, value: string) => {
    const updatedCategories = [...subCategories];
    updatedCategories[index] = {
      ...updatedCategories[index],
      [field]: value
    };
    
    // Calculate bill amount for Room Charges based on days * tariff amount
    if (updatedCategories[index].name === "Room Charges") {
      if (field === 'days' || field === 'tariffAmount') {
        const days = parseInt(updatedCategories[index].days || '1');
        const tariffAmount = parseInt(updatedCategories[index].tariffAmount || '0');
        const billAmount = days * tariffAmount;
        updatedCategories[index].billAmount = billAmount.toLocaleString();
        updatedCategories[index].payableAmount = billAmount.toLocaleString();
      }
    }
    
    setSubCategories(updatedCategories);
  };

  const handleAddRoomChargeDetail = () => {
    const newDetail = {
      id: roomChargeDetails.length,
      type: roomChargeTypes[0],
      days: '1',
      tariffAmount: '0',
      billAmount: '0',
      deductions: '0',
      discount: '0'
    };
    setRoomChargeDetails([...roomChargeDetails, newDetail]);
  };

  const handleRoomChargeDetailChange = (index: number, field: string, value: string) => {
    const updatedDetails = [...roomChargeDetails];
    updatedDetails[index] = {
      ...updatedDetails[index],
      [field]: value
    };
    
    // Calculate bill amount based on days * tariff amount
    if (field === 'days' || field === 'tariffAmount') {
      const days = parseInt(updatedDetails[index].days || '1');
      const tariffAmount = parseFloat(updatedDetails[index].tariffAmount.replace(/,/g, '') || '0');
      const billAmount = days * tariffAmount;
      updatedDetails[index].billAmount = billAmount.toLocaleString();
    }
    
    setRoomChargeDetails(updatedDetails);
  };

  const handleDeleteRoomChargeDetail = (index: number) => {
    setRoomChargeDetails(roomChargeDetails.filter((_, i) => i !== index));
  };

  const handleAddNursingChargeDetail = () => {
    const newDetail = {
      id: nursingChargeDetails.length,
      type: nursingChargeTypes[0],
      days: '1',
      tariffAmount: '0',
      billAmount: '0',
      deductions: '0',
      discount: '0'
    };
    setNursingChargeDetails([...nursingChargeDetails, newDetail]);
  };

  const handleNursingChargeDetailChange = (index: number, field: string, value: string) => {
    const updatedDetails = [...nursingChargeDetails];
    updatedDetails[index] = {
      ...updatedDetails[index],
      [field]: value
    };
    
    // Calculate bill amount based on days * tariff amount
    if (field === 'days' || field === 'tariffAmount') {
      const days = parseInt(updatedDetails[index].days || '1');
      const tariffAmount = parseFloat(updatedDetails[index].tariffAmount.replace(/,/g, '') || '0');
      const billAmount = days * tariffAmount;
      updatedDetails[index].billAmount = billAmount.toLocaleString();
    }
    
    setNursingChargeDetails(updatedDetails);
  };

  const handleDeleteNursingChargeDetail = (index: number) => {
    setNursingChargeDetails(nursingChargeDetails.filter((_, i) => i !== index));
  };

  const handleEditDetailRow = (index: number) => {
    setExpandedBillEntries(prev => ({
      ...prev,
      [`detail_${index}`]: !prev[`detail_${index}`]
    }));
  };

  const handleEditNursingDetailRow = (index: number) => {
    setExpandedBillEntries(prev => ({
      ...prev,
      [`nursing_detail_${index}`]: !prev[`nursing_detail_${index}`]
    }));
  };

  const handleSaveDetailRow = () => {
    setEditingDetailIndex(null);
  };

  const handleCancelDetailEdit = () => {
    setEditingDetailIndex(null);
  };

  const handleNewLineItemChange = (field: string, value: string) => {
    setNewLineItem(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAddLineItem = () => {
    // Here you would typically add the new line item to your data
    // For now, just close the modal and reset the form
    setAddLineItemOpen(false);
    setNewLineItem({
      category: '',
      tariffAmount: '',
      discount: '',
      billAmount: '',
      payableAmount: ''
    });
  };

  const handleCancelAddLineItem = () => {
    setAddLineItemOpen(false);
    setNewLineItem({
      category: '',
      tariffAmount: '',
      discount: '',
      billAmount: '',
      payableAmount: ''
    });
  };

  // Multiple policies data
  const [policiesData] = useState([
    {
      policyId: 'ACKO-HLTH-001234',
      planSelected: 'Individual Health',
      sumInsured: '₹5,00,000',
      remainingSI: '₹4,50,000',
      policyStart: '01 Jan 2025',
      policyEnd: '31 Dec 2025',
      deductible: 0,
      isActive: true
    },
    {
      policyId: 'ACKO-HLTH-001235',
      planSelected: 'Retail Health',
      sumInsured: '₹10,00,000',
      remainingSI: '₹9,50,000',
      policyStart: '15 Feb 2025',
      policyEnd: '14 Feb 2026',
      deductible: 0,
      isActive: true
    },
    {
      policyId: 'ACKO-HLTH-001236',
      planSelected: 'Group Health',
      sumInsured: '₹3,00,000',
      remainingSI: '₹2,80,000',
      policyStart: '01 Mar 2025',
      policyEnd: '28 Feb 2026',
      deductible: 0,
      isActive: true
    },
    {
      policyId: 'ACKO-STOP-001234',
      planSelected: 'Super top up',
      sumInsured: '₹20,00,000',
      remainingSI: '₹20,00,000',
      policyStart: '01 Jan 2025',
      policyEnd: '31 Dec 2025',
      deductible: 50000, // ₹50,000 deductible
      isActive: true
    }
  ]);

  // Calculate total claim amount from sub-categories
  const calculateTotalClaimAmount = () => {
    return subCategories.reduce((total, category) => {
      const payableAmount = parseFloat(category.payableAmount.replace(/,/g, '')) || 0;
      return total + payableAmount;
    }, 0); // Total from all line items
  };

  // Check if customer has super top up policy and should be nudged
  const shouldShowSuperTopUpNudge = () => {
    const totalClaimAmount = calculateTotalClaimAmount();
    const customerPolicies = policiesData.filter(policy => policy.isActive);
    const hasSuperTopUp = customerPolicies.some(policy => policy.planSelected === 'Super top up');
    const superTopUpPolicy = customerPolicies.find(policy => policy.planSelected === 'Super top up');
    
    if (hasSuperTopUp && superTopUpPolicy) {
      return totalClaimAmount > superTopUpPolicy.deductible;
    }
    return false;
  };

  // Get super top up policy details
  const getSuperTopUpPolicy = () => {
    return policiesData.find(policy => policy.planSelected === 'Super top up' && policy.isActive);
  };
  const [uhidData] = useState([
    {
      uhid: 'UHID001',
      name: 'Priya Sharma',
      age: '34 years',
      gender: 'Female',
      phone: '+91 98765 43210',
      email: 'priya.sharma@email.com'
    },
    {
      uhid: 'UHID002', 
      name: 'Rajesh Kumar',
      age: '28 years',
      gender: 'Male',
      phone: '+91 98765 43211',
      email: 'rajesh.kumar@email.com'
    },
    {
      uhid: 'UHID003',
      name: 'Anjali Patel', 
      age: '45 years',
      gender: 'Female',
      phone: '+91 98765 43212',
      email: 'anjali.patel@email.com'
    }
  ]);

  // Hospital data with associated details
  const [hospitalData, setHospitalData] = useState([
    {
      hospitalName: 'Apollo Hospital',
      hospitalLocation: 'Delhi',
      city: 'New Delhi',
      state: 'Delhi',
      pincode: '110076',
      networkType: 'Network',
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 11 2692 5858',
      hospitalAddress: 'Sarita Vihar, Delhi Mathura Road, New Delhi - 110076',
      isApproved: true
    },
    {
      hospitalName: 'Fortis Hospital',
      hospitalLocation: 'Gurgaon',
      city: 'Gurugram',
      state: 'Haryana',
      pincode: '122002',
      networkType: 'Network',
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 124 496 2200',
      hospitalAddress: 'Sector 44, Gurugram, Haryana - 122002',
      isApproved: true
    },
    {
      hospitalName: 'Max Healthcare',
      hospitalLocation: 'Noida',
      city: 'Noida',
      state: 'Uttar Pradesh',
      pincode: '201301',
      networkType: 'Network',
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 120 718 2000',
      hospitalAddress: 'B-22, Sector-62, Noida - 201301',
      isApproved: true
    },
    {
      hospitalName: 'AIIMS',
      hospitalLocation: 'Delhi',
      city: 'New Delhi',
      state: 'Delhi',
      pincode: '110029',
      networkType: 'Non-Network',
      networkStatus: 'non-network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 11 2658 8500',
      hospitalAddress: 'Ansari Nagar, New Delhi - 110029',
      isApproved: true
    },
    {
      hospitalName: 'Medanta Hospital',
      hospitalLocation: 'Gurgaon',
      city: 'Gurugram',
      state: 'Haryana',
      pincode: '122001',
      networkType: 'Network',
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 124 414 4444',
      hospitalAddress: 'Sector 38, Gurugram, Haryana - 122001',
      isApproved: true
    }
  ]);

  const [formData, setFormData] = useState({
    // Editable Claim Details
    claimType: 'Reimbursement',
    claimSubType: 'Hospitalisation (IPD)',
    mainClaimId: '', // For Pre-post claims
    requestType: 'Preauth Request', // Only used for Cashless claims
    opdSpecialty: '', // For Others (OPD) selection
    opdCategory: '', // For OPD claim sub type
    benefitType: '', // For GPA selection
    admissionDate: new Date('2025-03-25'),
    dischargeDate: new Date('2025-03-28'),
    claimAmount: '₹85,000',
    claimProgress: 75,
    // Policy Details
    policyId: 'ACKO-HLTH-001234',
    planSelected: 'Individual Health',
    sumInsured: '₹5,00,000',
    remainingSI: '₹4,50,000',
    policyStart: '01 Jan 2025',
    policyEnd: '31 Dec 2025',
    // Patient Details
    uhid: 'UHID001',
    customerName: 'Priya Sharma',
    customerAge: '34 years',
    customerGender: 'Female',
    riskStartDate: new Date('2025-01-01'),
    riskEndDate: new Date('2025-12-31'),
    customerPhone: '+91 98765 43210',
    customerEmail: 'priya.sharma@email.com',
    customerAddress: 'A-123, Sector 15, Noida, Uttar Pradesh - 201301',
    // Bank Account Details
    accountHolder: 'Priya Sharma',
    bankName: 'HDFC Bank',
    accountNo: '50200012345678',
    ifscCode: 'HDFC0001234',
    branch: 'Sector 18, Noida',
    upiId: 'priyasharma@hdfc',
    // Hospital Details
    hospitalName: 'Apollo Hospital',
    hospitalLocation: 'Delhi',
    networkType: 'Network',
    hospitalContact: '+91 11 2692 5858',
    treatingDoctor: 'Dr. Rajesh Patel',
    hospitalAddress: 'Sarita Vihar, Delhi Mathura Road, New Delhi - 110076',
    // Treatment Details
    primaryDiagnosis: 'Coronary Artery Disease',
    icdCode: 'I25.9',
    treatmentType: 'Surgical',
    roomType: 'Private AC',
    lengthOfStay: '3 days',
    emergency: 'Yes',
    procedures: 'Cardiac Catheterization, Angioplasty, Stent Placement'
  });

  // Hospital management functions
  const handleHospitalSearch = (searchTerm: string) => {
    setHospitalSearchTerm(searchTerm);
    const found = hospitalData.some(hospital => 
      hospital.hospitalName.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setShowHospitalNotFound(searchTerm.length > 2 && !found);
  };

  const addNewHospital = () => {
    // Combine address fields
    const fullAddress = `${newHospitalData.hospitalAddress}, ${newHospitalData.city}, ${newHospitalData.state} - ${newHospitalData.pincode}`;
    
    const newHospital = {
      hospitalName: newHospitalData.hospitalName,
      hospitalAddress: fullAddress,
      hospitalLocation: newHospitalData.hospitalLocation || '',
      city: newHospitalData.city,
      state: newHospitalData.state,
      pincode: newHospitalData.pincode,
      networkType: newHospitalData.networkType,
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: newHospitalData.hospitalContact || '',
      isApproved: false
    };
    
    // Add to hospital data
    setHospitalData(prev => [...prev, newHospital]);
    
    // Add to selected hospitals  
    if (editingHospitalIndex !== null) {
      const updatedHospitals = [...selectedHospitals];
      updatedHospitals[editingHospitalIndex] = newHospital;
      setSelectedHospitals(updatedHospitals);
    } else {
      setSelectedHospitals(prev => [...prev, newHospital]);
    }
    
    // Reset form
    setNewHospitalData({
      hospitalName: '',
      hospitalLocation: '',
      networkType: 'Network',
      hospitalContact: '',
      hospitalAddress: '',
      city: '',
      state: '',
      pincode: '',
      rohini: ''
    });
    setIsAddHospitalDialogOpen(false);
    setEditingHospitalIndex(null);
    setIsAddingHospital(false);
    setHospitalSearchTerm('');
    setShowHospitalNotFound(false);
    
    // Show success toast
    toast({
      title: "Request Sent for Approval",
      description: "The hospital addition request has been sent to the provider team for approval.",
    });
  };

  const addExistingHospital = (hospital: any) => {
    const exists = selectedHospitals.some(h => h.hospitalName === hospital.hospitalName);
    if (!exists) {
      setSelectedHospitals(prev => [...prev, hospital]);
    }
    setIsAddingHospital(false);
    setHospitalSearchTerm('');
    setShowHospitalNotFound(false);
  };

  const removeHospital = (hospitalName: string) => {
    setSelectedHospitals(prev => prev.filter(h => h.hospitalName !== hospitalName));
  };

  const handleSave = () => {
    // Here you would typically save to backend
    setIsEditing(false);
    console.log('Saving form data:', formData);
  };

  const handleCancel = () => {
    setIsEditing(false);
    // Reset form data if needed
  };

  // Patient & Policy Modal handlers
  const handleOpenPatientPolicyModal = () => {
    setSelectedPolicy(null);
    setSelectedMember(null);
    setIsPatientPolicyModalOpen(true);
  };

  const handlePatientIdentificationNext = (data: any) => {
    // Update formData with the selected policy and member information
    if (data.policy && data.member) {
      setFormData(prev => ({
        ...prev,
        customerName: data.member.name || prev.customerName,
        uhid: data.member.uhid || prev.uhid,
        policyId: data.policy.policyNumber || prev.policyId,
        planSelected: data.policy.policyType || prev.planSelected,
        sumInsured: data.policy.sumInsured || prev.sumInsured
      }));
    }
    
    // Close modal and reset
    setIsPatientPolicyModalOpen(false);
    setSelectedPolicy(null);
    setSelectedMember(null);
    
    toast({
      title: "Claim Updated",
      description: "Patient and policy details have been updated successfully.",
    });
  };

  const handleModalClose = () => {
    setIsPatientPolicyModalOpen(false);
    setSelectedPolicy(null);
    setSelectedMember(null);
    setIsCreatingExtension(false);
    setShowBackToLookup(false);
  };

  const handleBackToLookupClick = () => {
    setShowBackToLookup(false);
    setIsCreatingExtension(false);
  };

  const handleInputChange = (field: string, value: string | number | Date) => {
    setFormData(prev => {
      const newData = {
        ...prev,
        [field]: value
      };
      
      // Reset claim sub type when claim type changes
      if (field === 'claimType') {
        const subTypeOptions = getClaimSubTypeOptions(value as string);
        newData.claimSubType = subTypeOptions[0];
        newData.opdSpecialty = ''; // Reset OPD specialty
        newData.opdCategory = ''; // Reset OPD category
      }
      
      // Reset OPD specialty when claim sub type changes and it's not Others (OPD)
      if (field === 'claimSubType' && value !== 'Others (OPD)') {
        newData.opdSpecialty = '';
      }
      
      // Reset OPD category when claim sub type changes and it's not OPD
      if (field === 'claimSubType' && value !== 'OPD') {
        newData.opdCategory = '';
      }
      
      // Reset Benefit type when claim sub type changes and it's not GPA
      if (field === 'claimSubType' && value !== 'GPA') {
        newData.benefitType = '';
      }
      
      // Update patient details when UHID changes
      if (field === 'uhid') {
        const selectedPatient = uhidData.find(patient => patient.uhid === value);
        if (selectedPatient) {
          newData.customerName = selectedPatient.name;
          newData.customerAge = selectedPatient.age;
          newData.customerGender = selectedPatient.gender;
          newData.customerPhone = selectedPatient.phone;
          newData.customerEmail = selectedPatient.email;
        }
      }
      
      // Update policy details when policy ID or plan changes
      if (field === 'policyId') {
        const selectedPolicy = policiesData.find(policy => policy.policyId === value);
        if (selectedPolicy) {
          newData.planSelected = selectedPolicy.planSelected;
          newData.sumInsured = selectedPolicy.sumInsured;
          newData.remainingSI = selectedPolicy.remainingSI;
          newData.policyStart = selectedPolicy.policyStart;
          newData.policyEnd = selectedPolicy.policyEnd;
        }
      }
      
      if (field === 'planSelected') {
        const selectedPolicy = policiesData.find(policy => policy.planSelected === value);
        if (selectedPolicy) {
          newData.policyId = selectedPolicy.policyId;
          newData.sumInsured = selectedPolicy.sumInsured;
          newData.remainingSI = selectedPolicy.remainingSI;
          newData.policyStart = selectedPolicy.policyStart;
          newData.policyEnd = selectedPolicy.policyEnd;
        }
      }

      // Update hospital details when hospital is selected
      if (field === 'hospitalName') {
        const selectedHospital = hospitalData.find(hospital => hospital.hospitalName === value);
        if (selectedHospital) {
          newData.hospitalLocation = selectedHospital.hospitalLocation;
          newData.networkType = selectedHospital.networkType;
          newData.hospitalContact = selectedHospital.hospitalContact;
          newData.hospitalAddress = selectedHospital.hospitalAddress;
        }
      }
      
      return newData;
    });
  };

  const getClaimSubTypeOptions = (claimType: string) => {
    if (claimType === 'Reimbursement') {
      return [
        'Hospitalisation (IPD)',
        'Day care (IPD)', 
        'Doctor consultation & Medicines (OPD)',
        'Lab tests (OPD)',
        'Pre-post hospitalisation',
        'Domiciliary treatment',
        'Others (OPD)',
        'GPA'
      ];
    } else if (claimType === 'Cashless') {
      return [
        'Hospitalisation (IPD)',
        'Day care (IPD)'
      ];
    }
    return [];
  };

  // Get available claim IDs for main claim dropdown (settled or in progress claims)
  const getAvailableClaimIds = () => {
    // Mock data for claim IDs that are settled or in progress
    return [
      'CLM2024001234',
      'CLM2024001235', 
      'CLM2024001236',
      'CLM2024001237',
      'CLM2024001238'
    ];
  };

  const handlePreviousDocument = () => {
    const newIndex = currentDocumentIndex > 0 ? currentDocumentIndex - 1 : documents.length - 1;
    setCurrentDocumentIndex(newIndex);
    setSelectedDocument(newIndex.toString());
    setDocumentRotation(0); // Reset rotation when changing documents
  };

  const handleNextDocument = () => {
    const newIndex = currentDocumentIndex < documents.length - 1 ? currentDocumentIndex + 1 : 0;
    setCurrentDocumentIndex(newIndex);
    setSelectedDocument(newIndex.toString());
    setDocumentRotation(0); // Reset rotation when changing documents
  };

  // Handle opening document in new tab
  const handleOpenInNewTab = () => {
    const currentDoc = documents[currentDocumentIndex];
    if (currentDoc) {
      // In a real app, this would be the actual document URL
      const documentUrl = `/documents/${currentDoc.id}/${currentDoc.name}`;
      window.open(documentUrl, '_blank');
    }
  };

  // Handle document selection from dropdown
  const handleDocumentSelect = (value: string) => {
    setSelectedDocument(value);
    if (value === 'merged_document') {
      // Handle merged document view - could set a special index or flag
      setCurrentDocumentIndex(0); // For now, just show first document
    } else {
      const docIndex = parseInt(value);
      setCurrentDocumentIndex(docIndex);
      setPreviewDocumentIndex(docIndex);
      setIsDocumentPreviewOpen(true);
    }
  };

  // Function to generate system recommendations based on document analysis
  const generateSystemRecommendation = (category: string, readability: boolean, suspicious: boolean, irrelevant: boolean) => {
    if (irrelevant) {
      return 'Document marked as irrelevant to this claim. May be excluded from processing.';
    }
    if (suspicious) {
      return 'Document flagged as suspicious. Recommend thorough review and verification before approval.';
    }
    if (!readability) {
      return 'Document readability is poor. Request clearer version or additional documentation.';
    }
    
    switch (category) {
      case 'Prescription':
        return 'Prescription is clear and readable. Verify doctor credentials and date validity.';
      case 'Medicine Bills':
        return 'Medicine bill is clear. Cross-verify with prescription and pricing standards.';
      case 'Lab Reports':
        return 'Lab results are clear and within acceptable ranges. Safe to approve.';
      case 'Discharge Summary':
        return 'Discharge summary is complete with all required medical information. Recommend approval.';
      case 'ID Proof':
        return 'ID proof is clear and valid. Identity verification complete.';
      default:
        return 'Document analysis complete. Please review manually for final approval.';
    }
  };

  // Handle document field updates
  const handleDocumentFieldUpdate = (field: string, value: any) => {
    const updatedDocuments = [...documents];
    updatedDocuments[currentDocumentIndex] = {
      ...updatedDocuments[currentDocumentIndex],
      [field]: value
    };
    
    // Update system recommendation when any field changes
    const currentDoc = updatedDocuments[currentDocumentIndex];
    updatedDocuments[currentDocumentIndex].systemRecommendation = generateSystemRecommendation(
      currentDoc.category,
      currentDoc.readability,
      currentDoc.suspicious,
      currentDoc.irrelevant
    );
    
    setDocuments(updatedDocuments);
    
    // Auto-update document tagging checklist when category is set
    if (field === 'category') {
      const allDocumentsTagged = updatedDocuments.every(doc => doc.category && doc.category.trim() !== '');
      if (allDocumentsTagged) {
        setChecklist(prev => ({
          ...prev,
          documentTagging: true
        }));
      }
    }
  };

  // Handle checklist item toggle
  const toggleChecklistItem = (item: string) => {
    setChecklist(prev => ({
      ...prev,
      [item]: !prev[item]
    }));
  };

  const currentDocument = documents[currentDocumentIndex];

  // Zoom handlers
  const handleZoomIn = () => {
    setDocumentZoom(prev => Math.min(prev + 25, 200));
  };

  const handleZoomOut = () => {
    setDocumentZoom(prev => Math.max(prev - 25, 50));
  };

  const handleZoomReset = () => {
    setDocumentZoom(100);
  };

  const handleDocumentRotate = () => {
    setDocumentRotation(prev => (prev + 90) % 360);
  };

  const handleSaveDraft = () => {
    // Save draft logic here
    setLastSavedTime(new Date());
    toast({
      title: "Draft saved",
      description: "Your changes have been saved successfully.",
    });
  };

  return (
    <div className="h-screen overflow-hidden bg-background flex flex-col">
      {/* Header */}
      <header className="border-b bg-card shadow-sm">
        <div className="flex h-16 items-center px-6">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-semibold">Claim #{claimId}</h1>
            {lastSavedTime && (
              <span className="text-sm text-muted-foreground">
                Last saved at {format(lastSavedTime, 'HH:mm:ss')} {format(lastSavedTime, 'dd MMM yyyy')}
              </span>
            )}
          </div>
          
          {/* Minimized Section Card - Stage 2 */}
          {workflowStage === 'billEntry' && (
            <Button 
              variant="outline" 
              className="ml-6 h-auto py-2 hover:bg-muted/50"
              onClick={() => setWorkflowStage('review')}
            >
              <div className="flex items-center gap-4 text-xs">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-primary flex-shrink-0" />
                  <div className="text-left">
                    <div className="font-medium">Priya Sharma</div>
                    <div className="text-muted-foreground">POL1234567</div>
                  </div>
                </div>
                
                <div className="h-8 w-px bg-border" />
                
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-primary flex-shrink-0" />
                  <div className="text-left">
                    <div className="font-medium">Cashless</div>
                    <div className="text-muted-foreground">28/03/2025</div>
                  </div>
                </div>
                
                <div className="h-8 w-px bg-border" />
                
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-primary flex-shrink-0" />
                  <div className="text-left">
                    <div className="font-medium">Apollo Hospital</div>
                    <div className="text-muted-foreground">Network</div>
                  </div>
                </div>
                
                <div className="h-8 w-px bg-border" />
                
                <div className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-primary flex-shrink-0" />
                  <div className="text-left">
                    <div className="font-medium">Bank Details</div>
                    <div className="text-muted-foreground">****5678</div>
                  </div>
                </div>
              </div>
            </Button>
          )}
          
          <div className="ml-auto flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setIsRaiseQueryDialogOpen(true)}
            >
              <Flag className="h-4 w-4 mr-2" />
              Raise Query
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleSaveDraft}
            >
              <Save className="h-4 w-4 mr-2" />
              Save Draft
            </Button>
            <Link 
              to="/past-claims" 
              className="text-primary hover:underline font-medium text-sm flex items-center space-x-1"
            >
              <Receipt className="h-4 w-4" />
              <span>Past claim details</span>
            </Link>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setIsKeyboardShortcutsOpen(true)}
              title="Keyboard shortcuts"
            >
              <Keyboard className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Split Screen Layout with Resizable Panels */}
      <ResizablePanelGroup direction="horizontal" className="flex-1 min-h-0 overflow-hidden">
        {/* Left Side: Document Viewer */}
        <ResizablePanel defaultSize={60} minSize={40} className="bg-card overflow-hidden min-h-0 min-w-0">
          <ScrollArea className="h-full">
            <div className="p-4 border-b sticky top-0 z-10 bg-card">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <h2 className="text-lg font-semibold">Document Review</h2>
                <div className="flex items-center gap-2 flex-wrap">
                  {/* Download Documents Button */}
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setIsDownloadDialogOpen(true)}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                  
                  {/* Document Selection Dropdown */}
                  <Select value={selectedDocument} onValueChange={handleDocumentSelect}>
                    <SelectTrigger className="w-[200px]">
                      <SelectValue placeholder="Select document to review" />
                    </SelectTrigger>
                    <SelectContent>
                      {documents.map((doc, index) => (
                        <SelectItem key={index} value={index.toString()}>
                          {doc.name}
                        </SelectItem>
                      ))}
                      <SelectItem value="merged_document">
                        📄 Merged Document View
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="flex items-center gap-1 border rounded-md p-1">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handleZoomOut}
                      disabled={documentZoom <= 50}
                    >
                      <ZoomOut className="h-3 w-3" />
                    </Button>
                    <span className="text-xs text-muted-foreground px-2 min-w-[3rem] text-center">
                      {documentZoom}%
                    </span>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handleZoomIn}
                      disabled={documentZoom >= 200}
                    >
                      <ZoomIn className="h-3 w-3" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handleZoomReset}
                    >
                      <RotateCcw className="h-3 w-3" />
                    </Button>
                  </div>
                  
                  {/* Document Rotation */}
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleDocumentRotate}
                  >
                    <RotateCw className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setDocumentOverlayOpen(true)}
                  >
                    <Maximize2 className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleOpenInNewTab}
                    title="Open in new tab"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                  {/* View Policy Document Button */}
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => window.open('/policy-document', '_blank')}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Policy Document
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Document Display */}
              <div className="p-4">
                <div className="relative flex items-center">
                  {/* Left Navigation Arrow */}
                  <Button 
                    variant="outline" 
                    size="icon"
                    className="absolute left-2 z-10 h-10 w-10 rounded-full bg-background/80 hover:bg-background shadow-md"
                    onClick={handlePreviousDocument}
                    disabled={documents.length <= 1}
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                  
                  <div className={`flex-1 border-2 border-dashed border-muted-foreground/30 rounded-lg flex items-center justify-center bg-muted/20`} 
                       style={{ height: `${previewHeight}px` }}>
                    <div className="text-center space-y-4" style={{ transform: `scale(${documentZoom / 100})` }}>
                      <div className="bg-background/80 rounded-full p-6 mx-auto w-fit">
                        <currentDocument.icon className="h-16 w-16 text-muted-foreground" />
                      </div>
                      <div className="space-y-2">
                        <p className="font-medium text-foreground text-lg">
                          {currentDocument.name}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {currentDocument.type} • {currentDocument.size} • {currentDocument.uploadDate}
                        </p>
                        <p className="text-sm text-muted-foreground max-w-md">
                          {currentDocument.content}
                        </p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                  
                  {/* Right Navigation Arrow */}
                  <Button 
                    variant="outline" 
                    size="icon"
                    className="absolute right-2 z-10 h-10 w-10 rounded-full bg-background/80 hover:bg-background shadow-md"
                    onClick={handleNextDocument}
                    disabled={documents.length <= 1}
                  >
                    <ChevronRight className="h-5 w-5" />
                  </Button>
                </div>
              </div>
              
              {/* Document Analysis Panel */}
              <div className="p-4 border-t bg-muted/20">
            <h4 className="font-medium text-sm mb-4">Document Analysis</h4>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Category</label>
                <div className="mt-1">
                  <Select 
                    value={currentDocument.category} 
                    onValueChange={(value) => handleDocumentFieldUpdate('category', value)}
                  >
                    <SelectTrigger className="w-full h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {documentCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
            </div>
            
            <div className="space-y-4 mb-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Readability</label>
                <div className="mt-1 flex items-center gap-2">
                  <Switch
                    checked={!currentDocument.readability}
                    onCheckedChange={(checked) => handleDocumentFieldUpdate('readability', !checked)}
                  />
                  <Badge variant={!currentDocument.readability ? 'destructive' : 'success'} className="text-xs">
                    {!currentDocument.readability ? 'Unreadable' : 'Readable'}
                  </Badge>
                </div>
                {!currentDocument.readability && (
                  <div className="mt-3">
                    <Select 
                      value={currentDocument.unreadableReason || ''} 
                      onValueChange={(value) => handleDocumentFieldUpdate('unreadableReason', value)}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select reason" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="entire-unreadable">Entire document is unreadable</SelectItem>
                        <SelectItem value="some-pages-unreadable">Some pages are not readable</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div>
                <label className="text-sm font-medium text-muted-foreground">Suspicion</label>
                <div className="mt-1 flex items-center gap-2">
                  <Switch
                    checked={currentDocument.suspicious}
                    onCheckedChange={(checked) => handleDocumentFieldUpdate('suspicious', checked)}
                  />
                  <Badge variant={currentDocument.suspicious ? 'destructive' : 'success'} className="text-xs">
                    {currentDocument.suspicious ? 'Suspicious' : 'Clear'}
                  </Badge>
                </div>
                {currentDocument.suspicious && (
                  <div className="mt-3">
                    <Select 
                      value={currentDocument.suspiciousReason || ''} 
                      onValueChange={(value) => handleDocumentFieldUpdate('suspiciousReason', value)}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select reason" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="document-edited">Document is edited</SelectItem>
                        <SelectItem value="past-claim-reused">Past claim document reused</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div>
                <label className="text-sm font-medium text-muted-foreground">Relevancy</label>
                <div className="mt-1 flex items-center gap-2">
                  <Switch
                    checked={currentDocument.irrelevant}
                    onCheckedChange={(checked) => handleDocumentFieldUpdate('irrelevant', checked)}
                  />
                  <Badge variant={currentDocument.irrelevant ? 'destructive' : 'success'} className="text-xs">
                    {currentDocument.irrelevant ? 'Irrelevant' : 'Relevant'}
                  </Badge>
                </div>
                {currentDocument.irrelevant && (
                  <div className="mt-3">
                    <Select 
                      value={currentDocument.irrelevantReason || ''} 
                      onValueChange={(value) => handleDocumentFieldUpdate('irrelevantReason', value)}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select reason" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="unrelated-document">Unrelated document e.g. random picture</SelectItem>
                        <SelectItem value="bill-not-needed">Bill entry not needed (Payment receipt, KYC, discharge summary, prescription etc.)</SelectItem>
                        <SelectItem value="name-not-matching">Bill is for some other person (Name not matching)</SelectItem>
                        <SelectItem value="claim-not-matching">Bill is for some other claim (Bill date/ number/details are not matching)</SelectItem>
                        <SelectItem value="duplicate">Duplicate document</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
              
              <div>
                <label className="text-sm font-medium text-muted-foreground">Completeness</label>
                <div className="mt-1 flex items-center gap-2">
                  <Switch
                    checked={!currentDocument.isComplete}
                    onCheckedChange={(checked) => handleDocumentFieldUpdate('isComplete', !checked)}
                  />
                  <Badge variant={!currentDocument.isComplete ? 'destructive' : 'success'} className="text-xs">
                    {!currentDocument.isComplete ? 'Missing' : 'Complete'}
                  </Badge>
                </div>
                {!currentDocument.isComplete && (
                  <div className="mt-3">
                    <Select 
                      value={currentDocument.missingReason || ''} 
                      onValueChange={(value) => handleDocumentFieldUpdate('missingReason', value)}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select reason" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pages-missing">Few pages are missing</SelectItem>
                        <SelectItem value="info-missing">Information (e.g. signature/ stamp/ hospital/doctor name) is missing</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </div>
            
            <div className="mb-4">
              <label className="text-sm font-medium text-muted-foreground">System Recommendation</label>
              <div className="mt-1 p-3 bg-background rounded-md border">
                <div className="flex items-start gap-2">
                  <Info className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                  <p className="text-sm">{currentDocument.systemRecommendation}</p>
                </div>
              </div>
            </div>
            
            <div>
              <label className="text-sm font-medium text-muted-foreground">Agent Notes</label>
              <div className="mt-1 space-y-2">
                <Textarea
                  placeholder="Add notes about this document..."
                  value={isEditingNotes ? tempNotes : currentDocument.agentNotes}
                  onChange={(e) => {
                    if (!isEditingNotes) {
                      setIsEditingNotes(true);
                      setOriginalNotes(currentDocument.agentNotes || '');
                      setTempNotes(e.target.value);
                    } else {
                      setTempNotes(e.target.value);
                    }
                  }}
                  className="min-h-[80px] text-sm"
                />
                {isEditingNotes && (
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => {
                        handleDocumentFieldUpdate('agentNotes', tempNotes);
                        setIsEditingNotes(false);
                        setOriginalNotes('');
                        setTempNotes('');
                      }}
                      className="flex-1"
                    >
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Save
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setTempNotes('');
                        setIsEditingNotes(false);
                        setOriginalNotes('');
                      }}
                      className="flex-1"
                    >
                      <X className="h-4 w-4 mr-1" />
                      Cancel
                    </Button>
                  </div>
                )}
               </div>
            </div>
            
            </div>
            </ScrollArea>
            
            {/* Resize Handle */}
            <div 
              className={`h-2 bg-border hover:bg-primary/50 cursor-row-resize flex items-center justify-center group transition-colors ${isResizing ? 'bg-primary' : ''}`}
              onMouseDown={(e) => {
                e.preventDefault();
                setIsResizing(true);
                
                const startY = e.clientY;
                const startHeight = previewHeight;
                
                const handleMouseMove = (e: MouseEvent) => {
                  const deltaY = e.clientY - startY;
                  const newHeight = Math.max(200, Math.min(800, startHeight + deltaY));
                  setPreviewHeight(newHeight);
                };
                
                const handleMouseUp = () => {
                  setIsResizing(false);
                  document.removeEventListener('mousemove', handleMouseMove);
                  document.removeEventListener('mouseup', handleMouseUp);
                };
                
                document.addEventListener('mousemove', handleMouseMove);
                document.addEventListener('mouseup', handleMouseUp);
              }}
            >
              <div className="w-8 h-1 bg-muted-foreground/30 rounded-full group-hover:bg-primary/70 transition-colors" />
            </div>
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* Right Side: Claim Information Panels */}
        <ResizablePanel defaultSize={40} minSize={30} className="bg-muted/10 h-full overflow-hidden min-h-0 min-w-0">
           <ScrollArea className="h-full">
              <div className="p-4 pb-8 space-y-4 min-h-full">


              {/* Step-based Review Wizard */}
              {workflowStage === 'review' && (
                <div className="space-y-4">
                  {/* Step 1: Patient & Policy Details */}
                  {reviewStep === 1 && (
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Button variant="outline" className="flex-1 justify-start cursor-default hover:bg-background">
                          <div className="flex items-center space-x-2">
                            <User className="h-4 w-4 text-primary" />
                            <span className="font-medium">Patient & Policy Details</span>
                          </div>
                        </Button>
                        <Button variant="outline" size="sm" onClick={handleOpenPatientPolicyModal} className="flex-shrink-0">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="space-y-3">
                        {/* Super Top Up Policy Nudge */}
                        {shouldShowSuperTopUpNudge() && (
                          <Alert className="bg-amber-50 border-amber-200">
                            <AlertCircle className="h-4 w-4 text-amber-600" />
                            <AlertDescription>
                              <div className="flex items-start justify-between">
                                <div>
                                  <p className="font-medium text-amber-800 mb-1">Super Top Up Policy Available</p>
                                  <p className="text-sm text-amber-700 mb-2">
                                    Claim amount (₹{calculateTotalClaimAmount().toLocaleString()}) exceeds the deductible amount 
                                    (₹{getSuperTopUpPolicy()?.deductible.toLocaleString()}) for the Super Top Up policy.
                                  </p>
                                  <p className="text-sm text-amber-700">
                                    <strong>Recommendation:</strong> Consider utilizing the Super Top Up policy 
                                    ({getSuperTopUpPolicy()?.policyId}) in addition to the base policy for better coverage.
                                  </p>
                                </div>
                              </div>
                            </AlertDescription>
                          </Alert>
                        )}
                        
                        {/* Policy Overview */}
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium">Policy Overview</CardTitle>
                          </CardHeader>
                          <CardContent className="p-4 space-y-3 text-sm">
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Policy No:</span>
                              {isPatientEditing ? (
                                <Select value={formData.policyId} onValueChange={value => handleInputChange('policyId', value)}>
                                  <SelectTrigger className="w-40 h-8">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {policiesData.map(policy => (
                                      <SelectItem key={policy.policyId} value={policy.policyId}>{policy.policyId}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              ) : (
                                <span className="font-medium">{formData.policyId}</span>
                              )}
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">SI:</span>
                              <span className="font-medium">{formData.sumInsured}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Plan Name:</span>
                              {isPatientEditing ? (
                                <Select value={formData.planSelected} onValueChange={value => handleInputChange('planSelected', value)}>
                                  <SelectTrigger className="w-40 h-8">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Individual Health">Individual Health</SelectItem>
                                    <SelectItem value="Retail Health">Retail Health</SelectItem>
                                    <SelectItem value="Group Health">Group Health</SelectItem>
                                    <SelectItem value="Super top up">Super top up</SelectItem>
                                    <SelectItem value="Arogya Sanjeevani">Arogya Sanjeevani</SelectItem>
                                  </SelectContent>
                                </Select>
                              ) : (
                                <span className="font-medium">{formData.planSelected}</span>
                              )}
                            </div>
                          </CardContent>
                        </Card>

                        {/* Policyholder Details */}
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium">Policyholder Details</CardTitle>
                          </CardHeader>
                          <CardContent className="p-4 space-y-3 text-sm">
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Name:</span>
                              <span className="font-medium">{formData.customerName}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Email:</span>
                              <span className="font-medium">{formData.customerEmail}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Phone:</span>
                              <span className="font-medium">{formData.customerPhone}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Start Date:</span>
                              <span className="font-medium">{formData.policyStart}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">End Date:</span>
                              <span className="font-medium">{formData.policyEnd}</span>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Patient Details */}
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium">Patient Details</CardTitle>
                          </CardHeader>
                          <CardContent className="p-4 space-y-3 text-sm">
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Name:</span>
                              <span className="font-medium">{formData.customerName}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">UHID:</span>
                              <span className="font-medium">{formData.uhid}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Risk Start Date:</span>
                              <span className="font-medium">{formData.riskStartDate instanceof Date ? format(formData.riskStartDate, 'dd MMM yyyy') : formData.riskStartDate}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Risk End Date:</span>
                              <span className="font-medium">{formData.riskEndDate instanceof Date ? format(formData.riskEndDate, 'dd MMM yyyy') : formData.riskEndDate}</span>
                            </div>
                          </CardContent>
                        </Card>
                      </div>

                      {/* Navigation */}
                      <div className="flex justify-end pt-4">
                        <Button onClick={() => setReviewStep(2)} className="px-8">
                          Next
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Step 2: Claim Details */}
                  {reviewStep === 2 && (
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Button variant="outline" className="flex-1 justify-start cursor-default hover:bg-background">
                          <div className="flex items-center space-x-2">
                            <FileText className="h-4 w-4 text-primary" />
                            <span className="font-medium">Claim Details</span>
                          </div>
                        </Button>
                        {!isEditing ? (
                          <Button variant="outline" size="sm" onClick={() => setIsEditing(true)} className="flex-shrink-0">
                            <Edit className="h-4 w-4" />
                          </Button>
                        ) : (
                          <div className="flex items-center space-x-1">
                            <Button variant="outline" size="sm" onClick={handleSave} className="flex-shrink-0">
                              <Save className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={handleCancel} className="flex-shrink-0">
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>

                      <Card>
                        <CardContent className="p-4 space-y-3 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Claim ID:</span>
                            <span className="font-medium">HLTHCR8472</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Claim Type:</span>
                            {isEditing ? (
                              <Select value={formData.claimType} onValueChange={value => handleInputChange('claimType', value)}>
                                <SelectTrigger className="w-32 h-8">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Reimbursement">Reimbursement</SelectItem>
                                  <SelectItem value="Cashless">Cashless</SelectItem>
                                </SelectContent>
                              </Select>
                            ) : (
                              <span className="font-medium">{formData.claimType}</span>
                            )}
                          </div>
                          
                          {formData.claimType === 'Cashless' && (
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Request Type:</span>
                              {isEditing ? (
                                <Select value={formData.requestType} onValueChange={value => handleInputChange('requestType', value)}>
                                  <SelectTrigger className="w-40 h-8">
                                    <SelectValue placeholder="Select type" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Preauth Initial">Preauth Initial</SelectItem>
                                    <SelectItem value="Enhancement">Enhancement</SelectItem>
                                    <SelectItem value="Final">Final</SelectItem>
                                  </SelectContent>
                                </Select>
                              ) : (
                                <span className="font-medium">{formData.requestType}</span>
                              )}
                            </div>
                          )}
                          
                          <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Claim Sub Type:</span>
                            {isEditing ? (
                              <Select value={formData.claimSubType} onValueChange={value => handleInputChange('claimSubType', value)}>
                                <SelectTrigger className="w-32 h-8">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {getClaimSubTypeOptions(formData.claimType).map(option => (
                                    <SelectItem key={option} value={option}>{option}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            ) : (
                              <span className="font-medium">{formData.claimSubType}</span>
                            )}
                          </div>
                          
                          {formData.claimSubType === 'OPD' && (
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Category:</span>
                              {isEditing ? (
                                <Select value={formData.opdCategory} onValueChange={value => handleInputChange('opdCategory', value)}>
                                  <SelectTrigger className="w-32 h-8">
                                    <SelectValue placeholder="Select category" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Natal">Natal</SelectItem>
                                    <SelectItem value="Psychiatry">Psychiatry</SelectItem>
                                    <SelectItem value="Infertility">Infertility</SelectItem>
                                    <SelectItem value="Accidental">Accidental</SelectItem>
                                    <SelectItem value="Vision">Vision</SelectItem>
                                    <SelectItem value="Dental">Dental</SelectItem>
                                    <SelectItem value="Autism">Autism</SelectItem>
                                    <SelectItem value="Ayush">Ayush</SelectItem>
                                  </SelectContent>
                                </Select>
                              ) : (
                                <span className="font-medium">{formData.opdCategory || '-'}</span>
                              )}
                            </div>
                          )}
                          
                          {formData.claimSubType === 'Others (OPD)' && (
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">OPD Specialty:</span>
                              {isEditing ? (
                                <Select value={formData.opdSpecialty} onValueChange={value => handleInputChange('opdSpecialty', value)}>
                                  <SelectTrigger className="w-32 h-8">
                                    <SelectValue placeholder="Select specialty" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="dental">Dental</SelectItem>
                                    <SelectItem value="eye/vision">Eye/Vision</SelectItem>
                                    <SelectItem value="ante/post natal">Ante/Post Natal</SelectItem>
                                    <SelectItem value="vaccination">Vaccination</SelectItem>
                                    <SelectItem value="mental illness">Mental Illness</SelectItem>
                                    <SelectItem value="infertility">Infertility</SelectItem>
                                    <SelectItem value="physiotherapy">Physiotherapy</SelectItem>
                                    <SelectItem value="autism">Autism</SelectItem>
                                    <SelectItem value="oral chemo">Oral Chemo</SelectItem>
                                    <SelectItem value="ayush">Ayush</SelectItem>
                                    <SelectItem value="animal bite">Animal Bite</SelectItem>
                                  </SelectContent>
                                </Select>
                              ) : (
                                <span className="font-medium">{formData.opdSpecialty}</span>
                              )}
                            </div>
                          )}
                          
                          {formData.claimSubType === 'GPA' && (
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Benefit Type:</span>
                              {isEditing ? (
                                <Select value={formData.benefitType} onValueChange={value => handleInputChange('benefitType', value)}>
                                  <SelectTrigger className="w-48 h-8">
                                    <SelectValue placeholder="Select benefit type" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Temporary_total_disability">Temporary_total_disability</SelectItem>
                                    <SelectItem value="Permanent_total_disability">Permanent_total_disability</SelectItem>
                                    <SelectItem value="permanent_partial_disabiity">permanent_partial_disabiity</SelectItem>
                                    <SelectItem value="opd_treatment">opd_treatment</SelectItem>
                                    <SelectItem value="Accidental Death">Accidental Death</SelectItem>
                                  </SelectContent>
                                </Select>
                              ) : (
                                <span className="font-medium">{formData.benefitType}</span>
                              )}
                            </div>
                          )}
                          
                          {formData.claimSubType === 'Pre-post hospitalisation' && (
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">Main Claim:</span>
                              {isEditing ? (
                                <Select value={formData.mainClaimId} onValueChange={value => handleInputChange('mainClaimId', value)}>
                                  <SelectTrigger className="w-32 h-8">
                                    <SelectValue placeholder="Select claim" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {getAvailableClaimIds().map(claimId => (
                                      <SelectItem key={claimId} value={claimId}>{claimId}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              ) : (
                                <span className="font-medium">{formData.mainClaimId || 'Not selected'}</span>
                              )}
                            </div>
                          )}
                          
                          <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">
                              {formData.claimSubType === 'GPA' ? 'Date of accident:' : 'DOA:'}
                            </span>
                            {isEditing ? (
                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button variant="outline" className="w-32 h-8 text-left font-normal">
                                    <CalendarIcon className="mr-2 h-3 w-3" />
                                    {format(formData.admissionDate, "dd/MM/yyyy")}
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0">
                                  <Calendar
                                    mode="single"
                                    selected={formData.admissionDate}
                                    onSelect={(date) => date && handleInputChange('admissionDate', date)}
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                            ) : (
                              <span className="font-medium">{format(formData.admissionDate, "PPP")}</span>
                            )}
                          </div>
                          
                          {formData.claimSubType !== 'GPA' && (
                            <div className="flex justify-between items-center">
                              <span className="text-muted-foreground">DOD:</span>
                              {isEditing ? (
                                <Popover>
                                  <PopoverTrigger asChild>
                                    <Button variant="outline" className="w-32 h-8 text-left font-normal">
                                      <CalendarIcon className="mr-2 h-3 w-3" />
                                      {format(formData.dischargeDate, "dd/MM/yyyy")}
                                    </Button>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-auto p-0">
                                    <Calendar
                                      mode="single"
                                      selected={formData.dischargeDate}
                                      onSelect={(date) => date && handleInputChange('dischargeDate', date)}
                                      initialFocus
                                    />
                                  </PopoverContent>
                                </Popover>
                              ) : (
                                <span className="font-medium">{format(formData.dischargeDate, "PPP")}</span>
                              )}
                            </div>
                          )}
                        </CardContent>
                      </Card>

                      {/* Navigation */}
                      <div className="flex justify-between pt-4">
                        <Button variant="outline" onClick={() => setReviewStep(1)} className="px-8">
                          <ChevronLeft className="h-4 w-4 mr-2" />
                          Back
                        </Button>
                        <Button onClick={() => setReviewStep(3)} className="px-8">
                          Next
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Step 3: Hospital Details */}
                  {reviewStep === 3 && (
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Button variant="outline" className="flex-1 justify-start cursor-default hover:bg-background">
                          <div className="flex items-center space-x-2">
                            <Building2 className="h-4 w-4 text-primary" />
                            <span className="font-medium">Hospital Details</span>
                            {selectedHospitals.length > 1 && (
                              <Badge variant="secondary" className="text-xs">
                                {selectedHospitals.length} hospitals
                              </Badge>
                            )}
                          </div>
                        </Button>
                        {!isHospitalEditing ? (
                          <Button variant="outline" size="sm" onClick={() => {
                            setIsHospitalEditing(true);
                            setEditingHospitalIndex(null);
                          }} className="flex-shrink-0">
                            <Edit className="h-4 w-4" />
                          </Button>
                        ) : (
                          <div className="flex items-center space-x-1">
                            <Button variant="outline" size="sm" onClick={() => {
                              setIsHospitalEditing(false);
                              setEditingHospitalIndex(null);
                            }} className="flex-shrink-0">
                              <Save className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => {
                              setIsHospitalEditing(false);
                              setEditingHospitalIndex(null);
                            }} className="flex-shrink-0">
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>

                      <div className="space-y-3">
                        {selectedHospitals.map((hospital, index) => (
                          <Card key={`${hospital.hospitalName}-${index}`}>
                            <CardHeader className="pb-2">
                              <div className="flex items-center justify-between">
                                <CardTitle className="text-sm font-medium">
                                  Hospital {selectedHospitals.length > 1 ? `${index + 1}` : ''} Information
                                </CardTitle>
                                {isHospitalEditing && selectedHospitals.length > 1 && (
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => removeHospital(hospital.hospitalName)}
                                    className="text-destructive hover:text-destructive"
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                              {!hospital.isApproved && (
                                <Alert className="mt-2">
                                  <AlertCircle className="h-4 w-4" />
                                  <AlertDescription className="text-xs">
                                    This hospital will be sent for approval before confirmation
                                  </AlertDescription>
                                </Alert>
                              )}
                            </CardHeader>
                            <CardContent className="p-4 space-y-3 text-sm">
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">
                                  {formData.claimType === 'Reimbursement' && formData.claimSubType === 'Doctor consultation & Medicines (OPD)' 
                                    ? 'Hospital/ Clinic:'
                                    : formData.claimType === 'Reimbursement' && formData.claimSubType === 'Lab tests (OPD)'
                                    ? 'Diagnostic centre/ Lab:'
                                    : 'Hospital:'}
                                </span>
                                <span className="font-medium">{hospital.hospitalName}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Address:</span>
                                <span className="font-medium text-xs">{hospital.hospitalAddress || 'N/A'}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Network Status:</span>
                                <div className="flex items-center gap-2">
                                  <Badge variant={
                                    hospital.networkStatus === 'network' ? 'default' : 
                                    hospital.networkStatus === 'excluded' ? 'destructive' : 
                                    'secondary'
                                  } className="text-xs">
                                    {hospital.networkStatus === 'network' ? 'Network' : 
                                     hospital.networkStatus === 'excluded' ? 'Excluded' : 
                                     'Non-Network'}
                                  </Badge>
                                  {hospital.networkStatus === 'non-network' && hospital.cashlessAnywhere && (
                                    <Badge variant="outline" className="text-xs border-green-500 text-green-700">
                                      Cashless Anywhere
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>

                      {/* Navigation */}
                      <div className="flex justify-between pt-4">
                        <Button variant="outline" onClick={() => setReviewStep(2)} className="px-8">
                          <ChevronLeft className="h-4 w-4 mr-2" />
                          Back
                        </Button>
                        <Button onClick={() => setReviewStep(4)} className="px-8">
                          Next
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Step 4: Bank Account Details */}
                  {reviewStep === 4 && (
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Button variant="outline" className="flex-1 justify-start cursor-default hover:bg-background">
                          <div className="flex items-center space-x-2">
                            <CreditCard className="h-4 w-4 text-primary" />
                            <span className="font-medium">Bank Account Details</span>
                          </div>
                        </Button>
                        {!isBankEditing ? (
                          <Button variant="outline" size="sm" onClick={() => setIsBankEditing(true)} className="flex-shrink-0">
                            <Edit className="h-4 w-4" />
                          </Button>
                        ) : (
                          <div className="flex items-center space-x-1">
                            <Button variant="outline" size="sm" onClick={() => setIsBankEditing(false)} className="flex-shrink-0">
                              <Save className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => setIsBankEditing(false)} className="flex-shrink-0">
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>

                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-medium">Bank Information</CardTitle>
                        </CardHeader>
                        <CardContent className="p-4 space-y-3 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Account Holder:</span>
                            <span className="font-medium">{formData.accountHolder}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Bank Name:</span>
                            <span className="font-medium">{formData.bankName}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Account No:</span>
                            {isBankEditing ? (
                              <Input 
                                value={formData.accountNo} 
                                onChange={(e) => handleInputChange('accountNo', e.target.value)}
                                className="w-32 h-8 text-right text-xs"
                                placeholder="Account number"
                              />
                            ) : (
                              <span className="font-medium text-xs">{formData.accountNo}</span>
                            )}
                          </div>
                        </CardContent>
                      </Card>

                      {/* Navigation */}
                      <div className="flex justify-between pt-4">
                        <Button variant="outline" onClick={() => setReviewStep(3)} className="px-8">
                          <ChevronLeft className="h-4 w-4 mr-2" />
                          Back
                        </Button>
                        <Button 
                          className="px-8" 
                          onClick={() => {
                            setWorkflowStage('billEntry');
                            toast({
                              title: "Ready for Bill Entry",
                              description: "You can now start entering bill line items.",
                            });
                          }}
                        >
                          Continue with bill entry
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Bill Line Items */}
              {workflowStage === 'billEntry' && (
              <Collapsible defaultOpen>
                <CollapsibleTrigger asChild>
                  <Button variant="outline" className="w-full justify-between">
                    <div className="flex items-center space-x-2">
                      <Receipt className="h-4 w-4 text-primary" />
                      <span className="font-medium">Bill Line Items</span>
                    </div>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-2">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Bill Line Items</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 space-y-6">
                      {/* Section 1: Search and Add Category */}
                      <div className="space-y-4 border rounded-lg p-4 bg-muted/20">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <div className="h-2 w-2 rounded-full bg-primary"></div>
                            <Label className="text-sm font-semibold">Search and Add Category</Label>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="h-7 text-xs gap-1"
                            onClick={() => navigate('/hospital-tariff')}
                          >
                            <ExternalLink className="h-3 w-3" />
                            View Tariff
                          </Button>
                        </div>
                        
                        <div className="space-y-2">
                          <Label className="text-xs text-muted-foreground">Select Category/Subcategory</Label>
                          <Command className="border rounded-lg">
                            <CommandInput 
                              placeholder="Type to search categories..." 
                              value={categorySearchValue}
                              onValueChange={setCategorySearchValue}
                            />
                            {categorySearchValue && (
                              <CommandList>
                                <CommandEmpty>No category found.</CommandEmpty>
                                <CommandGroup>
                                  {getSearchOptions().map((option) => (
                                    <CommandItem
                                      key={option.value}
                                      value={option.label}
                                      onSelect={() => {
                                        handleCategorySelect(option.value);
                                        setCategorySearchValue("");
                                      }}
                                    >
                                      <Check
                                        className={cn(
                                          "mr-2 h-4 w-4",
                                          selectedBillItems.length > 0 && 
                                          selectedBillItems[selectedBillItems.length - 1].id === 'temp' &&
                                          selectedBillItems[selectedBillItems.length - 1].fullPath === option.value
                                            ? "opacity-100"
                                            : "opacity-0"
                                        )}
                                      />
                                      {option.label}
                                    </CommandItem>
                                  ))}
                                </CommandGroup>
                              </CommandList>
                            )}
                          </Command>
                        </div>

                        {/* Bill and Deduction Entry Form - Shows when a category is selected */}
                        {selectedBillItems.length > 0 && selectedBillItems[selectedBillItems.length - 1].id === 'temp' && (
                          <div className="space-y-4 border-t pt-4">
                            {/* Category Header */}
                            <div className="bg-muted/50 px-3 py-2 rounded-lg">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-medium">
                                  {selectedBillItems[selectedBillItems.length - 1].level1}
                                </span>
                                {selectedBillItems[selectedBillItems.length - 1].level2 && (
                                  <>
                                    <span className="text-muted-foreground">→</span>
                                    <span className="text-sm text-muted-foreground">
                                      {selectedBillItems[selectedBillItems.length - 1].level2}
                                    </span>
                                  </>
                                )}
                                {selectedBillItems[selectedBillItems.length - 1].level3 && (
                                  <>
                                    <span className="text-muted-foreground">→</span>
                                    <span className="text-sm text-muted-foreground">
                                      {selectedBillItems[selectedBillItems.length - 1].level3}
                                    </span>
                                  </>
                                )}
                              </div>
                            </div>
                            
<BillEntryExpandable 
  ref={billEntryRef}
  isExpanded={true}
  onToggle={() => {}}
  currentAmount={parseFloat(selectedBillItems[selectedBillItems.length - 1].payableAmount) || 0}
  onSave={handleSaveBillEntry}
  savedBills={tempSavedBills}
  savedDeductions={tempSavedDeductions}
  onUpdateBill={(billId, updatedBill) => {
    setTempSavedBills(prev => prev.map(bill => bill.id === billId ? updatedBill : bill));
  }}
  onDeleteBill={(billId) => {
    setTempSavedBills(prev => prev.filter(bill => bill.id !== billId));
  }}
  onUpdateDeduction={(deductionId, updatedDeduction) => {
    setTempSavedDeductions(prev => prev.map(ded => ded.id === deductionId ? updatedDeduction : ded));
  }}
  onDeleteDeduction={(deductionId) => {
    setTempSavedDeductions(prev => prev.filter(ded => ded.id !== deductionId));
  }}
/>
                            <div className="flex justify-end mt-2">
                              <Button size="sm" onClick={handleFinalSaveBillEntry} className="h-7">
                                Save Entry
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Section 2: Saved Entries */}
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className="h-2 w-2 rounded-full bg-primary"></div>
                            <Label className="text-sm font-semibold">Saved Entries</Label>
                          </div>
                          <Button variant="outline" size="sm" className="gap-1 h-7 text-xs" onClick={() => setSummaryModalOpen(true)}>
                            <Calculator className="h-3 w-3" />
                            View Summary
                          </Button>
                        </div>

                        {selectedBillItems.filter(item => item.id !== 'temp').length > 0 ? (
                          <div className="space-y-6">
                            {/* Group items by document */}
                            {(() => {
                              // Group bill items by documentId
                              const itemsByDocument = selectedBillItems
                                .filter(item => item.id !== 'temp')
                                .reduce((acc, item) => {
                                  const docId = item.documentId || 'unknown';
                                  if (!acc[docId]) {
                                    acc[docId] = {
                                      documentName: item.documentName || 'Unknown Document',
                                      items: []
                                    };
                                  }
                                  acc[docId].items.push(item);
                                  return acc;
                                }, {} as Record<string, { documentName: string; items: any[] }>);

                              return Object.entries(itemsByDocument).map(([docId, { documentName, items }]) => (
                                <div key={docId} className="space-y-3">
                                  {/* Document Header */}
                                  <div className="flex items-center gap-2 px-3 py-2 bg-primary/5 border border-primary/20 rounded-lg">
                                    <FileText className="h-4 w-4 text-primary" />
                                    <span className="text-sm font-semibold text-primary">{documentName}</span>
                                    <Badge variant="outline" className="ml-auto text-xs">
                                      {items.length} {items.length === 1 ? 'entry' : 'entries'}
                                    </Badge>
                                  </div>

                                  {/* Items under this document */}
                                  <Accordion type="single" collapsible className="w-full space-y-2">
                                    {items.map((item) => {
                                      const summary = getBillSummary(item.id);
                                      const eligibleData = getEligibleAmount(item.id);
                                      const discount = parseFloat(item.discount) || 0;
                                      const payable = eligibleData.eligible - discount;
                                      
                                      return (
                                        <AccordionItem key={item.id} value={item.id} className="border rounded-lg">
                                          <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/50">
                                            <div className="flex items-center justify-between w-full pr-4">
                                              <div className="flex items-center space-x-3">
                                                <div className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10">
                                                  <span className="text-primary text-xs font-medium">+</span>
                                                </div>
                                                <span className="font-medium text-sm">{item.fullPath}</span>
                                              </div>
                                              <div className="flex items-center space-x-4">
                                                <Badge variant="secondary" className="text-xs">
                                                  ₹{Math.max(0, payable).toLocaleString()}
                                                </Badge>
                                              </div>
                                            </div>
                                          </AccordionTrigger>
                                          <AccordionContent className="px-4 pb-4">
                                            <div className="space-y-4 pt-2">
                                              {/* Summary Section */}
                                              <div className="grid grid-cols-2 gap-4 p-4 bg-muted/30 rounded-lg">
                                                <div className="space-y-3">
                                                  <div className="flex justify-between items-center">
                                                    <span className="text-xs text-muted-foreground">Bill Amount:</span>
                                                    <span className="text-sm font-medium">
                                                      {summary.totalBillAmount ? `₹${summary.totalBillAmount.toLocaleString()}` : '-'}
                                                    </span>
                                                  </div>
                                                  <div className="flex justify-between items-center">
                                                    <span className="text-xs text-muted-foreground">Deductions:</span>
                                                    <span className="text-sm font-medium">
                                                      {summary.totalDeductions ? `₹${summary.totalDeductions.toLocaleString()}` : '-'}
                                                    </span>
                                                  </div>
                                                  <div className="flex justify-between items-center">
                                                    <span className="text-xs text-muted-foreground">Post Deductions:</span>
                                                    <span className="text-sm font-medium">
                                                      {summary.billAmountPostDeductions ? `₹${summary.billAmountPostDeductions.toLocaleString()}` : '-'}
                                                    </span>
                                                  </div>
                                                </div>
                                                <div className="space-y-3">
                                                  <div className="flex justify-between items-center">
                                                    <span className="text-xs text-muted-foreground">Eligible:</span>
                                                    <span className="text-sm font-medium">₹{eligibleData.eligible.toLocaleString()}</span>
                                                  </div>
                                                  <div className="flex justify-between items-center">
                                                    <span className="text-xs text-muted-foreground">Discount:</span>
                                                    <Input
                                                      type="number"
                                                      value={item.discount}
                                                      onChange={(e) => handleBillItemChange(item.id, 'discount', e.target.value)}
                                                      className="h-7 w-24 text-xs text-right"
                                                    />
                                                  </div>
                                                  <div className="flex justify-between items-center pt-2 border-t">
                                                    <span className="text-xs font-semibold">Payable Amount:</span>
                                                    <span className="text-sm font-bold text-primary">
                                                      ₹{Math.max(0, payable).toLocaleString()}
                                                    </span>
                                                  </div>
                                                </div>
                                              </div>

                                              {/* Bill & Deduction Details */}
                                              <div className="space-y-3">
                                                <div className="flex items-center justify-between">
                                                  <span className="text-xs font-semibold text-muted-foreground">Bill & Deduction Details</span>
                                                  <Button
                                                    variant="outline"
                                                    size="sm"
                                                    onClick={() => handleToggleBillEntry(item.id)}
                                                    className="h-7"
                                                  >
                                                    {expandedBillEntries[item.id as any] ? 'Hide Details' : 'Show Details'}
                                          </Button>
                                        </div>

                                        {expandedBillEntries[item.id as any] && (
                                          <div className="border rounded-lg p-4 bg-background">
                                            <BillEntryExpandable 
                                              isExpanded={true}
                                              onToggle={() => handleToggleBillEntry(item.id)}
                                              currentAmount={parseFloat(item.payableAmount) || 0}
                                              savedBills={savedBillDetails[item.id]?.bills || []}
                                              savedDeductions={savedBillDetails[item.id]?.deductions || []}
                                              mode="edit"
                                              onDeleteBill={(billId) => {
                                                setSavedBillDetails(prev => ({
                                                  ...prev,
                                                  [item.id]: {
                                                    ...prev[item.id],
                                                    bills: prev[item.id]?.bills.filter(b => b.id !== billId) || []
                                                  }
                                                }));
                                                toast({
                                                  title: "Bill Deleted",
                                                  description: "The bill entry has been removed."
                                                });
                                              }}
                                              onDeleteDeduction={(deductionId) => {
                                                setSavedBillDetails(prev => ({
                                                  ...prev,
                                                  [item.id]: {
                                                    ...prev[item.id],
                                                    deductions: prev[item.id]?.deductions.filter(d => d.id !== deductionId) || []
                                                  }
                                                }));
                                                toast({
                                                  title: "Deduction Deleted",
                                                  description: "The deduction entry has been removed."
                                                });
                                              }}
                                              onUpdateBill={(billId, updatedBill) => {
                                                setSavedBillDetails(prev => ({
                                                  ...prev,
                                                  [item.id]: {
                                                    ...prev[item.id],
                                                    bills: prev[item.id]?.bills.map(b => b.id === billId ? updatedBill : b) || []
                                                  }
                                                }));
                                                toast({
                                                  title: "Bill Updated",
                                                  description: "The bill entry has been updated successfully."
                                                });
                                              }}
                                              onUpdateDeduction={(deductionId, updatedDeduction) => {
                                                setSavedBillDetails(prev => ({
                                                  ...prev,
                                                  [item.id]: {
                                                    ...prev[item.id],
                                                    deductions: prev[item.id]?.deductions.map(d => d.id === deductionId ? updatedDeduction : d) || []
                                                  }
                                                }));
                                                toast({
                                                  title: "Deduction Updated",
                                                  description: "The deduction entry has been updated successfully."
                                                });
                                              }}
                                            />
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  </AccordionContent>
                                </AccordionItem>
                              );
                            })}
                          </Accordion>
                        </div>
                      ));
                            })()}
                          </div>
                        ) : (
                          <div className="text-center py-8 text-muted-foreground border rounded-lg bg-muted/10">
                            <p className="text-sm">No saved entries yet. Add entries using the search above.</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </CollapsibleContent>
              </Collapsible>
              )}

              {/* Done Action */}
              {workflowStage === 'billEntry' && (
              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 rounded-full bg-primary"></div>
                      <span className="text-sm font-medium">Ready to Complete?</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Review all changes made and proceed to the next stage.
                    </p>
                    <Button 
                      className="w-full" 
                      onClick={() => setIsReviewScreenOpen(true)}
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Done
                    </Button>
                  </div>
                </CardContent>
              </Card>
              )}

            </div>
           </ScrollArea>
        </ResizablePanel>
      </ResizablePanelGroup>

      {/* Document Overlay */}
      <Dialog open={documentOverlayOpen} onOpenChange={setDocumentOverlayOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] p-0">
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-semibold">Document Viewer</h2>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 border rounded-md p-1">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleZoomOut}
                    disabled={documentZoom <= 50}
                  >
                    <ZoomOut className="h-3 w-3" />
                  </Button>
                  <span className="text-xs text-muted-foreground px-2 min-w-[3rem] text-center">
                    {documentZoom}%
                  </span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleZoomIn}
                    disabled={documentZoom >= 200}
                  >
                    <ZoomIn className="h-3 w-3" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleZoomReset}
                  >
                    <RotateCcw className="h-3 w-3" />
                  </Button>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handlePreviousDocument}
                  disabled={documents.length === 0}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm text-muted-foreground">
                  {currentDocumentIndex + 1} of {documents.length}
                </span>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleNextDocument}
                  disabled={documents.length === 0}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setDocumentOverlayOpen(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <ScrollArea className="flex-1 p-4">
              <div className="border-2 border-dashed border-muted-foreground/30 rounded-lg flex items-center justify-center bg-muted/20 min-h-[500px]">
                <div className="text-center space-y-4" style={{ transform: `scale(${documentZoom / 100})` }}>
                  <div className="bg-background/80 rounded-full p-6 mx-auto w-fit">
                    <currentDocument.icon className="h-24 w-24 text-muted-foreground" />
                  </div>
                  <div className="space-y-2">
                    <p className="font-medium text-foreground text-xl">
                      {currentDocument.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {currentDocument.type} • {currentDocument.size} • {currentDocument.uploadDate}
                    </p>
                    <p className="text-sm text-muted-foreground max-w-md">
                      {currentDocument.content}
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialogs and modals */}

      {/* Add Sub-Category Modal */}
      <Dialog open={addSubCategoryOpen} onOpenChange={setAddSubCategoryOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold">Add New Sub-Category</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Sub-Category Name</label>
                <Input 
                  value={newSubCategory.name}
                  onChange={(e) => handleNewSubCategoryChange('name', e.target.value)}
                  placeholder="Enter sub-category name"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Days</label>
                <Input
                  type="number"
                  value={newSubCategory.days}
                  onChange={(e) => handleNewSubCategoryChange('days', e.target.value)}
                  placeholder="Number of days"
                  min="1"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Tariff Amount (₹)</label>
                <Input 
                  type="number"
                  value={newSubCategory.tariffAmount}
                  onChange={(e) => handleNewSubCategoryChange('tariffAmount', e.target.value)}
                  placeholder="Enter tariff amount"
                  min="0"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Deductions (₹)</label>
                <Input 
                  type="number"
                  value={newSubCategory.deductions}
                  onChange={(e) => handleNewSubCategoryChange('deductions', e.target.value)}
                  placeholder="Enter deductions amount"
                  min="0"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Discount (₹)</label>
                <Input 
                  type="number"
                  value={newSubCategory.discount}
                  onChange={(e) => handleNewSubCategoryChange('discount', e.target.value)}
                  placeholder="Enter discount amount"
                  min="0"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Bill Amount (₹)</label>
                <Input 
                  value={newSubCategory.billAmount}
                  placeholder="Auto-calculated"
                  disabled
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Payable Amount (₹)</label>
              <Input 
                value={newSubCategory.payableAmount}
                placeholder="Auto-calculated"
                disabled
              />
            </div>
            
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => setAddSubCategoryOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleAddSubCategory}
                disabled={!newSubCategory.name || !newSubCategory.tariffAmount}
              >
                Add Sub-Category
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Line Item Modal */}
      <Dialog open={addLineItemOpen} onOpenChange={setAddLineItemOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader className="flex flex-row items-center justify-between border-b pb-4">
            <DialogTitle className="text-xl font-semibold">
              Add New Line Item
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCancelAddLineItem}
              className="h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogHeader>
          
          <div className="space-y-4 pt-4">
            <div>
              <label className="text-sm font-medium">Category</label>
              <Select value={newLineItem.category} onValueChange={(value) => handleNewLineItemChange('category', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="accommodation">Room & Nursing Charges</SelectItem>
                  <SelectItem value="icu">ICU Charges</SelectItem>
                  <SelectItem value="ot">OT Charges</SelectItem>
                  <SelectItem value="pharmacy">Medicine & Consumables charges</SelectItem>
                  <SelectItem value="professional">Professional fees charges</SelectItem>
                  <SelectItem value="investigation">Investigation Charges</SelectItem>
                  <SelectItem value="ambulance">Ambulance Charges</SelectItem>
                  <SelectItem value="miscellaneous">Miscellaneous charges</SelectItem>
                  <SelectItem value="package">Package Charges</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium">Tariff Amount (₹)</label>
              <Input
                type="number"
                placeholder="0"
                value={newLineItem.tariffAmount}
                onChange={(e) => handleNewLineItemChange('tariffAmount', e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm font-medium">Discount (₹)</label>
              <Input
                type="number"
                placeholder="0"
                value={newLineItem.discount}
                onChange={(e) => handleNewLineItemChange('discount', e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Bill Amount (₹)</label>
                <Input
                  type="number"
                  placeholder="0"
                  value={newLineItem.billAmount}
                  onChange={(e) => handleNewLineItemChange('billAmount', e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Payable Amount (₹)</label>
                <Input
                  type="number"
                  placeholder="0"
                  value={newLineItem.payableAmount}
                  onChange={(e) => handleNewLineItemChange('payableAmount', e.target.value)}
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={handleCancelAddLineItem} className="flex-1">
                Cancel
              </Button>
              <Button onClick={handleAddLineItem} className="flex-1">
                Add Line Item
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Document Overlay Dialog */}
      <Dialog open={documentOverlayOpen} onOpenChange={setDocumentOverlayOpen}>
        <DialogContent className="max-w-6xl w-[90vw] h-[90vh] p-0">
          <div className="h-full flex flex-col">
            <DialogHeader className="p-4 border-b flex-shrink-0">
              <div className="flex items-center justify-between">
                <DialogTitle className="text-lg font-semibold">
                  {currentDocument.name}
                </DialogTitle>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 border rounded-md p-1">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handleZoomOut}
                      disabled={documentZoom <= 50}
                    >
                      <ZoomOut className="h-3 w-3" />
                    </Button>
                    <span className="text-xs text-muted-foreground px-2 min-w-[3rem] text-center">
                      {documentZoom}%
                    </span>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handleZoomIn}
                      disabled={documentZoom >= 200}
                    >
                      <ZoomIn className="h-3 w-3" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handleZoomReset}
                    >
                      <RotateCcw className="h-3 w-3" />
                    </Button>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handlePreviousDocument}
                    disabled={documents.length === 0}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm text-muted-foreground">
                    {currentDocumentIndex + 1} of {documents.length}
                  </span>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleNextDocument}
                    disabled={documents.length === 0}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </DialogHeader>
            
            <div className="flex-1 p-6 overflow-auto">
              <div className="h-full flex items-center justify-center">
                <div className="text-center space-y-6" style={{ transform: `scale(${documentZoom / 100})` }}>
                  <div className="bg-background/80 rounded-full p-8 mx-auto w-fit">
                    <currentDocument.icon className="h-24 w-24 text-muted-foreground" />
                  </div>
                  <div className="space-y-3">
                    <p className="font-medium text-foreground text-2xl">
                      {currentDocument.name}
                    </p>
                    <p className="text-base text-muted-foreground">
                      {currentDocument.type} • {currentDocument.size} • {currentDocument.uploadDate}
                    </p>
                    <p className="text-base text-muted-foreground max-w-2xl mx-auto">
                      {currentDocument.content}
                    </p>
                  </div>
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Download Full Size
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Summary Modal */}
      <Dialog open={summaryModalOpen} onOpenChange={setSummaryModalOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Bill Summary & Breakup
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            {/* Bills Breakdown by Category */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-foreground">Bills Breakdown by Category:</h4>
              <div className="bg-muted/20 p-4 rounded-lg space-y-4">
                {selectedBillItems.filter(item => item.id !== 'temp').map((item) => {
                  const billData = savedBillDetails[item.id];
                  const summary = getBillSummary(item.id);
                  
                  return (
                    <div key={item.id} className="space-y-2">
                      <div className="font-semibold text-sm border-b pb-1">{item.fullPath}</div>
                      {billData?.bills && billData.bills.length > 0 ? (
                        <div className="space-y-1 pl-4">
                          {billData.bills.map((bill: any, idx: number) => (
                            <div key={idx} className="flex justify-between items-center text-xs">
                              <span className="text-muted-foreground">
                                {bill.itemName} ({bill.days} days × ₹{bill.rent})
                              </span>
                              <span className="font-medium">₹{bill.amount.toLocaleString()}</span>
                            </div>
                          ))}
                          <div className="flex justify-between items-center text-sm font-medium pt-1 border-t">
                            <span>Subtotal:</span>
                            <span>₹{summary.totalBillAmount.toLocaleString()}</span>
                          </div>
                        </div>
                      ) : (
                        <div className="text-xs text-muted-foreground pl-4">No bills added</div>
                      )}
                    </div>
                  );
                })}
                <div className="border-t pt-2 mt-3">
                  <div className="flex justify-between items-center text-sm font-semibold">
                    <span>Total Billed Amount:</span>
                    <span>₹{selectedBillItems
                      .filter(item => item.id !== 'temp')
                      .reduce((sum, item) => sum + getBillSummary(item.id).totalBillAmount, 0)
                      .toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Deductions Breakdown */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-foreground">Deductions Breakdown:</h4>
              <div className="bg-red-50 dark:bg-red-950/20 p-4 rounded-lg space-y-4">
                {selectedBillItems.filter(item => item.id !== 'temp').map((item) => {
                  const billData = savedBillDetails[item.id];
                  const summary = getBillSummary(item.id);
                  
                  if (!billData?.deductions || billData.deductions.length === 0) return null;
                  
                  return (
                    <div key={item.id} className="space-y-2">
                      <div className="font-semibold text-sm border-b pb-1">{item.fullPath}</div>
                      <div className="space-y-1 pl-4">
                        {billData.deductions.map((deduction: any, idx: number) => (
                          <div key={idx} className="flex justify-between items-center text-xs">
                            <span className="text-muted-foreground">{deduction.deductionName}</span>
                            <span className="font-medium text-destructive">- ₹{deduction.amount.toLocaleString()}</span>
                          </div>
                        ))}
                        <div className="flex justify-between items-center text-sm font-medium pt-1 border-t">
                          <span>Subtotal Deductions:</span>
                          <span className="text-destructive">- ₹{summary.totalDeductions.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div className="border-t pt-2 mt-3">
                  <div className="flex justify-between items-center text-sm font-semibold">
                    <span>Total Deductions:</span>
                    <span className="text-destructive">- ₹{selectedBillItems
                      .filter(item => item.id !== 'temp')
                      .reduce((sum, item) => sum + getBillSummary(item.id).totalDeductions, 0)
                      .toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Policy Limit & Discounts */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-foreground">Policy Limit & Discounts:</h4>
              <div className="bg-muted/20 p-4 rounded-lg space-y-2">
                {selectedBillItems.filter(item => item.id !== 'temp').map((item) => {
                  const summary = getBillSummary(item.id);
                  const eligibleData = getEligibleAmount(item.id);
                  const discount = parseFloat(item.discount) || 0;
                  const policyExcess = eligibleData.billAmountPostDeductions - eligibleData.eligible;
                  
                  return (
                    <div key={item.id} className="space-y-1">
                      <div className="font-semibold text-xs">{item.fullPath}</div>
                      <div className="pl-4 space-y-1">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-muted-foreground">Bill Amount (post deductions):</span>
                          <span>₹{summary.billAmountPostDeductions.toLocaleString()}</span>
                        </div>
                        {policyExcess > 0 && (
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-muted-foreground">Policy limit excess:</span>
                            <span className="text-destructive">- ₹{policyExcess.toLocaleString()}</span>
                          </div>
                        )}
                        {discount > 0 && (
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-muted-foreground">Network discount:</span>
                            <span className="text-green-600">- ₹{discount.toLocaleString()}</span>
                          </div>
                        )}
                        <div className="flex justify-between items-center text-sm font-medium pt-1 border-t">
                          <span>Payable:</span>
                          <span className="text-primary">₹{(eligibleData.eligible - discount).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Final Summary */}
            <div className="bg-primary/10 p-4 rounded-lg">
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span>Total Billed Amount:</span>
                  <span className="font-medium">₹{selectedBillItems
                    .filter(item => item.id !== 'temp')
                    .reduce((sum, item) => sum + getBillSummary(item.id).totalBillAmount, 0)
                    .toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span>Total Deductions:</span>
                  <span className="font-medium text-destructive">- ₹{selectedBillItems
                    .filter(item => item.id !== 'temp')
                    .reduce((sum, item) => sum + getBillSummary(item.id).totalDeductions, 0)
                    .toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span>Total Policy Excess:</span>
                  <span className="font-medium text-destructive">- ₹{selectedBillItems
                    .filter(item => item.id !== 'temp')
                    .reduce((sum, item) => {
                      const eligibleData = getEligibleAmount(item.id);
                      return sum + (eligibleData.billAmountPostDeductions - eligibleData.eligible);
                    }, 0)
                    .toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span>Total Discounts:</span>
                  <span className="font-medium text-green-600">- ₹{selectedBillItems
                    .filter(item => item.id !== 'temp')
                    .reduce((sum, item) => sum + (parseFloat(item.discount || '0') || 0), 0)
                    .toLocaleString()}</span>
                </div>
                <div className="border-t pt-2">
                  <div className="flex justify-between items-center">
                    <span className="text-base font-bold">Final Payable Amount:</span>
                    <span className="text-lg font-bold text-primary">₹{selectedBillItems
                      .filter(item => item.id !== 'temp')
                      .reduce((sum, item) => {
                        const eligibleData = getEligibleAmount(item.id);
                        const discount = parseFloat(item.discount) || 0;
                        return sum + (eligibleData.eligible - discount);
                      }, 0)
                      .toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <Button variant="outline" onClick={() => setSummaryModalOpen(false)} className="flex-1">
                Close
              </Button>
              <Button className="flex-1">
                Export Summary
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Keyboard Shortcuts Dialog */}
      <Dialog open={isKeyboardShortcutsOpen} onOpenChange={setIsKeyboardShortcutsOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Keyboard Shortcuts</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="space-y-3">
              <h3 className="text-sm font-semibold">Document Controls</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span>Zoom in</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + Plus</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Zoom out</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + Minus</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Reset zoom</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + Zero</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Rotate clockwise</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + R</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Rotate counterclockwise</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + Shift + R</kbd>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-sm font-semibold">Navigation</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span>Navigate to next/previous document</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Right/Left arrow</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Navigate to the next section/block</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Tab</kbd>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-sm font-semibold">Text Field Entry Shortcuts</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span>Open relevant tabs (Policy details, customer details etc.)</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + Shift + 1/2/3/4</kbd>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-sm font-semibold">For Any Block</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span>Edit</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + E</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Navigate to the next section/block</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Tab</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Save</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + S</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Cancel</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + L</kbd>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Patient & Policy Update Modal */}
      <Dialog open={isPatientPolicyModalOpen} onOpenChange={setIsPatientPolicyModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <DialogTitle className="text-xl font-semibold">
              {isCreatingExtension ? 'Select Policy for Extension' : 'Update Claim Details'}
            </DialogTitle>
            <div className="flex items-center gap-2">
              {showBackToLookup && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleBackToLookupClick}
                  className="gap-2"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Back to Lookup
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={handleModalClose}
                className="h-6 w-6"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          <div className="space-y-6">
            <PatientIdentificationStep
              onNext={handlePatientIdentificationNext}
              onCancel={handleModalClose}
              onBackToLookup={handleBackToLookupClick}
              initialPatientData={isCreatingExtension ? {
                uhid: formData.uhid,
                customerName: formData.customerName,
                customerPhone: formData.customerPhone,
                customerEmail: formData.customerEmail
              } : undefined}
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Hospital Dialog */}
      <Dialog open={isAddHospitalDialogOpen} onOpenChange={setIsAddHospitalDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add New Hospital</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="hospitalName">Hospital Name</Label>
              <Input
                id="hospitalName"
                value={newHospitalData.hospitalName}
                onChange={(e) => setNewHospitalData(prev => ({...prev, hospitalName: e.target.value}))}
                placeholder="Enter hospital name"
              />
            </div>
            <div>
              <Label htmlFor="hospitalAddress">Address</Label>
              <Input
                id="hospitalAddress"
                value={newHospitalData.hospitalAddress}
                onChange={(e) => setNewHospitalData(prev => ({...prev, hospitalAddress: e.target.value}))}
                placeholder="Street address, building name, etc."
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  value={newHospitalData.city}
                  onChange={(e) => setNewHospitalData(prev => ({...prev, city: e.target.value}))}
                  placeholder="Enter city"
                />
              </div>
              <div>
                <Label htmlFor="state">State</Label>
                <Input
                  id="state"
                  value={newHospitalData.state}
                  onChange={(e) => setNewHospitalData(prev => ({...prev, state: e.target.value}))}
                  placeholder="Enter state"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="pincode">Pincode</Label>
              <Input
                id="pincode"
                value={newHospitalData.pincode}
                onChange={(e) => setNewHospitalData(prev => ({...prev, pincode: e.target.value}))}
                placeholder="Enter pincode"
                maxLength={6}
              />
            </div>
            <div>
              <Label htmlFor="rohini">ROHINI (Optional)</Label>
              <Input
                id="rohini"
                value={newHospitalData.rohini}
                onChange={(e) => setNewHospitalData(prev => ({...prev, rohini: e.target.value}))}
                placeholder="Enter ROHINI"
              />
            </div>
            <div className="flex items-center space-x-2 pt-2">
              <Button 
                onClick={addNewHospital}
                disabled={!newHospitalData.hospitalName || !newHospitalData.hospitalAddress || !newHospitalData.city || !newHospitalData.state || !newHospitalData.pincode}
                className="flex-1"
              >
                Save
              </Button>
              <Button 
                variant="outline"
                onClick={() => {
                  setIsAddHospitalDialogOpen(false);
                  setNewHospitalData({
                    hospitalName: '',
                    hospitalLocation: '',
                    networkType: 'Network',
                    hospitalContact: '',
                    hospitalAddress: '',
                    city: '',
                    state: '',
                    pincode: '',
                    rohini: ''
                  });
                }}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Review Screen Dialog */}
      <Dialog open={isReviewScreenOpen} onOpenChange={setIsReviewScreenOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-primary" />
              Review Changes Summary
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Summary of Changes */}
            <div className="space-y-4">
              <div className="border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-sm">Claim Details Updated</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground">Claim Type:</span>
                    <span className="ml-2 font-medium">{formData.claimType}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Claim Sub Type:</span>
                    <span className="ml-2 font-medium">{formData.claimSubType}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Date of Admission:</span>
                    <span className="ml-2 font-medium">{format(formData.admissionDate, 'dd MMM yyyy')}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Date of Discharge:</span>
                    <span className="ml-2 font-medium">{format(formData.dischargeDate, 'dd MMM yyyy')}</span>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-sm">Patient Information</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground">Name:</span>
                    <span className="ml-2 font-medium">{formData.customerName}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Policy ID:</span>
                    <span className="ml-2 font-medium">{formData.policyId}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">UHID:</span>
                    <span className="ml-2 font-medium">{formData.uhid}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Age:</span>
                    <span className="ml-2 font-medium">{formData.customerAge}</span>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-sm">Hospital Details</h3>
                {selectedHospitals.map((hospital, idx) => (
                  <div key={idx} className="text-sm">
                    <div className="font-medium">{hospital.hospitalName}</div>
                    <div className="text-muted-foreground text-xs">{hospital.hospitalLocation}</div>
                  </div>
                ))}
              </div>

              <div className="border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-sm">Bill Entries</h3>
                <div className="text-sm">
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <span className="text-muted-foreground">Total Categories:</span>
                      <span className="ml-2 font-medium">{subCategories.length}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Total Billed:</span>
                      <span className="ml-2 font-medium">₹{subCategories.reduce((sum, item) => sum + parseFloat(item.billAmount.replace(/,/g, '') || '0'), 0).toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Total Payable:</span>
                      <span className="ml-2 font-medium">₹{subCategories.reduce((sum, item) => sum + parseFloat(item.payableAmount.replace(/,/g, '') || '0'), 0).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 pt-4 border-t">
              <Button 
                className="w-full" 
                size="lg"
                onClick={() => {
                  // Check if all documents are tagged
                  const allDocumentsTagged = documents.every(doc => doc.category && doc.category.trim() !== '');
                  
                  if (!allDocumentsTagged) {
                    toast({
                      title: "Document Tagging Required",
                      description: "Please complete document tagging before moving to adjudication.",
                      variant: "destructive",
                    });
                    return;
                  }

                  // Check if any document is marked as "Bill is for some other person (Name not matching)"
                  const hasOtherPersonBill = documents.some(doc => 
                    doc.irrelevant && doc.irrelevantReason === 'name-not-matching'
                  );
                  
                  // Close review screen first
                  setIsReviewScreenOpen(false);
                  
                  // Show adjudication confirmation
                  toast({
                    title: "Case Moved to Adjudication",
                    description: "The case has been successfully moved to adjudication for review.",
                  });
                  
                  if (hasOtherPersonBill) {
                    // Show the other person bill dialog after a brief delay
                    setTimeout(() => {
                      setShowOtherPersonBillDialog(true);
                    }, 500);
                    return;
                  }

                  // Check for documents tagged as 'Irrelevant' or 'Bills for some other claims or person'
                  const hasOtherDocs = documents.some(doc => 
                    doc.category === 'Irrelevant' || doc.category === 'Bills for some other claims or person'
                  );
                  
                  if (hasOtherDocs) {
                    setTimeout(() => {
                      setHasOtherClaimDocuments(true);
                      setShowDocumentTagDialog(true);
                    }, 500);
                  } else {
                    if (onBack) onBack();
                  }
                }}
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Done, move it to adjudication
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full" 
                size="lg"
                onClick={() => {
                  setIsReviewScreenOpen(false);
                  toast({
                    title: "Moved to TL for Review",
                    description: "This case has been flagged and moved to Team Lead for review and assignment.",
                    variant: "default",
                  });
                  // Navigate back or to next page
                  if (onBack) onBack();
                }}
              >
                <AlertCircle className="h-4 w-4 mr-2" />
                Needs review
                <span className="text-xs text-muted-foreground ml-2">(Move to TL for review)</span>
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Review Screen Dialog */}
      <Dialog open={isReviewScreenOpen} onOpenChange={setIsReviewScreenOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-primary" />
              Review Changes Summary
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Summary of Changes */}
            <div className="space-y-4">
              {/* Claim Details */}
              <div className="border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-sm">Claim Details</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground">Claim Type:</span>
                    <span className="ml-2 font-medium">{formData.claimType}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Claim Sub Type:</span>
                    <span className="ml-2 font-medium">{formData.claimSubType}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Date of Admission:</span>
                    <span className="ml-2 font-medium">{format(formData.admissionDate, 'dd MMM yyyy')}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Date of Discharge:</span>
                    <span className="ml-2 font-medium">{format(formData.dischargeDate, 'dd MMM yyyy')}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Length of Stay:</span>
                    <span className="ml-2 font-medium">{formData.lengthOfStay}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Emergency:</span>
                    <span className="ml-2 font-medium">{formData.emergency}</span>
                  </div>
                </div>
              </div>

              {/* Patient Information */}
              <div className="border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-sm">Patient Information</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground">Name:</span>
                    <span className="ml-2 font-medium">{formData.customerName}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">UHID:</span>
                    <span className="ml-2 font-medium">{formData.uhid}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Age:</span>
                    <span className="ml-2 font-medium">{formData.customerAge}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Gender:</span>
                    <span className="ml-2 font-medium">{formData.customerGender}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Phone:</span>
                    <span className="ml-2 font-medium">{formData.customerPhone}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Email:</span>
                    <span className="ml-2 font-medium">{formData.customerEmail}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-muted-foreground">Address:</span>
                    <span className="ml-2 font-medium">{formData.customerAddress}</span>
                  </div>
                </div>
              </div>

              {/* Policy Details */}
              <div className="border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-sm">Policy Details</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground">Policy ID:</span>
                    <span className="ml-2 font-medium">{formData.policyId}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Plan Selected:</span>
                    <span className="ml-2 font-medium">{formData.planSelected}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Sum Insured:</span>
                    <span className="ml-2 font-medium">{formData.sumInsured}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Remaining SI:</span>
                    <span className="ml-2 font-medium">{formData.remainingSI}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Policy Start:</span>
                    <span className="ml-2 font-medium">{formData.policyStart}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Policy End:</span>
                    <span className="ml-2 font-medium">{formData.policyEnd}</span>
                  </div>
                </div>
              </div>

              {/* Hospital Details */}
              <div className="border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-sm">Hospital Details</h3>
                {selectedHospitals.map((hospital, idx) => (
                  <div key={idx} className="space-y-2 text-sm">
                    <div>
                      <span className="font-medium">{hospital.hospitalName}</span>
                      <Badge variant="outline" className="ml-2">
                        {hospital.networkType}
                      </Badge>
                    </div>
                    <div className="text-muted-foreground text-xs space-y-1">
                      <div>{hospital.hospitalAddress}</div>
                      {hospital.hospitalContact && <div>Contact: {hospital.hospitalContact}</div>}
                    </div>
                  </div>
                ))}
              </div>

              {/* Bank Account Details */}
              <div className="border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-sm">Bank Account Details</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground">Account Holder:</span>
                    <span className="ml-2 font-medium">{formData.accountHolder}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Bank Name:</span>
                    <span className="ml-2 font-medium">{formData.bankName}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Account Number:</span>
                    <span className="ml-2 font-medium">{formData.accountNo}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">IFSC Code:</span>
                    <span className="ml-2 font-medium">{formData.ifscCode}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-muted-foreground">Branch:</span>
                    <span className="ml-2 font-medium">{formData.branch}</span>
                  </div>
                </div>
              </div>

              {/* Bill Entries with Details */}
              <div className="border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-sm">Bill Entries Summary</h3>
                
                {/* Group items by document */}
                {(() => {
                  const groupedByDocument = selectedBillItems.reduce((acc: any, item: any) => {
                    const docId = item.documentId || 'unknown';
                    if (!acc[docId]) {
                      acc[docId] = {
                        documentName: item.documentName || 'Unknown Document',
                        items: []
                      };
                    }
                    acc[docId].items.push(item);
                    return acc;
                  }, {});

                  return Object.entries(groupedByDocument).map(([docId, docData]: [string, any]) => (
                    <div key={docId} className="space-y-2">
                      <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
                        <FileText className="h-3 w-3" />
                        {docData.documentName}
                        <Badge variant="secondary" className="text-xs">
                          {docData.items.length} {docData.items.length === 1 ? 'entry' : 'entries'}
                        </Badge>
                      </div>
                      
                      <div className="space-y-2 pl-5">
                        {docData.items.map((item: any) => {
                          const details = savedBillDetails[item.id];
                          if (!details) return null;

                          const billSummary = getBillSummary(item.id);
                          const eligibleData = getEligibleAmount(item.id);

                          return (
                            <div key={item.id} className="border rounded p-3 space-y-2 text-xs">
                              <div className="font-medium">{item.category}</div>
                              <div className="grid grid-cols-2 gap-2">
                                <div>
                                  <span className="text-muted-foreground">Billed:</span>
                                  <span className="ml-2 font-medium">₹{billSummary.totalBillAmount.toLocaleString()}</span>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Deductions:</span>
                                  <span className="ml-2 font-medium">₹{billSummary.totalDeductions.toLocaleString()}</span>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Post Deductions:</span>
                                  <span className="ml-2 font-medium">₹{eligibleData.billAmountPostDeductions.toLocaleString()}</span>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Payable:</span>
                                  <span className="ml-2 font-medium text-primary">₹{eligibleData.eligible.toLocaleString()}</span>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ));
                })()}

                {/* Overall Totals */}
                <div className="border-t pt-3 mt-3">
                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <div>
                      <span className="text-muted-foreground">Total Categories:</span>
                      <span className="ml-2 font-medium">{selectedBillItems.length}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Total Billed:</span>
                      <span className="ml-2 font-medium">
                        ₹{selectedBillItems.reduce((sum, item) => {
                          const details = savedBillDetails[item.id];
                          if (!details) return sum;
                          const billSummary = getBillSummary(item.id);
                          return sum + billSummary.totalBillAmount;
                        }, 0).toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Total Payable:</span>
                      <span className="ml-2 font-medium text-primary">
                        ₹{selectedBillItems.reduce((sum, item) => {
                          const details = savedBillDetails[item.id];
                          if (!details) return sum;
                          const billSummary = getBillSummary(item.id);
                          const eligibleData = getEligibleAmount(item.id);
                          return sum + eligibleData.eligible;
                        }, 0).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 pt-4 border-t">
              <Button 
                className="w-full" 
                size="lg"
                onClick={() => {
                  // Check if all documents are tagged
                  const allDocumentsTagged = documents.every(doc => doc.category && doc.category.trim() !== '');
                  
                  if (!allDocumentsTagged) {
                    toast({
                      title: "Document Tagging Required",
                      description: "Please complete document tagging before moving to adjudication.",
                      variant: "destructive",
                    });
                    return;
                  }

                  // Check if any document is marked as "Bill is for some other person (Name not matching)"
                  const hasOtherPersonBill = documents.some(doc => 
                    doc.irrelevant && doc.irrelevantReason === 'name-not-matching'
                  );
                  
                  // Close review screen first
                  setIsReviewScreenOpen(false);
                  
                  // Show adjudication confirmation
                  toast({
                    title: "Case Moved to Adjudication",
                    description: "The case has been successfully moved to adjudication for review.",
                  });
                  
                  if (hasOtherPersonBill) {
                    // Show the other person bill dialog after a brief delay
                    setTimeout(() => {
                      setShowOtherPersonBillDialog(true);
                    }, 500);
                    return;
                  }

                  // Check for documents tagged as 'Irrelevant' or 'Bills for some other claims or person'
                  const hasOtherDocs = documents.some(doc => 
                    doc.category === 'Irrelevant' || doc.category === 'Bills for some other claims or person'
                  );
                  
                  if (hasOtherDocs) {
                    setTimeout(() => {
                      setHasOtherClaimDocuments(true);
                      setShowDocumentTagDialog(true);
                    }, 500);
                  } else {
                    if (onBack) onBack();
                  }
                }}
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Done, move it to adjudication
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full" 
                size="lg"
                onClick={() => {
                  setIsReviewScreenOpen(false);
                  toast({
                    title: "Moved to TL for Review",
                    description: "This case has been flagged and moved to Team Lead for review and assignment.",
                    variant: "default",
                  });
                  // Navigate back or to next page
                  if (onBack) onBack();
                }}
              >
                <AlertCircle className="h-4 w-4 mr-2" />
                Needs review
                <span className="text-xs text-muted-foreground ml-2">(Move to TL for review)</span>
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Download Documents Dialog */}
      <Dialog open={isDownloadDialogOpen} onOpenChange={setIsDownloadDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Download Claim Documents</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Select Claim Extension</Label>
              <Select value={selectedExtension} onValueChange={setSelectedExtension}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select extension to download" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="HLTHCR5474-1">HLTHCR5474-1</SelectItem>
                  <SelectItem value="HLTHCR5474-2">HLTHCR5474-2</SelectItem>
                  <SelectItem value="HLTHCR5474-3">HLTHCR5474-3</SelectItem>
                  <SelectItem value="all">All Extensions</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {selectedExtension && (
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-3">Document Preview</h3>
                <ScrollArea className="h-[300px]">
                  <div className="space-y-2">
                    {documents.map((doc, index) => (
                      <div 
                        key={index}
                        className="flex items-center justify-between p-3 border rounded-md hover:bg-accent/50 transition-colors cursor-pointer"
                        onClick={() => {
                          setPreviewDocumentIndex(index);
                          setIsDocumentPreviewOpen(true);
                        }}
                      >
                        <div className="flex items-center gap-3">
                          {doc.type === 'pdf' || doc.type === 'PDF' ? (
                            <FileText className="h-5 w-5 text-red-500" />
                          ) : (
                            <FileImage className="h-5 w-5 text-blue-500" />
                          )}
                          <div>
                            <p className="font-medium text-sm">{doc.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {doc.type.toUpperCase()} • {doc.size}
                            </p>
                          </div>
                        </div>
                        <Badge variant="outline">
                          {selectedExtension === 'all' ? `Extension ${(index % 3) + 1}` : selectedExtension}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
                
                <div className="mt-4 pt-4 border-t">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm text-muted-foreground">
                      {selectedExtension === 'all' 
                        ? `${documents.length} documents from all extensions` 
                        : `${documents.length} documents from ${selectedExtension}`}
                    </p>
                    <p className="text-sm font-medium">
                      Total: ~{Math.floor(documents.length * 250)}KB
                    </p>
                  </div>
                  <Button 
                    onClick={() => {
                      toast({
                        title: "Download Started",
                        description: `Preparing ${selectedExtension === 'all' ? 'all documents' : selectedExtension + ' documents'} as ZIP file...`,
                      });
                      // Simulate download
                      setTimeout(() => {
                        toast({
                          title: "Download Complete",
                          description: `Documents downloaded successfully as ${selectedExtension === 'all' ? 'all_extensions' : selectedExtension}.zip`,
                        });
                        setIsDownloadDialogOpen(false);
                      }, 2000);
                    }}
                    className="w-full"
                    disabled={!selectedExtension}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download as ZIP
                  </Button>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Document Preview Modal */}
      <Dialog open={isDocumentPreviewOpen} onOpenChange={setIsDocumentPreviewOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Document Preview
            </DialogTitle>
            <DialogDescription>
              View and review document details, content, and metadata
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[70vh]">
            <div className="space-y-4 p-4">
              {/* Document Header */}
              <div className="flex items-start justify-between pb-4 border-b">
                <div className="space-y-1">
                  <h3 className="text-lg font-semibold">{documents[previewDocumentIndex]?.name}</h3>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <span>{documents[previewDocumentIndex]?.type}</span>
                    <span>•</span>
                    <span>{documents[previewDocumentIndex]?.size}</span>
                    <span>•</span>
                    <span>{documents[previewDocumentIndex]?.uploadDate}</span>
                  </div>
                  <Badge variant={
                    documents[previewDocumentIndex]?.status === 'Approved' ? 'default' :
                    documents[previewDocumentIndex]?.status === 'Rejected' ? 'destructive' : 'secondary'
                  }>
                    {documents[previewDocumentIndex]?.status}
                  </Badge>
                </div>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </div>

              {/* Document Content Preview */}
              <div className="border rounded-lg p-6 bg-muted/20 min-h-[400px]">
                <div className="flex flex-col items-center justify-center space-y-4">
                  {(() => {
                    const IconComponent = documents[previewDocumentIndex]?.icon;
                    return IconComponent ? <IconComponent className="h-20 w-20 text-muted-foreground" /> : null;
                  })()}
                  <div className="text-center max-w-2xl">
                    <pre className="whitespace-pre-wrap text-sm text-foreground font-mono bg-background/50 p-4 rounded-md text-left">
                      {documents[previewDocumentIndex]?.content}
                    </pre>
                  </div>
                </div>
              </div>

              {/* Document Metadata */}
              <div className="space-y-3 pt-4 border-t">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">Category</Label>
                    <p className="text-sm font-medium mt-1">{documents[previewDocumentIndex]?.category}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Document Status</Label>
                    <div className="flex items-center gap-2 mt-1">
                      {documents[previewDocumentIndex]?.readability && (
                        <Badge variant="outline" className="text-xs">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Readable
                        </Badge>
                      )}
                      {documents[previewDocumentIndex]?.suspicious && (
                        <Badge variant="destructive" className="text-xs">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Suspicious
                        </Badge>
                      )}
                      {documents[previewDocumentIndex]?.isComplete && (
                        <Badge variant="default" className="text-xs">
                          <Check className="h-3 w-3 mr-1" />
                          Complete
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
                
                {documents[previewDocumentIndex]?.systemRecommendation && (
                  <div>
                    <Label className="text-xs text-muted-foreground">System Recommendation</Label>
                    <p className="text-sm mt-1">{documents[previewDocumentIndex]?.systemRecommendation}</p>
                  </div>
                )}
                
                {documents[previewDocumentIndex]?.agentNotes && (
                  <div>
                    <Label className="text-xs text-muted-foreground">Agent Notes</Label>
                    <p className="text-sm mt-1">{documents[previewDocumentIndex]?.agentNotes}</p>
                  </div>
                )}
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Document Tagging Alert Dialog */}
      <AlertDialog open={showDocumentTagDialog} onOpenChange={setShowDocumentTagDialog}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl font-semibold">
              Other Claim Documents Detected
            </AlertDialogTitle>
            <AlertDialogDescription className="text-base leading-relaxed pt-2">
              Some documents are tagged as <span className="font-semibold text-foreground">"Bills for some other claims or person"</span>. 
              <br /><br />
              Would you like to create a new claim or add an extension to the existing claim?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col sm:flex-col gap-2 sm:gap-2">
            <AlertDialogAction
              className="w-full"
              onClick={() => {
                setShowDocumentTagDialog(false);
                toast({
                  title: "Creating New Claim",
                  description: "Redirecting to create a new claim with the tagged documents.",
                });
                // Navigate to create new claim
                navigate('/register-new-claim');
              }}
            >
              Create a New Claim
            </AlertDialogAction>
            <AlertDialogAction
              className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/80"
              onClick={() => {
                setShowDocumentTagDialog(false);
                toast({
                  title: "Creating Extension",
                  description: "Adding an extension to the current claim with the tagged documents.",
                });
                // Logic to create extension
                setIsReviewScreenOpen(false);
                if (onBack) onBack();
              }}
            >
              Create Extension to Same Claim
            </AlertDialogAction>
            <AlertDialogCancel className="w-full mt-0">
              Cancel
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Other Person Bill Alert Dialog */}
      <AlertDialog open={showOtherPersonBillDialog} onOpenChange={setShowOtherPersonBillDialog}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl font-semibold">
              Bill for Different Person Detected
            </AlertDialogTitle>
            <AlertDialogDescription className="text-base leading-relaxed pt-2">
              You have marked one or more documents as <span className="font-semibold text-foreground">"Bill is for some other person (Name not matching)"</span>. 
              <br /><br />
              Would you like to create a new claim or add an extension to the existing claim?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col sm:flex-col gap-2 sm:gap-2">
            <AlertDialogAction
              className="w-full"
              onClick={() => {
                setShowOtherPersonBillDialog(false);
                toast({
                  title: "Creating New Claim",
                  description: "Redirecting to create a new claim for the different person.",
                });
                navigate('/register-claim');
              }}
            >
              Create a New Claim
            </AlertDialogAction>
            <AlertDialogAction
              className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/80"
              onClick={() => {
                setShowOtherPersonBillDialog(false);
                setIsCreatingExtension(true);
                setShowBackToLookup(true);
                setIsPatientPolicyModalOpen(true);
                toast({
                  title: "Creating Extension",
                  description: "Please select a policy for the extension to the current claim.",
                });
              }}
            >
              Create Extension to Same Claim
            </AlertDialogAction>
            <AlertDialogCancel className="w-full mt-0">
              Cancel
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Raise Query Dialog */}
      <Dialog open={isRaiseQueryDialogOpen} onOpenChange={setIsRaiseQueryDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Raise Query</DialogTitle>
            <DialogDescription>
              Select the reason(s) for raising a query and provide additional details if needed.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Standard Query Reasons */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Reason for Query</Label>
              <div className="space-y-2">
                {[
                  'Documents are not readable/clear',
                  'Mandatory documents are missing',
                  'Documents are not relevant to the claim',
                  'Patient name mismatch in documents',
                  'Bill dates are inconsistent',
                  'Treatment details are unclear',
                  'Other'
                ].map((reason) => (
                  <div key={reason} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={reason}
                      checked={queryReasons.includes(reason)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setQueryReasons([...queryReasons, reason]);
                        } else {
                          setQueryReasons(queryReasons.filter(r => r !== reason));
                        }
                      }}
                      className="h-4 w-4 rounded border-input"
                    />
                    <Label htmlFor={reason} className="text-sm font-normal cursor-pointer">
                      {reason}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Free Text Area */}
            <div className="space-y-2">
              <Label htmlFor="query-details" className="text-sm font-medium">
                Additional Details
              </Label>
              <Textarea
                id="query-details"
                placeholder="Provide any additional information about the query..."
                value={queryFreeText}
                onChange={(e) => setQueryFreeText(e.target.value)}
                rows={4}
                className="resize-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setIsRaiseQueryDialogOpen(false);
                setQueryReasons([]);
                setQueryFreeText('');
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (queryReasons.length === 0 && !queryFreeText.trim()) {
                  toast({
                    title: "Error",
                    description: "Please select at least one reason or provide details.",
                    variant: "destructive"
                  });
                  return;
                }
                
                toast({
                  title: "Query Raised Successfully",
                  description: "The query has been submitted for review.",
                });
                
                setIsRaiseQueryDialogOpen(false);
                setQueryReasons([]);
                setQueryFreeText('');
              }}
            >
              Submit Query
            </Button>
          </div>
        </DialogContent>
      </Dialog>

    </div>
  );
};

export default ClaimDetailView;