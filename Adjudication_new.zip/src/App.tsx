import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";

import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import PastClaimDetails from "./pages/PastClaimDetails";
import PastExtensions from "./pages/PastExtensions";
import HospitalTariff from "./pages/HospitalTariff";
import RegisterNewClaim from "./pages/RegisterNewClaim";
import FinancialAdjudication from "./pages/FinancialAdjudication";
import CustomerPolicies from "./pages/CustomerPolicies";
import Declarations from "./pages/Declarations";



const App = () => (
  <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/past-claims" element={<PastClaimDetails />} />
          <Route path="/past-extensions" element={<PastExtensions />} />
          <Route path="/hospital-tariff" element={<HospitalTariff />} />
          <Route path="/register-claim" element={<RegisterNewClaim />} />
          <Route path="/financial-adjudication" element={<FinancialAdjudication />} />
          <Route path="/customer-policies" element={<CustomerPolicies />} />
          <Route path="/declarations" element={<Declarations />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </ThemeProvider>
);

export default App;
