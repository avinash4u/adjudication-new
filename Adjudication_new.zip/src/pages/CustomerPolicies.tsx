import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Shield, Car, Heart, FileText, CheckCircle2, XCircle, CreditCard, Calendar, User, Search, Filter, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface Endorsement {
  date: string;
  type: 'member_addition' | 'member_deletion' | 'sum_insured_change' | 'coverage_change' | 'vehicle_change';
  description: string;
  effectiveFrom: string;
  premiumImpact?: number;
}

interface Policy {
  id: string;
  policyNumber: string;
  type: 'health' | 'auto' | 'life';
  planName: string;
  status: 'active' | 'expired' | 'cancelled';
  startDate: string;
  endDate: string;
  premium: number;
  paymentSchedule: 'monthly' | 'yearly';
  sumInsured: number;
  memberDetails: {
    name: string;
    relation: string;
    uhid?: string;
    vehicleNumber?: string;
  }[];
  kycStatus: 'verified' | 'pending' | 'rejected';
  lastPaymentDate?: string;
  nextPaymentDate?: string;
  endorsements?: Endorsement[];
}

const mockPolicies: Policy[] = [
  {
    id: '1',
    policyNumber: 'ACKO-HLTH-001234',
    type: 'health',
    planName: 'Health Protect Plus',
    status: 'active',
    startDate: '2024-01-15',
    endDate: '2025-01-14',
    premium: 15000,
    paymentSchedule: 'yearly',
    sumInsured: 500000,
    memberDetails: [
      { name: 'Rajesh Kumar', relation: 'Self', uhid: 'UHID-2024-001234' },
      { name: 'Priya Kumar', relation: 'Spouse', uhid: 'UHID-2024-001235' },
      { name: 'Arjun Kumar', relation: 'Son', uhid: 'UHID-2024-001236' },
    ],
    kycStatus: 'verified',
    lastPaymentDate: '2024-01-15',
    nextPaymentDate: '2025-01-15',
    endorsements: [
      {
        date: '2024-06-20',
        type: 'member_addition',
        description: 'Added Arjun Kumar (Son) to policy',
        effectiveFrom: '2024-06-20',
        premiumImpact: 3500,
      },
      {
        date: '2024-09-15',
        type: 'sum_insured_change',
        description: 'Sum insured increased from ₹3,00,000 to ₹5,00,000',
        effectiveFrom: '2024-09-15',
        premiumImpact: 2000,
      },
    ],
  },
  {
    id: '2',
    policyNumber: 'ACKO-HLTH-005678',
    type: 'health',
    planName: 'Super Top Up',
    status: 'active',
    startDate: '2024-03-01',
    endDate: '2025-02-28',
    premium: 8000,
    paymentSchedule: 'yearly',
    sumInsured: 1500000,
    memberDetails: [
      { name: 'Rajesh Kumar', relation: 'Self', uhid: 'UHID-2024-001234' },
      { name: 'Priya Kumar', relation: 'Spouse', uhid: 'UHID-2024-001235' },
    ],
    kycStatus: 'verified',
    lastPaymentDate: '2024-03-01',
    nextPaymentDate: '2025-03-01',
  },
  {
    id: '3',
    policyNumber: 'ACKO-AUTO-009876',
    type: 'auto',
    planName: 'Comprehensive Car Insurance',
    status: 'active',
    startDate: '2024-06-10',
    endDate: '2025-06-09',
    premium: 12000,
    paymentSchedule: 'yearly',
    sumInsured: 800000,
    memberDetails: [
      { name: 'Rajesh Kumar', relation: 'Owner', vehicleNumber: 'MH-12-AB-1234' },
    ],
    kycStatus: 'verified',
    lastPaymentDate: '2024-06-10',
    nextPaymentDate: '2025-06-10',
    endorsements: [
      {
        date: '2024-10-05',
        type: 'coverage_change',
        description: 'Added Zero Depreciation cover',
        effectiveFrom: '2024-10-05',
        premiumImpact: 1500,
      },
    ],
  },
  {
    id: '4',
    policyNumber: 'ACKO-AUTO-008765',
    type: 'auto',
    planName: 'Two Wheeler Insurance',
    status: 'active',
    startDate: '2024-02-20',
    endDate: '2025-02-19',
    premium: 2500,
    paymentSchedule: 'yearly',
    sumInsured: 150000,
    memberDetails: [
      { name: 'Rajesh Kumar', relation: 'Owner', vehicleNumber: 'MH-12-CD-5678' },
    ],
    kycStatus: 'verified',
    lastPaymentDate: '2024-02-20',
    nextPaymentDate: '2025-02-20',
  },
  {
    id: '5',
    policyNumber: 'ACKO-HLTH-003456',
    type: 'health',
    planName: 'Health Protect Basic',
    status: 'expired',
    startDate: '2023-01-15',
    endDate: '2024-01-14',
    premium: 10000,
    paymentSchedule: 'yearly',
    sumInsured: 300000,
    memberDetails: [
      { name: 'Rajesh Kumar', relation: 'Self', uhid: 'UHID-2023-001234' },
    ],
    kycStatus: 'verified',
    lastPaymentDate: '2023-01-15',
  },
  {
    id: '7',
    policyNumber: 'ACKO-HLTH-002345',
    type: 'health',
    planName: 'Critical Illness Cover',
    status: 'cancelled',
    startDate: '2022-06-01',
    endDate: '2023-05-31',
    premium: 6000,
    paymentSchedule: 'monthly',
    sumInsured: 1000000,
    memberDetails: [
      { name: 'Rajesh Kumar', relation: 'Self', uhid: 'UHID-2022-001234' },
    ],
    kycStatus: 'verified',
    lastPaymentDate: '2023-02-01',
  },
];

const getTypeIcon = (type: Policy['type']) => {
  switch (type) {
    case 'health':
      return <Heart className="h-4 w-4" />;
    case 'auto':
      return <Car className="h-4 w-4" />;
    case 'life':
      return <Shield className="h-4 w-4" />;
    default:
      return <FileText className="h-4 w-4" />;
  }
};

const getTypeColor = (type: Policy['type']) => {
  switch (type) {
    case 'health':
      return 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400';
    case 'auto':
      return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400';
    case 'life':
      return 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400';
    default:
      return 'bg-muted text-muted-foreground';
  }
};

const getStatusBadge = (status: Policy['status']) => {
  switch (status) {
    case 'active':
      return <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400">Active</Badge>;
    case 'expired':
      return <Badge variant="secondary" className="bg-muted text-muted-foreground">Expired</Badge>;
    case 'cancelled':
      return <Badge variant="destructive">Cancelled</Badge>;
    default:
      return null;
  }
};

const getKycBadge = (status: Policy['kycStatus']) => {
  switch (status) {
    case 'verified':
      return (
        <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 gap-1">
          <CheckCircle2 className="h-3 w-3" />
          Verified
        </Badge>
      );
    case 'pending':
      return (
        <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 gap-1">
          <Calendar className="h-3 w-3" />
          Pending
        </Badge>
      );
    case 'rejected':
      return (
        <Badge variant="destructive" className="gap-1">
          <XCircle className="h-3 w-3" />
          Rejected
        </Badge>
      );
    default:
      return null;
  }
};

const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
};

const CustomerPolicies = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [activeTab, setActiveTab] = useState('all');

  const customerName = 'Rajesh Kumar';
  const customerId = 'CUST-2024-001234';

  const filteredPolicies = mockPolicies.filter(policy => {
    const matchesSearch = 
      policy.policyNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      policy.planName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      policy.memberDetails.some(m => 
        m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.uhid?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.vehicleNumber?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    
    const matchesStatus = statusFilter === 'all' || policy.status === statusFilter;
    const matchesType = typeFilter === 'all' || policy.type === typeFilter;
    const matchesTab = activeTab === 'all' || policy.type === activeTab;
    
    return matchesSearch && matchesStatus && matchesType && matchesTab;
  });

  const activePolicies = mockPolicies.filter(p => p.status === 'active').length;
  const expiredPolicies = mockPolicies.filter(p => p.status === 'expired').length;
  const totalPremium = mockPolicies.filter(p => p.status === 'active').reduce((sum, p) => sum + p.premium, 0);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" asChild>
                <Link to="/">
                  <ArrowLeft className="h-5 w-5" />
                </Link>
              </Button>
              <div>
                <h1 className="text-xl font-semibold flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  Customer Policies
                </h1>
                <p className="text-sm text-muted-foreground">
                  {customerName} • {customerId}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Policies</p>
                  <p className="text-2xl font-bold">{mockPolicies.length}</p>
                </div>
                <FileText className="h-8 w-8 text-muted-foreground/50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Policies</p>
                  <p className="text-2xl font-bold text-emerald-600">{activePolicies}</p>
                </div>
                <CheckCircle2 className="h-8 w-8 text-emerald-500/50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Expired Policies</p>
                  <p className="text-2xl font-bold text-muted-foreground">{expiredPolicies}</p>
                </div>
                <XCircle className="h-8 w-8 text-muted-foreground/50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Annual Premium</p>
                  <p className="text-2xl font-bold">{formatCurrency(totalPremium)}</p>
                </div>
                <CreditCard className="h-8 w-8 text-primary/50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-4">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Filters:</span>
              </div>
              <div className="relative flex-1 max-w-xs">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search policies, UHID, vehicle..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="health">Health</SelectItem>
                  <SelectItem value="auto">Auto</SelectItem>
                  <SelectItem value="life">Life</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="all" className="gap-2">
              <FileText className="h-4 w-4" />
              All ({mockPolicies.length})
            </TabsTrigger>
            <TabsTrigger value="health" className="gap-2">
              <Heart className="h-4 w-4" />
              Health ({mockPolicies.filter(p => p.type === 'health').length})
            </TabsTrigger>
            <TabsTrigger value="auto" className="gap-2">
              <Car className="h-4 w-4" />
              Auto ({mockPolicies.filter(p => p.type === 'auto').length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  {activeTab === 'all' ? 'All Policies' : `${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Policies`}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Policy</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Period</TableHead>
                      <TableHead>Member/Vehicle Details</TableHead>
                      <TableHead>Endorsements</TableHead>
                      <TableHead>KYC</TableHead>
                      <TableHead>Payment</TableHead>
                      <TableHead className="text-right">Sum Insured</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPolicies.map((policy) => (
                      <TableRow key={policy.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{policy.policyNumber}</p>
                            <p className="text-sm text-muted-foreground">{policy.planName}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={`gap-1 ${getTypeColor(policy.type)}`}>
                            {getTypeIcon(policy.type)}
                            {policy.type.charAt(0).toUpperCase() + policy.type.slice(1)}
                          </Badge>
                        </TableCell>
                        <TableCell>{getStatusBadge(policy.status)}</TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <p>{formatDate(policy.startDate)}</p>
                            <p className="text-muted-foreground">to {formatDate(policy.endDate)}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            {policy.memberDetails.map((member, idx) => (
                              <Tooltip key={idx}>
                                <TooltipTrigger asChild>
                                  <div className="flex items-center gap-2 text-sm cursor-default">
                                    <User className="h-3 w-3 text-muted-foreground" />
                                    <span>{member.name}</span>
                                    {member.uhid && (
                                      <Badge variant="outline" className="text-xs">
                                        {member.uhid}
                                      </Badge>
                                    )}
                                    {member.vehicleNumber && (
                                      <Badge variant="outline" className="text-xs">
                                        {member.vehicleNumber}
                                      </Badge>
                                    )}
                                  </div>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>{member.relation}</p>
                                </TooltipContent>
                              </Tooltip>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          {policy.endorsements && policy.endorsements.length > 0 ? (
                            <div className="space-y-1">
                              {policy.endorsements.map((endorsement, idx) => (
                                <Tooltip key={idx}>
                                  <TooltipTrigger asChild>
                                    <div className="flex items-center gap-1.5 cursor-default">
                                      <Badge 
                                        variant="outline" 
                                        className="gap-1 bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-800"
                                      >
                                        <AlertCircle className="h-3 w-3" />
                                        {formatDate(endorsement.date)}
                                      </Badge>
                                    </div>
                                  </TooltipTrigger>
                                  <TooltipContent className="max-w-xs">
                                    <div className="space-y-1">
                                      <p className="font-medium">{endorsement.description}</p>
                                      <p className="text-xs text-muted-foreground">
                                        Effective: {formatDate(endorsement.effectiveFrom)}
                                      </p>
                                      {endorsement.premiumImpact && (
                                        <p className="text-xs text-amber-600 dark:text-amber-400">
                                          Premium Impact: +{formatCurrency(endorsement.premiumImpact)}
                                        </p>
                                      )}
                                    </div>
                                  </TooltipContent>
                                </Tooltip>
                              ))}
                            </div>
                          ) : (
                            <span className="text-sm text-muted-foreground">—</span>
                          )}
                        </TableCell>
                        <TableCell>{getKycBadge(policy.kycStatus)}</TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <Badge variant="outline" className="gap-1 mb-1">
                              <CreditCard className="h-3 w-3" />
                              {policy.paymentSchedule === 'yearly' ? 'Yearly' : 'Monthly'}
                            </Badge>
                            <p className="text-muted-foreground">
                              {formatCurrency(policy.premium)}/yr
                            </p>
                            {policy.nextPaymentDate && (
                              <p className="text-xs text-muted-foreground">
                                Next: {formatDate(policy.nextPaymentDate)}
                              </p>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          {formatCurrency(policy.sumInsured)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                
                {filteredPolicies.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No policies found matching your criteria</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CustomerPolicies;
