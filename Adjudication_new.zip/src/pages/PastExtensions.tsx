import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { ArrowLeft, Calendar, GitBranch, Filter } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { format } from "date-fns";
import { cn } from "@/lib/utils";

const PastExtensions: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const claimIdFromUrl = searchParams.get('claimId') || '';
  
  // Use the claim ID from URL as the base claim
  const baseClaimId = claimIdFromUrl || 'HLTHCR5474';
  
  // Generate extension IDs for this claim (e.g., HLTHCR5474/1, HLTHCR5474/2, etc.)
  const extensionIds = [
    `${baseClaimId}/1`,
    `${baseClaimId}/2`,
    `${baseClaimId}/3`
  ];
  
  const [selectedExtensionId, setSelectedExtensionId] = useState<string>(extensionIds[0]);

  // Mock extensions data per extension ID
  const getExtensionsData = (extId: string) => {
    const extNumber = extId.split('/')[1];
    
    const allExtensionsData: Record<string, {
      extensionId: string;
      extensionDate: Date;
      requestType: string;
      requestedAmount: string;
      approvedAmount: string;
      status: string;
      remarks: string;
    }> = {
      '1': {
        extensionId: `${baseClaimId}/1`,
        extensionDate: new Date('2025-01-10'),
        requestType: 'Enhancement',
        requestedAmount: '₹50,000',
        approvedAmount: '₹45,000',
        status: 'Approved',
        remarks: 'Additional surgery required'
      },
      '2': {
        extensionId: `${baseClaimId}/2`,
        extensionDate: new Date('2025-01-12'),
        requestType: 'Enhancement',
        requestedAmount: '₹30,000',
        approvedAmount: '₹25,000',
        status: 'Approved',
        remarks: 'ICU stay extended'
      },
      '3': {
        extensionId: `${baseClaimId}/3`,
        extensionDate: new Date('2025-01-14'),
        requestType: 'Final Bill',
        requestedAmount: '₹20,000',
        approvedAmount: '-',
        status: 'Pending',
        remarks: 'Awaiting final discharge'
      }
    };
    
    return extNumber ? allExtensionsData[extNumber] : null;
  };

  const selectedExtension = selectedExtensionId ? getExtensionsData(selectedExtensionId) : null;

  

  const getStatusBadge = (status: string) => {
    const statusColors: Record<string, string> = {
      'Approved': 'bg-green-500',
      'Rejected': 'bg-red-500',
      'Pending': 'bg-yellow-500',
    };
    return statusColors[status] || 'bg-gray-500';
  };

  const getRequestTypeBadge = (type: string) => {
    const typeColors: Record<string, string> = {
      'Pre-Auth': 'bg-blue-500',
      'Enhancement': 'bg-purple-500',
      'Final Bill': 'bg-orange-500',
    };
    return typeColors[type] || 'bg-gray-500';
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button variant="outline" onClick={() => navigate('/')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <div>
          <h1 className="text-2xl font-bold">Past Claim Extensions</h1>
          <p className="text-sm text-muted-foreground">View all extensions for a specific claim</p>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Filters</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-w-xs">
            <Label htmlFor="extension-id">Claim Extension *</Label>
            <Select value={selectedExtensionId} onValueChange={setSelectedExtensionId}>
              <SelectTrigger id="extension-id">
                <SelectValue placeholder="Select Extension" />
              </SelectTrigger>
              <SelectContent>
                {extensionIds.map((extId) => (
                  <SelectItem key={extId} value={extId}>
                    {extId}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Extension Details */}
      {selectedExtension && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <GitBranch className="h-5 w-5" />
              <span>Extension Details</span>
              <Badge variant="secondary">{selectedExtensionId}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Extension ID</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Request Type</TableHead>
                    <TableHead>Requested Amount</TableHead>
                    <TableHead>Approved Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Remarks</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">{selectedExtension.extensionId}</TableCell>
                    <TableCell>{format(selectedExtension.extensionDate, 'dd/MM/yyyy')}</TableCell>
                    <TableCell>
                      <Badge 
                        variant="secondary" 
                        className={`text-white ${getRequestTypeBadge(selectedExtension.requestType)}`}
                      >
                        {selectedExtension.requestType}
                      </Badge>
                    </TableCell>
                    <TableCell>{selectedExtension.requestedAmount}</TableCell>
                    <TableCell>{selectedExtension.approvedAmount}</TableCell>
                    <TableCell>
                      <Badge 
                        variant="secondary" 
                        className={`text-white ${getStatusBadge(selectedExtension.status)}`}
                      >
                        {selectedExtension.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">{selectedExtension.remarks}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {!selectedExtension && (
        <Card>
          <CardContent className="py-8">
            <div className="text-center text-muted-foreground">
              <GitBranch className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Please select an extension to view details</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PastExtensions;