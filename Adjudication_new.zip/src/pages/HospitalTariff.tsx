import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Search, Download, Building2, Calendar } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const HospitalTariff = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  // Sample tariff data
  const consultationTariffs = [
    { id: 1, service: 'General Physician Consultation', code: 'GP-001', rate: 500, category: 'Consultation' },
    { id: 2, service: 'Specialist Consultation', code: 'SP-001', rate: 1000, category: 'Consultation' },
    { id: 3, service: 'Senior Consultant', code: 'SC-001', rate: 1500, category: 'Consultation' },
    { id: 4, service: 'Emergency Consultation', code: 'EM-001', rate: 800, category: 'Consultation' },
  ];

  const diagnosticTariffs = [
    { id: 1, service: 'Complete Blood Count (CBC)', code: 'LAB-001', rate: 300, category: 'Laboratory' },
    { id: 2, service: 'Lipid Profile', code: 'LAB-002', rate: 800, category: 'Laboratory' },
    { id: 3, service: 'Liver Function Test', code: 'LAB-003', rate: 600, category: 'Laboratory' },
    { id: 4, service: 'X-Ray Chest', code: 'RAD-001', rate: 500, category: 'Radiology' },
    { id: 5, service: 'MRI Brain', code: 'RAD-002', rate: 8000, category: 'Radiology' },
    { id: 6, service: 'CT Scan Abdomen', code: 'RAD-003', rate: 6000, category: 'Radiology' },
    { id: 7, service: 'Ultrasound Whole Abdomen', code: 'RAD-004', rate: 1500, category: 'Radiology' },
    { id: 8, service: 'ECG', code: 'CARD-001', rate: 200, category: 'Cardiology' },
    { id: 9, service: '2D Echo', code: 'CARD-002', rate: 2000, category: 'Cardiology' },
  ];

  const procedureTariffs = [
    { id: 1, service: 'Appendectomy', code: 'SURG-001', rate: 35000, category: 'Surgery' },
    { id: 2, service: 'Hernia Repair', code: 'SURG-002', rate: 40000, category: 'Surgery' },
    { id: 3, service: 'Cholecystectomy (Laparoscopic)', code: 'SURG-003', rate: 55000, category: 'Surgery' },
    { id: 4, service: 'Knee Replacement', code: 'ORTHO-001', rate: 150000, category: 'Orthopedics' },
    { id: 5, service: 'Hip Replacement', code: 'ORTHO-002', rate: 180000, category: 'Orthopedics' },
    { id: 6, service: 'Angioplasty', code: 'CARD-003', rate: 120000, category: 'Cardiology' },
    { id: 7, service: 'Caesarean Section', code: 'OBS-001', rate: 45000, category: 'Obstetrics' },
    { id: 8, service: 'Normal Delivery', code: 'OBS-002', rate: 25000, category: 'Obstetrics' },
  ];

  const roomTariffs = [
    { id: 1, service: 'General Ward (per day)', code: 'ROOM-001', rate: 1500, category: 'Accommodation' },
    { id: 2, service: 'Semi-Private Room (per day)', code: 'ROOM-002', rate: 3000, category: 'Accommodation' },
    { id: 3, service: 'Private Room (per day)', code: 'ROOM-003', rate: 5000, category: 'Accommodation' },
    { id: 4, service: 'Deluxe Room (per day)', code: 'ROOM-004', rate: 8000, category: 'Accommodation' },
    { id: 5, service: 'ICU (per day)', code: 'ROOM-005', rate: 12000, category: 'Critical Care' },
    { id: 6, service: 'NICU (per day)', code: 'ROOM-006', rate: 10000, category: 'Critical Care' },
  ];

  const filterTariffs = (tariffs: typeof consultationTariffs) => {
    if (!searchQuery) return tariffs;
    return tariffs.filter(tariff => 
      tariff.service.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tariff.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tariff.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  const TariffTable = ({ data }: { data: typeof consultationTariffs }) => (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Service Code</TableHead>
          <TableHead>Service Name</TableHead>
          <TableHead>Category</TableHead>
          <TableHead className="text-right">Rate (₹)</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {filterTariffs(data).map((item) => (
          <TableRow key={item.id}>
            <TableCell className="font-mono text-sm">{item.code}</TableCell>
            <TableCell>{item.service}</TableCell>
            <TableCell>
              <Badge variant="secondary">{item.category}</Badge>
            </TableCell>
            <TableCell className="text-right font-medium">₹{item.rate.toLocaleString('en-IN')}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center space-x-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Building2 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h1 className="text-xl font-semibold">Hospital Tariff Details</h1>
                  <p className="text-sm text-muted-foreground">Apollo Hospital, Mumbai</p>
                </div>
              </div>
            </div>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export Tariff
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-6">
        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <CardTitle>Tariff Rate Card</CardTitle>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>Effective from: 1st January 2025</span>
                  <Badge variant="secondary" className="ml-2">Version 2.5</Badge>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {/* Search Bar */}
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by service name, code, or category..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Tabs for different categories */}
            <Tabs defaultValue="consultation" className="space-y-4">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="consultation">Consultation</TabsTrigger>
                <TabsTrigger value="diagnostics">Diagnostics</TabsTrigger>
                <TabsTrigger value="procedures">Procedures</TabsTrigger>
                <TabsTrigger value="rooms">Rooms & ICU</TabsTrigger>
              </TabsList>

              <TabsContent value="consultation" className="space-y-4">
                <div className="rounded-lg border">
                  <TariffTable data={consultationTariffs} />
                </div>
              </TabsContent>

              <TabsContent value="diagnostics" className="space-y-4">
                <div className="rounded-lg border">
                  <TariffTable data={diagnosticTariffs} />
                </div>
              </TabsContent>

              <TabsContent value="procedures" className="space-y-4">
                <div className="rounded-lg border">
                  <TariffTable data={procedureTariffs} />
                </div>
              </TabsContent>

              <TabsContent value="rooms" className="space-y-4">
                <div className="rounded-lg border">
                  <TariffTable data={roomTariffs} />
                </div>
              </TabsContent>
            </Tabs>

            {/* Footer Note */}
            <div className="mt-6 p-4 bg-muted/50 rounded-lg">
              <p className="text-sm text-muted-foreground">
                <strong>Note:</strong> All rates are in Indian Rupees (₹). Rates are subject to change without prior notice. 
                GST and other applicable taxes will be charged extra. For detailed package rates or any clarifications, 
                please contact the hospital billing department.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default HospitalTariff;
