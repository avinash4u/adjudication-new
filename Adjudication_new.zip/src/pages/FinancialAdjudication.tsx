import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, CheckCircle, FileText, User, Building2, CreditCard, ClipboardCheck, ChevronDown, ChevronUp, Mail, MessageSquare, Phone, Paperclip, Clock, ExternalLink, History, Circle, Filter, StickyNote, MessageCircle, ArrowDownLeft, ArrowUpRight, Save, Receipt, Shield, Bell, RefreshCw, FileUp, HelpCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import StatusNextActionCard from "@/components/StatusNextActionCard";
import { cn } from "@/lib/utils";
import { useNavigate, useLocation } from 'react-router-dom';
import { FinancialSummarySection } from "@/components/financial-adjudication/FinancialSummarySection";

const FinancialAdjudication: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const claimData = location.state?.claimData || {};

  // Collapsible states
  const [isMedicalSummaryOpen, setIsMedicalSummaryOpen] = useState(false);
  const [isCommunicationsOpen, setIsCommunicationsOpen] = useState(false);
  const [isAuditTrailOpen, setIsAuditTrailOpen] = useState(false);
  const [isUpdatesSummaryOpen, setIsUpdatesSummaryOpen] = useState(false);
  const [isMoreDetailsModalOpen, setIsMoreDetailsModalOpen] = useState(false);

  // Filter states
  const [commExtensionFilter, setCommExtensionFilter] = useState<string>('all');
  const [commDirectionFilter, setCommDirectionFilter] = useState<string>('all');
  const [auditExtensionFilter, setAuditExtensionFilter] = useState<string>('all');
  const [auditTypeFilter, setAuditTypeFilter] = useState<string>('all');


  // Handler for save draft
  const handleSaveDraft = () => {
    console.log('Draft saved');
  };

  // Claim extensions (phases)
  const claimExtensions = [
    { id: 'all', label: 'All Extensions' },
    { id: 'pre-auth', label: 'Pre-Authorization' },
    { id: 'enhancement-1', label: 'Enhancement #1' },
    { id: 'enhancement-2', label: 'Enhancement #2' },
    { id: 'final-claim', label: 'Final Claim' },
  ];

  // Audit trail data
  const auditTrail = [
    {
      id: 'audit-1',
      stage: 'Claim Registered',
      status: 'completed',
      timestamp: '2024-01-15 10:15 AM',
      user: 'System',
      description: 'Claim CLM-2024-001234 registered via hospital portal',
      extension: 'pre-auth',
      type: 'system',
    },
    {
      id: 'audit-2',
      stage: 'Documents Uploaded',
      status: 'completed',
      timestamp: '2024-01-15 10:30 AM',
      user: 'Apollo Hospital',
      description: 'Initial documents uploaded: Admission form, ID proof, Insurance card',
      extension: 'pre-auth',
      type: 'system',
    },
    {
      id: 'audit-3',
      stage: 'Pre-Authorization Requested',
      status: 'completed',
      timestamp: '2024-01-15 11:00 AM',
      user: 'Priya Sharma (Claims Officer)',
      description: 'Pre-auth request initiated for estimated amount ₹2,50,000',
      extension: 'pre-auth',
      type: 'system',
    },
    {
      id: 'audit-note-1',
      stage: 'Internal Note',
      status: 'completed',
      timestamp: '2024-01-15 11:30 AM',
      user: 'Priya Sharma (Claims Officer)',
      description: 'Verified patient eligibility. Policy active with sufficient sum insured. No waiting period applicable.',
      extension: 'pre-auth',
      type: 'internal-note',
    },
    {
      id: 'audit-4',
      stage: 'Pre-Authorization Approved',
      status: 'completed',
      timestamp: '2024-01-15 02:45 PM',
      user: 'Dr. Rajesh Kumar (Medical Officer)',
      description: 'Pre-auth approved for ₹2,50,000. Valid for 7 days.',
      extension: 'pre-auth',
      type: 'system',
    },
    {
      id: 'audit-query-1',
      stage: 'Internal Query',
      status: 'completed',
      timestamp: '2024-01-16 09:00 AM',
      user: 'Vikram Singh (Finance Officer)',
      description: 'Query to Medical Team: Please confirm if day care package applies for this procedure.',
      extension: 'pre-auth',
      type: 'internal-query',
    },
    {
      id: 'audit-query-response-1',
      stage: 'Query Response',
      status: 'completed',
      timestamp: '2024-01-16 10:30 AM',
      user: 'Dr. Rajesh Kumar (Medical Officer)',
      description: 'Response: This is a full hospitalization case, not day care. Standard surgical package applies.',
      extension: 'pre-auth',
      type: 'internal-query',
    },
    {
      id: 'audit-5',
      stage: 'Enhancement Requested',
      status: 'completed',
      timestamp: '2024-01-18 03:00 PM',
      user: 'Apollo Hospital',
      description: 'Enhancement request for additional ₹50,000 due to extended stay',
      extension: 'enhancement-1',
      type: 'system',
    },
    {
      id: 'audit-discussion-1',
      stage: 'Internal Discussion',
      status: 'completed',
      timestamp: '2024-01-18 04:00 PM',
      user: 'Team Discussion',
      description: 'Discussed enhancement request with medical and finance team. Agreed to approve based on clinical necessity. Extended ICU stay justified due to post-operative monitoring.',
      extension: 'enhancement-1',
      type: 'internal-discussion',
    },
    {
      id: 'audit-6',
      stage: 'Enhancement Approved',
      status: 'completed',
      timestamp: '2024-01-18 05:30 PM',
      user: 'Dr. Anita Desai (Medical Reviewer)',
      description: 'Enhancement approved. Total approved amount: ₹3,00,000',
      extension: 'enhancement-1',
      type: 'system',
    },
    {
      id: 'audit-7',
      stage: 'Patient Discharged',
      status: 'completed',
      timestamp: '2024-01-20 10:00 AM',
      user: 'Apollo Hospital',
      description: 'Patient discharged. Final bill amount: ₹2,85,000',
      extension: 'final-claim',
      type: 'system',
    },
    {
      id: 'audit-8',
      stage: 'Final Documents Received',
      status: 'completed',
      timestamp: '2024-01-20 03:30 PM',
      user: 'Apollo Hospital',
      description: 'Discharge summary, final bill, investigation reports uploaded',
      extension: 'final-claim',
      type: 'system',
    },
    {
      id: 'audit-note-2',
      stage: 'Internal Note',
      status: 'completed',
      timestamp: '2024-01-21 08:45 AM',
      user: 'Dr. Anita Desai (Medical Reviewer)',
      description: 'All clinical documents verified. Treatment protocol followed as per guidelines. Ready for financial review.',
      extension: 'final-claim',
      type: 'internal-note',
    },
    {
      id: 'audit-9',
      stage: 'Medical Adjudication Started',
      status: 'completed',
      timestamp: '2024-01-21 09:00 AM',
      user: 'Dr. Anita Desai (Medical Reviewer)',
      description: 'Claim assigned for medical review',
      extension: 'final-claim',
      type: 'system',
    },
    {
      id: 'audit-10',
      stage: 'Medical Adjudication Completed',
      status: 'completed',
      timestamp: '2024-01-22 04:30 PM',
      user: 'Dr. Anita Desai (Medical Reviewer)',
      description: 'Medical review completed. Claim admissible. Recommended for financial adjudication.',
      extension: 'final-claim',
      type: 'system',
    },
    {
      id: 'audit-11',
      stage: 'Financial Adjudication',
      status: 'in-progress',
      timestamp: '2024-01-23 10:00 AM',
      user: 'Vikram Singh (Finance Officer)',
      description: 'Claim under financial review',
      extension: 'final-claim',
      type: 'system',
    },
    {
      id: 'audit-12',
      stage: 'Payment Processing',
      status: 'pending',
      timestamp: '-',
      user: '-',
      description: 'Awaiting financial adjudication completion',
      extension: 'final-claim',
      type: 'system',
    },
    {
      id: 'audit-13',
      stage: 'Claim Settled',
      status: 'pending',
      timestamp: '-',
      user: '-',
      description: 'Pending payment processing',
      extension: 'final-claim',
      type: 'system',
    },
  ];

  // Updates summary calculation (must be after auditTrail definition)
  const updatesSummary = useMemo(() => {
    const newAuditEntries = auditTrail.filter(a => a.type === 'internal-note' || a.type === 'internal-query');
    return {
      totalNewItems: newAuditEntries.length,
      newAuditEntries,
      claimStatus: 'Final Claim',
      isFirstTimeAdjudication: false
    };
  }, []);

  const [selectedCommunication, setSelectedCommunication] = useState<any>(null);

  // Communications log data
  const communicationsLog = [
    {
      id: 'comm-1',
      type: 'Email',
      direction: 'Outbound',
      recipient: 'patient@email.com',
      recipientType: 'Customer',
      subject: 'Claim Registration Confirmation',
      timestamp: '2024-01-15 10:30 AM',
      status: 'Delivered',
      hasAttachment: true,
      extension: 'pre-auth',
      content: 'Dear Customer,\n\nYour health insurance claim has been successfully registered with us.\n\nClaim Details:\n- Claim ID: CLM-2024-001234\n- Hospital: Apollo Hospital, Delhi\n- Date of Admission: 15-Jan-2024\n- Estimated Amount: ₹2,50,000\n\nWe will review your claim and update you on the status within 24-48 hours.\n\nFor any queries, please contact our helpline at 1800-XXX-XXXX.\n\nBest Regards,\nACKO Health Insurance Team',
    },
    {
      id: 'comm-2',
      type: 'SMS',
      direction: 'Outbound',
      recipient: '+91 98765 43210',
      recipientType: 'Customer',
      subject: 'Document Request',
      timestamp: '2024-01-15 02:15 PM',
      status: 'Delivered',
      hasAttachment: false,
      extension: 'pre-auth',
      content: 'Dear Customer, Please upload the following documents for your claim CLM-2024-001234: 1) Discharge Summary 2) Final Bill 3) Investigation Reports. Upload via ACKO app or reply to this message. - ACKO',
    },
    {
      id: 'comm-3',
      type: 'Email',
      direction: 'Outbound',
      recipient: 'billing@hospital.com',
      recipientType: 'Hospital',
      subject: 'Bill Verification Request',
      timestamp: '2024-01-16 09:00 AM',
      status: 'Delivered',
      hasAttachment: true,
      extension: 'pre-auth',
      content: 'Dear Hospital Billing Team,\n\nWe are processing a health insurance claim for patient admitted at your facility.\n\nPatient Details:\n- Name: Rahul Sharma\n- UHID: APL-2024-5678\n- Admission Date: 15-Jan-2024\n\nPlease verify and confirm the following:\n1. Final itemized bill breakdown\n2. Procedures performed\n3. Any pending investigations\n\nKindly respond within 24 hours.\n\nRegards,\nACKO Claims Processing Team',
    },
    {
      id: 'comm-4',
      type: 'Phone Call',
      direction: 'Inbound',
      recipient: '+91 98765 43210',
      recipientType: 'Customer',
      subject: 'Query about claim status',
      timestamp: '2024-01-16 11:45 AM',
      status: 'Completed',
      duration: '5 mins',
      hasAttachment: false,
      extension: 'pre-auth',
      content: 'Call Summary:\n\nCaller: Customer (Rahul Sharma)\nDuration: 5 minutes\n\nQuery: Customer called to inquire about claim status and expected settlement date.\n\nResolution: Informed customer that claim is under review. Documents have been verified and claim will be processed within 2-3 business days. Customer was satisfied with the update.\n\nAgent: Priya Gupta (Agent ID: AG-1234)',
    },
    {
      id: 'comm-5',
      type: 'Email',
      direction: 'Inbound',
      recipient: 'billing@hospital.com',
      recipientType: 'Hospital',
      subject: 'RE: Bill Verification Request',
      timestamp: '2024-01-17 03:30 PM',
      status: 'Received',
      hasAttachment: true,
      extension: 'pre-auth',
      content: 'Dear ACKO Team,\n\nPlease find attached the verified bill details for patient Rahul Sharma:\n\n1. Final Bill Amount: ₹2,45,000\n2. Room Charges: ₹35,000 (5 days × ₹7,000)\n3. OT Charges: ₹85,000\n4. Medicine & Consumables: ₹45,000\n5. Investigation Charges: ₹25,000\n6. Surgeon Fees: ₹40,000\n7. Anaesthetist Fees: ₹15,000\n\nAll procedures have been completed as per medical protocol.\n\nRegards,\nApollo Hospital Billing Team',
    },
    {
      id: 'comm-6',
      type: 'Email',
      direction: 'Outbound',
      recipient: 'billing@hospital.com',
      recipientType: 'Hospital',
      subject: 'Enhancement Request Acknowledgement',
      timestamp: '2024-01-18 03:15 PM',
      status: 'Delivered',
      hasAttachment: false,
      extension: 'enhancement-1',
      content: 'Dear Hospital Billing Team,\n\nWe acknowledge receipt of your enhancement request for patient Rahul Sharma.\n\nEnhancement Details:\n- Additional Amount Requested: ₹50,000\n- Reason: Extended ICU stay\n\nWe are reviewing the request and will update you shortly.\n\nRegards,\nACKO Claims Processing Team',
    },
    {
      id: 'comm-7',
      type: 'SMS',
      direction: 'Outbound',
      recipient: '+91 98765 43210',
      recipientType: 'Customer',
      subject: 'Enhancement Approved',
      timestamp: '2024-01-18 06:00 PM',
      status: 'Delivered',
      hasAttachment: false,
      extension: 'enhancement-1',
      content: 'Dear Customer, Enhancement for your claim CLM-2024-001234 has been approved. Total approved amount is now ₹3,00,000. - ACKO',
    },
    {
      id: 'comm-8',
      type: 'Email',
      direction: 'Inbound',
      recipient: 'claims@acko.com',
      recipientType: 'Hospital',
      subject: 'Final Bill Submission',
      timestamp: '2024-01-20 04:00 PM',
      status: 'Received',
      hasAttachment: true,
      extension: 'final-claim',
      content: 'Dear ACKO Team,\n\nPlease find attached the final bill and discharge summary for patient Rahul Sharma.\n\nFinal Bill Amount: ₹2,85,000\n\nRegards,\nApollo Hospital Billing Team',
    },
    {
      id: 'comm-9',
      type: 'Phone Call',
      direction: 'Inbound',
      recipient: '+91 98765 43210',
      recipientType: 'Customer',
      subject: 'Follow-up on settlement timeline',
      timestamp: '2024-01-22 10:30 AM',
      status: 'Completed',
      duration: '3 mins',
      hasAttachment: false,
      extension: 'final-claim',
      content: 'Call Summary:\n\nCaller: Customer (Rahul Sharma)\nDuration: 3 minutes\n\nQuery: Customer inquired about final settlement timeline.\n\nResolution: Informed customer that claim is in final review stage and payment will be processed within 48 hours. Customer was satisfied.\n\nAgent: Amit Kumar (Agent ID: AG-5678)',
    },
  ];

  // Filtered communications
  const filteredCommunications = useMemo(() => {
    return communicationsLog.filter(comm => {
      const extensionMatch = commExtensionFilter === 'all' || comm.extension === commExtensionFilter;
      const directionMatch = commDirectionFilter === 'all' || comm.direction === commDirectionFilter;
      return extensionMatch && directionMatch;
    });
  }, [commExtensionFilter, commDirectionFilter]);

  // Filtered audit trail
  const filteredAuditTrail = useMemo(() => {
    return auditTrail.filter(event => {
      const extensionMatch = auditExtensionFilter === 'all' || event.extension === auditExtensionFilter;
      const typeMatch = auditTypeFilter === 'all' || (auditTypeFilter === 'internal-notes' && event.type === 'internal-note');
      return extensionMatch && typeMatch;
    });
  }, [auditExtensionFilter, auditTypeFilter]);

  const getAuditTypeIcon = (type: string) => {
    switch (type) {
      case 'internal-note':
        return <StickyNote className="h-3 w-3" />;
      case 'internal-query':
        return <MessageCircle className="h-3 w-3" />;
      case 'internal-discussion':
        return <MessageSquare className="h-3 w-3" />;
      default:
        return null;
    }
  };

  const getAuditTypeBadge = (type: string) => {
    switch (type) {
      case 'internal-note':
        return <Badge variant="outline" className="text-[10px] bg-amber-50 text-amber-700 border-amber-200">Note</Badge>;
      case 'internal-query':
        return <Badge variant="outline" className="text-[10px] bg-purple-50 text-purple-700 border-purple-200">Query</Badge>;
      case 'internal-discussion':
        return <Badge variant="outline" className="text-[10px] bg-indigo-50 text-indigo-700 border-indigo-200">Discussion</Badge>;
      default:
        return null;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'Email':
        return <Mail className="h-4 w-4" />;
      case 'SMS':
        return <MessageSquare className="h-4 w-4" />;
      case 'Phone Call':
        return <Phone className="h-4 w-4" />;
      default:
        return <Mail className="h-4 w-4" />;
    }
  };

  const getDirectionBadge = (direction: string) => {
    return direction === 'Inbound' ? (
      <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">Inbound</Badge>
    ) : (
      <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">Outbound</Badge>
    );
  };

  const getStatusBadge = (status: string) => {
    const statusStyles: { [key: string]: string } = {
      'Delivered': 'bg-green-100 text-green-700',
      'Received': 'bg-blue-100 text-blue-700',
      'Completed': 'bg-green-100 text-green-700',
      'Pending': 'bg-yellow-100 text-yellow-700',
      'Failed': 'bg-red-100 text-red-700',
    };
    return (
      <Badge className={`text-xs ${statusStyles[status] || 'bg-muted text-muted-foreground'}`}>
        {status}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate('/', { state: { step: 2, claimId: 'CLM-2024-001' } })}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div className="flex-1">
            <h1 className="text-lg font-semibold">Financial Adjudication</h1>
            <p className="text-xs text-muted-foreground">Review and process claim payment</p>
          </div>
          <Badge variant="secondary" className="bg-primary/10 text-primary">
            <CheckCircle className="h-3 w-3 mr-1" />
            Ready for Adjudication
          </Badge>

          {/* Updates Summary Popover */}
          <Popover open={isUpdatesSummaryOpen} onOpenChange={setIsUpdatesSummaryOpen}>
            <Tooltip>
              <TooltipTrigger asChild>
                <PopoverTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="icon"
                    className={cn(
                      "relative h-8 w-8",
                      updatesSummary.totalNewItems > 0 && "border-primary"
                    )}
                  >
                    <Bell className="h-4 w-4" />
                    {updatesSummary.totalNewItems > 0 && (
                      <span className="absolute -top-1.5 -right-1.5 h-4 min-w-4 px-1 flex items-center justify-center rounded-full bg-primary text-primary-foreground text-[10px] font-medium">
                        {updatesSummary.totalNewItems}
                      </span>
                    )}
                  </Button>
                </PopoverTrigger>
              </TooltipTrigger>
              <TooltipContent>Updates Summary</TooltipContent>
            </Tooltip>
            <PopoverContent align="end" className="w-[320px] p-0">
              <div className="p-4 border-b bg-muted/30">
                <div className="flex items-center gap-2">
                  <div className={cn(
                    "p-2 rounded-full",
                    updatesSummary.totalNewItems > 0 ? "bg-primary/10" : "bg-muted"
                  )}>
                    {updatesSummary.totalNewItems > 0 ? (
                      <RefreshCw className="h-4 w-4 text-primary" />
                    ) : (
                      <CheckCircle className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm">
                      {updatesSummary.isFirstTimeAdjudication 
                        ? 'First Time Adjudication' 
                        : `Claim Status: ${updatesSummary.claimStatus}`}
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      {updatesSummary.totalNewItems > 0 
                        ? `${updatesSummary.totalNewItems} internal notes/queries`
                        : 'No new updates'}
                    </p>
                  </div>
                </div>
              </div>
              {updatesSummary.totalNewItems > 0 ? (
                <div className="p-3 space-y-2 max-h-[300px] overflow-auto">
                  {updatesSummary.newAuditEntries.map((entry) => (
                    <div 
                      key={entry.id} 
                      className="flex items-start gap-2 text-xs p-2 bg-muted/50 rounded-md"
                    >
                      <StickyNote className="h-3.5 w-3.5 text-amber-600 flex-shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium">{entry.stage}</div>
                        <div className="text-muted-foreground truncate">{entry.description}</div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-4 text-center text-xs text-muted-foreground">
                  No new updates since last adjudication
                </div>
              )}
            </PopoverContent>
          </Popover>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="outline" 
                size="icon"
                className="h-8 w-8"
                onClick={handleSaveDraft}
              >
                <Save className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Save Draft</TooltipContent>
          </Tooltip>

          {/* Need More Details Button */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="outline" 
                size="sm"
                className="h-8 gap-2"
                onClick={() => setIsMoreDetailsModalOpen(true)}
              >
                <HelpCircle className="h-4 w-4" />
                <span className="text-xs">Need more details?</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>Access past claims, declarations, policies, and more</TooltipContent>
          </Tooltip>

          {/* Communications Sheet (triggered from modal) */}
          <Sheet open={isCommunicationsOpen} onOpenChange={setIsCommunicationsOpen}>
            <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto">
              <SheetHeader>
                <SheetTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-primary" />
                  Communications Log
                </SheetTitle>
                <SheetDescription>
                  All communications with customer and hospital for verification
                </SheetDescription>
              </SheetHeader>

              {/* Filters */}
              <div className="mt-4 flex flex-wrap gap-3 p-3 bg-muted/30 rounded-lg border">
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Filters:</span>
                </div>
                <Select value={commExtensionFilter} onValueChange={setCommExtensionFilter}>
                  <SelectTrigger className="w-[180px] h-8 text-xs">
                    <SelectValue placeholder="Claim Extension" />
                  </SelectTrigger>
                  <SelectContent className="bg-background border shadow-lg z-50">
                    {claimExtensions.map((ext) => (
                      <SelectItem key={ext.id} value={ext.id}>{ext.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={commDirectionFilter} onValueChange={setCommDirectionFilter}>
                  <SelectTrigger className="w-[140px] h-8 text-xs">
                    <SelectValue placeholder="Direction" />
                  </SelectTrigger>
                  <SelectContent className="bg-background border shadow-lg z-50">
                    <SelectItem value="all">All Directions</SelectItem>
                    <SelectItem value="Inbound">
                      <span className="flex items-center gap-2">
                        <ArrowDownLeft className="h-3 w-3 text-blue-600" />
                        Inbound (Customer/Hospital)
                      </span>
                    </SelectItem>
                    <SelectItem value="Outbound">
                      <span className="flex items-center gap-2">
                        <ArrowUpRight className="h-3 w-3 text-green-600" />
                        Outbound (ACKO)
                      </span>
                    </SelectItem>
                  </SelectContent>
                </Select>
                <Badge variant="secondary" className="text-xs">
                  {filteredCommunications.length} of {communicationsLog.length}
                </Badge>
              </div>

              {/* Direction Legend */}
              <div className="mt-3 flex gap-4 text-xs">
                <div className="flex items-center gap-1.5">
                  <ArrowDownLeft className="h-3.5 w-3.5 text-blue-600" />
                  <span className="text-muted-foreground">Inbound = From Customer/Hospital</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ArrowUpRight className="h-3.5 w-3.5 text-green-600" />
                  <span className="text-muted-foreground">Outbound = From ACKO</span>
                </div>
              </div>

              <div className="mt-4 space-y-4">
                {filteredCommunications.map((comm) => (
                  <div key={comm.id} className={cn(
                    "flex items-start gap-3 p-4 rounded-lg border transition-colors",
                    comm.direction === 'Inbound' 
                      ? "bg-blue-50/50 border-blue-200 dark:bg-blue-950/20 dark:border-blue-800" 
                      : "bg-green-50/50 border-green-200 dark:bg-green-950/20 dark:border-green-800"
                  )}>
                    <div className={cn(
                      "p-2.5 rounded-full shrink-0",
                      comm.type === 'Email' && "bg-blue-500/10 text-blue-600",
                      comm.type === 'SMS' && "bg-green-500/10 text-green-600",
                      comm.type === 'Phone Call' && "bg-orange-500/10 text-orange-600"
                    )}>
                      {getTypeIcon(comm.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-2">
                        {comm.direction === 'Inbound' ? (
                          <Badge className="text-xs bg-blue-100 text-blue-700 border-blue-300">
                            <ArrowDownLeft className="h-3 w-3 mr-1" />
                            From {comm.recipientType}
                          </Badge>
                        ) : (
                          <Badge className="text-xs bg-green-100 text-green-700 border-green-300">
                            <ArrowUpRight className="h-3 w-3 mr-1" />
                            To {comm.recipientType}
                          </Badge>
                        )}
                        {comm.hasAttachment && (
                          <Badge variant="secondary" className="text-xs">
                            <Paperclip className="h-3 w-3 mr-1" />
                            Attachment
                          </Badge>
                        )}
                        <Badge 
                          variant="outline" 
                          className={cn(
                            "text-xs",
                            comm.status === 'Delivered' && "border-green-500 text-green-600",
                            comm.status === 'Received' && "border-blue-500 text-blue-600",
                            comm.status === 'Completed' && "border-green-500 text-green-600"
                          )}
                        >
                          {comm.status}
                        </Badge>
                      </div>
                      <p className="font-medium text-sm">{comm.subject}</p>
                      <div className="flex items-center gap-2 mt-1.5 text-xs text-muted-foreground">
                        <span className={cn(
                          "px-1.5 py-0.5 rounded font-medium",
                          comm.recipientType === 'Customer' && "bg-primary/10 text-primary",
                          comm.recipientType === 'Hospital' && "bg-purple-500/10 text-purple-600"
                        )}>
                          {comm.recipientType}
                        </span>
                        <span>{comm.recipient}</span>
                        {comm.duration && <span>• Duration: {comm.duration}</span>}
                      </div>
                      <div className="flex items-center justify-between mt-3">
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {comm.timestamp}
                        </span>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-7 text-xs"
                          onClick={() => setSelectedCommunication(comm)}
                        >
                          <ExternalLink className="h-3 w-3 mr-1" />
                          View Content
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                {filteredCommunications.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>No communications match the selected filters</p>
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>

          {/* Audit Trail Sheet (triggered from modal) */}
          <Sheet open={isAuditTrailOpen} onOpenChange={setIsAuditTrailOpen}>
            <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto">
              <SheetHeader>
                <SheetTitle className="flex items-center gap-2">
                  <History className="h-5 w-5 text-primary" />
                  Audit Trail
                </SheetTitle>
                <SheetDescription>
                  Complete claim processing timeline including internal notes and discussions
                </SheetDescription>
              </SheetHeader>

              <div className="mt-4 flex flex-wrap gap-3 p-3 bg-muted/30 rounded-lg border">
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Filter:</span>
                </div>
                <Select value={auditExtensionFilter} onValueChange={setAuditExtensionFilter}>
                  <SelectTrigger className="w-[180px] h-8 text-xs">
                    <SelectValue placeholder="Claim Extension" />
                  </SelectTrigger>
                  <SelectContent className="bg-background border shadow-lg z-50">
                    {claimExtensions.map((ext) => (
                      <SelectItem key={ext.id} value={ext.id}>{ext.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={auditTypeFilter} onValueChange={setAuditTypeFilter}>
                  <SelectTrigger className="w-[160px] h-8 text-xs">
                    <SelectValue placeholder="Entry Type" />
                  </SelectTrigger>
                  <SelectContent className="bg-background border shadow-lg z-50">
                    <SelectItem value="all">All Entries</SelectItem>
                    <SelectItem value="internal-notes">
                      <span className="flex items-center gap-2">
                        <StickyNote className="h-3 w-3 text-amber-600" />
                        Internal Notes Only
                      </span>
                    </SelectItem>
                  </SelectContent>
                </Select>
                <Badge variant="secondary" className="text-xs">
                  {filteredAuditTrail.length} of {auditTrail.length}
                </Badge>
              </div>

              {/* Legend for internal items */}
              <div className="mt-3 flex flex-wrap gap-3 text-xs">
                <div className="flex items-center gap-1.5">
                  <StickyNote className="h-3.5 w-3.5 text-amber-600" />
                  <span className="text-muted-foreground">Internal Note</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <MessageCircle className="h-3.5 w-3.5 text-purple-600" />
                  <span className="text-muted-foreground">Internal Query</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <MessageSquare className="h-3.5 w-3.5 text-indigo-600" />
                  <span className="text-muted-foreground">Team Discussion</span>
                </div>
              </div>

              <div className="mt-4 relative">
                {/* Timeline line */}
                <div className="absolute left-[15px] top-2 bottom-2 w-0.5 bg-border" />
                
                <div className="space-y-4">
                  {filteredAuditTrail.map((event) => (
                    <div key={event.id} className={cn(
                      "relative flex gap-4 p-3 rounded-lg transition-colors",
                      event.type === 'internal-note' && "bg-amber-50/50 border border-amber-200 dark:bg-amber-950/20 dark:border-amber-800",
                      event.type === 'internal-query' && "bg-purple-50/50 border border-purple-200 dark:bg-purple-950/20 dark:border-purple-800",
                      event.type === 'internal-discussion' && "bg-indigo-50/50 border border-indigo-200 dark:bg-indigo-950/20 dark:border-indigo-800",
                      event.type === 'system' && "bg-transparent"
                    )}>
                      {/* Timeline dot */}
                      <div className="relative z-10 flex-shrink-0">
                        {event.type === 'internal-note' ? (
                          <div className="h-7 w-7 rounded-full bg-amber-100 border-2 border-amber-500 flex items-center justify-center">
                            <StickyNote className="h-3.5 w-3.5 text-amber-600" />
                          </div>
                        ) : event.type === 'internal-query' ? (
                          <div className="h-7 w-7 rounded-full bg-purple-100 border-2 border-purple-500 flex items-center justify-center">
                            <MessageCircle className="h-3.5 w-3.5 text-purple-600" />
                          </div>
                        ) : event.type === 'internal-discussion' ? (
                          <div className="h-7 w-7 rounded-full bg-indigo-100 border-2 border-indigo-500 flex items-center justify-center">
                            <MessageSquare className="h-3.5 w-3.5 text-indigo-600" />
                          </div>
                        ) : event.status === 'completed' ? (
                          <div className="h-7 w-7 rounded-full bg-green-100 border-2 border-green-500 flex items-center justify-center">
                            <CheckCircle className="h-3.5 w-3.5 text-green-600" />
                          </div>
                        ) : event.status === 'in-progress' ? (
                          <div className="h-7 w-7 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center animate-pulse">
                            <Circle className="h-3.5 w-3.5 text-primary fill-primary" />
                          </div>
                        ) : (
                          <div className="h-7 w-7 rounded-full bg-muted border-2 border-muted-foreground/30 flex items-center justify-center">
                            <Circle className="h-3.5 w-3.5 text-muted-foreground" />
                          </div>
                        )}
                      </div>
                      
                      {/* Content */}
                      <div className="flex-1 pb-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={cn(
                            "font-medium text-sm",
                            event.status === 'pending' && "text-muted-foreground"
                          )}>
                            {event.stage}
                          </span>
                          {getAuditTypeBadge(event.type)}
                          {event.status === 'in-progress' && (
                            <Badge className="bg-primary/20 text-primary text-xs">In Progress</Badge>
                          )}
                        </div>
                        <p className={cn(
                          "text-sm mt-1.5",
                          event.status === 'pending' ? "text-muted-foreground/60" : "text-muted-foreground",
                          (event.type === 'internal-note' || event.type === 'internal-query' || event.type === 'internal-discussion') && "italic"
                        )}>
                          {event.description}
                        </p>
                        <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                          {event.user !== '-' && (
                            <span className="flex items-center gap-1">
                              <User className="h-3 w-3" />
                              {event.user}
                            </span>
                          )}
                          {event.timestamp !== '-' && (
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {event.timestamp}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  {filteredAuditTrail.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <History className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p>No audit events match the selected filter</p>
                    </div>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Claim Summary Header */}
      <div className="border-b bg-card">
        <div className="container py-3">
          <div className="flex items-center gap-6 flex-wrap">
            {/* Customer & Policy */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">Priya Sharma</span>
              </div>
              <span className="text-muted-foreground">•</span>
              <span className="text-muted-foreground">ACKO-HLTH-001234</span>
            </div>

            {/* Separator */}
            <div className="h-8 w-px bg-border" />

            {/* Badges */}
            <div className="flex items-center gap-2">
              <Badge className="bg-blue-100 text-blue-700 border-blue-200">Reimbursement</Badge>
              <Badge className="bg-purple-100 text-purple-700 border-purple-200">Hospitalisation (IPD)</Badge>
              <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">ACKO_existing</Badge>
            </div>

            {/* Separator */}
            <div className="h-8 w-px bg-border" />

            {/* Hospital & Bank */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Building2 className="h-4 w-4 text-muted-foreground" />
                <span>Apollo Hospital</span>
              </div>
              <span className="text-muted-foreground">•</span>
              <div className="flex items-center gap-2">
                <CreditCard className="h-4 w-4 text-muted-foreground" />
                <span>****5678</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container py-6 space-y-6">
        {/* Medical Adjudication Summary - Collapsible */}
        <Collapsible open={isMedicalSummaryOpen} onOpenChange={setIsMedicalSummaryOpen}>
          <Card className="border-primary/20 bg-primary/5">
            <CollapsibleTrigger asChild>
              <CardHeader className="pb-3 cursor-pointer hover:bg-primary/10 transition-colors rounded-t-lg">
                <CardTitle className="flex items-center gap-2 text-base">
                  <ClipboardCheck className="h-4 w-4 text-primary" />
                  Medical Adjudication Summary
                  <Badge variant="secondary" className="ml-2 bg-green-100 text-green-700">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Completed
                  </Badge>
                  <div className="ml-auto">
                    {isMedicalSummaryOpen ? (
                      <ChevronUp className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                </CardTitle>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                {/* Clinical Coding */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-muted-foreground">Diagnosis & Coding</h4>
                    <div className="bg-background rounded-lg p-3 space-y-2 text-sm border">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Primary Diagnosis:</span>
                        <span className="font-medium">Acute Appendicitis (K35.80)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Procedure Code:</span>
                        <span className="font-medium">0DTJ4ZZ - Laparoscopic Appendectomy</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Line of Treatment:</span>
                        <span className="font-medium">Surgical</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-muted-foreground">Clinical Correlation</h4>
                    <div className="bg-background rounded-lg p-3 space-y-2 text-sm border">
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">ICD-PCS Correlation:</span>
                        <Badge className="bg-green-100 text-green-700">Strong</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Treatment Necessity:</span>
                        <Badge className="bg-green-100 text-green-700">Justified</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Medicine Correlation:</span>
                        <Badge className="bg-green-100 text-green-700">Aligned</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>


        {/* Communication Content Dialog */}
        <Dialog open={!!selectedCommunication} onOpenChange={() => setSelectedCommunication(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            {selectedCommunication && (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    {getTypeIcon(selectedCommunication.type)}
                    {selectedCommunication.subject}
                  </DialogTitle>
                  <DialogDescription asChild>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        {getDirectionBadge(selectedCommunication.direction)}
                        {getStatusBadge(selectedCommunication.status)}
                        <span className="text-xs">
                          {selectedCommunication.recipientType}: {selectedCommunication.recipient}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 text-xs">
                        <Clock className="h-3 w-3" />
                        {selectedCommunication.timestamp}
                        {selectedCommunication.duration && (
                          <span className="ml-2">• Duration: {selectedCommunication.duration}</span>
                        )}
                      </div>
                    </div>
                  </DialogDescription>
                </DialogHeader>
                <div className="mt-4 p-4 bg-muted/30 rounded-lg border">
                  <pre className="whitespace-pre-wrap text-sm font-sans">
                    {selectedCommunication.content}
                  </pre>
                </div>
                {selectedCommunication.hasAttachment && (
                  <div className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                    <Paperclip className="h-4 w-4" />
                    <span>This communication has attachments</span>
                    <Button variant="outline" size="sm" className="ml-auto text-xs">
                      View Attachments
                    </Button>
                  </div>
                )}
              </>
            )}
          </DialogContent>
        </Dialog>

        {/* Need More Details Modal */}
        <Dialog open={isMoreDetailsModalOpen} onOpenChange={setIsMoreDetailsModalOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <HelpCircle className="h-5 w-5 text-primary" />
                Need More Details?
              </DialogTitle>
              <DialogDescription>
                Access additional information about this claim
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 gap-3 py-4">
              {/* Past Claim Details */}
              <div className="space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full justify-start h-auto py-3"
                  asChild
                  onClick={() => setIsMoreDetailsModalOpen(false)}
                >
                  <Link to="/past-claims">
                    <Receipt className="h-5 w-5 mr-3 text-primary" />
                    <div className="text-left">
                      <div className="font-medium">View Past Claims</div>
                      <div className="text-xs text-muted-foreground">Browse all previous claims for this customer</div>
                    </div>
                  </Link>
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start h-auto py-3"
                  asChild
                  onClick={() => setIsMoreDetailsModalOpen(false)}
                >
                  <Link to="/past-extensions?claimId=CLM-2024-001">
                    <History className="h-5 w-5 mr-3 text-primary" />
                    <div className="text-left">
                      <div className="font-medium">View Past Extensions</div>
                      <div className="text-xs text-muted-foreground">Extensions to this specific claim</div>
                    </div>
                  </Link>
                </Button>
              </div>

              {/* Declarations */}
              <Button 
                variant="outline" 
                className="w-full justify-start h-auto py-3"
                asChild
                onClick={() => setIsMoreDetailsModalOpen(false)}
              >
                <Link to="/declarations">
                  <FileText className="h-5 w-5 mr-3 text-primary" />
                  <div className="text-left">
                    <div className="font-medium">View Declarations</div>
                    <div className="text-xs text-muted-foreground">Customer declarations and medical history</div>
                  </div>
                </Link>
              </Button>

              {/* All Policies */}
              <Button 
                variant="outline" 
                className="w-full justify-start h-auto py-3"
                asChild
                onClick={() => setIsMoreDetailsModalOpen(false)}
              >
                <Link to="/customer-policies">
                  <Shield className="h-5 w-5 mr-3 text-primary" />
                  <div className="text-left">
                    <div className="font-medium">View All Policies</div>
                    <div className="text-xs text-muted-foreground">Complete insurance portfolio for this customer</div>
                  </div>
                </Link>
              </Button>

              {/* Communications */}
              <Button 
                variant="outline" 
                className="w-full justify-start h-auto py-3"
                onClick={() => {
                  setIsMoreDetailsModalOpen(false);
                  setIsCommunicationsOpen(true);
                }}
              >
                <MessageSquare className="h-5 w-5 mr-3 text-primary" />
                <div className="text-left flex-1">
                  <div className="font-medium">Communications</div>
                  <div className="text-xs text-muted-foreground">All communications with customer and hospital</div>
                </div>
                <Badge variant="secondary" className="ml-2">{communicationsLog.length}</Badge>
              </Button>

              {/* Audit Trail */}
              <Button 
                variant="outline" 
                className="w-full justify-start h-auto py-3"
                onClick={() => {
                  setIsMoreDetailsModalOpen(false);
                  setIsAuditTrailOpen(true);
                }}
              >
                <History className="h-5 w-5 mr-3 text-primary" />
                <div className="text-left flex-1">
                  <div className="font-medium">Audit Trail</div>
                  <div className="text-xs text-muted-foreground">Complete history of claim processing</div>
                </div>
                <Badge variant="secondary" className="ml-2">{auditTrail.length}</Badge>
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Financial Summary */}
        <FinancialSummarySection />

        {/* Status & Next Action */}
        <StatusNextActionCard showDeductions={true} completeActionLabel="Approve claim" skipChecklistAnimation={true} />
      </main>
    </div>
  );
};

export default FinancialAdjudication;
