import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import PatientIdentificationStep from '../components/claim-registration/PatientIdentificationStep';
import DocumentUploadStep from '../components/claim-registration/DocumentUploadStep';
import QueryDetailsStep from '../components/claim-registration/QueryDetailsStep';

const RegisterNewClaim = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('claim');
  const [hasLookedUp, setHasLookedUp] = useState(false);
  
  // Claim registration states
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedPolicy, setSelectedPolicy] = useState<any>(null);
  const [selectedMember, setSelectedMember] = useState<any>(null);
  
  // Query registration states
  const [currentQueryStep, setCurrentQueryStep] = useState(0);
  const [querySelectedPolicy, setQuerySelectedPolicy] = useState<any>(null);
  const [querySelectedMember, setQuerySelectedMember] = useState<any>(null);
  const [queryDetails, setQueryDetails] = useState('');

  const steps = ['Patient Identification', 'Document Upload'];

  const handleNext = (data?: any) => {
    if (currentStep === 0) {
      setSelectedPolicy(data.policy);
      setSelectedMember(data.member);
      setHasLookedUp(true);
      setCurrentStep(prev => Math.min(prev + 1, steps.length - 1));
    }
  };

  const handleSubmit = (data: any) => {
    console.log('Claim registered:', {
      policy: selectedPolicy,
      member: selectedMember,
      documents: data.documents,
    });
    navigate('/');
  };

  const handleQuerySubmit = (data: any) => {
    console.log('Query registered:', {
      policy: querySelectedPolicy,
      member: querySelectedMember,
      queryDetails: queryDetails,
      documents: data.documents,
    });
    navigate('/');
  };

  const handleQueryIdentificationNext = (data: any) => {
    setQuerySelectedPolicy(data.policy);
    setQuerySelectedMember(data.member);
    setHasLookedUp(true);
    setCurrentQueryStep(1);
  };

  const handleQueryDetailsNext = (data: any) => {
    setQueryDetails(data.queryDetails);
    setCurrentQueryStep(2);
  };

  const handleQueryBack = () => {
    setCurrentQueryStep(prev => Math.max(prev - 1, 0));
  };

  const handleBack = () => {
    setCurrentStep(prev => Math.max(prev - 1, 0));
  };

  const handleCancel = () => {
    navigate('/');
  };

  const renderQueryStepContent = () => {
    switch (currentQueryStep) {
      case 0:
        return (
          <PatientIdentificationStep
            onNext={handleQueryIdentificationNext}
            onCancel={handleCancel}
          />
        );
      case 1:
        return (
          <QueryDetailsStep
            policyData={querySelectedPolicy}
            memberData={querySelectedMember}
            onNext={handleQueryDetailsNext}
            onBack={handleQueryBack}
            onCancel={handleCancel}
          />
        );
      case 2:
        return (
          <DocumentUploadStep
            policyData={querySelectedPolicy}
            memberData={querySelectedMember}
            onSubmit={handleQuerySubmit}
            onBack={handleQueryBack}
            onCancel={handleCancel}
            isOptional={true}
          />
        );
      default:
        return null;
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <PatientIdentificationStep
            onNext={handleNext}
            onCancel={handleCancel}
          />
        );
      case 1:
        return (
          <DocumentUploadStep
            policyData={selectedPolicy}
            memberData={selectedMember}
            onSubmit={handleSubmit}
            onBack={handleBack}
            onCancel={handleCancel}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card shadow-sm">
        <div className="flex h-16 items-center px-6">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate('/')}
            className="mr-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          <div className="flex items-center space-x-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground font-bold text-sm">
              A
            </div>
            <span className="text-xl font-bold text-primary">ACKO</span>
          </div>
        </div>
      </header>

      <div className="container mx-auto p-6 max-w-5xl">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Registration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {!hasLookedUp && (
              <RadioGroup value={activeTab} onValueChange={setActiveTab} className="flex flex-col space-y-3">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="claim" id="claim" />
                  <Label htmlFor="claim" className="cursor-pointer font-normal">
                    Register New Health Claim
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="query" id="query" />
                  <Label htmlFor="query" className="cursor-pointer font-normal">
                    Register Coverage Related Query
                  </Label>
                </div>
              </RadioGroup>
            )}

            {activeTab === 'claim' && (
              <div className="space-y-6">
                {renderStepContent()}
              </div>
            )}
            
            {activeTab === 'query' && (
              <div className="space-y-6">
                {renderQueryStepContent()}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RegisterNewClaim;
