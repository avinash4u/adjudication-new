import BillEntryDashboard from '@/components/BillEntryDashboard';

const Index = () => {
  return <BillEntryDashboard />;
};

export default Index;
