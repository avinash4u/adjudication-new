import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { ArrowLeft, User, Calendar, Receipt, Filter } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { format } from "date-fns";
import { cn } from "@/lib/utils";

const PastClaimDetails: React.FC = () => {
  const navigate = useNavigate();
  const [selectedUHID, setSelectedUHID] = useState<string>('');
  const [selectedPolicyId, setSelectedPolicyId] = useState<string>('ACKO-HLTH-001234');
  const [dateFrom, setDateFrom] = useState<Date>();
  const [dateTo, setDateTo] = useState<Date>();

  // Mock policy IDs
  const policyIds = [
    'ACKO-HLTH-001234',
    'ACKO-HLTH-001235',
    'ACKO-HLTH-001236'
  ];

  // Mock UHID data for the policy
  const uhidList = [
    {
      uhid: 'UHID001',
      name: 'Priya Sharma',
      age: '34 years',
      gender: 'Female'
    },
    {
      uhid: 'UHID002', 
      name: 'Rajesh Sharma',
      age: '38 years',
      gender: 'Male'
    },
    {
      uhid: 'UHID003',
      name: 'Anita Sharma',
      age: '65 years', 
      gender: 'Female'
    }
  ];

  // Mock past claims data
  const pastClaims = {
    'UHID001': [
      {
        claimId: 'CLM-2024-001',
        claimDate: new Date('2024-08-15'),
        hospitalName: 'Apollo Hospital',
        diagnosis: 'Appendicitis',
        claimAmount: '₹85,000',
        approvedAmount: '₹80,000',
        status: 'Settled',
        claimType: 'Cashless'
      },
      {
        claimId: 'CLM-2024-002', 
        claimDate: new Date('2024-11-20'),
        hospitalName: 'Fortis Hospital',
        diagnosis: 'Viral Fever',
        claimAmount: '₹15,000',
        approvedAmount: '₹12,000',
        status: 'Settled',
        claimType: 'Reimbursement'
      }
    ],
    'UHID002': [
      {
        claimId: 'CLM-2024-003',
        claimDate: new Date('2024-06-10'),
        hospitalName: 'Max Hospital',
        diagnosis: 'Diabetes Management',
        claimAmount: '₹25,000',
        approvedAmount: '₹20,000',
        status: 'Settled',
        claimType: 'Cashless'
      }
    ],
    'UHID003': [
      {
        claimId: 'CLM-2024-004',
        claimDate: new Date('2024-09-05'),
        hospitalName: 'AIIMS',
        diagnosis: 'Cataract Surgery',
        claimAmount: '₹45,000',
        approvedAmount: '₹40,000',
        status: 'Settled',
        claimType: 'Reimbursement'
      },
      {
        claimId: 'CLM-2024-005',
        claimDate: new Date('2024-12-01'),
        hospitalName: 'Medanta Hospital',
        diagnosis: 'Hypertension',
        claimAmount: '₹18,000',
        approvedAmount: '₹15,000',
        status: 'Settled',
        claimType: 'Cashless'
      }
    ]
  };

  const selectedUHIDInfo = uhidList.find(uhid => uhid.uhid === selectedUHID);
  const selectedClaims = selectedUHID ? pastClaims[selectedUHID as keyof typeof pastClaims] || [] : [];

  const getStatusBadge = (status: string) => {
    const statusColors = {
      'Settled': 'bg-green-500',
      'Rejected': 'bg-red-500',
      'Pending': 'bg-yellow-500',
    };
    return statusColors[status as keyof typeof statusColors] || 'bg-gray-500';
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button variant="outline" onClick={() => navigate('/')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <div>
          <h1 className="text-2xl font-bold">Past Claim Details</h1>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Filters</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Policy ID Selection */}
            <div className="space-y-2">
              <Label htmlFor="policy-id">Policy ID *</Label>
              <Select value={selectedPolicyId} onValueChange={setSelectedPolicyId}>
                <SelectTrigger id="policy-id">
                  <SelectValue placeholder="Select Policy ID" />
                </SelectTrigger>
                <SelectContent>
                  {policyIds.map((policyId) => (
                    <SelectItem key={policyId} value={policyId}>
                      {policyId}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Date From */}
            <div className="space-y-2">
              <Label>From Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !dateFrom && "text-muted-foreground"
                    )}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {dateFrom ? format(dateFrom, "dd/MM/yyyy") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={dateFrom}
                    onSelect={setDateFrom}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Date To */}
            <div className="space-y-2">
              <Label>To Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !dateTo && "text-muted-foreground"
                    )}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {dateTo ? format(dateTo, "dd/MM/yyyy") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={dateTo}
                    onSelect={setDateTo}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* UHID Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="h-5 w-5" />
            <span>Select Member</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <label className="text-sm font-medium">UHID:</label>
              <Select value={selectedUHID} onValueChange={setSelectedUHID}>
                <SelectTrigger className="w-[300px]">
                  <SelectValue placeholder="Select UHID to view past claims" />
                </SelectTrigger>
                <SelectContent>
                  {uhidList.map((uhid) => (
                    <SelectItem key={uhid.uhid} value={uhid.uhid}>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{uhid.uhid}</span>
                        <span className="text-muted-foreground">-</span>
                        <span>{uhid.name}</span>
                        <span className="text-muted-foreground">({uhid.age}, {uhid.gender})</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {selectedUHIDInfo && (
              <div className="p-4 bg-muted rounded-lg">
                <h3 className="font-medium">Selected Member Details:</h3>
                <div className="grid grid-cols-2 gap-4 mt-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Name:</span> {selectedUHIDInfo.name}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Age:</span> {selectedUHIDInfo.age}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Gender:</span> {selectedUHIDInfo.gender}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Total Past Claims:</span> {selectedClaims.length}
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Past Claims Table */}
      {selectedUHID && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Receipt className="h-5 w-5" />
              <span>Past Claims History</span>
              <Badge variant="secondary">{selectedClaims.length} claims</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedClaims.length > 0 ? (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Claim ID</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Hospital</TableHead>
                      <TableHead>Diagnosis</TableHead>
                      <TableHead>Claim Amount</TableHead>
                      <TableHead>Approved Amount</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedClaims.map((claim) => (
                      <TableRow key={claim.claimId}>
                        <TableCell className="font-medium">{claim.claimId}</TableCell>
                        <TableCell>{format(claim.claimDate, 'dd/MM/yyyy')}</TableCell>
                        <TableCell>{claim.hospitalName}</TableCell>
                        <TableCell>{claim.diagnosis}</TableCell>
                        <TableCell>{claim.claimAmount}</TableCell>
                        <TableCell>{claim.approvedAmount}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{claim.claimType}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="secondary" 
                            className={`text-white ${getStatusBadge(claim.status)}`}
                          >
                            {claim.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Receipt className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No past claims found for this member</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {!selectedUHID && (
        <Card>
          <CardContent className="py-8">
            <div className="text-center text-muted-foreground">
              <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Please select a UHID to view past claim details</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PastClaimDetails;