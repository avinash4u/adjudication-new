import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, FileText, Stethoscope, Phone, ArrowRightLeft, CheckCircle2, XCircle, Clock, Calendar, User, Building2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface Declaration {
  id: string;
  question: string;
  answer: string;
  declaredOn: string;
  category: 'medical' | 'lifestyle' | 'occupation' | 'travel';
}

interface MedicalCheckup {
  id: string;
  testName: string;
  result: string;
  normalRange: string;
  status: 'normal' | 'abnormal' | 'borderline';
  conductedOn: string;
  labName: string;
}

interface TeleMERRecord {
  id: string;
  callDate: string;
  duration: string;
  agentName: string;
  status: 'completed' | 'pending' | 'failed';
  summary: string;
  verifiedItems: string[];
}

interface PortabilityDetail {
  id: string;
  previousInsurer: string;
  policyNumber: string;
  portedYear: number;
  waitingPeriodServed: string;
  cumulativeBonus: string;
  preExistingConditions: string[];
  claimHistory: {
    year: number;
    claimsMade: number;
    totalAmount: number;
  }[];
}

const mockDeclarations: Declaration[] = [
  {
    id: '1',
    question: 'Do you have any pre-existing medical conditions?',
    answer: 'Yes - Diabetes Type 2 (diagnosed 2018)',
    declaredOn: '2024-01-15',
    category: 'medical',
  },
  {
    id: '2',
    question: 'Have you undergone any surgeries in the last 5 years?',
    answer: 'No',
    declaredOn: '2024-01-15',
    category: 'medical',
  },
  {
    id: '3',
    question: 'Do you consume tobacco or alcohol?',
    answer: 'Occasional alcohol consumption',
    declaredOn: '2024-01-15',
    category: 'lifestyle',
  },
  {
    id: '4',
    question: 'What is your current occupation?',
    answer: 'IT Professional - Software Engineer',
    declaredOn: '2024-01-15',
    category: 'occupation',
  },
  {
    id: '5',
    question: 'Do you travel frequently for work?',
    answer: 'Yes - Domestic travel 2-3 times per month',
    declaredOn: '2024-01-15',
    category: 'travel',
  },
  {
    id: '6',
    question: 'Are you currently on any medication?',
    answer: 'Yes - Metformin 500mg twice daily',
    declaredOn: '2024-01-15',
    category: 'medical',
  },
];

const mockMedicalCheckups: MedicalCheckup[] = [
  {
    id: '1',
    testName: 'Complete Blood Count (CBC)',
    result: 'Hb: 14.2 g/dL',
    normalRange: '13.5-17.5 g/dL',
    status: 'normal',
    conductedOn: '2024-01-10',
    labName: 'Dr. Lal PathLabs',
  },
  {
    id: '2',
    testName: 'Fasting Blood Sugar (FBS)',
    result: '142 mg/dL',
    normalRange: '70-100 mg/dL',
    status: 'abnormal',
    conductedOn: '2024-01-10',
    labName: 'Dr. Lal PathLabs',
  },
  {
    id: '3',
    testName: 'HbA1c',
    result: '7.2%',
    normalRange: '<5.7%',
    status: 'abnormal',
    conductedOn: '2024-01-10',
    labName: 'Dr. Lal PathLabs',
  },
  {
    id: '4',
    testName: 'Lipid Profile',
    result: 'Total Cholesterol: 195 mg/dL',
    normalRange: '<200 mg/dL',
    status: 'borderline',
    conductedOn: '2024-01-10',
    labName: 'Dr. Lal PathLabs',
  },
  {
    id: '5',
    testName: 'Liver Function Test (LFT)',
    result: 'SGPT: 32 U/L',
    normalRange: '7-56 U/L',
    status: 'normal',
    conductedOn: '2024-01-10',
    labName: 'Dr. Lal PathLabs',
  },
  {
    id: '6',
    testName: 'Kidney Function Test (KFT)',
    result: 'Creatinine: 0.9 mg/dL',
    normalRange: '0.7-1.3 mg/dL',
    status: 'normal',
    conductedOn: '2024-01-10',
    labName: 'Dr. Lal PathLabs',
  },
];

const mockTeleMER: TeleMERRecord[] = [
  {
    id: '1',
    callDate: '2024-01-12',
    duration: '18 mins',
    agentName: 'Priya Sharma',
    status: 'completed',
    summary: 'All medical declarations verified. Customer confirmed diabetes diagnosis and current medication.',
    verifiedItems: [
      'Identity verification completed',
      'Medical history confirmed',
      'Current medications verified',
      'Lifestyle declarations confirmed',
      'Occupation details verified',
    ],
  },
  {
    id: '2',
    callDate: '2024-01-14',
    duration: '8 mins',
    agentName: 'Rahul Verma',
    status: 'completed',
    summary: 'Follow-up call to verify pre-existing condition documentation.',
    verifiedItems: [
      'Diabetes diagnosis year confirmed',
      'Treatment history verified',
      'No hospitalization in last 2 years',
    ],
  },
];

const mockPortability: PortabilityDetail = {
  id: '1',
  previousInsurer: 'Star Health Insurance',
  policyNumber: 'STAR-HLTH-789456',
  portedYear: 2022,
  waitingPeriodServed: '3 years',
  cumulativeBonus: '25%',
  preExistingConditions: ['Diabetes Type 2'],
  claimHistory: [
    { year: 2021, claimsMade: 1, totalAmount: 45000 },
    { year: 2022, claimsMade: 0, totalAmount: 0 },
    { year: 2023, claimsMade: 2, totalAmount: 125000 },
  ],
};

const getCategoryColor = (category: Declaration['category']) => {
  switch (category) {
    case 'medical':
      return 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400';
    case 'lifestyle':
      return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400';
    case 'occupation':
      return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400';
    case 'travel':
      return 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400';
    default:
      return 'bg-muted text-muted-foreground';
  }
};

const getStatusBadge = (status: MedicalCheckup['status']) => {
  switch (status) {
    case 'normal':
      return <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"><CheckCircle2 className="h-3 w-3 mr-1" />Normal</Badge>;
    case 'abnormal':
      return <Badge className="bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400"><XCircle className="h-3 w-3 mr-1" />Abnormal</Badge>;
    case 'borderline':
      return <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"><AlertCircle className="h-3 w-3 mr-1" />Borderline</Badge>;
    default:
      return null;
  }
};

const getTeleMERStatusBadge = (status: TeleMERRecord['status']) => {
  switch (status) {
    case 'completed':
      return <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"><CheckCircle2 className="h-3 w-3 mr-1" />Completed</Badge>;
    case 'pending':
      return <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
    case 'failed':
      return <Badge className="bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400"><XCircle className="h-3 w-3 mr-1" />Failed</Badge>;
    default:
      return null;
  }
};

const Declarations = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-semibold">Customer Declarations</h1>
              <p className="text-sm text-muted-foreground">Policy: ACKO-HLTH-123456 | Rajesh Kumar</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-6 py-6">
        <Tabs defaultValue="declarations" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
            <TabsTrigger value="declarations" className="gap-2">
              <FileText className="h-4 w-4" />
              Declarations
            </TabsTrigger>
            <TabsTrigger value="medical-checkup" className="gap-2">
              <Stethoscope className="h-4 w-4" />
              Medical Checkup
            </TabsTrigger>
            <TabsTrigger value="telemer" className="gap-2">
              <Phone className="h-4 w-4" />
              TeleMER
            </TabsTrigger>
            <TabsTrigger value="portability" className="gap-2">
              <ArrowRightLeft className="h-4 w-4" />
              Portability
            </TabsTrigger>
          </TabsList>

          {/* Customer Declarations Tab */}
          <TabsContent value="declarations" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Customer Declarations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockDeclarations.map((declaration) => (
                    <div key={declaration.id} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <p className="font-medium text-foreground">{declaration.question}</p>
                          <p className="text-sm text-muted-foreground mt-1">{declaration.answer}</p>
                        </div>
                        <Badge className={getCategoryColor(declaration.category)}>
                          {declaration.category.charAt(0).toUpperCase() + declaration.category.slice(1)}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        Declared on: {new Date(declaration.declaredOn).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pre-Policy Medical Checkup Tab */}
          <TabsContent value="medical-checkup" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Stethoscope className="h-5 w-5" />
                    Pre-Policy Medical Checkup Reports
                  </CardTitle>
                  <Badge variant="outline" className="gap-1">
                    <Building2 className="h-3 w-3" />
                    Dr. Lal PathLabs
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Test Name</TableHead>
                      <TableHead>Result</TableHead>
                      <TableHead>Normal Range</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockMedicalCheckups.map((checkup) => (
                      <TableRow key={checkup.id}>
                        <TableCell className="font-medium">{checkup.testName}</TableCell>
                        <TableCell>{checkup.result}</TableCell>
                        <TableCell className="text-muted-foreground">{checkup.normalRange}</TableCell>
                        <TableCell>{getStatusBadge(checkup.status)}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {new Date(checkup.conductedOn).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* TeleMER Tab */}
          <TabsContent value="telemer" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Phone className="h-5 w-5" />
                  TeleMER Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {mockTeleMER.map((record) => (
                  <div key={record.id} className="border rounded-lg p-4 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{record.agentName}</span>
                          </div>
                          {getTeleMERStatusBadge(record.status)}
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(record.callDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            Duration: {record.duration}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <p className="text-sm font-medium mb-2">Summary</p>
                      <p className="text-sm text-muted-foreground">{record.summary}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-2">Verified Items</p>
                      <div className="space-y-1">
                        {record.verifiedItems.map((item, index) => (
                          <div key={index} className="flex items-center gap-2 text-sm">
                            <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                            <span>{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Portability Tab */}
          <TabsContent value="portability" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ArrowRightLeft className="h-5 w-5" />
                  Portability Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Previous Insurer Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-muted-foreground">Previous Insurer</p>
                    <p className="font-medium mt-1">{mockPortability.previousInsurer}</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-muted-foreground">Previous Policy Number</p>
                    <p className="font-medium mt-1">{mockPortability.policyNumber}</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-muted-foreground">Ported Year</p>
                    <p className="font-medium mt-1">{mockPortability.portedYear}</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-muted-foreground">Waiting Period Served</p>
                    <p className="font-medium mt-1">{mockPortability.waitingPeriodServed}</p>
                  </div>
                </div>

                <Separator />

                {/* Benefits */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-muted-foreground mb-2">Cumulative Bonus Carried Forward</p>
                    <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 text-lg">
                      {mockPortability.cumulativeBonus}
                    </Badge>
                  </div>
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-muted-foreground mb-2">Pre-existing Conditions (Covered)</p>
                    <div className="flex flex-wrap gap-2">
                      {mockPortability.preExistingConditions.map((condition, index) => (
                        <Badge key={index} variant="outline">{condition}</Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Claim History */}
                <div>
                  <p className="text-sm font-medium mb-4">Claim History with Previous Insurer</p>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Year</TableHead>
                        <TableHead>Claims Made</TableHead>
                        <TableHead>Total Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {mockPortability.claimHistory.map((history, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{history.year}</TableCell>
                          <TableCell>{history.claimsMade}</TableCell>
                          <TableCell>₹{history.totalAmount.toLocaleString('en-IN')}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Declarations;
