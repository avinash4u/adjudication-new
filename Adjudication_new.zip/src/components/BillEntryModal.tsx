import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon, Plus, Trash2 } from 'lucide-react';
import { cn } from "@/lib/utils";

interface Bill {
  id: string;
  billNumber: string;
  billDate: Date | undefined;
  amount: number;
}

interface Deduction {
  id: string;
  amount: number;
  reason: string;
}

interface BillEntryModalProps {
  open: boolean;
  onClose: () => void;
  currentAmount?: number;
}

export const BillEntryModal: React.FC<BillEntryModalProps> = ({
  open,
  onClose,
  currentAmount = 0
}) => {
  const [bills, setBills] = useState<Bill[]>([
    {
      id: '1',
      billNumber: 'BILL001',
      billDate: new Date('2025-03-28'),
      amount: 50000
    },
    {
      id: '2',
      billNumber: 'BILL002',
      billDate: new Date('2025-03-29'),
      amount: 25000
    }
  ]);

  const [deductions, setDeductions] = useState<Deduction[]>([
    {
      id: '1',
      amount: 5000,
      reason: 'Administrative charge discount'
    }
  ]);

  const [newBill, setNewBill] = useState({
    billNumber: '',
    billDate: undefined as Date | undefined,
    amount: 0
  });

  const [newDeduction, setNewDeduction] = useState({
    amount: 0,
    reason: ''
  });

  const addBill = () => {
    if (newBill.billNumber && newBill.billDate && newBill.amount > 0) {
      setBills(prev => [...prev, {
        id: Date.now().toString(),
        billNumber: newBill.billNumber,
        billDate: newBill.billDate,
        amount: newBill.amount
      }]);
      setNewBill({ billNumber: '', billDate: undefined, amount: 0 });
    }
  };

  const addDeduction = () => {
    if (newDeduction.amount > 0 && newDeduction.reason.trim()) {
      setDeductions(prev => [...prev, {
        id: Date.now().toString(),
        amount: newDeduction.amount,
        reason: newDeduction.reason
      }]);
      setNewDeduction({ amount: 0, reason: '' });
    }
  };

  const removeBill = (id: string) => {
    setBills(prev => prev.filter(bill => bill.id !== id));
  };

  const removeDeduction = (id: string) => {
    setDeductions(prev => prev.filter(deduction => deduction.id !== id));
  };

  const totalBilledAmount = bills.reduce((sum, bill) => sum + bill.amount, 0);
  const totalDeductions = deductions.reduce((sum, deduction) => sum + deduction.amount, 0);
  const finalAmount = totalBilledAmount - totalDeductions;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Bill Entry and Deductions Management</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Bills Section */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Bills</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Bill Number</TableHead>
                  <TableHead>Bill Date</TableHead>
                  <TableHead>Amount (₹)</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bills.map((bill) => (
                  <TableRow key={bill.id}>
                    <TableCell>{bill.billNumber}</TableCell>
                    <TableCell>
                      {bill.billDate ? format(bill.billDate, 'dd MMM yyyy') : 'Not set'}
                    </TableCell>
                    <TableCell>₹{bill.amount.toLocaleString()}</TableCell>
                    <TableCell>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => removeBill(bill.id)}
                        className="text-destructive hover:text-destructive/80"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                
                {/* Add New Bill Row */}
                <TableRow className="border-t-2">
                  <TableCell>
                    <Input
                      placeholder="Enter bill number"
                      value={newBill.billNumber}
                      onChange={(e) => setNewBill(prev => ({ ...prev, billNumber: e.target.value }))}
                    />
                  </TableCell>
                  <TableCell>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !newBill.billDate && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {newBill.billDate ? format(newBill.billDate, 'dd MMM yyyy') : 'Pick a date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={newBill.billDate}
                          onSelect={(date) => setNewBill(prev => ({ ...prev, billDate: date }))}
                          initialFocus
                          className="p-3 pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      placeholder="Enter amount"
                      value={newBill.amount || ''}
                      onChange={(e) => setNewBill(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                    />
                  </TableCell>
                  <TableCell>
                    <Button onClick={addBill} size="sm" className="w-full">
                      <Plus className="h-4 w-4 mr-1" />
                      Add Bill
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          {/* Deductions Section */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Deductions</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Amount (₹)</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {deductions.map((deduction) => (
                  <TableRow key={deduction.id}>
                    <TableCell>₹{deduction.amount.toLocaleString()}</TableCell>
                    <TableCell>{deduction.reason}</TableCell>
                    <TableCell>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => removeDeduction(deduction.id)}
                        className="text-destructive hover:text-destructive/80"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                
                {/* Add New Deduction Row */}
                <TableRow className="border-t-2">
                  <TableCell>
                    <Input
                      type="number"
                      placeholder="Enter amount"
                      value={newDeduction.amount || ''}
                      onChange={(e) => setNewDeduction(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                    />
                  </TableCell>
                  <TableCell>
                    <Textarea
                      placeholder="Enter deduction reason"
                      value={newDeduction.reason}
                      onChange={(e) => setNewDeduction(prev => ({ ...prev, reason: e.target.value }))}
                      className="min-h-[40px]"
                    />
                  </TableCell>
                  <TableCell>
                    <Button onClick={addDeduction} size="sm" className="w-full">
                      <Plus className="h-4 w-4 mr-1" />
                      Add Deduction
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          {/* Summary Section */}
          <div className="bg-muted/20 p-4 rounded-lg space-y-2">
            <div className="flex justify-between">
              <span>Total Billed Amount:</span>
              <span className="font-semibold">₹{totalBilledAmount.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span>Total Deductions:</span>
              <span className="font-semibold text-destructive">- ₹{totalDeductions.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-lg font-bold border-t pt-2">
              <span>Final Amount:</span>
              <span>₹{finalAmount.toLocaleString()}</span>
            </div>
            {currentAmount !== finalAmount && (
              <div className="text-sm text-amber-600">
                Note: Final amount (₹{finalAmount.toLocaleString()}) differs from current claim amount (₹{currentAmount.toLocaleString()})
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={onClose}>
              Save Changes
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};