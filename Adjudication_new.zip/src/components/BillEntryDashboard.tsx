import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import ClaimDetailView from './ClaimDetailView';
import RegisterNewClaimModal from './RegisterNewClaimModal';
import { GlobalSearchModal } from './GlobalSearchModal';
import StatusNextActionCard from '@/components/StatusNextActionCard';
import { Search, Bell, User, Filter, MoreHorizontal, Clock, CheckCircle, AlertTriangle, FileText, Play, Settings, Plus, TrendingUp, TrendingDown, LogOut, UserCircle, ChevronRight, Moon, Sun, Users, FileWarning, Activity, Keyboard } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { useTheme } from 'next-themes';
import { useNavigate, useLocation } from 'react-router-dom';
const BillEntryDashboard = () => {
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const locationState = location.state as { step?: number; claimId?: string } | null;
  const [selectedClaim, setSelectedClaim] = useState<string | null>(locationState?.claimId || null);
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showGlobalSearch, setShowGlobalSearch] = useState(false);
  const [showCompletedTasks, setShowCompletedTasks] = useState(false);
  const [isAvailable, setIsAvailable] = useState(true);
  const [showBreakSchedule, setShowBreakSchedule] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [completedTasksSearch, setCompletedTasksSearch] = useState('');
  const [completedTasksFilter, setCompletedTasksFilter] = useState('all');
  const [taskAllocatedTime, setTaskAllocatedTime] = useState(0);

  // Timer for allocated task
  useEffect(() => {
    const startTime = Date.now() - (2 * 60 * 60 * 1000 + 15 * 60 * 1000); // Started 2h 15m ago
    
    const timer = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      setTaskAllocatedTime(elapsed);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatElapsedTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${secs}s`;
    } else {
      return `${secs}s`;
    }
  };

  // Variation 3 - Bank Details States
  const [paymentMethod, setPaymentMethod] = useState<'bank' | 'upi'>('bank');
  const [accountNumberMasked, setAccountNumberMasked] = useState('');
  const [accountNumberActual, setAccountNumberActual] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  const [bankAddress, setBankAddress] = useState('');
  const [beneficiaryName, setBeneficiaryName] = useState('');
  const [upiId, setUpiId] = useState('');
  const [upiValidated, setUpiValidated] = useState(false);
  const [upiBeneficiaryName, setUpiBeneficiaryName] = useState('');
  const [accountMatchError, setAccountMatchError] = useState(false);
  const [isLoadingBankDetails, setIsLoadingBankDetails] = useState(false);
  
  // List of insureds for the policy
  const insureds = [
    { id: '1', name: 'Rajesh Kumar', relation: 'Self' },
    { id: '2', name: 'Priya Kumar', relation: 'Spouse' },
    { id: '3', name: 'Aarav Kumar', relation: 'Son' },
    { id: '4', name: 'Diya Kumar', relation: 'Daughter' }
  ];
  
  // Penny Drop Validation States
  const [pennyDropStep, setPennyDropStep] = useState<'form' | 'initiating' | 'validating' | 'result'>('form');
  const [pennyDropFetchedName, setPennyDropFetchedName] = useState('');
  const [nameMatchStatus, setNameMatchStatus] = useState<'matched' | 'not-matched' | null>(null);
  const [activeTab, setActiveTab] = useState('task-manager');
  const notificationCount = 3;
  const toBeProcessedClaims = claimsData.filter(claim => claim.status === 'In Progress' || claim.status === 'Not started');
  const completedClaims = claimsData.filter(claim => claim.status === 'Completed');
  if (selectedClaim) {
    return <ClaimDetailView claimId={selectedClaim} onBack={() => setSelectedClaim(null)} />;
  }
  return <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card shadow-sm">
        <div className="flex h-16 items-center px-6">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground font-bold text-sm">
                A
              </div>
              <span className="text-xl font-bold text-primary">ACKO</span>
            </div>
            
            <nav className="flex items-center space-x-1">
              <Button variant="ghost" size="sm" className={activeTab === 'task-manager' ? 'bg-primary/10 text-primary' : 'text-muted-foreground'} onClick={() => setActiveTab('task-manager')}>
                Task Manager
              </Button>
              <Button variant="ghost" size="sm" className={activeTab === 'performance' ? 'bg-primary/10 text-primary' : 'text-muted-foreground'} onClick={() => setActiveTab('performance')}>
                Performance
              </Button>
              <Button variant="ghost" size="sm" className={activeTab === 'variations' ? 'bg-primary/10 text-primary' : 'text-muted-foreground'} onClick={() => setActiveTab('variations')}>
                Card Variations
              </Button>
            </nav>
          </div>
          
          <div className="ml-auto flex items-center space-x-4">
            <div className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-muted/50">
              <span className={`text-sm font-medium ${isAvailable ? 'text-success' : 'text-muted-foreground'}`}>
                {isAvailable ? 'Available' : 'Unavailable'}
              </span>
              <Switch checked={isAvailable} onCheckedChange={setIsAvailable} className="data-[state=checked]:bg-success" />
            </div>
            <Button variant="ghost" size="icon" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </Button>
            <div className="relative">
              <Button variant="ghost" size="icon" onClick={() => setShowNotifications(!showNotifications)}>
                <Bell className="h-5 w-5" />
                {notificationCount > 0 && <span className="absolute top-1 right-1 h-4 w-4 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center">
                    {notificationCount}
                  </span>}
              </Button>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <UserCircle className="mr-2 h-4 w-4" />
                  My Profile
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Keyboard className="mr-2 h-4 w-4" />
                  Keyboard Shortcuts
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>


      <div className="p-6 space-y-6">
        {activeTab === 'task-manager' && <>
        {/* Top Section with Task Card and Metrics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Next Task Card */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <div className="flex items-center justify-between mb-2">
                <CardTitle className="text-sm text-muted-foreground">Next task to perform</CardTitle>
                <div className="flex items-center space-x-2 px-3 py-1 bg-muted/50 rounded-md">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium text-foreground">
                    Allocated for {formatElapsedTime(taskAllocatedTime)}
                  </span>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold">Adjudication</h3>
                  
                  <div className="flex items-start gap-3 mt-3">
                    {/* Customer Level */}
                    <div className="flex items-center flex-wrap gap-2 flex-1">
                      <Users className="h-3.5 w-3.5 text-blue-500 flex-shrink-0" />
                      <Badge variant="outline">ACKO_existing</Badge>
                      <Badge className="bg-amber-500 text-white hover:bg-amber-600">VIP</Badge>
                    </div>
                    
                    <div className="h-6 w-px bg-border flex-shrink-0" />
                    
                    {/* Claim Level */}
                    <div className="flex items-center flex-wrap gap-2 flex-1">
                      <FileWarning className="h-3.5 w-3.5 text-red-500 flex-shrink-0" />
                      <Badge variant="destructive">SLA breached</Badge>
                    </div>
                    
                    <div className="h-6 w-px bg-border flex-shrink-0" />
                    
                    {/* Status Level */}
                    <div className="flex items-center flex-wrap gap-2 flex-1">
                      <Activity className="h-3.5 w-3.5 text-purple-500 flex-shrink-0" />
                      <Badge variant="secondary">Repeat</Badge>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Claim ID</span>
                    <span className="font-medium text-primary">HLTHCR5474</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Patient Name</span>
                    <span className="font-medium">Rajesh Kumar</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Claim Type</span>
                    <Badge variant="outline">Cashless</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Claim Subtype</span>
                    <span className="font-medium">Hospitalization</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Request Type</span>
                    <span className="font-medium">Pre-authorization</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status</span>
                    <Badge variant="not-started">Query Response</Badge>
                  </div>
                </div>
                
                <Button className="w-full bg-foreground text-background hover:bg-foreground/90" onClick={() => setSelectedClaim('HLTHCR5474')}>
                  <Play className="mr-2 h-4 w-4" />
                  Start
                </Button>
              </div>
            </CardHeader>
          </Card>
          
          {/* Combined Progress Circle and Metrics */}
          <Card className="lg:col-span-1">
            <CardContent className="p-6">
                <div>
                  <h4 className="text-sm font-semibold mb-3">Today's snapshot</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1 cursor-pointer hover:bg-primary/5 p-3 rounded-lg transition-all border-2 border-transparent hover:border-primary/20 hover:shadow-sm group" onClick={() => setShowCompletedTasks(true)}>
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-muted-foreground">Total tasks today</div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                      </div>
                      <div className="text-2xl font-bold text-primary">18</div>
                      <div className="flex items-center space-x-1 text-xs">
                        <TrendingUp className="h-3 w-3 text-success" />
                        <span className="text-success">+12% from last 7 days avg</span>
                      </div>
                      <div className="text-xs text-primary font-medium mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        View completed tasks →
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Average time/task</div>
                      <div className="text-2xl font-bold">24m</div>
                      <div className="flex items-center space-x-1 text-xs">
                        <TrendingDown className="h-3 w-3 text-success" />
                        <span className="text-success">-8% from last 7 days avg</span>
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex items-center space-x-1">
                        <CheckCircle className="h-4 w-4 text-success" />
                        <span className="text-sm text-muted-foreground">On time</span>
                      </div>
                      <div className="text-2xl font-bold">11<span className="text-lg text-muted-foreground">/18</span></div>
                      <div className="text-xs text-muted-foreground">15 in last 7 days</div>
                      <div className="flex items-center space-x-1 text-xs">
                        <TrendingUp className="h-3 w-3 text-success" />
                        <span className="text-success">+15% from last 7 days avg</span>
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex items-center space-x-1">
                        <AlertTriangle className="h-4 w-4 text-destructive" />
                        <span className="text-sm text-muted-foreground">Breached</span>
                      </div>
                      <div className="text-2xl font-bold">5<span className="text-lg text-muted-foreground">/18</span></div>
                      <div className="text-xs text-muted-foreground">8 in last 7 days</div>
                      <div className="flex items-center space-x-1 text-xs">
                        <TrendingDown className="h-3 w-3 text-success" />
                        <span className="text-success">-20% from last 7 days avg</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Availability Metrics */}
                <div className="mt-6 pt-6 border-t">
                  <h4 className="text-sm font-semibold mb-3">Availability</h4>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Log in time</div>
                      <div className="text-lg font-bold">09:00 AM</div>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Hours logged</div>
                      <div className="text-lg font-bold">5h 30m</div>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Breaks</div>
                      <div className="text-lg font-bold">30 min</div>
                    </div>
                  </div>
                </div>
            </CardContent>
          </Card>
        </div>

          </>}

        {activeTab === 'performance' && <Card>
            <CardHeader>
              <CardTitle>Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Performance metrics and analytics will be displayed here.
              </p>
            </CardContent>
          </Card>}

        {activeTab === 'variations' && <Card>
            <CardHeader>
              <CardTitle>Design Variations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Capture and manage different design variations for claims.
                </p>
                
                 <div className="space-y-3">
                  <div className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-medium text-sm">Pull new task</h4>
                        <p className="text-xs text-muted-foreground">Created on 14 Oct 2025, 10:30</p>
                      </div>
                      <Badge variant="outline">Active</Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-3">
                      <Card className="lg:col-span-1">
                        <CardContent className="p-6 flex flex-col items-center justify-center min-h-[200px] space-y-4">
                          <div className="text-center space-y-2">
                            <h3 className="text-lg font-semibold">Adjudication</h3>
                            <p className="text-sm text-muted-foreground">
                              Ready to process the next task
                            </p>
                          </div>
                          
                          <Button className="w-full bg-foreground text-background hover:bg-foreground/90" onClick={() => setSelectedClaim('HLTHCR5474')}>
                            <Play className="mr-2 h-4 w-4" />
                            Get new task
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-medium text-sm">Card on the details page - bottom right</h4>
                        <p className="text-xs text-muted-foreground">Created on 14 Oct 2025, 11:00</p>
                      </div>
                      <Badge variant="secondary">Draft</Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-3">
                      <Card className="lg:col-span-1 bg-purple-50 border-purple-100">
                        <CardContent className="p-6 space-y-4">
                          <div className="flex items-start gap-3">
                            <div className="w-2 h-2 rounded-full bg-purple-600 mt-2 flex-shrink-0" />
                            <div className="flex-1 space-y-1">
                              <h3 className="text-lg font-semibold text-foreground">Need review?</h3>
                              <p className="text-sm text-muted-foreground">
                                Unable to process? Pass this task to your Team Lead for review.
                              </p>
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Reason for passing</label>
                            <Select>
                              <SelectTrigger className="w-full bg-background">
                                <SelectValue placeholder="Select a reason..." />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="missing-documents">Missing required documents</SelectItem>
                                <SelectItem value="unclear-information">Unclear or incomplete information</SelectItem>
                                <SelectItem value="technical-issue">Technical issue or system error</SelectItem>
                                <SelectItem value="requires-expertise">Requires specialized expertise</SelectItem>
                                <SelectItem value="other">Other reason</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                            <ChevronRight className="mr-2 h-4 w-4" />
                            Submit for review
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-medium text-sm">Status & Next Action - Rejection Case</h4>
                        <p className="text-xs text-muted-foreground">Created on 14 Oct 2025, 11:30</p>
                      </div>
                      <Badge variant="destructive">Rejection</Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-3">
                      <StatusNextActionCard 
                        showDeductions={false}
                        defaultAction="reject"
                        systemRecommendation={{
                          recommendedAction: "reject",
                          confidence: "high",
                          categories: [
                            {
                              id: "member-policy",
                              title: "Member & Policy Eligibility Checks",
                              objective: "Confirm the claimant and policy are eligible for coverage.",
                              status: "passed",
                              items: [
                                { label: "Member covered under policy on Date of Admission (DoA)", status: "passed" },
                                { label: "Policy active and valid during treatment period", status: "passed" },
                                { label: "Correct policy type applied (Retail / GMC / GPA)", status: "passed", detail: "Retail" },
                                { label: "Insured person details match policy records", status: "passed" },
                                { label: "Coverage applicable for claimed benefit type (IPD/OPD/Daycare)", status: "passed", detail: "IPD" },
                              ],
                            },
                            {
                              id: "disease-treatment",
                              title: "Disease / Treatment Eligibility Checks",
                              objective: "Validate medical appropriateness and coverage eligibility.",
                              status: "failed",
                              items: [
                                { label: "Treatment covered under policy terms", status: "failed", detail: "PED-related treatment not covered" },
                                { label: "Correct ICD / procedure mapping", status: "passed" },
                              ],
                            },
                            {
                              id: "waiting-exclusion",
                              title: "Waiting Period & Exclusion Checks",
                              objective: "Ensure no policy restrictions are violated.",
                              status: "failed",
                              items: [
                                { label: "No initial waiting period violation", status: "passed" },
                                { label: "No disease-specific waiting period breach", status: "passed" },
                                { label: "No pre-existing disease (PED) violation", status: "failed", detail: "Diabetes Mellitus Type 2 - diagnosed 2019, only 10 months elapsed" },
                                { label: "No permanent exclusion applicable", status: "passed" },
                                { label: "No sub-limit breach specific to disease/procedure", status: "passed" },
                              ],
                            },
                            {
                              id: "hospital-network",
                              title: "Hospital & Network Validation",
                              objective: "Validate provider legitimacy and network applicability.",
                              status: "passed",
                              items: [
                                { label: "Hospital empanelled / network status verified", status: "passed" },
                                { label: "Correct hospital category applied (Network / Non-network)", status: "passed", detail: "Network" },
                              ],
                            },
                            {
                              id: "financial-tariff",
                              title: "Financial & Tariff Compliance Checks",
                              objective: "Ensure claimed amounts are reasonable and policy-compliant.",
                              status: "passed",
                              items: [
                                { label: "Sum Insured sufficient", status: "passed", detail: "₹9,00,000 available" },
                                { label: "Tariff rates compliant with agreed network pricing", status: "passed" },
                                { label: "Room rent eligibility complied with", status: "passed" },
                                { label: "Procedure/package charges within limits", status: "passed" },
                                { label: "Non-payables correctly excluded", status: "passed" },
                              ],
                            },
                            {
                              id: "prior-claims",
                              title: "Prior Claims & History Analysis",
                              objective: "Detect duplication, recurrence, or abuse patterns.",
                              status: "passed",
                              items: [
                                { label: "No duplicate claim detected", status: "passed" },
                                { label: "No related claims for same condition in recent period", status: "passed" },
                              ],
                            },
                            {
                              id: "fraud-abuse",
                              title: "Fraud & Abuse Risk Assessment",
                              objective: "Identify signals requiring deeper scrutiny.",
                              status: "passed",
                              items: [
                                { label: "Documents internally consistent", status: "passed" },
                                { label: "No altered, forged, or templated documents", status: "passed" },
                                { label: "Billing consistent with clinical notes", status: "passed" },
                                { label: "Length of stay appropriate for diagnosis", status: "passed" },
                                { label: "No unusual cost inflation", status: "passed" },
                                { label: "No known fraud patterns triggered", status: "passed" },
                                { label: "Provider and member risk scores within acceptable range", status: "passed" },
                              ],
                            },
                            {
                              id: "documentation",
                              title: "Documentation Completeness & Quality",
                              objective: "Ensure decision can be defended.",
                              status: "passed",
                              items: [
                                { label: "All mandatory documents submitted", status: "passed" },
                                { label: "Documents legible and verifiable", status: "passed" },
                                { label: "Dates and timelines consistent", status: "passed" },
                              ],
                            },
                          ],
                          aiSummary: "This claim is recommended for rejection as the treatment for diabetic nephropathy is directly attributable to the member's pre-existing Diabetes Mellitus Type 2 condition. The policy's 24-month waiting period for PED has not been completed, with only 10 months elapsed since inception."
                        }}
                      />
                    </div>
                  </div>

                  <div className="border border-amber-200 rounded-lg p-4 bg-amber-50/30">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-medium text-sm">Status & Next Action - Investigation Case</h4>
                        <p className="text-xs text-muted-foreground">Created on 14 Oct 2025, 11:45</p>
                      </div>
                      <Badge className="bg-amber-500 text-white hover:bg-amber-600">Investigation</Badge>
                    </div>
                    
                    <StatusNextActionCard 
                      showDeductions={false}
                      completeActionLabel="Send for Investigation"
                      defaultAction="investigation"
                      systemRecommendation={{
                        recommendedAction: "investigation",
                        confidence: "high",
                        categories: [
                          {
                            id: "member-policy",
                            title: "Member & Policy Eligibility Checks",
                            objective: "Confirm the claimant and policy are eligible for coverage.",
                            status: "inconclusive",
                            items: [
                              { label: "Member covered under policy on Date of Admission (DoA)", status: "passed" },
                              { label: "Policy active and valid during treatment period", status: "passed" },
                              { label: "Correct policy type applied (Retail / GMC / GPA)", status: "passed", detail: "Retail" },
                              { label: "Insured person details match policy records", status: "inconclusive", detail: "Address mismatch needs verification" },
                              { label: "Coverage applicable for claimed benefit type (IPD/OPD/Daycare)", status: "passed", detail: "IPD" },
                            ],
                          },
                          {
                            id: "disease-treatment",
                            title: "Disease / Treatment Eligibility Checks",
                            objective: "Validate medical appropriateness and coverage eligibility.",
                            status: "inconclusive",
                            items: [
                              { label: "Treatment covered under policy terms", status: "inconclusive", detail: "Treatment history found 6 months prior" },
                              { label: "Correct ICD / procedure mapping", status: "passed" },
                            ],
                          },
                          {
                            id: "waiting-exclusion",
                            title: "Waiting Period & Exclusion Checks",
                            objective: "Ensure no policy restrictions are violated.",
                            status: "inconclusive",
                            items: [
                              { label: "No initial waiting period violation", status: "inconclusive", detail: "Claim within 30 days of policy activation" },
                              { label: "No disease-specific waiting period breach", status: "passed" },
                              { label: "No pre-existing disease (PED) violation", status: "inconclusive", detail: "Previous treatment records found" },
                              { label: "No permanent exclusion applicable", status: "passed" },
                              { label: "No sub-limit breach specific to disease/procedure", status: "passed" },
                            ],
                          },
                          {
                            id: "hospital-network",
                            title: "Hospital & Network Validation",
                            objective: "Validate provider legitimacy and network applicability.",
                            status: "failed",
                            items: [
                              { label: "Hospital empanelled / network status verified", status: "passed" },
                              { label: "Correct hospital category applied (Network / Non-network)", status: "failed", detail: "Hospital flagged for 3 investigations this quarter" },
                            ],
                          },
                          {
                            id: "financial-tariff",
                            title: "Financial & Tariff Compliance Checks",
                            objective: "Ensure claimed amounts are reasonable and policy-compliant.",
                            status: "inconclusive",
                            items: [
                              { label: "Sum Insured sufficient", status: "passed" },
                              { label: "Tariff rates compliant with agreed network pricing", status: "passed" },
                              { label: "Room rent eligibility complied with", status: "passed" },
                              { label: "Procedure/package charges within limits", status: "inconclusive", detail: "25% above average for procedure" },
                              { label: "Non-payables correctly excluded", status: "passed" },
                            ],
                          },
                          {
                            id: "prior-claims",
                            title: "Prior Claims & History Analysis",
                            objective: "Detect duplication, recurrence, or abuse patterns.",
                            status: "passed",
                            items: [
                              { label: "No duplicate claim detected", status: "passed" },
                              { label: "No related claims for same condition in recent period", status: "passed" },
                            ],
                          },
                          {
                            id: "fraud-abuse",
                            title: "Fraud & Abuse Risk Assessment",
                            objective: "Identify signals requiring deeper scrutiny.",
                            status: "failed",
                            items: [
                              { label: "Documents internally consistent", status: "failed", detail: "Discharge dates don't align with admission" },
                              { label: "No altered, forged, or templated documents", status: "inconclusive", detail: "Document quality requires verification" },
                              { label: "Billing consistent with clinical notes", status: "inconclusive", detail: "Some line items lack clinical justification" },
                              { label: "Length of stay appropriate for diagnosis", status: "inconclusive", detail: "Extended stay pattern detected" },
                              { label: "No unusual cost inflation", status: "failed", detail: "20% above expected cost" },
                              { label: "No known fraud patterns triggered", status: "failed", detail: "Multiple risk patterns detected" },
                              { label: "Provider and member risk scores within acceptable range", status: "failed", detail: "Provider risk score elevated" },
                            ],
                          },
                          {
                            id: "documentation",
                            title: "Documentation Completeness & Quality",
                            objective: "Ensure decision can be defended.",
                            status: "failed",
                            items: [
                              { label: "All mandatory documents submitted", status: "passed" },
                              { label: "Documents legible and verifiable", status: "passed" },
                              { label: "Dates and timelines consistent", status: "failed", detail: "Discharge dates don't align with admission" },
                            ],
                          },
                        ],
                        aiSummary: "Based on comprehensive analysis of claim patterns, medical history, and document verification, this claim requires thorough investigation before processing. Multiple risk indicators suggest potential misrepresentation of pre-existing conditions and possible fraudulent intent."
                      }}
                    />
                  </div>
                  
                  <Button variant="outline" className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Add New Variation
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>}
      </div>

      {/* Register New Claim Modal */}
      <RegisterNewClaimModal open={showRegisterModal} onOpenChange={setShowRegisterModal} />

      {/* Global Search Modal */}
      <GlobalSearchModal isOpen={showGlobalSearch} onClose={() => setShowGlobalSearch(false)} />

      {/* Notifications Panel */}
      {showNotifications && <div className="fixed inset-0 z-40" onClick={() => setShowNotifications(false)}>
          <div className="absolute top-16 right-6 w-96 bg-card border rounded-lg shadow-lg" onClick={e => e.stopPropagation()}>
            <div className="p-4 border-b">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Notifications</h3>
                <Badge variant="secondary">{notificationCount}</Badge>
              </div>
            </div>
            <div className="max-h-96 overflow-y-auto">
              <div className="p-4 border-b hover:bg-muted/50 cursor-pointer">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="h-5 w-5 text-destructive mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">2 tasks breached the SLA</p>
                    <p className="text-xs text-muted-foreground mt-1">These tasks need immediate attention</p>
                    <span className="text-xs text-muted-foreground">5 minutes ago</span>
                  </div>
                </div>
              </div>
              <div className="p-4 border-b hover:bg-muted/50 cursor-pointer">
                <div className="flex items-start space-x-3">
                  <Clock className="h-5 w-5 text-warning mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">3 tasks about to breach SLA</p>
                    <p className="text-xs text-muted-foreground mt-1">Complete within the next hour</p>
                    <span className="text-xs text-muted-foreground">15 minutes ago</span>
                  </div>
                </div>
              </div>
              <div className="p-4 hover:bg-muted/50 cursor-pointer">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-success mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">Great job! 15 tasks completed today</p>
                    <p className="text-xs text-muted-foreground mt-1">You're ahead of your daily average</p>
                    <span className="text-xs text-muted-foreground">1 hour ago</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>}

      {/* Break Schedule Modal */}
      {showBreakSchedule && <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
          <div className="fixed left-1/2 top-1/2 z-50 w-full max-w-lg -translate-x-1/2 -translate-y-1/2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Break Schedule</CardTitle>
                  <Button variant="ghost" size="icon" onClick={() => setShowBreakSchedule(false)}>
                    <span className="text-2xl">&times;</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Total break time today</span>
                      <span className="font-medium">60 minutes</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Break time used</span>
                      <span className="font-medium">30 minutes</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Break time remaining</span>
                      <span className="font-medium text-primary">30 minutes</span>
                    </div>
                    <Progress value={50} className="mt-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>}

      {/* Completed Tasks Modal */}
      {showCompletedTasks && <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
          <div className="fixed left-1/2 top-1/2 z-50 w-full max-w-6xl -translate-x-1/2 -translate-y-1/2 max-h-[90vh] overflow-hidden">
            <Card className="h-full flex flex-col">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <CardTitle>Completed Tasks</CardTitle>
                  <Button variant="ghost" size="icon" onClick={() => setShowCompletedTasks(false)}>
                    <span className="text-2xl">&times;</span>
                  </Button>
                </div>
                <div className="flex items-center gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input placeholder="Search by Claim ID, Customer, or Hospital..." className="pl-10" value={completedTasksSearch} onChange={e => setCompletedTasksSearch(e.target.value)} />
                  </div>
                  <Select value={completedTasksFilter} onValueChange={setCompletedTasksFilter}>
                    <SelectTrigger className="w-[200px]">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="Reimbursement">Reimbursement</SelectItem>
                      <SelectItem value="Cashless">Cashless</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent className="overflow-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Claim ID</TableHead>
                      <TableHead>Claim Type</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Hospital</TableHead>
                      <TableHead>Bill Amount</TableHead>
                      <TableHead>Documents</TableHead>
                      
                      <TableHead>Completed Time</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>SLA</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {completedClaims.filter(claim => {
                  const matchesSearch = completedTasksSearch === '' || claim.claimId.toLowerCase().includes(completedTasksSearch.toLowerCase()) || claim.customer.toLowerCase().includes(completedTasksSearch.toLowerCase()) || claim.hospital.toLowerCase().includes(completedTasksSearch.toLowerCase());
                  const matchesFilter = completedTasksFilter === 'all' || claim.claimType === completedTasksFilter;
                  return matchesSearch && matchesFilter;
                }).map(claim => <TableRow key={claim.claimId}>
                        <TableCell>
                          <span className="text-primary font-medium">{claim.claimId}</span>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{claim.claimType}</Badge>
                        </TableCell>
                        <TableCell>{claim.customer}</TableCell>
                        <TableCell>{claim.hospital}</TableCell>
                        <TableCell className="font-medium">₹{claim.billAmount.toLocaleString()}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1">
                            <FileText className="h-4 w-4 text-muted-foreground" />
                            <span>{claim.documents}</span>
                          </div>
                        </TableCell>
                        <TableCell>{claim.assignedTime}</TableCell>
                        <TableCell>
                          <Badge variant="default">
                            {claim.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={getPriorityVariant(claim.priority)}>
                            {claim.priority}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1">
                            <CheckCircle className="h-4 w-4 text-success" />
                            <span className="text-success">
                              {claim.slaTime}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1">
                            <Button variant="outline" size="sm" onClick={() => {
                        setSelectedClaim(claim.claimId);
                        setShowCompletedTasks(false);
                      }}>
                              View
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>)}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </div>}
    </div>;
};

// Helper functions for badge variants
const getStatusVariant = (status: string) => {
  switch (status) {
    case 'In Progress':
      return 'in-progress';
    case 'Not started':
      return 'not-started';
    case 'Completed':
      return 'default';
    default:
      return 'not-started';
  }
};
const getPriorityVariant = (priority: string) => {
  switch (priority) {
    case 'Critical':
      return 'critical';
    case 'High':
      return 'high';
    case 'Medium':
      return 'medium';
    case 'Low':
      return 'low';
    default:
      return 'medium';
  }
};

// Sample data
const claimsData = [{
  taskDetails: 'Bill Entry',
  claimId: 'HLTHCR5474',
  claimType: 'Reimbursement',
  customer: 'Rajesh Kumar',
  hospital: 'Fortis Healthcare',
  billAmount: 32000,
  documents: 5,
  processingType: 'Manual Entry',
  assignedTime: '2 hours ago',
  status: 'Not started',
  priority: 'Critical',
  slaTime: '8 hours',
  slaStatus: 'On time',
  actionType: 'Start'
}, {
  taskDetails: 'Bill Entry',
  claimId: 'HLTHCR5478',
  claimType: 'Reimbursement',
  customer: 'Arjun Reddy',
  hospital: 'Care Hospital',
  billAmount: 55000,
  documents: 8,
  processingType: 'Auto-digitised',
  assignedTime: '2 days ago',
  status: 'Completed',
  priority: 'High',
  slaTime: '8 hours',
  slaStatus: 'On time',
  actionType: 'View'
}, {
  taskDetails: 'Bill Entry',
  claimId: 'HLTHCR5479',
  claimType: 'Cashless',
  customer: 'Kavita Joshi',
  hospital: 'Kokilaben Hospital',
  billAmount: 42000,
  documents: 11,
  processingType: 'Manual Entry',
  assignedTime: '1 day ago',
  status: 'Completed',
  priority: 'Medium',
  slaTime: '12 hours',
  slaStatus: 'On time',
  actionType: 'View'
}, {
  taskDetails: 'Bill Entry',
  claimId: 'HLTHCR5480',
  claimType: 'Reimbursement',
  customer: 'Suresh Nair',
  hospital: 'Medanta Hospital',
  billAmount: 73000,
  documents: 14,
  processingType: 'Auto-digitised',
  assignedTime: '3 days ago',
  status: 'Completed',
  priority: 'Critical',
  slaTime: '6 hours',
  slaStatus: 'On time',
  actionType: 'View'
}];
export default BillEntryDashboard;