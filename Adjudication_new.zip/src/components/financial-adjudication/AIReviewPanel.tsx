import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Bot,
  AlertTriangle,
  AlertCircle,
  Info,
  FileQuestion,
  MessageSquare,
  FileX,
  Eye,
  ChevronRight,
} from 'lucide-react';
import { AIFlag } from './types';
import { cn } from '@/lib/utils';

interface AIReviewPanelProps {
  flags: AIFlag[];
  onAction?: (flag: AIFlag) => void;
}

const severityConfig = {
  High: {
    icon: AlertTriangle,
    bg: 'bg-destructive/10',
    border: 'border-destructive/30',
    text: 'text-destructive',
    badge: 'bg-destructive text-destructive-foreground',
  },
  Medium: {
    icon: AlertCircle,
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    text: 'text-amber-700',
    badge: 'bg-amber-500 text-white',
  },
  Low: {
    icon: Info,
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    text: 'text-blue-700',
    badge: 'bg-blue-500 text-white',
  },
};

const actionIcons = {
  query_hospital: MessageSquare,
  query_customer: MessageSquare,
  request_document: FileQuestion,
  reject: FileX,
  review: Eye,
};

export const AIReviewPanel: React.FC<AIReviewPanelProps> = ({ flags, onAction }) => {
  const highCount = flags.filter((f) => f.severity === 'High').length;
  const mediumCount = flags.filter((f) => f.severity === 'Medium').length;
  const lowCount = flags.filter((f) => f.severity === 'Low').length;

  const sortedFlags = [...flags].sort((a, b) => {
    const order = { High: 0, Medium: 1, Low: 2 };
    return order[a.severity] - order[b.severity];
  });

  return (
    <Card className="h-full">
      <CardHeader className="py-3 border-b">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Bot className="h-4 w-4 text-primary" />
          AI Review
          {flags.length > 0 && (
            <div className="flex gap-1 ml-auto">
              {highCount > 0 && (
                <Badge className="bg-destructive text-xs">{highCount}</Badge>
              )}
              {mediumCount > 0 && (
                <Badge className="bg-amber-500 text-xs">{mediumCount}</Badge>
              )}
              {lowCount > 0 && (
                <Badge className="bg-blue-500 text-xs">{lowCount}</Badge>
              )}
            </div>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          {flags.length === 0 ? (
            <div className="p-6 text-center">
              <Bot className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">
                No issues detected. All checks passed.
              </p>
            </div>
          ) : (
            <div className="p-3 space-y-2">
              {sortedFlags.map((flag) => {
                const config = severityConfig[flag.severity];
                const Icon = config.icon;
                const ActionIcon = flag.actionType ? actionIcons[flag.actionType] : Eye;

                return (
                  <div
                    key={flag.id}
                    className={cn(
                      'p-3 rounded-lg border transition-all',
                      config.bg,
                      config.border
                    )}
                  >
                    <div className="flex items-start gap-2">
                      <Icon className={cn('h-4 w-4 mt-0.5 flex-shrink-0', config.text)} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge className={cn('text-xs', config.badge)}>
                            {flag.severity}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {flag.category}
                          </Badge>
                        </div>
                        <p className="text-sm mt-1">{flag.message}</p>
                        <div className="mt-2 p-2 rounded bg-card/50 border text-xs">
                          <span className="text-muted-foreground">Recommendation: </span>
                          <span>{flag.recommendation}</span>
                        </div>
                        {flag.actionType && onAction && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="mt-2 h-7 text-xs"
                            onClick={() => onAction(flag)}
                          >
                            <ActionIcon className="h-3 w-3 mr-1" />
                            {flag.actionType === 'query_hospital' && 'Query Hospital'}
                            {flag.actionType === 'query_customer' && 'Query Customer'}
                            {flag.actionType === 'request_document' && 'Request Document'}
                            {flag.actionType === 'reject' && 'Add Rejection'}
                            {flag.actionType === 'review' && 'Review'}
                            <ChevronRight className="h-3 w-3 ml-1" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>

      </CardContent>
    </Card>
  );
};
