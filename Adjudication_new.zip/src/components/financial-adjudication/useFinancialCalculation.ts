import { useMemo, useCallback } from 'react';
import {
  FinancialAdjudicationState,
  CalculationResult,
  CalculationStep,
  OverridableField,
  AIFlag,
} from './types';

export function createOverridableField<T>(value: T, source: 'System' | 'Extracted' | 'Handler' = 'System'): OverridableField<T> {
  return {
    systemValue: value,
    finalValue: value,
    isOverridden: false,
    source,
  };
}

export function getFinalValue<T>(field: OverridableField<T>): T {
  return field.isOverridden ? field.finalValue : field.systemValue;
}

export function useFinancialCalculation(state: FinancialAdjudicationState): CalculationResult {
  return useMemo(() => {
    const steps: CalculationStep[] = [];
    let stepNumber = 0;

    const billInputs = state.billInputs;
    const roomInputs = state.roomInputs;
    const deductibleInputs = state.deductibleInputs;
    const copayInputs = state.copayInputs;
    const otherInsurerInputs = state.otherInsurerInputs;
    const benefitInputs = state.benefitInputs;
    const subLimitInputs = state.subLimitInputs;
    const bsiInputs = state.bsiInputs;
    const tdsInputs = state.tdsInputs;

    // Step 0: Cash Reserve
    const reserveAmount = getFinalValue(billInputs.totalBilledAmount);

    // Step 1: Start from Total Billed Amount
    const A0 = getFinalValue(billInputs.totalBilledAmount);
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Total Billed Amount',
      description: 'Starting amount from hospital bill',
      inputsUsed: ['Total Billed Amount'],
      formula: 'A0 = Total Billed',
      computedValue: A0,
      finalValue: billInputs.totalBilledAmount,
      runningTotal: A0,
    });

    // Step 2: Non-medical deductions
    const nmeDeduction = getFinalValue(billInputs.nmeTotal);
    const A1 = Math.max(0, A0 - nmeDeduction);
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Non-Medical Expense Deduction',
      description: 'Deduct non-medical items (NME)',
      inputsUsed: ['NME Total'],
      formula: 'A1 = A0 - NME',
      computedValue: A1,
      finalValue: createOverridableField(A1),
      runningTotal: A1,
    });

    // Step 3: Non-related medical deductions
    const nonRelatedDeduction = getFinalValue(billInputs.nonRelatedMedicalExpenses);
    const A2 = Math.max(0, A1 - nonRelatedDeduction);
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Non-Related Medical Deduction',
      description: 'Deduct expenses not related to primary diagnosis',
      inputsUsed: ['Non-Related Medical Expenses'],
      formula: 'A2 = A1 - Non-Related',
      computedValue: A2,
      finalValue: createOverridableField(A2),
      runningTotal: A2,
    });

    // Step 4: Tariff/discount adjustments
    const tariffDeduction = getFinalValue(billInputs.tariffDiscountAdjustment);
    const A3 = Math.max(0, A2 - tariffDeduction);
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Tariff/Discount Adjustment',
      description: 'Apply tariff caps or discounts',
      inputsUsed: ['Tariff Adjustment'],
      formula: 'A3 = A2 - Tariff Adjustment',
      computedValue: A3,
      finalValue: createOverridableField(A3),
      runningTotal: A3,
    });

    // Step 5: Proportionate deductions (room rent mismatch)
    const actualRoomRent = getFinalValue(roomInputs.actualRoomRentPerDay);
    const allowedRoomRent = getFinalValue(roomInputs.allowedRoomRentPerDay);
    const proportionateFactor = actualRoomRent > 0 ? Math.min(1, allowedRoomRent / actualRoomRent) : 1;
    
    // Apply proportionate only to applicable heads (exclude Pharmacy, Consumables, Investigation)
    const exemptHeads = billInputs.billHeads.pharmacy + billInputs.billHeads.consumables + billInputs.billHeads.investigationDiagnostics;
    const applicableForProportionate = A3 - exemptHeads;
    const proportionateDeduction = applicableForProportionate * (1 - proportionateFactor);
    const A4 = Math.max(0, A3 - proportionateDeduction);
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Proportionate Deduction',
      description: `Room rent mismatch adjustment (Factor: ${(proportionateFactor * 100).toFixed(1)}%)`,
      inputsUsed: ['Actual Room Rent', 'Allowed Room Rent', 'Applicable Bill Heads'],
      formula: 'A4 = A3 - ((Applicable Heads) × (1 - Factor))',
      computedValue: A4,
      finalValue: createOverridableField(A4),
      runningTotal: A4,
    });

    // Step 6: Per-claim deductible
    let perClaimDeductible = 0;
    if (deductibleInputs.perClaimDeductibleType === 'Fixed') {
      perClaimDeductible = getFinalValue(deductibleInputs.perClaimDeductibleValue);
    } else {
      perClaimDeductible = A4 * (getFinalValue(deductibleInputs.perClaimDeductibleValue) / 100);
    }
    const A5 = Math.max(0, A4 - perClaimDeductible);
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Per-Claim Deductible',
      description: `Deductible: ${deductibleInputs.perClaimDeductibleType === 'Fixed' ? '₹' + perClaimDeductible.toLocaleString() : getFinalValue(deductibleInputs.perClaimDeductibleValue) + '%'}`,
      inputsUsed: ['Per-Claim Deductible'],
      formula: 'A5 = A4 - Per-Claim Deductible',
      computedValue: A5,
      finalValue: createOverridableField(A5),
      runningTotal: A5,
    });

    // Step 7: Aggregate deductible / Top-up deductible
    const remainingAggregate = getFinalValue(deductibleInputs.remainingAggregateDeductible);
    const aggregateDeductible = Math.min(A5, remainingAggregate);
    const A6 = Math.max(0, A5 - aggregateDeductible);
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Aggregate/Top-up Deductible',
      description: 'Remaining aggregate deductible for policy year',
      inputsUsed: ['Remaining Aggregate Deductible'],
      formula: 'A6 = max(0, A5 - Remaining Aggregate)',
      computedValue: A6,
      finalValue: createOverridableField(A6),
      runningTotal: A6,
    });

    // Step 8: Co-pay
    const copayApplicable = getFinalValue(copayInputs.isApplicable);
    const copayPercentage = getFinalValue(copayInputs.percentage);
    const copayAmount = copayApplicable ? A6 * (copayPercentage / 100) : 0;
    const A7 = Math.max(0, A6 - copayAmount);
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Co-pay Deduction',
      description: copayApplicable ? `Co-pay: ${copayPercentage}%` : 'Co-pay not applicable',
      inputsUsed: ['Co-pay %', 'Co-pay Applicable'],
      formula: 'A7 = A6 - (A6 × Copay%)',
      computedValue: A7,
      finalValue: createOverridableField(A7),
      runningTotal: A7,
    });

    // Step 9: Other insurer / other policy settlements
    const otherInsurerPaid = getFinalValue(otherInsurerInputs.otherInsurerPaid);
    const otherAckoPaid = getFinalValue(otherInsurerInputs.otherAckoPolicyPaid);
    const A8 = Math.max(0, A7 - otherInsurerPaid - otherAckoPaid);
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Other Insurer Offset',
      description: 'Deduct amounts paid by other insurers',
      inputsUsed: ['Other Insurer Paid', 'Other ACKO Policy Paid'],
      formula: 'A8 = A7 - Other Insurer - Other ACKO',
      computedValue: A8,
      finalValue: createOverridableField(A8),
      runningTotal: A8,
    });

    // Step 10: Add/Select benefits (e.g., Hospicash)
    const hcbApplicable = getFinalValue(benefitInputs.hcbApplicable);
    const hcbPayout = hcbApplicable
      ? getFinalValue(benefitInputs.hcbPerDayAmount) * getFinalValue(benefitInputs.hcbPayableDays)
      : 0;
    const A9 = A8 + hcbPayout;
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Benefit Addition (HCB)',
      description: hcbApplicable ? `Hospital Cash Benefit: ₹${hcbPayout.toLocaleString()}` : 'No HCB applicable',
      inputsUsed: ['HCB Per Day', 'HCB Payable Days'],
      formula: 'A9 = A8 + HCB Payout',
      computedValue: A9,
      finalValue: createOverridableField(A9),
      runningTotal: A9,
    });

    // Step 11: Apply Sub-limit cap
    const subLimitBalance = getFinalValue(subLimitInputs.availableBalance);
    const subLimitApplied = subLimitInputs.applicableType !== null && subLimitBalance > 0;
    const A10 = subLimitApplied ? Math.min(A9, subLimitBalance) : A9;
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Sub-limit Cap',
      description: subLimitApplied ? `Sub-limit: ₹${subLimitBalance.toLocaleString()}` : 'No sub-limit applicable',
      inputsUsed: ['Sub-limit Type', 'Available Balance'],
      formula: 'A10 = min(A9, Sub-limit Balance)',
      computedValue: A10,
      finalValue: createOverridableField(A10),
      runningTotal: A10,
    });

    // Step 12: BSI check
    const availableBSI = getFinalValue(bsiInputs.availableBSI);
    const bsiApplied = !bsiInputs.isSubLimitOverBSI;
    const A11 = bsiApplied ? Math.min(A10, availableBSI) : A10;
    steps.push({
      stepNumber: ++stepNumber,
      name: 'BSI Check',
      description: `Available BSI: ₹${availableBSI.toLocaleString()}`,
      inputsUsed: ['Available BSI', 'Is Sub-limit Over BSI'],
      formula: 'A11 = min(A10, Available BSI)',
      computedValue: A11,
      finalValue: createOverridableField(A11),
      runningTotal: A11,
    });

    // Step 13: Buffer adjustments
    const bufferApproved = bsiInputs.bufferApproved;
    const bufferAmount = getFinalValue(bsiInputs.bufferAmount);
    const effectiveLimit = bufferApproved ? availableBSI + bufferAmount : availableBSI;
    const A12 = bufferApproved ? Math.min(A10, effectiveLimit) : A11;
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Buffer Adjustment',
      description: bufferApproved ? `Buffer: ₹${bufferAmount.toLocaleString()}` : 'No buffer approved',
      inputsUsed: ['Buffer Approved', 'Buffer Amount'],
      formula: 'A12 = min(A10, BSI + Buffer)',
      computedValue: A12,
      finalValue: createOverridableField(A12),
      runningTotal: A12,
    });

    // Step 14: Adjust customer advance
    const customerAdvance = getFinalValue(billInputs.customerAdvancePaid);
    const A13 = Math.max(0, A12 - customerAdvance);
    steps.push({
      stepNumber: ++stepNumber,
      name: 'Customer Advance Adjustment',
      description: customerAdvance > 0 ? `Advance paid: ₹${customerAdvance.toLocaleString()}` : 'No advance paid',
      inputsUsed: ['Customer Advance'],
      formula: 'A13 = max(0, A12 - Customer Advance)',
      computedValue: A13,
      finalValue: createOverridableField(A13),
      runningTotal: A13,
    });

    // TDS calculation (not shown as step, but used for settlement details)
    const isCashless = tdsInputs.claimType === 'Cashless';
    const tdsApplicable = getFinalValue(tdsInputs.tdsApplicable);
    const tdsRate = getFinalValue(tdsInputs.tdsRate);
    const tdsDeducted = isCashless && tdsApplicable ? A13 * (tdsRate / 100) : 0;
    const netPayableToHospital = A13 - tdsDeducted;

    // Final calculations
    const updatedBSI = availableBSI - A13;
    const reserveReleased = reserveAmount - A13;

    return {
      steps,
      reserveAmount,
      totalBilled: A0,
      totalDeductions: {
        nme: nmeDeduction,
        nonRelated: nonRelatedDeduction,
        tariff: tariffDeduction,
        proportionate: proportionateDeduction,
        perClaimDeductible,
        aggregateDeductible,
        copay: copayAmount,
        otherInsurer: otherInsurerPaid + otherAckoPaid,
      },
      additionalBenefits: hcbPayout,
      payableBeforeCaps: A9,
      subLimitApplied,
      subLimitAmount: subLimitApplied ? subLimitBalance : 0,
      bsiApplied,
      bsiAmount: bsiApplied ? availableBSI : 0,
      bufferApplied: bufferApproved,
      bufferAmount: bufferApproved ? bufferAmount : 0,
      finalPayable: A13,
      netPayableToHospital: isCashless ? netPayableToHospital : A13,
      tdsDeducted,
      updatedBSI: Math.max(0, updatedBSI),
      reserveReleased: Math.max(0, reserveReleased),
    };
  }, [state]);
}

export function useAIFlags(state: FinancialAdjudicationState, result: CalculationResult): AIFlag[] {
  return useMemo(() => {
    const flags: AIFlag[] = [];

    // Check for missing prerequisites
    if (getFinalValue(state.otherInsurerInputs.otherInsurerPaid) > 0) {
      flags.push({
        id: 'missing-other-insurer-letter',
        severity: 'High',
        category: 'Missing Document',
        message: 'Other insurer amount entered but settlement letter not attached',
        recommendation: 'Request settlement letter from other insurer before processing',
        actionType: 'request_document',
        relatedStep: 9, // Other Insurer Offset
      });
    }

    // Check consumables coverage
    if (state.billInputs.billHeads.consumables > 0 && getFinalValue(state.billInputs.nmeTotal) > 0) {
      flags.push({
        id: 'consumables-nme-check',
        severity: 'Medium',
        category: 'Policy Check',
        message: 'Consumables present in bill. Check if policy covers consumables',
        recommendation: 'Verify consumables coverage - if covered, remove from NME',
        actionType: 'review',
        relatedStep: 2, // NME Deduction
      });
    }

    // Room type mismatch
    if (state.roomInputs.roomTypeAvailed !== state.roomInputs.allowedRoomType) {
      flags.push({
        id: 'room-type-mismatch',
        severity: 'Medium',
        category: 'Proportionate Deduction',
        message: `Room type availed (${state.roomInputs.roomTypeAvailed}) differs from allowed (${state.roomInputs.allowedRoomType})`,
        recommendation: 'Verify proportionate deduction is correctly applied',
        actionType: 'review',
        relatedStep: 5, // Proportionate Deduction
      });
    }

    // Copay missing
    if (getFinalValue(state.copayInputs.isApplicable) && getFinalValue(state.copayInputs.percentage) === 0) {
      flags.push({
        id: 'copay-missing',
        severity: 'High',
        category: 'Policy Configuration',
        message: 'Co-pay is applicable but percentage is 0%',
        recommendation: 'Verify co-pay percentage from policy configuration',
        actionType: 'review',
        relatedStep: 8, // Co-pay Deduction
      });
    }

    // Sub-limit exhausted
    if (state.subLimitInputs.isExhausted) {
      flags.push({
        id: 'sublimit-exhausted',
        severity: 'High',
        category: 'Sub-limit',
        message: 'Sub-limit is exhausted. Payable will be 0 for this benefit',
        recommendation: 'Consider rejection with reason: Sub-limit exhausted',
        actionType: 'reject',
        relatedStep: 11, // Sub-limit Cap
      });
    }

    // BSI exhausted
    if (state.bsiInputs.isBSIExhausted) {
      flags.push({
        id: 'bsi-exhausted',
        severity: 'High',
        category: 'Sum Insured',
        message: 'Balance Sum Insured is exhausted',
        recommendation: state.bsiInputs.hasOtherActivePolicy
          ? 'Re-adjudicate under other active policy'
          : 'Reject with reason: Sum insured exhausted',
        actionType: state.bsiInputs.hasOtherActivePolicy ? 'review' : 'reject',
        relatedStep: 12, // BSI Check
      });
    }

    // Large override delta
    state.calculationResult?.steps.forEach((step) => {
      if (step.finalValue.isOverridden) {
        const delta = Math.abs(step.finalValue.finalValue - step.computedValue);
        const percentDelta = (delta / step.computedValue) * 100;
        if (percentDelta > 20) {
          flags.push({
            id: `large-override-${step.stepNumber}`,
            severity: 'Medium',
            category: 'Override Review',
            message: `Large override at Step ${step.stepNumber}: ${step.name} (${percentDelta.toFixed(1)}% difference)`,
            recommendation: 'Verify evidence attachment for this override',
            actionType: 'review',
            relatedStep: step.stepNumber,
          });
        }
      }
    });

    // Advance paid greater than payable
    if (getFinalValue(state.billInputs.customerAdvancePaid) > result.finalPayable) {
      flags.push({
        id: 'advance-exceeds-payable',
        severity: 'Medium',
        category: 'Refund Handling',
        message: 'Customer advance exceeds final payable amount',
        recommendation: 'Add refund handling note for excess advance',
        actionType: 'review',
        relatedStep: 14, // Customer Advance Adjustment
      });
    }

    // TDS missing for cashless
    if (state.tdsInputs.claimType === 'Cashless' && !getFinalValue(state.tdsInputs.tdsApplicable)) {
      flags.push({
        id: 'tds-missing-cashless',
        severity: 'Low',
        category: 'TDS Configuration',
        message: 'Cashless claim but TDS not applicable',
        recommendation: 'Verify hospital TDS configuration',
        actionType: 'review',
      });
    }

    return flags;
  }, [state, result]);
}
