// Financial Adjudication Types

export type SourceTag = 'System' | 'Extracted' | 'Handler';

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  field: string;
  oldValue: string | number | null;
  newValue: string | number;
  reason: string;
  note?: string;
  evidenceLink?: string;
}

export interface OverridableField<T> {
  systemValue: T;
  finalValue: T;
  isOverridden: boolean;
  overrideReason?: string;
  overrideNote?: string;
  evidenceLink?: string;
  source: SourceTag;
}

export interface BillHeadTotals {
  roomRent: number;
  treatmentProcedure: number;
  pharmacy: number;
  consumables: number;
  investigationDiagnostics: number;
  other: number;
}

export interface BillDocumentInputs {
  totalBilledAmount: OverridableField<number>;
  billHeads: BillHeadTotals;
  nmeTotal: OverridableField<number>;
  nmeBreakdown: { item: string; amount: number }[];
  nonRelatedMedicalExpenses: OverridableField<number>;
  tariffDiscountAdjustment: OverridableField<number>;
  customerAdvancePaid: OverridableField<number>;
}

export type RoomType = 'Ward' | 'Shared' | 'Single' | 'Suite' | 'Other';
export type CityType = 'Metro' | 'Non-Metro';
export type CapType = 'FixedPerDay' | 'PercentOfSI';

export interface RoomDeductionInputs {
  roomTypeAvailed: RoomType;
  actualRoomRentPerDay: OverridableField<number>;
  allowedRoomType: RoomType;
  allowedRoomRentPerDay: OverridableField<number>;
  capType: CapType;
  cityType: CityType;
  isICU: boolean;
  lengthOfStay: number;
}

export interface DeductibleInputs {
  perClaimDeductibleType: 'Fixed' | 'Percentage';
  perClaimDeductibleValue: OverridableField<number>;
  catastrophicDeductible: OverridableField<number>;
  aggregateDeductibleLimit: OverridableField<number>;
  consumedAggregateDeductible: OverridableField<number>;
  remainingAggregateDeductible: OverridableField<number>;
  isResettlement: boolean;
}

export interface CopayInputs {
  isApplicable: OverridableField<boolean>;
  percentage: OverridableField<number>;
  drivers: {
    claimType: string;
    ageSlab: string;
    city: string;
    relationship: string;
    providerType: string;
    roomType: string;
    admissionType: string;
    isICU: boolean;
    diseaseCategory: string;
    hasSecondOpinion: boolean;
  };
}

export interface OtherInsurerInputs {
  otherInsurerPaid: OverridableField<number>;
  otherAckoPolicyPaid: OverridableField<number>;
}

export interface BenefitInputs {
  hcbApplicable: OverridableField<boolean>;
  hcbPerDayAmount: OverridableField<number>;
  hcbPayableDays: OverridableField<number>;
  hcbMaxPayableDays: number;
  selectedBenefit: string;
  alternativeBenefits: { name: string; payout: number }[];
}

export type SubLimitType = 'Member' | 'Policy' | 'Disease' | 'Procedure' | 'Claim' | 'Benefit' | 'ClaimType' | 'CityAge' | 'RoomType' | 'HospitalisationType';

export interface SubLimitInputs {
  applicableType: SubLimitType | null;
  availableBalance: OverridableField<number>;
  isExhausted: boolean;
}

export interface BSIInputs {
  availableBSI: OverridableField<number>;
  isSubLimitOverBSI: boolean;
  bufferApproved: boolean;
  bufferAmount: OverridableField<number>;
  bufferApprovalReference: string;
  isBSIExhausted: boolean;
  hasOtherActivePolicy: boolean;
}

export interface TDSSettlementInputs {
  claimType: 'Cashless' | 'Reimbursement';
  tdsApplicable: OverridableField<boolean>;
  tdsRate: OverridableField<number>;
}

export interface CalculationStep {
  stepNumber: number;
  name: string;
  description: string;
  inputsUsed: string[];
  formula: string;
  computedValue: number;
  finalValue: OverridableField<number>;
  runningTotal: number;
}

export interface CalculationResult {
  steps: CalculationStep[];
  reserveAmount: number;
  totalBilled: number;
  totalDeductions: {
    nme: number;
    nonRelated: number;
    tariff: number;
    proportionate: number;
    perClaimDeductible: number;
    aggregateDeductible: number;
    copay: number;
    otherInsurer: number;
  };
  additionalBenefits: number;
  payableBeforeCaps: number;
  subLimitApplied: boolean;
  subLimitAmount: number;
  bsiApplied: boolean;
  bsiAmount: number;
  bufferApplied: boolean;
  bufferAmount: number;
  finalPayable: number;
  netPayableToHospital: number;
  tdsDeducted: number;
  updatedBSI: number;
  reserveReleased: number;
}

export interface AIFlag {
  id: string;
  severity: 'High' | 'Medium' | 'Low';
  category: string;
  message: string;
  recommendation: string;
  actionType?: 'query_hospital' | 'query_customer' | 'request_document' | 'reject' | 'review';
  relatedStep?: number; // Links to calculation step number
}

export interface FinancialAdjudicationState {
  billInputs: BillDocumentInputs;
  roomInputs: RoomDeductionInputs;
  deductibleInputs: DeductibleInputs;
  copayInputs: CopayInputs;
  otherInsurerInputs: OtherInsurerInputs;
  benefitInputs: BenefitInputs;
  subLimitInputs: SubLimitInputs;
  bsiInputs: BSIInputs;
  tdsInputs: TDSSettlementInputs;
  isManualMode: boolean;
  auditLog: AuditLogEntry[];
  aiFlags: AIFlag[];
  calculationResult: CalculationResult | null;
}
