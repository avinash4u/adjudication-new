import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, XCircle, AlertTriangle, IndianRupee, TrendingDown, Gift, ArrowRight } from 'lucide-react';
import { CalculationResult } from './types';
import { cn } from '@/lib/utils';

interface SummaryCardProps {
  result: CalculationResult;
  claimType: 'Cashless' | 'Reimbursement';
}

export const SummaryCard: React.FC<SummaryCardProps> = ({ result, claimType }) => {
  const totalDeductions = Object.values(result.totalDeductions).reduce((a, b) => a + b, 0);

  const deductionItems = [
    { label: 'Non-Medical Expenses', value: result.totalDeductions.nme },
    { label: 'Non-Related Treatment', value: result.totalDeductions.nonRelated },
    { label: 'Tariff Adjustment', value: result.totalDeductions.tariff },
    { label: 'Proportionate Deduction', value: result.totalDeductions.proportionate },
    { label: 'Per-Claim Deductible', value: result.totalDeductions.perClaimDeductible },
    { label: 'Aggregate Deductible', value: result.totalDeductions.aggregateDeductible },
    { label: 'Co-payment', value: result.totalDeductions.copay },
    { label: 'Other Insurer Recovery', value: result.totalDeductions.otherInsurer },
  ].filter(item => item.value > 0);

  return (
    <Card className="border-primary/20 overflow-hidden">
      <CardContent className="p-0">
        <div className="flex flex-col lg:flex-row">
          {/* Left Panel - Key Figures */}
          <div className="lg:w-72 bg-gradient-to-br from-primary/5 to-primary/10 p-5 space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <IndianRupee className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">Settlement Summary</span>
              <Badge variant="outline" className="ml-auto text-[10px]">
                {claimType}
              </Badge>
            </div>

            {/* Final Payable - Hero */}
            <div className="p-4 rounded-xl bg-primary text-primary-foreground">
              <p className="text-xs opacity-80 mb-1">Final Payable</p>
              <p className="text-2xl font-bold">
                ₹{result.finalPayable.toLocaleString('en-IN')}
              </p>
            </div>

            {/* Calculation Flow */}
            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between py-2 border-b border-primary/10">
                <span className="text-muted-foreground">Total Billed</span>
                <span className="font-medium">₹{result.totalBilled.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-primary/10">
                <span className="text-destructive flex items-center gap-1">
                  <TrendingDown className="h-3 w-3" />
                  Deductions
                </span>
                <span className="font-medium text-destructive">
                  -₹{totalDeductions.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-emerald-600 flex items-center gap-1">
                  <Gift className="h-3 w-3" />
                  Benefits
                </span>
                <span className="font-medium text-emerald-600">
                  +₹{(result.additionalBenefits || 0).toLocaleString('en-IN')}
                </span>
              </div>
            </div>
          </div>

          {/* Right Panel - Tabbed Details */}
          <div className="flex-1 p-4">
            <Tabs defaultValue="deductions" className="w-full">
              <TabsList className="grid w-full grid-cols-3 h-9">
                <TabsTrigger value="deductions" className="text-xs">
                  Deductions
                  {deductionItems.length > 0 && (
                    <Badge variant="secondary" className="ml-1.5 h-4 px-1 text-[10px]">
                      {deductionItems.length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="caps" className="text-xs">Caps & Limits</TabsTrigger>
                <TabsTrigger value="balance" className="text-xs">Balance</TabsTrigger>
              </TabsList>

              <TabsContent value="deductions" className="mt-3 space-y-1.5">
                {deductionItems.length > 0 ? (
                  deductionItems.map((item) => (
                    <div
                      key={item.label}
                      className="flex items-center justify-between py-2 px-3 rounded-lg bg-destructive/5 border border-destructive/10"
                    >
                      <span className="text-sm text-muted-foreground">{item.label}</span>
                      <span className="text-sm font-medium text-destructive">
                        -₹{item.value.toLocaleString('en-IN')}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="py-8 text-center text-muted-foreground text-sm">
                    <CheckCircle className="h-8 w-8 mx-auto mb-2 text-emerald-500" />
                    No deductions applied
                  </div>
                )}
              </TabsContent>

              <TabsContent value="caps" className="mt-3 space-y-2">
                <CapItem
                  label="Sub-limit"
                  applied={result.subLimitApplied}
                  detail={result.subLimitApplied 
                    ? `Capped at ₹${result.subLimitAmount.toLocaleString('en-IN')}` 
                    : 'Not applicable'}
                  type="warning"
                />
                <CapItem
                  label="Balance Sum Insured"
                  applied={result.bsiApplied}
                  detail={result.bsiApplied 
                    ? `Limited to ₹${result.bsiAmount.toLocaleString('en-IN')}` 
                    : `Available: ₹${result.bsiAmount.toLocaleString('en-IN')}`}
                  type={result.bsiApplied ? "warning" : "success"}
                />
                <CapItem
                  label="Buffer Benefit"
                  applied={result.bufferApplied}
                  detail={result.bufferApplied 
                    ? `+₹${result.bufferAmount.toLocaleString('en-IN')} approved` 
                    : 'Not requested'}
                  type={result.bufferApplied ? "success" : "neutral"}
                />
              </TabsContent>

              <TabsContent value="balance" className="mt-3 space-y-2">
                <div className="p-3 rounded-lg bg-muted/50 border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Updated BSI</p>
                      <p className="text-lg font-semibold">
                        ₹{result.updatedBSI.toLocaleString('en-IN')}
                      </p>
                    </div>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">Reserve Released</p>
                      <p className="text-lg font-semibold text-emerald-600">
                        ₹{result.reserveReleased.toLocaleString('en-IN')}
                      </p>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground text-center mt-2">
                  Balance after this claim settlement
                </p>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

interface CapItemProps {
  label: string;
  applied: boolean;
  detail: string;
  type: 'success' | 'warning' | 'neutral';
}

const CapItem: React.FC<CapItemProps> = ({ label, applied, detail, type }) => {
  const bgClass = {
    success: 'bg-emerald-50 border-emerald-200 dark:bg-emerald-950/30 dark:border-emerald-800',
    warning: 'bg-amber-50 border-amber-200 dark:bg-amber-950/30 dark:border-amber-800',
    neutral: 'bg-muted/50 border-muted',
  }[type];

  const iconClass = {
    success: 'text-emerald-600',
    warning: 'text-amber-600',
    neutral: 'text-muted-foreground',
  }[type];

  const Icon = type === 'warning' ? AlertTriangle : type === 'success' ? CheckCircle : XCircle;

  return (
    <div className={cn('p-3 rounded-lg border flex items-center gap-3', bgClass)}>
      <Icon className={cn('h-4 w-4 flex-shrink-0', iconClass)} />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium">{label}</p>
        <p className="text-xs text-muted-foreground truncate">{detail}</p>
      </div>
    </div>
  );
};
