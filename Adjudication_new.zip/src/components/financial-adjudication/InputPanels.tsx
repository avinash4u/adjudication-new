import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown, FileText, Home, CreditCard, Users, Shield, Wallet, Building2, Calculator } from 'lucide-react';
import { OverridableFieldInput } from './OverridableFieldInput';
import {
  BillDocumentInputs,
  RoomDeductionInputs,
  DeductibleInputs,
  CopayInputs,
  OtherInsurerInputs,
  BenefitInputs,
  SubLimitInputs,
  BSIInputs,
  TDSSettlementInputs,
  OverridableField,
  AuditLogEntry,
  RoomType,
  CapType,
  CityType,
  SubLimitType,
} from './types';
import { cn } from '@/lib/utils';

interface InputPanelProps<T> {
  data: T;
  onChange: (data: T) => void;
  onAuditLog: (entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => void;
  isManualMode?: boolean;
}

// Helper to update a specific field
function updateField<T, K extends keyof T>(
  data: T,
  key: K,
  newValue: T[K],
  onChange: (data: T) => void
) {
  onChange({ ...data, [key]: newValue });
}

export const BillInputPanel: React.FC<InputPanelProps<BillDocumentInputs>> = ({
  data,
  onChange,
  onAuditLog,
  isManualMode,
}) => {
  const [isOpen, setIsOpen] = React.useState(true);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <FileText className="h-4 w-4 text-primary" />
              Bill & Document Inputs
              <ChevronDown className={cn('h-4 w-4 ml-auto transition-transform', isOpen && 'rotate-180')} />
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-3 pt-0">
            <OverridableFieldInput
              label="Total Billed Amount"
              field={data.totalBilledAmount}
              onChange={(f) => updateField(data, 'totalBilledAmount', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Bill Head Totals</Label>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(data.billHeads).map(([key, value]) => (
                  <div key={key} className="flex items-center justify-between py-1 px-2 rounded bg-muted/20 text-sm">
                    <span className="text-muted-foreground capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                    <span className="font-medium">₹{value.toLocaleString('en-IN')}</span>
                  </div>
                ))}
              </div>
            </div>

            <OverridableFieldInput
              label="Non-Medical Expenses (NME)"
              field={data.nmeTotal}
              onChange={(f) => updateField(data, 'nmeTotal', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <OverridableFieldInput
              label="Non-Related Medical Expenses"
              field={data.nonRelatedMedicalExpenses}
              onChange={(f) => updateField(data, 'nonRelatedMedicalExpenses', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <OverridableFieldInput
              label="Tariff/Discount Adjustment"
              field={data.tariffDiscountAdjustment}
              onChange={(f) => updateField(data, 'tariffDiscountAdjustment', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <OverridableFieldInput
              label="Customer Advance Paid"
              field={data.customerAdvancePaid}
              onChange={(f) => updateField(data, 'customerAdvancePaid', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};

export const RoomInputPanel: React.FC<InputPanelProps<RoomDeductionInputs>> = ({
  data,
  onChange,
  onAuditLog,
}) => {
  const [isOpen, setIsOpen] = React.useState(false);
  const roomTypes: RoomType[] = ['Ward', 'Shared', 'Single', 'Suite', 'Other'];

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Home className="h-4 w-4 text-primary" />
              Room / Proportionate Deduction
              {data.roomTypeAvailed !== data.allowedRoomType && (
                <Badge variant="outline" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
                  Mismatch
                </Badge>
              )}
              <ChevronDown className={cn('h-4 w-4 ml-auto transition-transform', isOpen && 'rotate-180')} />
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-3 pt-0">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Room Type Availed</Label>
                <Select
                  value={data.roomTypeAvailed}
                  onValueChange={(v) => updateField(data, 'roomTypeAvailed', v as RoomType, onChange)}
                >
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {roomTypes.map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Allowed Room Type</Label>
                <Select
                  value={data.allowedRoomType}
                  onValueChange={(v) => updateField(data, 'allowedRoomType', v as RoomType, onChange)}
                >
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {roomTypes.map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <OverridableFieldInput
              label="Actual Room Rent/Day"
              field={data.actualRoomRentPerDay}
              onChange={(f) => updateField(data, 'actualRoomRentPerDay', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <OverridableFieldInput
              label="Allowed Room Rent/Day"
              field={data.allowedRoomRentPerDay}
              onChange={(f) => updateField(data, 'allowedRoomRentPerDay', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1">
                <Label className="text-xs">Cap Type</Label>
                <Select
                  value={data.capType}
                  onValueChange={(v) => updateField(data, 'capType', v as CapType, onChange)}
                >
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="FixedPerDay">Fixed/Day</SelectItem>
                    <SelectItem value="PercentOfSI">% of SI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">City Type</Label>
                <Select
                  value={data.cityType}
                  onValueChange={(v) => updateField(data, 'cityType', v as CityType, onChange)}
                >
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Metro">Metro</SelectItem>
                    <SelectItem value="Non-Metro">Non-Metro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">ICU</Label>
                <div className="flex items-center h-8 gap-2">
                  <Switch
                    checked={data.isICU}
                    onCheckedChange={(v) => updateField(data, 'isICU', v, onChange)}
                  />
                  <span className="text-xs">{data.isICU ? 'Yes' : 'No'}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between py-2 px-3 rounded-lg bg-muted/30">
              <span className="text-sm text-muted-foreground">Length of Stay</span>
              <span className="font-medium">{data.lengthOfStay} days</span>
            </div>
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};

export const DeductibleInputPanel: React.FC<InputPanelProps<DeductibleInputs>> = ({
  data,
  onChange,
  onAuditLog,
}) => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <CreditCard className="h-4 w-4 text-primary" />
              Deductibles
              <ChevronDown className={cn('h-4 w-4 ml-auto transition-transform', isOpen && 'rotate-180')} />
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-3 pt-0">
            <div className="space-y-1">
              <Label className="text-xs">Per-Claim Deductible Type</Label>
              <Select
                value={data.perClaimDeductibleType}
                onValueChange={(v) => updateField(data, 'perClaimDeductibleType', v as 'Fixed' | 'Percentage', onChange)}
              >
                <SelectTrigger className="h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Fixed">Fixed Amount</SelectItem>
                  <SelectItem value="Percentage">Percentage</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <OverridableFieldInput
              label={`Per-Claim Deductible (${data.perClaimDeductibleType === 'Fixed' ? '₹' : '%'})`}
              field={data.perClaimDeductibleValue}
              onChange={(f) => updateField(data, 'perClaimDeductibleValue', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type={data.perClaimDeductibleType === 'Fixed' ? 'currency' : 'percentage'}
            />

            <OverridableFieldInput
              label="Catastrophic Deductible"
              field={data.catastrophicDeductible}
              onChange={(f) => updateField(data, 'catastrophicDeductible', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <OverridableFieldInput
              label="Aggregate Deductible Limit"
              field={data.aggregateDeductibleLimit}
              onChange={(f) => updateField(data, 'aggregateDeductibleLimit', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <OverridableFieldInput
              label="Consumed Aggregate Deductible"
              field={data.consumedAggregateDeductible}
              onChange={(f) => updateField(data, 'consumedAggregateDeductible', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <OverridableFieldInput
              label="Remaining Aggregate Deductible"
              field={data.remainingAggregateDeductible}
              onChange={(f) => updateField(data, 'remainingAggregateDeductible', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <div className="flex items-center justify-between py-2 px-3 rounded-lg bg-muted/30">
              <span className="text-sm text-muted-foreground">Is Resettlement</span>
              <Switch
                checked={data.isResettlement}
                onCheckedChange={(v) => updateField(data, 'isResettlement', v, onChange)}
              />
            </div>
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};

export const CopayInputPanel: React.FC<InputPanelProps<CopayInputs>> = ({
  data,
  onChange,
  onAuditLog,
}) => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Users className="h-4 w-4 text-primary" />
              Co-pay
              {(data.isApplicable.finalValue as boolean) && (
                <Badge variant="outline" className="text-xs">{data.percentage.finalValue}%</Badge>
              )}
              <ChevronDown className={cn('h-4 w-4 ml-auto transition-transform', isOpen && 'rotate-180')} />
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-3 pt-0">
            <OverridableFieldInput
              label="Co-pay Applicable"
              field={data.isApplicable}
              onChange={(f) => updateField(data, 'isApplicable', f as OverridableField<boolean>, onChange)}
              onAuditLog={onAuditLog}
              type="boolean"
            />

            {(data.isApplicable.finalValue as boolean) && (
              <OverridableFieldInput
                label="Co-pay Percentage"
                field={data.percentage}
                onChange={(f) => updateField(data, 'percentage', f as OverridableField<number>, onChange)}
                onAuditLog={onAuditLog}
                type="percentage"
              />
            )}

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Co-pay Drivers (Display Only)</Label>
              <div className="grid grid-cols-2 gap-1 text-xs">
                <div className="flex justify-between py-1 px-2 bg-muted/20 rounded">
                  <span className="text-muted-foreground">Claim Type:</span>
                  <span>{data.drivers.claimType}</span>
                </div>
                <div className="flex justify-between py-1 px-2 bg-muted/20 rounded">
                  <span className="text-muted-foreground">Age Slab:</span>
                  <span>{data.drivers.ageSlab}</span>
                </div>
                <div className="flex justify-between py-1 px-2 bg-muted/20 rounded">
                  <span className="text-muted-foreground">City:</span>
                  <span>{data.drivers.city}</span>
                </div>
                <div className="flex justify-between py-1 px-2 bg-muted/20 rounded">
                  <span className="text-muted-foreground">Provider:</span>
                  <span>{data.drivers.providerType}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};

export const OtherInsurerPanel: React.FC<InputPanelProps<OtherInsurerInputs>> = ({
  data,
  onChange,
  onAuditLog,
}) => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Shield className="h-4 w-4 text-primary" />
              Other Insurer / Policy
              <ChevronDown className={cn('h-4 w-4 ml-auto transition-transform', isOpen && 'rotate-180')} />
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-3 pt-0">
            <OverridableFieldInput
              label="Amount Paid by Other Insurer"
              field={data.otherInsurerPaid}
              onChange={(f) => updateField(data, 'otherInsurerPaid', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <OverridableFieldInput
              label="Amount Paid by Another ACKO Policy"
              field={data.otherAckoPolicyPaid}
              onChange={(f) => updateField(data, 'otherAckoPolicyPaid', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};

export const BenefitInputPanel: React.FC<InputPanelProps<BenefitInputs>> = ({
  data,
  onChange,
  onAuditLog,
}) => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Wallet className="h-4 w-4 text-primary" />
              Benefits / Covers
              <ChevronDown className={cn('h-4 w-4 ml-auto transition-transform', isOpen && 'rotate-180')} />
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-3 pt-0">
            <OverridableFieldInput
              label="Hospital Cash Benefit (HCB) Applicable"
              field={data.hcbApplicable}
              onChange={(f) => updateField(data, 'hcbApplicable', f as OverridableField<boolean>, onChange)}
              onAuditLog={onAuditLog}
              type="boolean"
            />

            {(data.hcbApplicable.finalValue as boolean) && (
              <>
                <OverridableFieldInput
                  label="HCB Per Day Amount"
                  field={data.hcbPerDayAmount}
                  onChange={(f) => updateField(data, 'hcbPerDayAmount', f as OverridableField<number>, onChange)}
                  onAuditLog={onAuditLog}
                  type="currency"
                />

                <OverridableFieldInput
                  label="HCB Payable Days"
                  field={data.hcbPayableDays}
                  onChange={(f) => updateField(data, 'hcbPayableDays', f as OverridableField<number>, onChange)}
                  onAuditLog={onAuditLog}
                  type="number"
                />

                <div className="flex items-center justify-between py-2 px-3 rounded-lg bg-muted/30">
                  <span className="text-sm text-muted-foreground">Max Payable Days</span>
                  <span className="font-medium">{data.hcbMaxPayableDays} days</span>
                </div>
              </>
            )}

            {data.alternativeBenefits.length > 0 && (
              <div className="space-y-2">
                <Label className="text-xs text-muted-foreground">Alternative Benefits</Label>
                <div className="space-y-1">
                  {data.alternativeBenefits.map((b, i) => (
                    <div
                      key={i}
                      className={cn(
                        'flex items-center justify-between py-2 px-3 rounded-lg border cursor-pointer transition-colors',
                        data.selectedBenefit === b.name
                          ? 'border-primary bg-primary/5'
                          : 'hover:bg-muted/30'
                      )}
                      onClick={() => updateField(data, 'selectedBenefit', b.name, onChange)}
                    >
                      <span className="text-sm">{b.name}</span>
                      <span className="font-medium">₹{b.payout.toLocaleString('en-IN')}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};

export const SubLimitPanel: React.FC<InputPanelProps<SubLimitInputs>> = ({
  data,
  onChange,
  onAuditLog,
}) => {
  const [isOpen, setIsOpen] = React.useState(false);
  const subLimitTypes: SubLimitType[] = ['Member', 'Policy', 'Disease', 'Procedure', 'Claim', 'Benefit', 'ClaimType', 'CityAge', 'RoomType', 'HospitalisationType'];

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Calculator className="h-4 w-4 text-primary" />
              Sub-limits
              {data.isExhausted && (
                <Badge variant="destructive" className="text-xs">Exhausted</Badge>
              )}
              <ChevronDown className={cn('h-4 w-4 ml-auto transition-transform', isOpen && 'rotate-180')} />
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-3 pt-0">
            <div className="space-y-1">
              <Label className="text-xs">Applicable Sub-limit Type</Label>
              <Select
                value={data.applicableType || 'none'}
                onValueChange={(v) => updateField(data, 'applicableType', v === 'none' ? null : v as SubLimitType, onChange)}
              >
                <SelectTrigger className="h-8">
                  <SelectValue placeholder="None" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {subLimitTypes.map((t) => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {data.applicableType && (
              <OverridableFieldInput
                label="Available Sub-limit Balance"
                field={data.availableBalance}
                onChange={(f) => updateField(data, 'availableBalance', f as OverridableField<number>, onChange)}
                onAuditLog={onAuditLog}
                type="currency"
              />
            )}
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};

export const BSIPanel: React.FC<InputPanelProps<BSIInputs>> = ({
  data,
  onChange,
  onAuditLog,
}) => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Wallet className="h-4 w-4 text-primary" />
              BSI & Buffers
              {data.bufferApproved && (
                <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">Buffer Approved</Badge>
              )}
              <ChevronDown className={cn('h-4 w-4 ml-auto transition-transform', isOpen && 'rotate-180')} />
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-3 pt-0">
            <OverridableFieldInput
              label="Available BSI"
              field={data.availableBSI}
              onChange={(f) => updateField(data, 'availableBSI', f as OverridableField<number>, onChange)}
              onAuditLog={onAuditLog}
              type="currency"
            />

            <div className="flex items-center justify-between py-2 px-3 rounded-lg bg-muted/30">
              <span className="text-sm text-muted-foreground">Sub-limit Over & Above BSI</span>
              <Switch
                checked={data.isSubLimitOverBSI}
                onCheckedChange={(v) => updateField(data, 'isSubLimitOverBSI', v, onChange)}
              />
            </div>

            <div className="flex items-center justify-between py-2 px-3 rounded-lg bg-muted/30">
              <span className="text-sm text-muted-foreground">Buffer Approved</span>
              <Switch
                checked={data.bufferApproved}
                onCheckedChange={(v) => updateField(data, 'bufferApproved', v, onChange)}
              />
            </div>

            {data.bufferApproved && (
              <>
                <OverridableFieldInput
                  label="Buffer Amount"
                  field={data.bufferAmount}
                  onChange={(f) => updateField(data, 'bufferAmount', f as OverridableField<number>, onChange)}
                  onAuditLog={onAuditLog}
                  type="currency"
                />
                <div className="space-y-1">
                  <Label className="text-xs">Buffer Approval Reference</Label>
                  <Input
                    value={data.bufferApprovalReference}
                    onChange={(e) => updateField(data, 'bufferApprovalReference', e.target.value, onChange)}
                    placeholder="Enter reference..."
                    className="h-8"
                  />
                </div>
              </>
            )}

            <div className="flex items-center justify-between py-2 px-3 rounded-lg bg-muted/30">
              <span className="text-sm text-muted-foreground">Has Other Active Policy</span>
              <Switch
                checked={data.hasOtherActivePolicy}
                onCheckedChange={(v) => updateField(data, 'hasOtherActivePolicy', v, onChange)}
              />
            </div>
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};

export const TDSPanel: React.FC<InputPanelProps<TDSSettlementInputs>> = ({
  data,
  onChange,
  onAuditLog,
}) => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Building2 className="h-4 w-4 text-primary" />
              TDS & Settlement
              <Badge variant="outline" className="text-xs">
                {data.claimType}
              </Badge>
              <ChevronDown className={cn('h-4 w-4 ml-auto transition-transform', isOpen && 'rotate-180')} />
            </CardTitle>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-3 pt-0">
            <div className="space-y-1">
              <Label className="text-xs">Settlement Destination</Label>
              <Select
                value={data.claimType}
                onValueChange={(v) => updateField(data, 'claimType', v as 'Cashless' | 'Reimbursement', onChange)}
              >
                <SelectTrigger className="h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Cashless">Hospital (Cashless)</SelectItem>
                  <SelectItem value="Reimbursement">Customer (Reimbursement)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {data.claimType === 'Cashless' && (
              <>
                <OverridableFieldInput
                  label="TDS Applicable"
                  field={data.tdsApplicable}
                  onChange={(f) => updateField(data, 'tdsApplicable', f as OverridableField<boolean>, onChange)}
                  onAuditLog={onAuditLog}
                  type="boolean"
                />

                {(data.tdsApplicable.finalValue as boolean) && (
                  <OverridableFieldInput
                    label="TDS Rate"
                    field={data.tdsRate}
                    onChange={(f) => updateField(data, 'tdsRate', f as OverridableField<number>, onChange)}
                    onAuditLog={onAuditLog}
                    type="percentage"
                  />
                )}
              </>
            )}
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};
