import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calculator, RefreshCw } from 'lucide-react';

import {
  FinancialAdjudicationState,
  AuditLogEntry,
} from './types';
import { createOverridableField, useFinancialCalculation, useAIFlags } from './useFinancialCalculation';
import { CalculationLadder } from './CalculationLadder';
import { SummaryCard } from './SummaryCard';
import { AuditLogSheet } from './AuditLogSheet';

// Initial state with sample data
const createInitialState = (): FinancialAdjudicationState => ({
  billInputs: {
    totalBilledAmount: createOverridableField(245000, 'Extracted'),
    billHeads: {
      roomRent: 35000,
      treatmentProcedure: 85000,
      pharmacy: 25000,
      consumables: 15000,
      investigationDiagnostics: 25000,
      other: 60000,
    },
    nmeTotal: createOverridableField(5000, 'Extracted'),
    nmeBreakdown: [
      { item: 'Registration charges', amount: 1000 },
      { item: 'File charges', amount: 500 },
      { item: 'Laundry', amount: 1500 },
      { item: 'Food (attendant)', amount: 2000 },
    ],
    nonRelatedMedicalExpenses: createOverridableField(0, 'System'),
    tariffDiscountAdjustment: createOverridableField(0, 'System'),
    customerAdvancePaid: createOverridableField(0, 'System'),
  },
  roomInputs: {
    roomTypeAvailed: 'Single',
    actualRoomRentPerDay: createOverridableField(7000, 'Extracted'),
    allowedRoomType: 'Shared',
    allowedRoomRentPerDay: createOverridableField(5000, 'System'),
    capType: 'FixedPerDay',
    cityType: 'Metro',
    isICU: false,
    lengthOfStay: 5,
  },
  deductibleInputs: {
    perClaimDeductibleType: 'Fixed',
    perClaimDeductibleValue: createOverridableField(0, 'System'),
    catastrophicDeductible: createOverridableField(0, 'System'),
    aggregateDeductibleLimit: createOverridableField(50000, 'System'),
    consumedAggregateDeductible: createOverridableField(50000, 'System'),
    remainingAggregateDeductible: createOverridableField(0, 'System'),
    isResettlement: false,
  },
  copayInputs: {
    isApplicable: createOverridableField(true, 'System'),
    percentage: createOverridableField(10, 'System'),
    drivers: {
      claimType: 'Cashless',
      ageSlab: '31-45',
      city: 'Metro',
      relationship: 'Self',
      providerType: 'Network',
      roomType: 'Single',
      admissionType: 'Emergency',
      isICU: false,
      diseaseCategory: 'Surgical',
      hasSecondOpinion: false,
    },
  },
  otherInsurerInputs: {
    otherInsurerPaid: createOverridableField(0, 'System'),
    otherAckoPolicyPaid: createOverridableField(0, 'System'),
  },
  benefitInputs: {
    hcbApplicable: createOverridableField(true, 'System'),
    hcbPerDayAmount: createOverridableField(1000, 'System'),
    hcbPayableDays: createOverridableField(4, 'System'),
    hcbMaxPayableDays: 30,
    selectedBenefit: 'Hospital Cash Benefit',
    alternativeBenefits: [],
  },
  subLimitInputs: {
    applicableType: null,
    availableBalance: createOverridableField(0, 'System'),
    isExhausted: false,
  },
  bsiInputs: {
    availableBSI: createOverridableField(500000, 'System'),
    isSubLimitOverBSI: false,
    bufferApproved: false,
    bufferAmount: createOverridableField(0, 'System'),
    bufferApprovalReference: '',
    isBSIExhausted: false,
    hasOtherActivePolicy: false,
  },
  tdsInputs: {
    claimType: 'Cashless',
    tdsApplicable: createOverridableField(true, 'System'),
    tdsRate: createOverridableField(2, 'System'),
  },
  isManualMode: false,
  auditLog: [],
  aiFlags: [],
  calculationResult: null,
});

export const FinancialSummarySection: React.FC = () => {
  const [state, setState] = useState<FinancialAdjudicationState>(createInitialState);
  const [isAuditLogOpen, setIsAuditLogOpen] = useState(false);

  // Calculate results
  const calculationResult = useFinancialCalculation(state);
  const aiFlags = useAIFlags(state, calculationResult);

  // Add audit log entry
  const addAuditEntry = useCallback((entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => {
    const newEntry: AuditLogEntry = {
      ...entry,
      id: `audit-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      auditLog: [...prev.auditLog, newEntry],
    }));
  }, []);

  // Handle step override
  const handleStepOverride = useCallback(
    (stepNumber: number, newValue: number, reason: string, note?: string) => {
      // This would update the relevant input field that affects this step
      // For now, we just log it
      addAuditEntry({
        user: 'Current User',
        field: `Calculation Step ${stepNumber}`,
        oldValue: null,
        newValue,
        reason,
        note,
      });
    },
    [addAuditEntry]
  );

  // Toggle manual mode
  const toggleManualMode = () => {
    setState((prev) => ({ ...prev, isManualMode: !prev.isManualMode }));
  };

  // Recalculate
  const handleRecalculate = () => {
    // Force re-render by updating state
    setState((prev) => ({ ...prev }));
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="py-3 border-b bg-muted/30">
        <CardTitle className="flex items-center justify-between text-base">
          <div className="flex items-center gap-2">
            <Calculator className="h-4 w-4 text-primary" />
            Financial Summary
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={handleRecalculate}>
              <RefreshCw className="h-3 w-3 mr-1" />
              Recalculate
            </Button>
            <AuditLogSheet
              entries={state.auditLog}
              isOpen={isAuditLogOpen}
              onOpenChange={setIsAuditLogOpen}
            />
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {/* Summary Card - Always visible at top */}
        <div className="p-4 border-b">
          <SummaryCard result={calculationResult} claimType={state.tdsInputs.claimType} />
        </div>

        {/* Calculation Ladder - Full width */}
        <div className="p-4">
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3">
            Calculation Pipeline
          </h3>
          <CalculationLadder
            result={calculationResult}
            state={state}
            claimType={state.tdsInputs.claimType}
            aiFlags={aiFlags}
            onStepOverride={handleStepOverride}
            onAuditLog={addAuditEntry}
          />
        </div>
      </CardContent>
    </Card>
  );
};
