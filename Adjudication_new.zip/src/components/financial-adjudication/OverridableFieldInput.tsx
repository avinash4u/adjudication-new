import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Switch } from '@/components/ui/switch';
import { Edit2, Check, X, AlertCircle, Link } from 'lucide-react';
import { OverridableField, SourceTag, AuditLogEntry } from './types';
import { cn } from '@/lib/utils';

interface OverridableFieldInputProps {
  label: string;
  field: OverridableField<number | boolean>;
  onChange: (newField: OverridableField<number | boolean>) => void;
  onAuditLog: (entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => void;
  type?: 'currency' | 'percentage' | 'boolean' | 'number';
  disabled?: boolean;
  user?: string;
}

const SourceBadge: React.FC<{ source: SourceTag }> = ({ source }) => {
  const colors = {
    System: 'bg-blue-100 text-blue-700 border-blue-200',
    Extracted: 'bg-purple-100 text-purple-700 border-purple-200',
    Handler: 'bg-orange-100 text-orange-700 border-orange-200',
  };
  return (
    <Badge variant="outline" className={cn('text-xs', colors[source])}>
      {source}
    </Badge>
  );
};

export const OverridableFieldInput: React.FC<OverridableFieldInputProps> = ({
  label,
  field,
  onChange,
  onAuditLog,
  type = 'currency',
  disabled = false,
  user = 'Current User',
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempValue, setTempValue] = useState<string | boolean>(
    type === 'boolean' ? field.finalValue as boolean : String(field.finalValue)
  );
  const [reason, setReason] = useState(field.overrideReason || '');
  const [note, setNote] = useState(field.overrideNote || '');
  const [evidenceLink, setEvidenceLink] = useState(field.evidenceLink || '');

  const formatValue = (val: number | boolean): string => {
    if (type === 'boolean') return val ? 'Yes' : 'No';
    if (type === 'currency') return `₹${(val as number).toLocaleString('en-IN')}`;
    if (type === 'percentage') return `${val}%`;
    return String(val);
  };

  const handleSave = () => {
    if (!reason.trim()) return;

    const newValue = type === 'boolean' 
      ? tempValue as boolean 
      : type === 'percentage' 
        ? parseFloat(tempValue as string) || 0
        : parseFloat((tempValue as string).replace(/,/g, '')) || 0;

    const newField: OverridableField<number | boolean> = {
      ...field,
      finalValue: newValue,
      isOverridden: true,
      overrideReason: reason,
      overrideNote: note,
      evidenceLink,
      source: 'Handler',
    };

    onAuditLog({
      user,
      field: label,
      oldValue: field.isOverridden ? (field.finalValue as string | number) : (field.systemValue as string | number),
      newValue: newValue as string | number,
      reason,
      note,
      evidenceLink,
    });

    onChange(newField);
    setIsEditing(false);
  };

  const handleReset = () => {
    const newField: OverridableField<number | boolean> = {
      ...field,
      finalValue: field.systemValue,
      isOverridden: false,
      overrideReason: undefined,
      overrideNote: undefined,
      evidenceLink: undefined,
      source: field.source === 'Handler' ? 'System' : field.source,
    };

    onAuditLog({
      user,
      field: label,
      oldValue: field.finalValue as string | number,
      newValue: field.systemValue as string | number,
      reason: 'Reset to system value',
    });

    onChange(newField);
    setIsEditing(false);
  };

  return (
    <div className="flex items-center justify-between py-2 px-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
      <div className="flex-1">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">{label}</span>
          <SourceBadge source={field.source} />
          {field.isOverridden && (
            <Badge variant="outline" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
              <Edit2 className="h-2 w-2 mr-1" />
              Overridden
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-3 mt-1">
          {field.isOverridden && (
            <span className="text-xs text-muted-foreground line-through">
              {formatValue(field.systemValue as (number | boolean))}
            </span>
          )}
          <span className={cn('font-medium', field.isOverridden && 'text-amber-700')}>
            {formatValue(field.finalValue as (number | boolean))}
          </span>
        </div>
      </div>

      <Popover open={isEditing} onOpenChange={setIsEditing}>
        <PopoverTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            disabled={disabled}
            className="h-8"
          >
            <Edit2 className="h-3 w-3" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80" align="end">
          <div className="space-y-3">
            <div className="space-y-1">
              <Label className="text-xs">Override Value</Label>
              {type === 'boolean' ? (
                <div className="flex items-center gap-2">
                  <Switch
                    checked={tempValue as boolean}
                    onCheckedChange={setTempValue}
                  />
                  <span className="text-sm">{tempValue ? 'Yes' : 'No'}</span>
                </div>
              ) : (
                <Input
                  type="text"
                  value={tempValue as string}
                  onChange={(e) => setTempValue(e.target.value)}
                  placeholder={type === 'currency' ? '₹0' : '0'}
                  className="h-8"
                />
              )}
            </div>

            <div className="space-y-1">
              <Label className="text-xs flex items-center gap-1">
                Reason <span className="text-destructive">*</span>
              </Label>
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Enter reason for override..."
                className="h-16 text-sm resize-none"
              />
            </div>

            <div className="space-y-1">
              <Label className="text-xs">Note (optional)</Label>
              <Textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Additional notes..."
                className="h-12 text-sm resize-none"
              />
            </div>

            <div className="space-y-1">
              <Label className="text-xs flex items-center gap-1">
                <Link className="h-3 w-3" />
                Evidence Link (optional)
              </Label>
              <Input
                value={evidenceLink}
                onChange={(e) => setEvidenceLink(e.target.value)}
                placeholder="https://..."
                className="h-8 text-sm"
              />
            </div>

            <div className="flex justify-between pt-2">
              {field.isOverridden && (
                <Button variant="outline" size="sm" onClick={handleReset}>
                  <X className="h-3 w-3 mr-1" />
                  Reset
                </Button>
              )}
              <div className="flex gap-2 ml-auto">
                <Button variant="outline" size="sm" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button size="sm" onClick={handleSave} disabled={!reason.trim()}>
                  <Check className="h-3 w-3 mr-1" />
                  Save
                </Button>
              </div>
            </div>

            {!reason.trim() && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <AlertCircle className="h-3 w-3" />
                Reason is required for overrides
              </p>
            )}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
};
