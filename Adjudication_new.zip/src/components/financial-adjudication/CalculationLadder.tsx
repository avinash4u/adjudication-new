import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Calculator, ChevronDown, ChevronRight, Edit2, Check, X, Info, Building2, User, AlertTriangle, AlertCircle } from 'lucide-react';
import { CalculationResult, CalculationStep, AuditLogEntry, OverridableField, FinancialAdjudicationState, AIFlag } from './types';
import { cn } from '@/lib/utils';
import { getFinalValue } from './useFinancialCalculation';

interface CalculationLadderProps {
  result: CalculationResult;
  state: FinancialAdjudicationState;
  claimType: 'Cashless' | 'Reimbursement';
  aiFlags: AIFlag[];
  onStepOverride: (stepNumber: number, newValue: number, reason: string, note?: string) => void;
  onAuditLog: (entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => void;
}

// Helper to get step-specific input details
const getStepInputDetails = (stepNumber: number, state: FinancialAdjudicationState): { label: string; value: string; source?: string }[] => {
  const details: { label: string; value: string; source?: string }[] = [];
  
  switch (stepNumber) {
    case 1: // Total Billed Amount
      details.push({ 
        label: 'Total Billed', 
        value: `₹${getFinalValue(state.billInputs.totalBilledAmount).toLocaleString('en-IN')}`,
        source: state.billInputs.totalBilledAmount.source
      });
      // Bill head breakdown
      Object.entries(state.billInputs.billHeads).forEach(([key, value]) => {
        const label = key.replace(/([A-Z])/g, ' $1').trim();
        details.push({ label: label.charAt(0).toUpperCase() + label.slice(1), value: `₹${value.toLocaleString('en-IN')}` });
      });
      break;
      
    case 2: // NME Deduction
      details.push({ 
        label: 'NME Total', 
        value: `₹${getFinalValue(state.billInputs.nmeTotal).toLocaleString('en-IN')}`,
        source: state.billInputs.nmeTotal.source
      });
      state.billInputs.nmeBreakdown.forEach((item) => {
        details.push({ label: item.item, value: `₹${item.amount.toLocaleString('en-IN')}` });
      });
      break;
      
    case 3: // Non-Related Medical
      details.push({ 
        label: 'Non-Related Expenses', 
        value: `₹${getFinalValue(state.billInputs.nonRelatedMedicalExpenses).toLocaleString('en-IN')}`,
        source: state.billInputs.nonRelatedMedicalExpenses.source
      });
      break;
      
    case 4: // Tariff Adjustment
      details.push({ 
        label: 'Tariff/Discount', 
        value: `₹${getFinalValue(state.billInputs.tariffDiscountAdjustment).toLocaleString('en-IN')}`,
        source: state.billInputs.tariffDiscountAdjustment.source
      });
      break;
      
    case 5: // Proportionate Deduction
      details.push({ label: 'Room Availed', value: state.roomInputs.roomTypeAvailed });
      details.push({ label: 'Room Allowed', value: state.roomInputs.allowedRoomType });
      details.push({ 
        label: 'Actual Rent/Day', 
        value: `₹${getFinalValue(state.roomInputs.actualRoomRentPerDay).toLocaleString('en-IN')}`,
        source: state.roomInputs.actualRoomRentPerDay.source
      });
      details.push({ 
        label: 'Allowed Rent/Day', 
        value: `₹${getFinalValue(state.roomInputs.allowedRoomRentPerDay).toLocaleString('en-IN')}`,
        source: state.roomInputs.allowedRoomRentPerDay.source
      });
      details.push({ label: 'Length of Stay', value: `${state.roomInputs.lengthOfStay} days` });
      details.push({ label: 'City Type', value: state.roomInputs.cityType });
      details.push({ label: 'ICU', value: state.roomInputs.isICU ? 'Yes' : 'No' });
      break;
      
    case 6: // Per-Claim Deductible
      details.push({ 
        label: 'Type', 
        value: state.deductibleInputs.perClaimDeductibleType
      });
      details.push({ 
        label: 'Value', 
        value: state.deductibleInputs.perClaimDeductibleType === 'Fixed' 
          ? `₹${getFinalValue(state.deductibleInputs.perClaimDeductibleValue).toLocaleString('en-IN')}` 
          : `${getFinalValue(state.deductibleInputs.perClaimDeductibleValue)}%`,
        source: state.deductibleInputs.perClaimDeductibleValue.source
      });
      break;
      
    case 7: // Aggregate Deductible
      details.push({ 
        label: 'Aggregate Limit', 
        value: `₹${getFinalValue(state.deductibleInputs.aggregateDeductibleLimit).toLocaleString('en-IN')}`,
        source: state.deductibleInputs.aggregateDeductibleLimit.source
      });
      details.push({ 
        label: 'Consumed', 
        value: `₹${getFinalValue(state.deductibleInputs.consumedAggregateDeductible).toLocaleString('en-IN')}`,
        source: state.deductibleInputs.consumedAggregateDeductible.source
      });
      details.push({ 
        label: 'Remaining', 
        value: `₹${getFinalValue(state.deductibleInputs.remainingAggregateDeductible).toLocaleString('en-IN')}`,
        source: state.deductibleInputs.remainingAggregateDeductible.source
      });
      details.push({ label: 'Resettlement', value: state.deductibleInputs.isResettlement ? 'Yes' : 'No' });
      break;
      
    case 8: // Co-pay
      details.push({ 
        label: 'Applicable', 
        value: getFinalValue(state.copayInputs.isApplicable) ? 'Yes' : 'No',
        source: state.copayInputs.isApplicable.source
      });
      if (getFinalValue(state.copayInputs.isApplicable)) {
        details.push({ 
          label: 'Percentage', 
          value: `${getFinalValue(state.copayInputs.percentage)}%`,
          source: state.copayInputs.percentage.source
        });
      }
      details.push({ label: 'Claim Type', value: state.copayInputs.drivers.claimType });
      details.push({ label: 'Age Slab', value: state.copayInputs.drivers.ageSlab });
      details.push({ label: 'Provider', value: state.copayInputs.drivers.providerType });
      break;
      
    case 9: // Other Insurer
      details.push({ 
        label: 'Other Insurer Paid', 
        value: `₹${getFinalValue(state.otherInsurerInputs.otherInsurerPaid).toLocaleString('en-IN')}`,
        source: state.otherInsurerInputs.otherInsurerPaid.source
      });
      details.push({ 
        label: 'Other ACKO Policy', 
        value: `₹${getFinalValue(state.otherInsurerInputs.otherAckoPolicyPaid).toLocaleString('en-IN')}`,
        source: state.otherInsurerInputs.otherAckoPolicyPaid.source
      });
      break;
      
    case 10: // HCB Benefit
      details.push({ 
        label: 'HCB Applicable', 
        value: getFinalValue(state.benefitInputs.hcbApplicable) ? 'Yes' : 'No',
        source: state.benefitInputs.hcbApplicable.source
      });
      if (getFinalValue(state.benefitInputs.hcbApplicable)) {
        details.push({ 
          label: 'Per Day', 
          value: `₹${getFinalValue(state.benefitInputs.hcbPerDayAmount).toLocaleString('en-IN')}`,
          source: state.benefitInputs.hcbPerDayAmount.source
        });
        details.push({ 
          label: 'Payable Days', 
          value: `${getFinalValue(state.benefitInputs.hcbPayableDays)} / ${state.benefitInputs.hcbMaxPayableDays}`,
          source: state.benefitInputs.hcbPayableDays.source
        });
      }
      break;
      
    case 11: // Sub-limit
      details.push({ label: 'Type', value: state.subLimitInputs.applicableType || 'None' });
      details.push({ 
        label: 'Available Balance', 
        value: `₹${getFinalValue(state.subLimitInputs.availableBalance).toLocaleString('en-IN')}`,
        source: state.subLimitInputs.availableBalance.source
      });
      details.push({ label: 'Exhausted', value: state.subLimitInputs.isExhausted ? 'Yes' : 'No' });
      break;
      
    case 12: // BSI Check
      details.push({ 
        label: 'Available BSI', 
        value: `₹${getFinalValue(state.bsiInputs.availableBSI).toLocaleString('en-IN')}`,
        source: state.bsiInputs.availableBSI.source
      });
      details.push({ label: 'BSI Exhausted', value: state.bsiInputs.isBSIExhausted ? 'Yes' : 'No' });
      details.push({ label: 'Other Active Policy', value: state.bsiInputs.hasOtherActivePolicy ? 'Yes' : 'No' });
      break;
      
    case 13: // Buffer
      details.push({ label: 'Buffer Approved', value: state.bsiInputs.bufferApproved ? 'Yes' : 'No' });
      if (state.bsiInputs.bufferApproved) {
        details.push({ 
          label: 'Buffer Amount', 
          value: `₹${getFinalValue(state.bsiInputs.bufferAmount).toLocaleString('en-IN')}`,
          source: state.bsiInputs.bufferAmount.source
        });
        details.push({ label: 'Reference', value: state.bsiInputs.bufferApprovalReference || 'N/A' });
      }
      break;
      
    case 14: // Customer Advance
      details.push({ 
        label: 'Advance Paid', 
        value: `₹${getFinalValue(state.billInputs.customerAdvancePaid).toLocaleString('en-IN')}`,
        source: state.billInputs.customerAdvancePaid.source
      });
      break;
      
  }
  
  return details;
};

const StepCard: React.FC<{
  step: CalculationStep;
  inputDetails: { label: string; value: string; source?: string }[];
  aiFlags: AIFlag[];
  onOverride: (newValue: number, reason: string, note?: string) => void;
  isLast: boolean;
  isExpanded: boolean;
  onToggleExpand: () => void;
}> = ({ step, inputDetails, aiFlags, onOverride, isLast, isExpanded, onToggleExpand }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempValue, setTempValue] = useState(String(step.finalValue.finalValue));
  const [reason, setReason] = useState('');

  const handleSave = () => {
    if (!reason.trim()) return;
    const numValue = parseFloat(tempValue.replace(/,/g, '')) || 0;
    onOverride(numValue, reason);
    setIsEditing(false);
    setReason('');
  };

  const getSourceBadgeColor = (source?: string) => {
    switch (source) {
      case 'Extracted': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Handler': return 'bg-purple-100 text-purple-700 border-purple-200';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  return (
    <div className="relative">
      {/* Connector line */}
      {!isLast && (
        <div className="absolute left-4 top-8 w-0.5 h-4 bg-border" />
      )}
      
      <div className={cn(
        'py-2 px-3 rounded-md border transition-all',
        step.finalValue.isOverridden
          ? 'bg-amber-50 border-amber-200'
          : 'bg-card hover:bg-muted/30'
      )}>
        <div className="flex items-center gap-2">
          {/* Step number */}
          <div className={cn(
            'flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-medium',
            step.finalValue.isOverridden
              ? 'bg-amber-200 text-amber-800'
              : 'bg-primary/10 text-primary'
          )}>
            {step.stepNumber}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0 flex items-center gap-2">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-medium text-xs">{step.name}</span>
                {step.finalValue.isOverridden && (
                  <Badge variant="outline" className="text-[10px] px-1 py-0 h-4 bg-amber-100 text-amber-700 border-amber-300">
                    <Edit2 className="h-2 w-2 mr-0.5" />
                    Override
                  </Badge>
                )}
                {/* AI Flag Indicator */}
                {aiFlags.length > 0 && (
                  <TooltipProvider delayDuration={0}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className={cn(
                          'flex items-center justify-center w-4 h-4 rounded-full cursor-help',
                          aiFlags.some(f => f.severity === 'High') 
                            ? 'bg-destructive/10 text-destructive' 
                            : aiFlags.some(f => f.severity === 'Medium')
                            ? 'bg-amber-100 text-amber-600'
                            : 'bg-blue-100 text-blue-600'
                        )}>
                          {aiFlags.some(f => f.severity === 'High') ? (
                            <AlertTriangle className="h-2.5 w-2.5" />
                          ) : (
                            <AlertCircle className="h-2.5 w-2.5" />
                          )}
                        </div>
                      </TooltipTrigger>
                      <TooltipContent side="right" className="max-w-xs p-0">
                        <div className="space-y-0">
                          {aiFlags.map((flag) => (
                            <div
                              key={flag.id}
                              className={cn(
                                'p-2 text-xs border-b last:border-b-0',
                                flag.severity === 'High' && 'bg-destructive/5',
                                flag.severity === 'Medium' && 'bg-amber-50',
                                flag.severity === 'Low' && 'bg-blue-50'
                              )}
                            >
                              <div className="flex items-center gap-1.5 mb-1">
                                <Badge 
                                  variant="outline" 
                                  className={cn(
                                    'text-[9px] px-1 py-0 h-3.5',
                                    flag.severity === 'High' && 'bg-destructive text-destructive-foreground border-destructive',
                                    flag.severity === 'Medium' && 'bg-amber-500 text-white border-amber-500',
                                    flag.severity === 'Low' && 'bg-blue-500 text-white border-blue-500'
                                  )}
                                >
                                  {flag.severity}
                                </Badge>
                                <span className="text-muted-foreground">{flag.category}</span>
                              </div>
                              <p className="font-medium mb-1">{flag.message}</p>
                              <p className="text-muted-foreground">
                                <span className="text-foreground font-medium">Recommendation:</span> {flag.recommendation}
                              </p>
                            </div>
                          ))}
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
              </div>
              <p className="text-[10px] text-muted-foreground truncate">{step.description}</p>
            </div>

            {/* Values - inline */}
            <div className="flex items-center gap-2 text-xs">
              {step.finalValue.isOverridden && (
                <span className="line-through text-muted-foreground">
                  ₹{step.computedValue.toLocaleString('en-IN')}
                </span>
              )}
              <span className={cn(
                'font-semibold',
                step.finalValue.isOverridden ? 'text-amber-700' : 'text-foreground'
              )}>
                ₹{step.runningTotal.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Expand toggle for input details */}
            {inputDetails.length > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-5 px-1.5 text-[10px] text-muted-foreground hover:text-foreground"
                onClick={onToggleExpand}
              >
                {isExpanded ? (
                  <ChevronDown className="h-3 w-3" />
                ) : (
                  <ChevronRight className="h-3 w-3" />
                )}
              </Button>
            )}
          </div>

          {/* Override button */}
          <Popover open={isEditing} onOpenChange={setIsEditing}>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="sm" className="h-5 w-5 p-0">
                <Edit2 className="h-2.5 w-2.5" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-72" align="end">
              <div className="space-y-3">
                <div className="space-y-1">
                  <Label className="text-xs">Override Amount</Label>
                  <Input
                    value={tempValue}
                    onChange={(e) => setTempValue(e.target.value)}
                    placeholder="₹0"
                    className="h-8"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">
                    Reason <span className="text-destructive">*</span>
                  </Label>
                  <Textarea
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="Enter reason..."
                    className="h-16 text-sm resize-none"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" size="sm" onClick={() => setIsEditing(false)}>
                    <X className="h-3 w-3 mr-1" />
                    Cancel
                  </Button>
                  <Button size="sm" onClick={handleSave} disabled={!reason.trim()}>
                    <Check className="h-3 w-3 mr-1" />
                    Save
                  </Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>

        {/* Expandable Input Details */}
        {inputDetails.length > 0 && isExpanded && (
          <div className="mt-1.5 ml-8 p-2 rounded-md bg-muted/30 border border-border/50">
            <div className="grid grid-cols-2 gap-x-3 gap-y-0.5">
              {inputDetails.map((detail, idx) => (
                <div key={idx} className="flex items-center justify-between py-0.5 text-[10px]">
                  <span className="text-muted-foreground truncate">{detail.label}</span>
                  <div className="flex items-center gap-1">
                    <span className="font-medium">{detail.value}</span>
                    {detail.source && (
                      <Badge variant="outline" className={cn('text-[9px] px-0.5 py-0 h-3', getSourceBadgeColor(detail.source))}>
                        {detail.source.charAt(0)}
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export const CalculationLadder: React.FC<CalculationLadderProps> = ({
  result,
  state,
  claimType,
  aiFlags,
  onStepOverride,
  onAuditLog,
}) => {
  const [showExplanation, setShowExplanation] = useState(false);
  const [expandedSteps, setExpandedSteps] = useState<Set<number>>(new Set());
  const [allExpanded, setAllExpanded] = useState(false);

  const toggleStep = (stepNumber: number) => {
    setExpandedSteps(prev => {
      const newSet = new Set(prev);
      if (newSet.has(stepNumber)) {
        newSet.delete(stepNumber);
      } else {
        newSet.add(stepNumber);
      }
      return newSet;
    });
  };

  const toggleAllExpanded = () => {
    if (allExpanded) {
      setExpandedSteps(new Set());
    } else {
      setExpandedSteps(new Set(result.steps.map(s => s.stepNumber)));
    }
    setAllExpanded(!allExpanded);
  };

  const generateExplanation = (): string => {
    const lines: string[] = [];
    lines.push('=== Financial Adjudication Calculation Breakdown ===\n');
    lines.push(`Starting with Total Billed Amount: ₹${result.totalBilled.toLocaleString('en-IN')}\n`);
    
    result.steps.forEach((step) => {
      lines.push(`Step ${step.stepNumber}: ${step.name}`);
      lines.push(`  Formula: ${step.formula}`);
      lines.push(`  Computed: ₹${step.computedValue.toLocaleString('en-IN')}`);
      if (step.finalValue.isOverridden) {
        lines.push(`  ⚠️ OVERRIDDEN to: ₹${step.runningTotal.toLocaleString('en-IN')}`);
        lines.push(`  Reason: ${step.finalValue.overrideReason}`);
      }
      lines.push(`  Running Total: ₹${step.runningTotal.toLocaleString('en-IN')}\n`);
    });

    lines.push('=== Final Summary ===');
    lines.push(`Final Payable: ₹${result.finalPayable.toLocaleString('en-IN')}`);
    if (result.tdsDeducted > 0) {
      lines.push(`TDS Deducted: ₹${result.tdsDeducted.toLocaleString('en-IN')}`);
      lines.push(`Net Payable to Hospital: ₹${result.netPayableToHospital.toLocaleString('en-IN')}`);
    }
    
    return lines.join('\n');
  };

  return (
    <Card>
      <CardHeader className="py-2">
        <CardTitle className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Calculator className="h-4 w-4 text-primary" />
            Calculation Ladder
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-6 text-[10px] px-2"
              onClick={toggleAllExpanded}
            >
              {allExpanded ? (
                <>
                  <ChevronDown className="h-3 w-3 mr-1" />
                  Collapse All
                </>
              ) : (
                <>
                  <ChevronRight className="h-3 w-3 mr-1" />
                  Expand All
                </>
              )}
            </Button>
            <Collapsible open={showExplanation} onOpenChange={setShowExplanation}>
              <CollapsibleTrigger asChild>
                <Button variant="outline" size="sm" className="h-6 text-[10px]">
                  <Info className="h-3 w-3 mr-1" />
                  Explain
                  {showExplanation ? (
                    <ChevronDown className="h-3 w-3 ml-1" />
                  ) : (
                    <ChevronRight className="h-3 w-3 ml-1" />
                  )}
                </Button>
              </CollapsibleTrigger>
            </Collapsible>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-1 pt-0">
        <Collapsible open={showExplanation}>
          <CollapsibleContent>
            <div className="mb-3 p-2 bg-muted/50 rounded-lg border">
              <pre className="text-[10px] whitespace-pre-wrap font-mono text-muted-foreground">
                {generateExplanation()}
              </pre>
            </div>
          </CollapsibleContent>
        </Collapsible>

        {/* Cash Reserve Banner */}
        <div className="py-1.5 px-2 rounded-md bg-blue-50 border border-blue-200 mb-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-blue-700">Cash Reserve (Blocked from BSI)</span>
            <span className="font-semibold text-blue-800">
              ₹{result.reserveAmount.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* Calculation Steps */}
        <div className="space-y-1">
          {result.steps.map((step, index) => {
            const stepFlags = aiFlags.filter(f => f.relatedStep === step.stepNumber);
            return (
              <StepCard
                key={step.stepNumber}
                step={step}
                inputDetails={getStepInputDetails(step.stepNumber, state)}
                aiFlags={stepFlags}
                onOverride={(value, reason, note) => {
                  onStepOverride(step.stepNumber, value, reason, note);
                  onAuditLog({
                    user: 'Current User',
                    field: step.name,
                    oldValue: step.computedValue,
                    newValue: value,
                    reason,
                    note,
                  });
                }}
                isLast={index === result.steps.length - 1}
                isExpanded={expandedSteps.has(step.stepNumber)}
                onToggleExpand={() => toggleStep(step.stepNumber)}
              />
            );
          })}
        </div>

        <Separator className="my-4" />

        {/* Settlement Details */}
        <div className="p-3 rounded-lg bg-card border space-y-2">
          <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1">
            {claimType === 'Cashless' ? (
              <Building2 className="h-3 w-3" />
            ) : (
              <User className="h-3 w-3" />
            )}
            Settlement to {claimType === 'Cashless' ? 'Hospital' : 'Customer'}
          </h4>
          
          {claimType === 'Cashless' && result.tdsDeducted > 0 ? (
            <div className="space-y-1">
              <div className="flex justify-between text-sm font-medium">
                <span>Total Settled Amount</span>
                <span>₹{result.finalPayable.toLocaleString('en-IN')}</span>
              </div>
              <Separator className="my-1" />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">TDS Deducted</span>
                <span className="font-medium text-amber-600">₹{result.tdsDeducted.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Net Payable to Hospital</span>
                <span className="font-medium">₹{result.netPayableToHospital.toLocaleString('en-IN')}</span>
              </div>
            </div>
          ) : (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">
                {claimType === 'Cashless' ? 'Payable to Hospital' : 'Payable to Customer'}
              </span>
              <span className="font-semibold text-primary">
                ₹{result.finalPayable.toLocaleString('en-IN')}
              </span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
