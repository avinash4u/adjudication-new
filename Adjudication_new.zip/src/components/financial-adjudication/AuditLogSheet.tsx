import React from 'react';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { History, User, Clock, ArrowRight, Link } from 'lucide-react';
import { AuditLogEntry } from './types';
import { cn } from '@/lib/utils';

interface AuditLogSheetProps {
  entries: AuditLogEntry[];
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export const AuditLogSheet: React.FC<AuditLogSheetProps> = ({
  entries,
  isOpen,
  onOpenChange,
}) => {
  const sortedEntries = [...entries].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  return (
    <Sheet open={isOpen} onOpenChange={onOpenChange}>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm">
          <History className="h-4 w-4 mr-2" />
          Override Audit Log
          {entries.length > 0 && (
            <Badge variant="secondary" className="ml-2 text-xs">
              {entries.length}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-full sm:max-w-xl">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            Override Audit Log
          </SheetTitle>
          <SheetDescription>
            Complete history of all overrides and changes
          </SheetDescription>
        </SheetHeader>
        
        <ScrollArea className="h-[calc(100vh-120px)] mt-6">
          {entries.length === 0 ? (
            <div className="text-center py-12">
              <History className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">No overrides recorded yet</p>
            </div>
          ) : (
            <div className="space-y-3 pr-4">
              {sortedEntries.map((entry) => (
                <div
                  key={entry.id}
                  className="p-3 rounded-lg border bg-muted/30 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium text-sm">{entry.field}</span>
                        <Badge variant="outline" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
                          Override
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2 mt-2 text-sm">
                        <span className="text-muted-foreground line-through">
                          {typeof entry.oldValue === 'number'
                            ? `₹${entry.oldValue.toLocaleString('en-IN')}`
                            : entry.oldValue === null
                            ? 'null'
                            : String(entry.oldValue)}
                        </span>
                        <ArrowRight className="h-3 w-3 text-muted-foreground" />
                        <span className="font-medium text-amber-700">
                          {typeof entry.newValue === 'number'
                            ? `₹${entry.newValue.toLocaleString('en-IN')}`
                            : String(entry.newValue)}
                        </span>
                      </div>

                      <div className="mt-2 p-2 rounded bg-muted/50 text-xs">
                        <span className="text-muted-foreground">Reason: </span>
                        <span>{entry.reason}</span>
                      </div>

                      {entry.note && (
                        <div className="mt-1 text-xs text-muted-foreground">
                          <span>Note: </span>
                          <span>{entry.note}</span>
                        </div>
                      )}

                      {entry.evidenceLink && (
                        <a
                          href={entry.evidenceLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-2 inline-flex items-center gap-1 text-xs text-primary hover:underline"
                        >
                          <Link className="h-3 w-3" />
                          View Evidence
                        </a>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 mt-3 pt-2 border-t text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <User className="h-3 w-3" />
                      {entry.user}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {entry.timestamp}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
};
