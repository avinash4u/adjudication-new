import React, { useState, forwardRef, useImperativeHandle } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { CalendarIcon, Plus, Trash2, ChevronUp, ChevronDown, Pencil, Check, X, Info } from 'lucide-react';
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

// Predefined deduction reasons
const DEDUCTION_REASONS = [
  'Administrative charge discount',
  'Co-payment',
  'Deductible amount',
  'Non-medical expenses',
  'Room rent limit exceeded',
  'Pre-existing disease exclusion',
  'Treatment not covered',
  'Missing documentation',
  'Duplicate claim',
  'Policy limit exceeded',
  'Other'
];

interface Bill {
  id: string;
  billNumber: string;
  billDate: Date | undefined;
  days: number;
  rent: number;
  amount: number;
  isNonMedical: boolean;
  particulars: string;
}

interface Deduction {
  id: string;
  amount: number;
  reason: string;
}

interface BillEntryExpandableProps {
  isExpanded: boolean;
  onToggle: () => void;
  currentAmount?: number;
  onSave?: (data: { bills: Bill[], deductions: Deduction[] }) => void;
  savedBills?: Bill[];
  savedDeductions?: Deduction[];
  mode?: 'add' | 'edit'; // 'add' mode allows adding new entries, 'edit' mode only allows editing/deleting existing
  onUpdateBill?: (billId: string, updatedBill: Bill) => void;
  onDeleteBill?: (billId: string) => void;
  onUpdateDeduction?: (deductionId: string, updatedDeduction: Deduction) => void;
  onDeleteDeduction?: (deductionId: string) => void;
}

export interface BillEntryExpandableHandle {
  flushPending: () => { bills: Bill[]; deductions: Deduction[] }
}


export const BillEntryExpandable = forwardRef<BillEntryExpandableHandle, BillEntryExpandableProps>((
  {
    isExpanded,
    onToggle,
    currentAmount = 0,
    onSave,
    savedBills = [],
    savedDeductions = [],
    mode = 'add',
    onUpdateBill,
    onDeleteBill,
    onUpdateDeduction,
    onDeleteDeduction
  },
  ref
) => {
  const [bills, setBills] = useState<Bill[]>([]);
  const [deductions, setDeductions] = useState<Deduction[]>([]);
  const [editingBillId, setEditingBillId] = useState<string | null>(null);
  const [editingDeductionId, setEditingDeductionId] = useState<string | null>(null);
  const [editedBill, setEditedBill] = useState<Bill | null>(null);
  const [editedDeduction, setEditedDeduction] = useState<Deduction | null>(null);

  const [newBill, setNewBill] = useState({
    billNumber: '',
    billDate: undefined as Date | undefined,
    days: 0,
    rent: 0,
    amount: 0,
    isNonMedical: false,
    particulars: ''
  });

  const [newDeduction, setNewDeduction] = useState({
    amount: 0,
    reason: ''
  });

  const addBill = () => {
    if (newBill.billNumber && newBill.billDate && newBill.amount > 0) {
      const addedBillNumber = newBill.billNumber;
      const addedBillDate = newBill.billDate;
      setBills(prev => [...prev, {
        id: Date.now().toString(),
        billNumber: newBill.billNumber,
        billDate: newBill.billDate,
        days: newBill.days,
        rent: newBill.rent,
        amount: newBill.amount,
        isNonMedical: newBill.isNonMedical,
        particulars: newBill.particulars
      }]);
      setNewBill({ billNumber: addedBillNumber, billDate: addedBillDate, days: 0, rent: 0, amount: 0, isNonMedical: false, particulars: '' });
    }
  };

  const toggleNonMedical = (id: string) => {
    setBills(prev => prev.map(bill => 
      bill.id === id ? { ...bill, isNonMedical: !bill.isNonMedical } : bill
    ));
  };

  const addDeduction = () => {
    if (newDeduction.amount > 0 && newDeduction.reason.trim()) {
      setDeductions(prev => [...prev, {
        id: Date.now().toString(),
        amount: newDeduction.amount,
        reason: newDeduction.reason
      }]);
      setNewDeduction({ amount: 0, reason: '' });
    }
  };

  const removeBill = (id: string) => {
    setBills(prev => prev.filter(bill => bill.id !== id));
  };

  const removeDeduction = (id: string) => {
    setDeductions(prev => prev.filter(deduction => deduction.id !== id));
  };

  const handleEditBill = (bill: Bill) => {
    setEditingBillId(bill.id);
    setEditedBill({ ...bill });
  };

  const handleSaveEditedBill = () => {
    if (editedBill && onUpdateBill) {
      onUpdateBill(editedBill.id, editedBill);
      setEditingBillId(null);
      setEditedBill(null);
    }
  };

  const handleCancelEditBill = () => {
    setEditingBillId(null);
    setEditedBill(null);
  };

  const handleEditDeduction = (deduction: Deduction) => {
    setEditingDeductionId(deduction.id);
    setEditedDeduction({ ...deduction });
  };

  const handleSaveEditedDeduction = () => {
    if (editedDeduction && onUpdateDeduction) {
      onUpdateDeduction(editedDeduction.id, editedDeduction);
      setEditingDeductionId(null);
      setEditedDeduction(null);
    }
  };

  const handleCancelEditDeduction = () => {
    setEditingDeductionId(null);
    setEditedDeduction(null);
  };

const handleSaveChanges = () => {
  if (mode === 'add') {
    // Include any in-progress inputs as part of this save
    const pendingBills: Bill[] = [...bills];
    if (newBill.billNumber && newBill.billDate && (newBill.amount || 0) > 0) {
      pendingBills.push({
        id: Date.now().toString(),
        billNumber: newBill.billNumber,
        billDate: newBill.billDate,
        days: newBill.days || 0,
        rent: newBill.rent || 0,
        amount: newBill.amount || 0,
        isNonMedical: newBill.isNonMedical || false,
        particulars: newBill.particulars || ''
      });
    }

    const pendingDeductions: Deduction[] = [...deductions];
    if ((newDeduction.amount || 0) > 0 && newDeduction.reason.trim()) {
      pendingDeductions.push({
        id: (Date.now() + 1).toString(),
        amount: newDeduction.amount,
        reason: newDeduction.reason
      });
    }

    // Pass everything up to the parent to be treated as saved
    if (onSave && (pendingBills.length > 0 || pendingDeductions.length > 0)) {
      onSave({ bills: pendingBills, deductions: pendingDeductions });
    }
    
    // Reset temporary lists and inputs
    setBills([]);
    setDeductions([]);
    setNewBill({
      billNumber: '',
      billDate: undefined,
      days: 0,
      rent: 0,
      amount: 0,
      isNonMedical: false,
      particulars: ''
    });
    setNewDeduction({
      amount: 0,
      reason: ''
    });
  } else if (onSave) {
    onSave({ bills, deductions });
    onToggle();
  }
};

useImperativeHandle(ref, () => ({
  flushPending: () => {
    const pendingBills: Bill[] = [...bills];
    if (newBill.billNumber && newBill.billDate && (newBill.amount || 0) > 0) {
      pendingBills.push({
        id: Date.now().toString(),
        billNumber: newBill.billNumber,
        billDate: newBill.billDate,
        days: newBill.days || 0,
        rent: newBill.rent || 0,
        amount: newBill.amount || 0,
        isNonMedical: newBill.isNonMedical || false,
        particulars: newBill.particulars || ''
      });
    }

    const pendingDeductions: Deduction[] = [...deductions];
    if ((newDeduction.amount || 0) > 0 && newDeduction.reason.trim()) {
      pendingDeductions.push({
        id: (Date.now() + 1).toString(),
        amount: newDeduction.amount,
        reason: newDeduction.reason
      });
    }

    // Reset local state after flushing
    setBills([]);
    setDeductions([]);
    setNewBill({
      billNumber: '',
      billDate: undefined,
      days: 0,
      rent: 0,
      amount: 0,
      isNonMedical: false,
      particulars: ''
    });
    setNewDeduction({ amount: 0, reason: '' });

    return { bills: pendingBills, deductions: pendingDeductions };
  }
}));

  const totalBilledAmount = bills.reduce((sum, bill) => sum + bill.amount, 0);
  const totalNonMedicalExpenses = bills.reduce((sum, bill) => bill.isNonMedical ? sum + bill.amount : sum, 0);
  const totalDeductions = deductions.reduce((sum, deduction) => sum + deduction.amount, 0);
  const finalAmount = totalBilledAmount - totalDeductions;

  // Calculate totals including saved entries
  const savedTotalBilledAmount = savedBills.reduce((sum, bill) => sum + bill.amount, 0);
  const savedTotalNonMedicalExpenses = savedBills.reduce((sum, bill) => bill.isNonMedical ? sum + bill.amount : sum, 0);
  const savedTotalDeductions = savedDeductions.reduce((sum, deduction) => sum + deduction.amount, 0);
  const grandTotalBilled = totalBilledAmount + savedTotalBilledAmount;
  const grandTotalNonMedical = totalNonMedicalExpenses + savedTotalNonMedicalExpenses;
  const grandTotalDeductions = totalDeductions + savedTotalDeductions;
  const grandFinalAmount = grandTotalBilled - grandTotalDeductions;

  return (
    <Card className="w-full">
      <CardContent className="space-y-2 p-3">
          {/* Edit Mode: Show saved entries with edit/delete options */}
          {mode === 'edit' && (
            <>
              {/* Saved Bills with Edit/Delete */}
              {savedBills.length > 0 && (
                <div>
                  <h3 className="text-xs font-semibold mb-2">Bills</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs font-medium w-1/3">Bill Date</TableHead>
                        <TableHead className="text-xs font-medium w-1/3">Bill Number</TableHead>
                        <TableHead className="text-xs font-medium w-[80px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {savedBills.map((bill) => (
                        <React.Fragment key={bill.id}>
                          {editingBillId === bill.id && editedBill ? (
                            <>
                              <TableRow>
                                <TableCell>
                                  <div className="flex gap-1">
                                    <Input
                                      type="text"
                                      placeholder="DD/MM/YYYY"
                                      value={editedBill.billDate ? format(editedBill.billDate, 'dd/MM/yyyy') : ''}
                                      onChange={(e) => {
                                        const value = e.target.value;
                                        const parts = value.split('/');
                                        if (parts.length === 3) {
                                          const day = parseInt(parts[0]);
                                          const month = parseInt(parts[1]) - 1;
                                          const year = parseInt(parts[2]);
                                          if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
                                            const date = new Date(year, month, day);
                                            if (date.getDate() === day && date.getMonth() === month) {
                                              setEditedBill({ ...editedBill, billDate: date });
                                            }
                                          }
                                        }
                                      }}
                                      className="h-7 text-xs"
                                    />
                                    <Popover>
                                      <PopoverTrigger asChild>
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          className="h-7 w-7 p-0"
                                        >
                                          <CalendarIcon className="h-3 w-3" />
                                        </Button>
                                      </PopoverTrigger>
                                      <PopoverContent className="w-auto p-0 bg-background z-50" align="start">
                                        <Calendar
                                          mode="single"
                                          selected={editedBill.billDate}
                                          onSelect={(date) => setEditedBill({ ...editedBill, billDate: date })}
                                          initialFocus
                                          className="p-3 pointer-events-auto"
                                        />
                                      </PopoverContent>
                                    </Popover>
                                  </div>
                                 </TableCell>
                                 <TableCell>
                                   <Input
                                     value={editedBill.billNumber}
                                     onChange={(e) => setEditedBill({ ...editedBill, billNumber: e.target.value })}
                                     className="h-7 text-xs"
                                   />
                                 </TableCell>
                                 <TableCell>
                                   <div className="flex gap-1">
                                     <Button 
                                       variant="ghost" 
                                       size="sm" 
                                       onClick={handleSaveEditedBill}
                                       className="text-green-600 hover:text-green-700 h-7 w-7 p-0"
                                     >
                                       <Check className="h-3 w-3" />
                                     </Button>
                                     <Button 
                                       variant="ghost" 
                                       size="sm" 
                                       onClick={handleCancelEditBill}
                                       className="text-muted-foreground hover:text-foreground h-7 w-7 p-0"
                                     >
                                       <X className="h-3 w-3" />
                                     </Button>
                                   </div>
                                 </TableCell>
                               </TableRow>
                               <TableRow className="border-t-0">
                                 <TableCell colSpan={3} className="py-2">
                                   <div className="mb-2">
                                     <label className="text-xs text-muted-foreground">Particulars</label>
                                     <Input
                                       value={editedBill.particulars}
                                       onChange={(e) => setEditedBill({ ...editedBill, particulars: e.target.value })}
                                       placeholder="Enter particular details"
                                       className="h-7 text-xs"
                                     />
                                   </div>
                                   <div className="grid grid-cols-3 gap-2">
                                    <div>
                                      <label className="text-xs text-muted-foreground">Days</label>
                                      <Input
                                        type="number"
                                        value={editedBill.days}
                                        onChange={(e) => {
                                          const days = parseFloat(e.target.value) || 0;
                                          setEditedBill({ 
                                            ...editedBill, 
                                            days,
                                            amount: days * editedBill.rent // Auto-calculate amount
                                          });
                                        }}
                                        className="h-7 text-xs"
                                      />
                                    </div>
                                    <div>
                                      <div className="flex items-center gap-1 mb-1">
                                        <label className="text-xs text-muted-foreground">Rent (₹)</label>
                                        <TooltipProvider>
                                          <Tooltip>
                                            <TooltipTrigger asChild>
                                              <Info className="h-3 w-3 text-muted-foreground cursor-help" />
                                            </TooltipTrigger>
                                            <TooltipContent>
                                              <p className="text-xs">Auto-fetched from tariff</p>
                                            </TooltipContent>
                                          </Tooltip>
                                        </TooltipProvider>
                                      </div>
                                      <Input
                                        type="number"
                                        value={editedBill.rent}
                                        onChange={(e) => {
                                          const rent = parseFloat(e.target.value) || 0;
                                          setEditedBill({ 
                                            ...editedBill, 
                                            rent,
                                            amount: editedBill.days * rent // Auto-calculate amount
                                          });
                                        }}
                                        className="h-7 text-xs"
                                      />
                                    </div>
                                    <div>
                                      <div className="flex items-center gap-1 mb-1">
                                        <label className="text-xs text-muted-foreground">Bill Amount (₹)</label>
                                        <TooltipProvider>
                                          <Tooltip>
                                            <TooltipTrigger asChild>
                                              <Info className="h-3 w-3 text-muted-foreground cursor-help" />
                                            </TooltipTrigger>
                                            <TooltipContent>
                                              <p className="text-xs">Days × Rent</p>
                                            </TooltipContent>
                                          </Tooltip>
                                        </TooltipProvider>
                                      </div>
                                      <Input
                                        type="number"
                                        value={editedBill.amount}
                                        onChange={(e) => setEditedBill({ ...editedBill, amount: parseFloat(e.target.value) || 0 })}
                                        className="h-7 text-xs"
                                      />
                                    </div>
                                  </div>
                                </TableCell>
                              </TableRow>
                            </>
                          ) : (
                            <>
                              <TableRow>
                                <TableCell className="text-xs">
                                  {bill.billDate ? format(bill.billDate, 'dd MMM yyyy') : 'Not set'}
                                </TableCell>
                                <TableCell className="text-xs">{bill.billNumber}</TableCell>
                                <TableCell>
                                  <div className="flex gap-1">
                                    <Button 
                                      variant="ghost" 
                                      size="sm" 
                                      onClick={() => handleEditBill(bill)}
                                      className="text-primary hover:text-primary/80 h-7 w-7 p-0"
                                    >
                                      <Pencil className="h-3 w-3" />
                                    </Button>
                                    <Button 
                                      variant="ghost" 
                                      size="sm" 
                                      onClick={() => onDeleteBill?.(bill.id)}
                                      className="text-destructive hover:text-destructive/80 h-7 w-7 p-0"
                                    >
                                      <Trash2 className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </TableCell>
                               </TableRow>
                               <TableRow className="border-t-0">
                                 <TableCell colSpan={3} className="py-2">
                                   <div className="mb-2 text-xs">
                                     <span className="text-muted-foreground">Particulars: </span>
                                     <span>{bill.particulars || 'N/A'}</span>
                                   </div>
                                   <div className="grid grid-cols-3 gap-2 text-xs">
                                    <div>
                                      <span className="text-muted-foreground">Days: </span>
                                      <span>{bill.days}</span>
                                    </div>
                                    <div>
                                      <span className="text-muted-foreground">Rent: </span>
                                      <span>₹{bill.rent.toLocaleString()}</span>
                                    </div>
                                    <div>
                                      <span className="text-muted-foreground">Bill Amount: </span>
                                      <span>₹{bill.amount.toLocaleString()}</span>
                                    </div>
                                  </div>
                                </TableCell>
                              </TableRow>
                            </>
                          )}
                        </React.Fragment>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {/* Saved Deductions with Edit/Delete */}
              {savedDeductions.length > 0 && (
                <div>
                  <h3 className="text-xs font-semibold mb-2 mt-3">Deductions</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs font-medium">Deduction Amount (₹)</TableHead>
                        <TableHead className="text-xs font-medium">Deduction Reason</TableHead>
                        <TableHead className="text-xs font-medium w-[80px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {savedDeductions.map((deduction) => (
                        <TableRow key={deduction.id}>
                          {editingDeductionId === deduction.id && editedDeduction ? (
                            <>
                              <TableCell>
                                <Input
                                  type="number"
                                  value={editedDeduction.amount}
                                  onChange={(e) => setEditedDeduction({ ...editedDeduction, amount: parseFloat(e.target.value) || 0 })}
                                  className="h-7 text-xs"
                                />
                              </TableCell>
                              <TableCell>
                                <Select
                                  value={editedDeduction.reason}
                                  onValueChange={(value) => setEditedDeduction({ ...editedDeduction, reason: value })}
                                >
                                  <SelectTrigger className="h-7 text-xs">
                                    <SelectValue placeholder="Select reason" />
                                  </SelectTrigger>
                                  <SelectContent className="bg-background z-50">
                                    {DEDUCTION_REASONS.map((reason) => (
                                      <SelectItem key={reason} value={reason} className="text-xs">
                                        {reason}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </TableCell>
                              <TableCell>
                                <div className="flex gap-1">
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={handleSaveEditedDeduction}
                                    className="text-green-600 hover:text-green-700 h-7 w-7 p-0"
                                  >
                                    <Check className="h-3 w-3" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={handleCancelEditDeduction}
                                    className="text-muted-foreground hover:text-foreground h-7 w-7 p-0"
                                  >
                                    <X className="h-3 w-3" />
                                  </Button>
                                </div>
                              </TableCell>
                            </>
                          ) : (
                            <>
                              <TableCell className="text-xs">₹{deduction.amount.toLocaleString()}</TableCell>
                              <TableCell className="text-xs">{deduction.reason}</TableCell>
                              <TableCell>
                                <div className="flex gap-1">
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => handleEditDeduction(deduction)}
                                    className="text-primary hover:text-primary/80 h-7 w-7 p-0"
                                  >
                                    <Pencil className="h-3 w-3" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => onDeleteDeduction?.(deduction.id)}
                                    className="text-destructive hover:text-destructive/80 h-7 w-7 p-0"
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                </div>
                              </TableCell>
                            </>
                          )}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

            </>
          )}

          {/* Add Mode: Show form to add new entries */}
          {mode === 'add' && (
            <>
              {/* Saved Entries Section */}
              {(savedBills.length > 0 || savedDeductions.length > 0) && (
                <div className="mb-4">
                  <h3 className="text-sm font-semibold mb-3 text-primary">Saved Entries</h3>
              
              {savedBills.length > 0 && (
                <div>
                  <h3 className="text-xs font-semibold mb-2">Saved Bills</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs font-medium w-1/2">Bill Date</TableHead>
                        <TableHead className="text-xs font-medium w-1/2">Bill Number</TableHead>
                        <TableHead className="text-xs font-medium w-[80px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {savedBills.map((bill) => (
                        <React.Fragment key={bill.id}>
                          {editingBillId === bill.id && editedBill ? (
                            <>
                              <TableRow>
                                <TableCell>
                                  <div className="flex gap-1">
                                    <Input
                                      type="text"
                                      placeholder="DD/MM/YYYY"
                                      value={editedBill.billDate ? format(editedBill.billDate, 'dd/MM/yyyy') : ''}
                                      onChange={(e) => {
                                        const value = e.target.value;
                                        const parts = value.split('/');
                                        if (parts.length === 3) {
                                          const day = parseInt(parts[0]);
                                          const month = parseInt(parts[1]) - 1;
                                          const year = parseInt(parts[2]);
                                          if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
                                            const date = new Date(year, month, day);
                                            if (date.getDate() === day && date.getMonth() === month) {
                                              setEditedBill({ ...editedBill, billDate: date });
                                            }
                                          }
                                        }
                                      }}
                                      className="h-7 text-xs"
                                    />
                                    <Popover>
                                      <PopoverTrigger asChild>
                                        <Button variant="outline" size="sm" className="h-7 w-7 p-0">
                                          <CalendarIcon className="h-3 w-3" />
                                        </Button>
                                      </PopoverTrigger>
                                      <PopoverContent className="w-auto p-0 bg-background z-50" align="start">
                                        <Calendar
                                          mode="single"
                                          selected={editedBill.billDate}
                                          onSelect={(date) => setEditedBill({ ...editedBill, billDate: date })}
                                          initialFocus
                                          className="p-3 pointer-events-auto"
                                        />
                                      </PopoverContent>
                                    </Popover>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Input
                                    value={editedBill.billNumber}
                                    onChange={(e) => setEditedBill({ ...editedBill, billNumber: e.target.value })}
                                    className="h-7 text-xs"
                                  />
                                </TableCell>
                                <TableCell>
                                  <div className="flex gap-1">
                                    <Button 
                                      variant="ghost" 
                                      size="sm" 
                                      onClick={() => {
                                        if (editedBill && onUpdateBill) {
                                          onUpdateBill(editedBill.id, editedBill);
                                          setEditingBillId(null);
                                          setEditedBill(null);
                                        }
                                      }}
                                      className="h-6 w-6 p-0"
                                    >
                                      <Check className="h-3 w-3" />
                                    </Button>
                                    <Button 
                                      variant="ghost" 
                                      size="sm" 
                                      onClick={handleCancelEditBill}
                                      className="h-6 w-6 p-0"
                                    >
                                      <X className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                              <TableRow className="border-t-0">
                                <TableCell colSpan={3} className="py-2">
                                  <div className="grid grid-cols-4 gap-2 text-xs">
                                    <div>
                                      <span className="text-muted-foreground">Days: </span>
                                      <Input
                                        type="number"
                                        value={editedBill.days}
                                        onChange={(e) => {
                                          const days = parseInt(e.target.value) || 0;
                                          setEditedBill({ 
                                            ...editedBill, 
                                            days,
                                            amount: days * editedBill.rent // Auto-calculate amount
                                          });
                                        }}
                                        className="h-6 text-xs inline-block w-16 ml-1"
                                      />
                                    </div>
                                    <div className="flex items-center">
                                      <span className="text-muted-foreground">Rent: </span>
                                      <Input
                                        type="number"
                                        value={editedBill.rent}
                                        onChange={(e) => {
                                          const rent = parseFloat(e.target.value) || 0;
                                          setEditedBill({ 
                                            ...editedBill, 
                                            rent,
                                            amount: editedBill.days * rent // Auto-calculate amount
                                          });
                                        }}
                                        className="h-6 text-xs inline-block w-20 ml-1"
                                      />
                                      <TooltipProvider>
                                        <Tooltip>
                                          <TooltipTrigger asChild>
                                            <Info className="h-3 w-3 text-muted-foreground cursor-help ml-1" />
                                          </TooltipTrigger>
                                          <TooltipContent>
                                            <p className="text-xs">Auto-fetched from tariff</p>
                                          </TooltipContent>
                                        </Tooltip>
                                      </TooltipProvider>
                                    </div>
                                    <div className="flex items-center">
                                      <span className="text-muted-foreground">Amount: </span>
                                      <Input
                                        type="number"
                                        value={editedBill.amount}
                                        onChange={(e) => setEditedBill({ ...editedBill, amount: parseFloat(e.target.value) || 0 })}
                                        className="h-6 text-xs inline-block w-24 ml-1"
                                      />
                                      <TooltipProvider>
                                        <Tooltip>
                                          <TooltipTrigger asChild>
                                            <Info className="h-3 w-3 text-muted-foreground cursor-help ml-1" />
                                          </TooltipTrigger>
                                          <TooltipContent>
                                            <p className="text-xs">Days × Rent</p>
                                          </TooltipContent>
                                        </Tooltip>
                                      </TooltipProvider>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <span className="text-muted-foreground">Non-Medical: </span>
                                      <Switch
                                        checked={editedBill.isNonMedical}
                                        onCheckedChange={(checked) => setEditedBill({ ...editedBill, isNonMedical: checked })}
                                        className="h-4 w-8"
                                      />
                                    </div>
                                  </div>
                                </TableCell>
                              </TableRow>
                            </>
                          ) : (
                            <>
                              <TableRow>
                                <TableCell className="text-xs">
                                  {bill.billDate ? format(bill.billDate, 'dd MMM yyyy') : 'Not set'}
                                </TableCell>
                                <TableCell className="text-xs">{bill.billNumber}</TableCell>
                                <TableCell>
                                  <div className="flex gap-1">
                                    <Button 
                                      variant="ghost" 
                                      size="sm" 
                                      onClick={() => handleEditBill(bill)}
                                      className="h-6 w-6 p-0"
                                    >
                                      <Pencil className="h-3 w-3" />
                                    </Button>
                                    <Button 
                                      variant="ghost" 
                                      size="sm" 
                                      onClick={() => onDeleteBill && onDeleteBill(bill.id)}
                                      className="h-6 w-6 p-0"
                                    >
                                      <Trash2 className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                              <TableRow className="border-t-0">
                                <TableCell colSpan={3} className="py-2">
                                  <div className="grid grid-cols-4 gap-2 text-xs">
                                    <div>
                                      <span className="text-muted-foreground">Days: </span>
                                      <span>{bill.days}</span>
                                    </div>
                                    <div>
                                      <span className="text-muted-foreground">Rent: </span>
                                      <span>₹{bill.rent.toLocaleString()}</span>
                                    </div>
                                    <div>
                                      <span className="text-muted-foreground">Bill Amount: </span>
                                      <span>₹{bill.amount.toLocaleString()}</span>
                                    </div>
                                    <div>
                                      {bill.isNonMedical && (
                                        <Badge variant="secondary" className="text-[10px] px-1 py-0">
                                          Non-Medical
                                        </Badge>
                                      )}
                                    </div>
                                  </div>
                                </TableCell>
                              </TableRow>
                            </>
                          )}
                        </React.Fragment>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {savedDeductions.length > 0 && (
                <div className="mt-3">
                  <h3 className="text-xs font-semibold mb-2">Saved Deductions</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs font-medium">Deduction Amount (₹)</TableHead>
                        <TableHead className="text-xs font-medium">Deduction Reason</TableHead>
                        <TableHead className="text-xs font-medium w-[80px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {savedDeductions.map((deduction) => (
                        <React.Fragment key={deduction.id}>
                          {editingDeductionId === deduction.id && editedDeduction ? (
                            <TableRow>
                              <TableCell>
                                <Input
                                  type="number"
                                  value={editedDeduction.amount}
                                  onChange={(e) => setEditedDeduction({ ...editedDeduction, amount: parseFloat(e.target.value) || 0 })}
                                  className="h-7 text-xs"
                                />
                              </TableCell>
                              <TableCell>
                                <Select
                                  value={editedDeduction.reason}
                                  onValueChange={(value) => setEditedDeduction({ ...editedDeduction, reason: value })}
                                >
                                  <SelectTrigger className="h-7 text-xs">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {DEDUCTION_REASONS.map((reason) => (
                                      <SelectItem key={reason} value={reason} className="text-xs">
                                        {reason}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </TableCell>
                              <TableCell>
                                <div className="flex gap-1">
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => {
                                      if (editedDeduction && onUpdateDeduction) {
                                        onUpdateDeduction(editedDeduction.id, editedDeduction);
                                        setEditingDeductionId(null);
                                        setEditedDeduction(null);
                                      }
                                    }}
                                    className="h-6 w-6 p-0"
                                  >
                                    <Check className="h-3 w-3" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={handleCancelEditDeduction}
                                    className="h-6 w-6 p-0"
                                  >
                                    <X className="h-3 w-3" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ) : (
                            <TableRow>
                              <TableCell className="text-xs">₹{deduction.amount.toLocaleString()}</TableCell>
                              <TableCell className="text-xs">{deduction.reason}</TableCell>
                              <TableCell>
                                <div className="flex gap-1">
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => handleEditDeduction(deduction)}
                                    className="h-6 w-6 p-0"
                                  >
                                    <Pencil className="h-3 w-3" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => onDeleteDeduction && onDeleteDeduction(deduction.id)}
                                    className="h-6 w-6 p-0"
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          )}
                        </React.Fragment>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
                </div>
              )}

              {/* New Entry Form */}
              <div className="space-y-3">
                <h3 className="text-sm font-semibold">Add New Entry</h3>
              
              {/* Bills Section */}
              <div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs font-medium w-1/3">Bill Date</TableHead>
                  <TableHead className="text-xs font-medium w-1/3">Bill Number</TableHead>
                  <TableHead className="text-xs font-medium w-1/3">Particulars</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bills.map((bill) => (
                  <React.Fragment key={bill.id}>
                    <TableRow>
                      <TableCell className="text-xs">
                        {bill.billDate ? format(bill.billDate, 'dd MMM yyyy') : 'Not set'}
                      </TableCell>
                      <TableCell className="text-xs">{bill.billNumber}</TableCell>
                      <TableCell className="text-xs">{bill.particulars}</TableCell>
                    </TableRow>
                    <TableRow className="border-t-0">
                      <TableCell colSpan={3} className="py-2">
                        <div className="grid grid-cols-3 gap-2 text-xs">
                          <div>
                            <span className="text-muted-foreground">Days: </span>
                            <span>{bill.days}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Rent: </span>
                            <span>₹{bill.rent.toLocaleString()}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Bill Amount: </span>
                            <span>₹{bill.amount.toLocaleString()}</span>
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  </React.Fragment>
                ))}
                
                {/* Add New Bill Rows */}
                <TableRow className="border-t-2">
                  <TableCell>
                    <div className="flex gap-1">
                      <Input
                        type="text"
                        placeholder="DD/MM/YYYY"
                        value={newBill.billDate ? format(newBill.billDate, 'dd/MM/yyyy') : ''}
                        onChange={(e) => {
                          const value = e.target.value;
                          const parts = value.split('/');
                          if (parts.length === 3) {
                            const day = parseInt(parts[0]);
                            const month = parseInt(parts[1]) - 1;
                            const year = parseInt(parts[2]);
                            if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
                              const date = new Date(year, month, day);
                              if (date.getDate() === day && date.getMonth() === month) {
                                setNewBill(prev => ({ ...prev, billDate: date }));
                              }
                            }
                          }
                        }}
                        className="h-7 text-xs"
                      />
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7 w-7 p-0"
                          >
                            <CalendarIcon className="h-3 w-3" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0 bg-background z-50" align="start">
                          <Calendar
                            mode="single"
                            selected={newBill.billDate}
                            onSelect={(date) => setNewBill(prev => ({ ...prev, billDate: date }))}
                            initialFocus
                            className="p-3 pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Input
                      placeholder="Bill number"
                      value={newBill.billNumber}
                      onChange={(e) => setNewBill(prev => ({ ...prev, billNumber: e.target.value }))}
                      className="h-7 text-xs"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      placeholder="Enter particular details"
                      value={newBill.particulars}
                      onChange={(e) => setNewBill(prev => ({ ...prev, particulars: e.target.value }))}
                      className="h-7 text-xs"
                    />
                  </TableCell>
                </TableRow>
                <TableRow className="border-t-0">
                  <TableCell colSpan={3} className="py-2">
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="text-xs text-muted-foreground">Days</label>
                        <Input
                          type="number"
                          placeholder="Days"
                          value={newBill.days || ''}
                          onChange={(e) => {
                            const days = parseFloat(e.target.value) || 0;
                            setNewBill(prev => ({ 
                              ...prev, 
                              days,
                              amount: days * prev.rent // Auto-calculate amount
                            }));
                          }}
                          className="h-7 text-xs"
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-1 mb-1">
                          <label className="text-xs text-muted-foreground">Rent (₹)</label>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Info className="h-3 w-3 text-muted-foreground cursor-help" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs">Auto-fetched from hospital tariff</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                        <Input
                          type="number"
                          placeholder="Rent"
                          value={newBill.rent || ''}
                          onChange={(e) => {
                            const rent = parseFloat(e.target.value) || 0;
                            setNewBill(prev => ({ 
                              ...prev, 
                              rent,
                              amount: prev.days * rent // Auto-calculate amount
                            }));
                          }}
                          className="h-7 text-xs"
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-1 mb-1">
                          <label className="text-xs text-muted-foreground">Bill Amount (₹)</label>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Info className="h-3 w-3 text-muted-foreground cursor-help" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs">Auto-calculated: Days × Rent</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                        <Input
                          type="number"
                          placeholder="Amount"
                          value={newBill.amount || ''}
                          onChange={(e) => setNewBill(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                          className="h-7 text-xs"
                        />
                      </div>
                    </div>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          {/* Deductions Section */}
          <div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs font-medium">Deduction Amount (₹)</TableHead>
                  <TableHead className="text-xs font-medium">Deduction Reason</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {deductions.map((deduction) => (
                  <TableRow key={deduction.id}>
                    <TableCell className="text-xs">₹{deduction.amount.toLocaleString()}</TableCell>
                    <TableCell className="text-xs">{deduction.reason}</TableCell>
                  </TableRow>
                ))}
                
                {/* Add New Deduction Row */}
                <TableRow className="border-t-2">
                  <TableCell>
                    <Input
                      type="number"
                      placeholder="Enter amount"
                      value={newDeduction.amount || ''}
                      onChange={(e) => setNewDeduction(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                      className="h-7 text-xs"
                    />
                  </TableCell>
                  <TableCell>
                    <Select
                      value={newDeduction.reason}
                      onValueChange={(value) => setNewDeduction(prev => ({ ...prev, reason: value }))}
                    >
                      <SelectTrigger className="h-7 text-xs">
                        <SelectValue placeholder="Select deduction reason" />
                      </SelectTrigger>
                      <SelectContent className="bg-background z-50">
                        {DEDUCTION_REASONS.map((reason) => (
                          <SelectItem key={reason} value={reason} className="text-xs">
                            {reason}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

              {/* Action Buttons - Only show in add mode */}
              </div>
            </>
          )}
        </CardContent>
    </Card>
  );
});