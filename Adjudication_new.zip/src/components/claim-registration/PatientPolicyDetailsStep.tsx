import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, User } from 'lucide-react';

interface PatientPolicyDetailsStepProps {
  patientData: any;
  onNext: (data: any) => void;
  onBack: () => void;
  onCancel: () => void;
}

const PatientPolicyDetailsStep: React.FC<PatientPolicyDetailsStepProps> = ({
  patientData,
  onNext,
  onBack,
  onCancel,
}) => {
  const [patientName, setPatientName] = useState(patientData?.name || '');
  const [mobileNumber, setMobileNumber] = useState(patientData?.mobile || '');
  const [uhid, setUhid] = useState(patientData?.uhid || '');
  const [emailAddress, setEmailAddress] = useState(patientData?.email || '');
  const [policyNumber, setPolicyNumber] = useState('');

  const isManualEntry = !patientData;

  const handleContinue = () => {
    if (isManualEntry) {
      // For manual entry, validate required fields
      if (patientName && policyNumber) {
        const manualPatientData = {
          name: patientName,
          mobile: mobileNumber,
          uhid: uhid,
          email: emailAddress
        };
        const manualPolicy = {
          id: policyNumber,
          name: 'Manual Policy Entry',
          type: 'Manual',
          coverage: 'N/A',
          status: 'Active'
        };
        onNext({ patientData: manualPatientData, policy: manualPolicy });
      }
    } else {
      // Existing logic for found patients
      const availablePolicies = [
        {
          id: 'ACKO-HLTH-001234',
          name: 'ACKO Health Insurance Premium',
          type: 'Individual',
          coverage: '₹5,00,000',
          status: 'Active'
        },
        {
          id: 'ACKO-HLTH-001235',
          name: 'ACKO Family Health Plan',
          type: 'Family',
          coverage: '₹10,00,000',
          status: 'Active'
        }
      ];
      
      if (policyNumber) {
        const policy = availablePolicies.find(p => p.id === policyNumber);
        onNext(policy);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2 text-primary">
        <User className="h-5 w-5" />
        <h2 className="text-lg font-semibold">Patient & Policy Details</h2>
      </div>

      {/* Patient Found Status - Only show for found patients */}
      {!isManualEntry && (
        <Card className="border-success bg-success/5">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 text-success">
              <CheckCircle className="h-5 w-5" />
              <span className="font-medium">Patient Found</span>
            </div>
            <div className="mt-2 text-sm">
              <span className="font-medium text-success">
                {patientData?.name || 'Priya Sharma'} - ACKO-HLTH-001234
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Patient Information */}
      <div className="space-y-4">
        <h3 className="text-base font-semibold">Patient Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="patient-name">Patient Name *</Label>
            <Input
              id="patient-name"
              value={patientName}
              onChange={(e) => setPatientName(e.target.value)}
              placeholder=""
              readOnly={!isManualEntry}
              className={!isManualEntry ? "bg-muted" : ""}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="mobile-number">Mobile Number</Label>
            <Input
              id="mobile-number"
              value={mobileNumber}
              onChange={(e) => setMobileNumber(e.target.value)}
              placeholder=""
              readOnly={!isManualEntry}
              className={!isManualEntry ? "bg-muted" : ""}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="uhid">UHID</Label>
            <Input
              id="uhid"
              value={uhid}
              onChange={(e) => setUhid(e.target.value)}
              placeholder=""
              readOnly={!isManualEntry}
              className={!isManualEntry ? "bg-muted" : ""}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              value={emailAddress}
              onChange={(e) => setEmailAddress(e.target.value)}
              placeholder=""
              readOnly={!isManualEntry}
              className={!isManualEntry ? "bg-muted" : ""}
            />
          </div>
        </div>
      </div>

      {/* Policy Number */}
      <div className="space-y-2">
        <Label htmlFor="policy-number">Policy Number *</Label>
        <Select value={policyNumber} onValueChange={setPolicyNumber}>
          <SelectTrigger id="policy-number">
            <SelectValue placeholder="Select a policy" />
          </SelectTrigger>
          <SelectContent className="bg-background">
            {isManualEntry ? (
              <SelectItem value="manual-entry">Manual Entry</SelectItem>
            ) : (
              <>
                <SelectItem value="ACKO-HLTH-001234">
                  ACKO-HLTH-001234 - ACKO Health Insurance Premium (Individual, ₹5,00,000)
                </SelectItem>
                <SelectItem value="ACKO-HLTH-001235">
                  ACKO-HLTH-001235 - ACKO Family Health Plan (Family, ₹10,00,000)
                </SelectItem>
              </>
            )}
          </SelectContent>
        </Select>
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={onBack}>
          Back
        </Button>
        
        <div className="flex space-x-2">
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button 
            onClick={handleContinue}
            disabled={!patientName || !policyNumber}
            className="px-6"
          >
            Continue
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PatientPolicyDetailsStep;