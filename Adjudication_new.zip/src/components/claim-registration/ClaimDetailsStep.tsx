import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { 
  FileText, 
  User, 
  CreditCard, 
  MapPin, 
  CalendarIcon,
  Upload,
  X,
  Search,
  CheckCircle,
  Circle,
  ChevronsUpDown,
  Check,
  AlertCircle
} from 'lucide-react';

interface ClaimDetailsStepProps {
  patientData: any;
  selectedPolicy: any;
  onBack: () => void;
  onCancel: () => void;
  onSubmit: (data: any) => void;
}

const ClaimDetailsStep: React.FC<ClaimDetailsStepProps> = ({
  patientData,
  selectedPolicy,
  onBack,
  onCancel,
  onSubmit,
}) => {
  const { toast } = useToast();
  
  // Check if we have imported claim data
  const importedClaim = patientData?.importedClaim;
  
  const [claimType, setClaimType] = useState(importedClaim?.claimType || '');
  const [claimSubType, setClaimSubType] = useState(importedClaim?.claimSubType || '');
  const [channel, setChannel] = useState(importedClaim?.channel || '');
  const [claimAmount, setClaimAmount] = useState(importedClaim?.claimAmount || '');
  const [admissionDate, setAdmissionDate] = useState<Date>(importedClaim?.admissionDate);
  const [dischargeDate, setDischargeDate] = useState<Date>(importedClaim?.dischargeDate);
  const [hospitalName, setHospitalName] = useState(importedClaim?.hospitalName || '');
  const [hospitalLocation, setHospitalLocation] = useState('');
  const [hospitalAddress, setHospitalAddress] = useState('');
  const [doctorName, setDoctorName] = useState(importedClaim?.doctorName || '');
  const [diseaseCondition, setDiseaseCondition] = useState(importedClaim?.diseaseCondition || '');
  const [bankAccount, setBankAccount] = useState(importedClaim?.bankAccount || '');
  const [confirmBankAccount, setConfirmBankAccount] = useState('');
  const [beneficiaryName, setBeneficiaryName] = useState(patientData?.mainMemberName || 'Rajesh Sharma');
  const [ifscCode, setIfscCode] = useState(importedClaim?.ifscCode || '');
  const [bankName, setBankName] = useState('');
  const [bankBranch, setBankBranch] = useState('');
  const [fetchingBankDetails, setFetchingBankDetails] = useState(false);
  const [accountNumberError, setAccountNumberError] = useState('');
  const [nameMatchStatus, setNameMatchStatus] = useState<'pending' | 'matched' | 'mismatch'>('pending');
  
  
  // Initialize uploaded files
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileSelect = (files: FileList | null) => {
    if (files) {
      const newFiles = Array.from(files);
      setUploadedFiles(prev => [...prev, ...newFiles]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileSelect(e.dataTransfer.files);
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  // Fetch bank details from IFSC code
  const fetchBankDetails = async (ifsc: string) => {
    if (ifsc.length !== 11) return;
    
    setFetchingBankDetails(true);
    try {
      const response = await fetch(`https://ifsc.razorpay.com/${ifsc}`);
      if (response.ok) {
        const data = await response.json();
        setBankName(data.BANK || '');
        setBankBranch(`${data.BRANCH || ''}, ${data.ADDRESS || ''}`);
        
        // Check name match
        const mainMemberName = patientData?.mainMemberName || 'Rajesh Sharma';
        if (beneficiaryName.toLowerCase() === mainMemberName.toLowerCase()) {
          setNameMatchStatus('matched');
        } else {
          setNameMatchStatus('mismatch');
        }
      } else {
        setBankName('');
        setBankBranch('');
      }
    } catch (error) {
      console.error('Error fetching bank details:', error);
      setBankName('');
      setBankBranch('');
    } finally {
      setFetchingBankDetails(false);
    }
  };

  // Handle IFSC code change
  const handleIfscChange = (value: string) => {
    const upperIfsc = value.toUpperCase();
    setIfscCode(upperIfsc);
    if (upperIfsc.length === 11) {
      fetchBankDetails(upperIfsc);
    } else {
      setBankName('');
      setBankBranch('');
    }
  };

  // Validate account numbers match
  const handleConfirmAccountChange = (value: string) => {
    setConfirmBankAccount(value);
    if (value && value !== bankAccount) {
      setAccountNumberError('Account numbers do not match');
    } else {
      setAccountNumberError('');
    }
  };

  // Check name match when beneficiary name changes
  const handleBeneficiaryNameChange = (value: string) => {
    setBeneficiaryName(value);
    const mainMemberName = patientData?.mainMemberName || 'Rajesh Sharma';
    if (value.toLowerCase() === mainMemberName.toLowerCase()) {
      setNameMatchStatus('matched');
    } else {
      setNameMatchStatus('mismatch');
    }
  };


  const handleSubmit = () => {
    // Validate account numbers match for reimbursement claims
    if (isReimbursementClaim && bankAccount !== confirmBankAccount) {
      setAccountNumberError('Account numbers do not match');
      return;
    }
    
    // Validate name match for reimbursement claims
    if (isReimbursementClaim && nameMatchStatus !== 'matched') {
      return;
    }
    
    const claimData = {
      patientData,
      selectedPolicy,
      claimType,
      claimSubType,
      channel,
      claimAmount,
      admissionDate,
      dischargeDate,
      uploadedFiles,
      hospitalName,
      hospitalLocation,
      hospitalAddress,
      doctorName,
      diseaseCondition,
      bankAccount,
      beneficiaryName,
      ifscCode,
      bankName,
      bankBranch
    };
    onSubmit(claimData);
  };

  const isReimbursementClaim = claimType === 'reimbursement';

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2 text-primary">
        <FileText className="h-5 w-5" />
        <h2 className="text-lg font-semibold">
          Claim Details
          {importedClaim && (
            <span className="ml-2 text-sm font-normal text-muted-foreground">
              (Imported from {importedClaim.claimId})
            </span>
          )}
        </h2>
      </div>

      {/* Customer Details */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center space-x-2 text-base">
            <User className="h-4 w-4" />
            <span>Customer Details</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-muted-foreground">Main Member Name</span>
            <div className="font-medium mt-1">{patientData?.mainMemberName || 'Rajesh Sharma'}</div>
          </div>
          <div>
            <span className="text-muted-foreground">Main Member UHID</span>
            <div className="font-medium mt-1">{patientData?.mainMemberUhid || 'UHID001234567'}</div>
          </div>
          <div>
            <span className="text-muted-foreground">Mobile Number</span>
            <div className="font-medium mt-1">{patientData?.mobile || '9876543210'}</div>
          </div>
          <div>
            <span className="text-muted-foreground">Email Address</span>
            <div className="font-medium mt-1">{patientData?.email || 'priya.sharma@email.com'}</div>
          </div>
          <div>
            <span className="text-muted-foreground">Policy Number</span>
            <div className="font-medium mt-1">{selectedPolicy?.id || 'ACKO-HLTH-001234'}</div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="patient-name">Patient Name</Label>
            <Select value={patientData?.name || 'Priya Sharma'} onValueChange={() => {}}>
              <SelectTrigger>
                <SelectValue placeholder="Select patient name" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Priya Sharma">Priya Sharma</SelectItem>
                <SelectItem value="Rajesh Sharma">Rajesh Sharma</SelectItem>
                <SelectItem value="Anita Sharma">Anita Sharma</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="patient-uhid">Patient UHID</Label>
            <Select value={patientData?.uhid || 'UHID001234567'} onValueChange={() => {}}>
              <SelectTrigger>
                <SelectValue placeholder="Select patient UHID" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="UHID001234567">UHID001234567</SelectItem>
                <SelectItem value="UHID001234568">UHID001234568</SelectItem>
                <SelectItem value="UHID001234569">UHID001234569</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Bank Account Details - Only for Reimbursement */}
      {isReimbursementClaim && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-base">
              <CreditCard className="h-4 w-4" />
              <span>Bank Account Details</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="beneficiary-name">Beneficiary Name *</Label>
                <Select value={beneficiaryName} onValueChange={handleBeneficiaryNameChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select beneficiary" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={patientData?.mainMemberName || 'Rajesh Sharma'}>
                      {patientData?.mainMemberName || 'Rajesh Sharma'} (Main Proposer)
                    </SelectItem>
                    <SelectItem value={patientData?.name || 'Priya Sharma'}>
                      {patientData?.name || 'Priya Sharma'}
                    </SelectItem>
                    <SelectItem value="Anita Sharma">Anita Sharma</SelectItem>
                    <SelectItem value="Amit Sharma">Amit Sharma</SelectItem>
                  </SelectContent>
                </Select>
                {nameMatchStatus === 'matched' && (
                  <div className="flex items-center text-sm text-green-600">
                    <CheckCircle className="h-4 w-4 mr-1" />
                    Name matched with proposer
                  </div>
                )}
                {nameMatchStatus === 'mismatch' && (
                  <div className="flex items-center text-sm text-amber-600">
                    <Circle className="h-4 w-4 mr-1" />
                    Name does not match main proposer
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="ifsc-code">IFSC Code *</Label>
                <Input
                  id="ifsc-code"
                  value={ifscCode}
                  onChange={(e) => handleIfscChange(e.target.value)}
                  placeholder="Enter IFSC code"
                  maxLength={11}
                />
                {fetchingBankDetails && (
                  <p className="text-sm text-muted-foreground">Fetching bank details...</p>
                )}
              </div>

              {bankName && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="bank-name">Bank Name</Label>
                    <Input
                      id="bank-name"
                      value={bankName}
                      readOnly
                      className="bg-muted"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bank-branch">Branch & Address</Label>
                    <Input
                      id="bank-branch"
                      value={bankBranch}
                      readOnly
                      className="bg-muted"
                    />
                  </div>
                </>
              )}

              <div className="space-y-2">
                <Label htmlFor="bank-account">Bank Account Number *</Label>
                <Input
                  id="bank-account"
                  type="text"
                  value={bankAccount}
                  onChange={(e) => setBankAccount(e.target.value)}
                  placeholder="Enter bank account number"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm-bank-account">Confirm Account Number *</Label>
                <Input
                  id="confirm-bank-account"
                  type="password"
                  value={confirmBankAccount}
                  onChange={(e) => handleConfirmAccountChange(e.target.value)}
                  placeholder="Re-enter account number"
                />
                {accountNumberError && (
                  <p className="text-sm text-destructive">{accountNumberError}</p>
                )}
                {!accountNumberError && confirmBankAccount && bankAccount === confirmBankAccount && (
                  <div className="flex items-center text-sm text-green-600">
                    <CheckCircle className="h-4 w-4 mr-1" />
                    Account numbers match
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Documents */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center space-x-2 text-base">
            <Upload className="h-4 w-4" />
            <span>Upload Documents</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Drag and Drop Zone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={cn(
              "border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer",
              isDragging 
                ? "border-primary bg-primary/5" 
                : "border-muted-foreground/25 hover:border-primary/50"
            )}
            onClick={() => document.getElementById('file-input')?.click()}
          >
            <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-sm font-medium mb-1">
              Drag and drop files here, or click to browse
            </p>
            <p className="text-xs text-muted-foreground">
              Support for multiple files
            </p>
            <input
              id="file-input"
              type="file"
              multiple
              className="hidden"
              onChange={(e) => handleFileSelect(e.target.files)}
            />
          </div>

          {/* Uploaded Files List */}
          {uploadedFiles.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm font-medium">
                Uploaded Files ({uploadedFiles.length})
              </p>
              <div className="space-y-2">
                {uploadedFiles.map((file, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 border rounded-lg bg-muted/30"
                  >
                    <div className="flex items-center space-x-3 flex-1 min-w-0">
                      <FileText className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{file.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatFileSize(file.size)}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeFile(index);
                      }}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Navigation Buttons */}
      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={onBack}>
          Back
        </Button>
        
        <div className="flex space-x-2">
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="px-6">
            Register Claim
          </Button>
        </div>
      </div>

    </div>
  );
};

export default ClaimDetailsStep;