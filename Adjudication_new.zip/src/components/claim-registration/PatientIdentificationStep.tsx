import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Phone, Mail, User, Plus, FileText, Building2, Calendar, Users, CheckCircle2, Info, Check, ChevronsUpDown } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

interface PatientIdentificationStepProps {
  onNext: (data: any) => void;
  onCancel: () => void;
  onBackToLookup?: () => void;
  initialPatientData?: {
    uhid: string;
    customerName: string;
    customerPhone: string;
    customerEmail: string;
  };
}

const PatientIdentificationStep: React.FC<PatientIdentificationStepProps> = ({
  onNext,
  onCancel,
  onBackToLookup,
  initialPatientData,
}) => {
  const [lookupMethod, setLookupMethod] = useState('mobile');
  const [searchValue, setSearchValue] = useState('');
  const [claimSearchValue, setClaimSearchValue] = useState('');
  const [searchedClaims, setSearchedClaims] = useState<any[]>([]);
  const [corporateName, setCorporateName] = useState('');
  const [employeeId, setEmployeeId] = useState('');
  const [showPolicySelection, setShowPolicySelection] = useState(false);
  const [foundPolicies, setFoundPolicies] = useState<any[]>([]);
  const [selectedPolicy, setSelectedPolicy] = useState<any>(null);
  const [selectedMember, setSelectedMember] = useState<any>(null);
  const [openCorporateCombobox, setOpenCorporateCombobox] = useState(false);
  const [corporateSearchQuery, setCorporateSearchQuery] = useState('');

  // If initialPatientData is provided, skip lookup and go directly to policy selection
  useEffect(() => {
    if (initialPatientData) {
      // Automatically show policy selection with mock policies for this patient
      setFoundPolicies(mockPolicies);
      setShowPolicySelection(true);
    }
  }, [initialPatientData]);

  const corporateList = [
    { value: 'tcs', label: 'Tata Consultancy Services (TCS)' },
    { value: 'infosys', label: 'Infosys Technologies Ltd' },
    { value: 'wipro', label: 'Wipro Limited' },
    { value: 'hcl', label: 'HCL Technologies' },
    { value: 'techm', label: 'Tech Mahindra' },
    { value: 'lnt', label: 'Larsen & Toubro (L&T)' },
    { value: 'reliance', label: 'Reliance Industries' },
    { value: 'icici', label: 'ICICI Bank' },
    { value: 'hdfc', label: 'HDFC Bank' },
    { value: 'sbi', label: 'State Bank of India' },
  ];

  const sampleData = [
    {
      mobile: '9876543210',
      uhid: 'UHID001234567',
      email: 'priya.sharma@email.com',
      name: 'Priya Sharma'
    },
    {
      mobile: '9876543211',
      uhid: 'UHID001234568',
      email: 'rajesh.kumar@email.com',
      name: 'Rajesh Kumar'
    },
    {
      mobile: '9876543212',
      uhid: 'UHID001234569',
      email: 'anita.desai@email.com',
      name: 'Anita Desai'
    }
  ];

  const mockPolicies = [
    {
      id: 'POL001',
      policyNumber: 'HL-987654321',
      policyType: 'Individual Health',
      sumInsured: '₹5,00,000',
      status: 'Active',
      startDate: '01 Jan 2024',
      endDate: '31 Dec 2024',
      totalMembers: 1,
      members: [
        {
          name: 'John Doe',
          relationship: 'Self',
          age: 35,
          uhid: 'UH-123456',
          memberStartDate: '01 Jan 2024',
          memberEndDate: '31 Dec 2024'
        }
      ]
    },
    {
      id: 'POL002',
      policyNumber: 'HL-987654322',
      policyType: 'Family Floater',
      sumInsured: '₹10,00,000',
      status: 'Active',
      startDate: '01 Jan 2024',
      endDate: '31 Dec 2024',
      totalMembers: 4,
      members: [
        {
          name: 'John Doe',
          relationship: 'Self',
          age: 35,
          uhid: 'UH-123456',
          memberStartDate: '01 Jan 2024',
          memberEndDate: '31 Dec 2024'
        },
        {
          name: 'Jane Doe',
          relationship: 'Spouse',
          age: 33,
          uhid: 'UH-123457',
          memberStartDate: '01 Jan 2024',
          memberEndDate: '31 Dec 2024'
        },
        {
          name: 'Jack Doe',
          relationship: 'Son',
          age: 8,
          uhid: 'UH-123458',
          memberStartDate: '01 Jan 2024',
          memberEndDate: '31 Dec 2024'
        },
        {
          name: 'Jill Doe',
          relationship: 'Daughter',
          age: 5,
          uhid: 'UH-123459',
          memberStartDate: '01 Jan 2024',
          memberEndDate: '31 Dec 2024'
        }
      ]
    },
    {
      id: 'POL003',
      policyNumber: 'HL-987654320',
      policyType: 'Individual Health',
      sumInsured: '₹3,00,000',
      status: 'Expired',
      startDate: '01 Jan 2023',
      endDate: '31 Dec 2023',
      totalMembers: 1,
      members: [
        {
          name: 'John Doe',
          relationship: 'Self',
          age: 34,
          uhid: 'UH-123456',
          memberStartDate: '01 Jan 2023',
          memberEndDate: '31 Dec 2023'
        }
      ]
    }
  ];

  const recentClaims = [
    {
      claimId: 'CLM001234569',
      patientName: 'Anita Desai',
      mobile: '9876543212',
      uhid: 'UHID001234569',
      email: 'anita.desai@email.com',
      policyNumber: 'POL001234569',
      claimAmount: '32000',
      claimDate: '2024-03-10',
      status: 'Completed',
      lastVisited: '2024-03-15',
      // Additional claim details for import
      claimType: 'reimbursement',
      claimSubType: 'hospitalization',
      channel: 'web',
      admissionDate: new Date('2024-03-08'),
      dischargeDate: new Date('2024-03-10'),
      hospitalName: 'Apollo Hospital, Mumbai',
      doctorName: 'Dr. Rajesh Patel',
      diseaseCondition: 'Acute appendicitis with complications',
      bankAccount: '1234567890123456',
      ifscCode: 'HDFC0001234',
      documents: [
        { id: 1, name: 'Discharge Summary', type: 'Discharge Summary', required: true, uploaded: true, selected: false },
        { id: 2, name: 'Medical Bills', type: 'Medical Bills', required: true, uploaded: true, selected: false },
        { id: 3, name: 'Lab Reports', type: 'Lab Reports', required: true, uploaded: true, selected: false },
        { id: 4, name: 'Prescription', type: 'Prescription', required: true, uploaded: true, selected: false },
        { id: 5, name: 'ID Proof', type: 'ID Proof', required: true, uploaded: true, selected: false }
      ]
    },
    {
      claimId: 'CLM001234568',
      patientName: 'Rajesh Kumar',
      mobile: '9876543211',
      uhid: 'UHID001234568',
      email: 'rajesh.kumar@email.com',
      policyNumber: 'POL001234568',
      claimAmount: '18500',
      claimDate: '2024-02-20',
      status: 'Completed',
      lastVisited: '2024-03-12',
      // Additional claim details for import
      claimType: 'cashless',
      claimSubType: 'daycare',
      channel: 'mobile',
      admissionDate: new Date('2024-02-20'),
      dischargeDate: new Date('2024-02-20'),
      hospitalName: 'Fortis Hospital, Delhi',
      doctorName: 'Dr. Priya Singh',
      diseaseCondition: 'Cataract surgery - left eye',
      bankAccount: '',
      ifscCode: '',
      documents: [
        { id: 1, name: 'Pre-auth Approval', type: 'Pre-auth Approval', required: true, uploaded: true, selected: false },
        { id: 2, name: 'Surgery Report', type: 'Surgery Report', required: true, uploaded: true, selected: false },
        { id: 3, name: 'Post-op Notes', type: 'Post-op Notes', required: true, uploaded: true, selected: false },
        { id: 4, name: 'ID Proof', type: 'ID Proof', required: true, uploaded: true, selected: false }
      ]
    },
    {
      claimId: 'CLM001234567',
      patientName: 'Priya Sharma',
      mobile: '9876543210',
      uhid: 'UHID001234567',
      email: 'priya.sharma@email.com',
      policyNumber: 'POL001234567',
      claimAmount: '25000',
      claimDate: '2024-01-15',
      status: 'Completed',
      lastVisited: '2024-03-08',
      // Additional claim details for import
      claimType: 'reimbursement',
      claimSubType: 'opd',
      channel: 'phone',
      admissionDate: new Date('2024-01-15'),
      dischargeDate: new Date('2024-01-15'),
      hospitalName: 'Max Healthcare, Bangalore',
      doctorName: 'Dr. Amit Sharma',
      diseaseCondition: 'Diabetes management and consultation',
      bankAccount: '9876543210987654',
      ifscCode: 'ICIC0001234',
      documents: [
        { id: 1, name: 'Consultation Report', type: 'Consultation Report', required: true, uploaded: true, selected: false },
        { id: 2, name: 'Prescription', type: 'Prescription', required: true, uploaded: true, selected: false },
        { id: 3, name: 'Blood Test Reports', type: 'Lab Reports', required: true, uploaded: true, selected: false },
        { id: 4, name: 'Policy Document', type: 'Policy Document', required: true, uploaded: true, selected: false }
      ]
    }
  ];

  const allClaims = [
    ...recentClaims,
    {
      claimId: 'CLM001234570',
      patientName: 'Suresh Patel',
      mobile: '9876543213',
      uhid: 'UHID001234570',
      email: 'suresh.patel@email.com',
      policyNumber: 'POL001234570',
      claimAmount: '15200',
      claimDate: '2024-02-05',
      status: 'Completed',
      lastVisited: '2024-02-28',
      // Additional claim details for import
      claimType: 'cashless',
      claimSubType: 'hospitalization',
      channel: 'web',
      admissionDate: new Date('2024-02-03'),
      dischargeDate: new Date('2024-02-05'),
      hospitalName: 'Manipal Hospital, Pune',
      doctorName: 'Dr. Kavitha Reddy',
      diseaseCondition: 'Gallbladder surgery (laparoscopic)',
      bankAccount: '',
      ifscCode: '',
      documents: [
        { id: 1, name: 'Discharge Summary', type: 'Discharge Summary', required: true, uploaded: true, selected: false },
        { id: 2, name: 'Surgery Report', type: 'Surgery Report', required: true, uploaded: true, selected: false },
        { id: 3, name: 'Medical Bills', type: 'Medical Bills', required: true, uploaded: true, selected: false }
      ]
    },
    {
      claimId: 'CLM001234571',
      patientName: 'Maya Singh',
      mobile: '9876543214',
      uhid: 'UHID001234571',
      email: 'maya.singh@email.com',
      policyNumber: 'POL001234571',
      claimAmount: '42800',
      claimDate: '2024-01-28',
      status: 'Completed',
      lastVisited: '2024-02-15',
      // Additional claim details for import
      claimType: 'reimbursement',
      claimSubType: 'hospitalization',
      channel: 'email',
      admissionDate: new Date('2024-01-25'),
      dischargeDate: new Date('2024-01-28'),
      hospitalName: 'AIIMS, New Delhi',
      doctorName: 'Dr. Suresh Kumar',
      diseaseCondition: 'Cardiac bypass surgery',
      bankAccount: '5432167890123456',
      ifscCode: 'SBI0001234',
      documents: [
        { id: 1, name: 'Discharge Summary', type: 'Discharge Summary', required: true, uploaded: true, selected: false },
        { id: 2, name: 'Medical Bills', type: 'Medical Bills', required: true, uploaded: true, selected: false },
        { id: 3, name: 'ECG Reports', type: 'Lab Reports', required: true, uploaded: true, selected: false },
        { id: 4, name: 'Surgery Notes', type: 'Surgery Report', required: true, uploaded: true, selected: false },
        { id: 5, name: 'ID Proof', type: 'ID Proof', required: true, uploaded: true, selected: false },
        { id: 6, name: 'Policy Document', type: 'Policy Document', required: true, uploaded: true, selected: false }
      ]
    }
  ];

  const handleLookup = () => {
    // Simulate policy lookup - show multiple policies
    setFoundPolicies(mockPolicies);
    setShowPolicySelection(true);
  };

  const handlePolicySelect = (policy: any) => {
    setSelectedPolicy(policy);
    setSelectedMember(null); // Reset member selection when policy changes
  };

  const handleMemberSelect = (member: any) => {
    setSelectedMember(member);
  };

  const handleConfirmSelection = () => {
    if (selectedPolicy && selectedMember) {
      onNext({
        policy: selectedPolicy,
        member: selectedMember,
        searchMethod: lookupMethod,
        searchValue: searchValue
      });
    }
  };

  const handleImportClaim = (claim: any) => {
    // Import patient data from existing claim
    const patientData = {
      name: claim.patientName,
      mobile: claim.mobile,
      uhid: claim.uhid,
      email: claim.email,
      fromExistingClaim: true,
      importedClaim: claim
    };
    onNext(patientData);
  };

  const handleClaimSearch = () => {
    // Simulate claim search
    const foundClaims = allClaims.filter(claim => 
      claim.claimId.toLowerCase().includes(claimSearchValue.toLowerCase()) ||
      claim.patientName.toLowerCase().includes(claimSearchValue.toLowerCase())
    );
    setSearchedClaims(foundClaims);
  };

  const handleProceed = () => {
    // For manual entry, proceed without patient data
    onNext(null);
  };

  const handleBackToLookup = () => {
    setShowPolicySelection(false);
    setFoundPolicies([]);
    setSelectedPolicy(null);
    setSelectedMember(null);
    if (onBackToLookup) {
      onBackToLookup();
    }
  };

  const getPlaceholder = () => {
    switch (lookupMethod) {
      case 'mobile':
        return 'Enter 10-digit mobile number';
      case 'uhid':
        return 'Enter UHID';
      case 'email':
        return 'Enter email address';
      case 'policy':
        return 'Enter policy number';
      case 'customer-name':
        return 'Enter customer name';
      case 'import-claim':
        return 'Search existing claims';
      case 'manual':
        return 'Enter patient details manually';
      case 'corporate':
        return 'Enter corporate name';
      default:
        return 'Enter search value';
    }
  };

  const getIcon = () => {
    switch (lookupMethod) {
      case 'mobile':
        return <Phone className="h-4 w-4" />;
      case 'uhid':
        return <User className="h-4 w-4" />;
      case 'email':
        return <Mail className="h-4 w-4" />;
      case 'policy':
        return <FileText className="h-4 w-4" />;
      case 'customer-name':
        return <User className="h-4 w-4" />;
      case 'import-claim':
        return <FileText className="h-4 w-4" />;
      case 'manual':
        return <Plus className="h-4 w-4" />;
      case 'corporate':
        return <Building2 className="h-4 w-4" />;
      default:
        return <Search className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {!showPolicySelection && (
        <>
          <div className="flex items-center space-x-2 text-primary">
            <Search className="h-5 w-5" />
            <h2 className="text-lg font-semibold">Patient Identification</h2>
          </div>

          <div className="space-y-4">
            <Label className="text-base font-medium">Choose lookup method</Label>
        
        <RadioGroup
          value={lookupMethod}
          onValueChange={setLookupMethod}
          className="grid grid-cols-2 gap-4"
        >
          <div className="flex items-center space-x-3 border rounded-lg p-4 hover:bg-accent">
            <RadioGroupItem value="mobile" id="mobile" />
            <div className="flex items-center space-x-2">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <Label htmlFor="mobile" className="font-medium">Mobile Number</Label>
            </div>
          </div>

          <div className="flex items-center space-x-3 border rounded-lg p-4 hover:bg-accent">
            <RadioGroupItem value="uhid" id="uhid" />
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-primary" />
              <Label htmlFor="uhid" className="font-medium">UHID</Label>
            </div>
          </div>

          <div className="flex items-center space-x-3 border rounded-lg p-4 hover:bg-accent">
            <RadioGroupItem value="email" id="email" />
            <div className="flex items-center space-x-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <Label htmlFor="email" className="font-medium">Email Address</Label>
            </div>
          </div>

          <div className="flex items-center space-x-3 border rounded-lg p-4 hover:bg-accent">
            <RadioGroupItem value="policy" id="policy" />
            <div className="flex items-center space-x-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <Label htmlFor="policy" className="font-medium">Policy Number</Label>
            </div>
          </div>

          <div className="flex items-center space-x-3 border rounded-lg p-4 hover:bg-accent">
            <RadioGroupItem value="customer-name" id="customer-name" />
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <Label htmlFor="customer-name" className="font-medium">Customer Name</Label>
            </div>
          </div>

          <div className="flex items-center space-x-3 border rounded-lg p-4 hover:bg-accent">
            <RadioGroupItem value="corporate" id="corporate" />
            <div className="flex items-center space-x-2">
              <Building2 className="h-4 w-4 text-muted-foreground" />
              <Label htmlFor="corporate" className="font-medium">Corporate Name & Employee ID</Label>
            </div>
          </div>
        </RadioGroup>
      </div>

      {lookupMethod === 'corporate' && (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="corporate-name" className="text-base font-medium">
              Corporate Name *
            </Label>
            <Popover open={openCorporateCombobox} onOpenChange={setOpenCorporateCombobox}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={openCorporateCombobox}
                  className="w-full justify-between"
                >
                  <div className="flex items-center">
                    <Building2 className="h-4 w-4 mr-2" />
                    {corporateName
                      ? corporateList.find((corp) => corp.value === corporateName)?.label
                      : "Select corporate name..."}
                  </div>
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-full p-0" align="start">
                <Command>
                  <CommandInput 
                    placeholder="Search corporate name..." 
                    value={corporateSearchQuery}
                    onValueChange={setCorporateSearchQuery}
                  />
                  <CommandList>
                    <CommandEmpty>
                      {corporateSearchQuery ? 'No corporate found.' : 'Start typing to search...'}
                    </CommandEmpty>
                    {corporateSearchQuery && (
                      <CommandGroup>
                        {corporateList.map((corp) => (
                          <CommandItem
                            key={corp.value}
                            value={corp.value}
                            onSelect={(currentValue) => {
                              setCorporateName(currentValue === corporateName ? "" : currentValue);
                              setOpenCorporateCombobox(false);
                              setCorporateSearchQuery('');
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                corporateName === corp.value ? "opacity-100" : "opacity-0"
                              )}
                            />
                            {corp.label}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    )}
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label htmlFor="employee-id" className="text-base font-medium">
              Employee ID *
            </Label>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2">
                <User className="h-4 w-4" />
              </div>
              <Input
                id="employee-id"
                value={employeeId}
                onChange={(e) => setEmployeeId(e.target.value)}
                placeholder="Enter employee ID"
                className="pl-10"
              />
            </div>
          </div>

          <Button 
            onClick={handleLookup}
            className="w-full"
            disabled={!corporateName.trim() || !employeeId.trim()}
          >
            <Search className="h-4 w-4 mr-2" />
            Lookup
          </Button>
        </div>
      )}

      {lookupMethod !== 'manual' && lookupMethod !== 'import-claim' && lookupMethod !== 'corporate' && (
        <>
          <div className="space-y-2">
            <Label htmlFor="search-input" className="text-base font-medium">
              {lookupMethod === 'mobile' ? 'Mobile Number' : 
               lookupMethod === 'uhid' ? 'UHID' :
               lookupMethod === 'email' ? 'Email Address' : 
               lookupMethod === 'policy' ? 'Policy Number' :
               lookupMethod === 'customer-name' ? 'Customer Name' :
               lookupMethod === 'import-claim' ? 'Search Claims' : 'Patient Details'} *
            </Label>
            
            <div className="flex space-x-2">
              <div className="relative flex-1">
                <div className="absolute left-3 top-1/2 -translate-y-1/2">
                  {getIcon()}
                </div>
                <Input
                  id="search-input"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                  placeholder={getPlaceholder()}
                  className="pl-10"
                />
              </div>
              <Button 
                onClick={handleLookup}
                className="px-6"
                disabled={!searchValue.trim()}
              >
                <Search className="h-4 w-4 mr-2" />
                Lookup
              </Button>
            </div>
            
            {lookupMethod === 'mobile' && (
              <p className="text-sm text-muted-foreground">
                Enter the policyholder's registered 10-digit mobile number
              </p>
            )}
            
            {lookupMethod === 'uhid' && (
              <p className="text-sm text-muted-foreground">
                Enter the patient's UHID
              </p>
            )}
            
            {lookupMethod === 'email' && (
              <p className="text-sm text-muted-foreground">
                Enter the policyholder's registered email address
              </p>
            )}
          </div>

          <Card className="bg-accent/20">
            <CardContent className="p-4">
              <h3 className="font-medium text-primary mb-3">Sample Data for Testing:</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                {sampleData.map((patient, index) => (
                  <div key={index} className="space-y-1">
                    <div><span className="font-medium text-primary">Mobile:</span> {patient.mobile}</div>
                    <div><span className="font-medium text-primary">UHID:</span> {patient.uhid}</div>
                    <div><span className="font-medium text-primary">Email:</span> {patient.email}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {lookupMethod === 'import-claim' && (
        <div className="space-y-6">
          {/* Search for specific claim */}
          <div className="space-y-2">
            <Label className="text-base font-medium">Search for Another Claim</Label>
            <div className="flex space-x-2">
              <div className="relative flex-1">
                <div className="absolute left-3 top-1/2 -translate-y-1/2">
                  <Search className="h-4 w-4" />
                </div>
                <Input
                  value={claimSearchValue}
                  onChange={(e) => setClaimSearchValue(e.target.value)}
                  placeholder="Enter Claim ID or Patient Name"
                  className="pl-10"
                />
              </div>
              <Button 
                onClick={handleClaimSearch}
                className="px-6"
                disabled={!claimSearchValue.trim()}
              >
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
            </div>
          </div>

          {/* Search results */}
          {searchedClaims.length > 0 && (
            <div className="space-y-3">
              <Label className="text-base font-medium">Search Results</Label>
              {searchedClaims.map((claim) => (
                <Card 
                  key={claim.claimId} 
                  className="p-4 cursor-pointer border hover:bg-accent/50 transition-colors"
                  onClick={() => handleImportClaim(claim)}
                >
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <h3 className="font-semibold">{claim.patientName}</h3>
                        <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                          {claim.status}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm text-muted-foreground">
                        <div><span className="font-medium">Claim ID:</span> {claim.claimId}</div>
                        <div><span className="font-medium">Amount:</span> ₹{claim.claimAmount}</div>
                        <div><span className="font-medium">Mobile:</span> {claim.mobile}</div>
                        <div><span className="font-medium">Date:</span> {claim.claimDate}</div>
                        <div><span className="font-medium">UHID:</span> {claim.uhid}</div>
                        <div><span className="font-medium">Policy:</span> {claim.policyNumber}</div>
                      </div>
                    </div>
                    <Button size="sm" variant="outline">
                      Import
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}

          {/* Recent claims */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Recently Visited Claims</Label>
            {recentClaims.map((claim) => (
              <Card 
                key={claim.claimId} 
                className="p-4 cursor-pointer border hover:bg-accent/50 transition-colors"
                onClick={() => handleImportClaim(claim)}
              >
                <div className="flex justify-between items-start">
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <h3 className="font-semibold">{claim.patientName}</h3>
                      <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                        {claim.status}
                      </span>
                      <span className="text-xs bg-accent text-accent-foreground px-2 py-1 rounded">
                        Last visited: {claim.lastVisited}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm text-muted-foreground">
                      <div><span className="font-medium">Claim ID:</span> {claim.claimId}</div>
                      <div><span className="font-medium">Amount:</span> ₹{claim.claimAmount}</div>
                      <div><span className="font-medium">Mobile:</span> {claim.mobile}</div>
                      <div><span className="font-medium">Date:</span> {claim.claimDate}</div>
                      <div><span className="font-medium">UHID:</span> {claim.uhid}</div>
                      <div><span className="font-medium">Policy:</span> {claim.policyNumber}</div>
                    </div>
                  </div>
                  <Button size="sm" variant="outline">
                    Import
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {lookupMethod === 'manual' && (
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold mb-2">Manual Entry Selected</h3>
              <p className="text-muted-foreground">
                You can proceed to enter patient details manually in the next step.
              </p>
            </div>
            <Button onClick={handleProceed} className="px-8">
              Proceed
            </Button>
          </div>
        </Card>
      )}
        </>
      )}

      {/* Policy Selection Screen */}
      {showPolicySelection && (
        <div className="space-y-6">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-1">
                <p className="font-medium">
                  Search parameter: {lookupMethod === 'mobile' ? 'Mobile Number' : lookupMethod === 'email' ? 'Email' : lookupMethod === 'uhid' ? 'UHID' : 'Corporate/Employee ID'} - {lookupMethod === 'corporate' ? `${corporateName} / ${employeeId}` : searchValue}
                </p>
                <p>
                  Found {foundPolicies.length} {foundPolicies.length === 1 ? 'policy' : 'policies'}. Select one to continue.
                </p>
              </div>
            </AlertDescription>
          </Alert>

          <RadioGroup
            value={selectedPolicy?.id}
            onValueChange={(value) => {
              const policy = foundPolicies.find(p => p.id === value);
              handlePolicySelect(policy);
            }}
            className="space-y-4"
          >
            {foundPolicies.map((policy) => (
              <Card 
                key={policy.id} 
                className={`cursor-pointer transition-all ${
                  selectedPolicy?.id === policy.id 
                    ? 'border-primary border-2 bg-accent/10' 
                    : 'hover:border-primary/50'
                }`}
                onClick={() => handlePolicySelect(policy)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <RadioGroupItem value={policy.id} id={policy.id} className="mt-1" />
                    
                    <div className="flex-1 space-y-4">
                      {/* Header */}
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-lg font-semibold">{policy.members[0].name}</h3>
                          <div className="space-y-1 mt-1">
                            <p className="text-sm text-muted-foreground">
                              Policy: {policy.policyNumber}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              UHID: {policy.members[0].uhid}
                            </p>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <p className="font-semibold text-base">{policy.policyType}</p>
                          <p className="text-xl font-bold text-primary">{policy.sumInsured}</p>
                          <Badge 
                            variant={policy.status === 'Active' ? 'default' : 'secondary'}
                            className={policy.status === 'Active' ? 'bg-green-500' : ''}
                          >
                            {policy.status}
                          </Badge>
                        </div>
                      </div>

                      {/* Policy Period and Members */}
                      <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-2">
                          <Calendar className="h-4 w-4" />
                          <span>{policy.startDate} - {policy.endDate}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Users className="h-4 w-4" />
                          <span>{policy.totalMembers} {policy.totalMembers === 1 ? 'Member' : 'Members'}</span>
                        </div>
                      </div>

                      {/* Insured Members - Only show if this policy is selected */}
                      {selectedPolicy?.id === policy.id && (
                        <div className="space-y-3 pt-4 border-t">
                          <p className="text-sm font-medium">Select Insured Member:</p>
                          <RadioGroup
                            value={selectedMember?.uhid}
                            onValueChange={(uhid) => {
                              const member = policy.members.find(m => m.uhid === uhid);
                              handleMemberSelect(member);
                            }}
                            className="space-y-2"
                          >
                            {policy.members.map((member, idx) => (
                              <Card 
                                key={idx} 
                                className={`cursor-pointer transition-all ${
                                  selectedMember?.uhid === member.uhid 
                                    ? 'border-primary bg-primary/5' 
                                    : 'hover:border-primary/30'
                                }`}
                                onClick={() => handleMemberSelect(member)}
                              >
                                <CardContent className="p-4">
                                  <div className="flex items-start space-x-3">
                                    <RadioGroupItem value={member.uhid} id={member.uhid} className="mt-1" />
                                    <div className="flex-1 grid grid-cols-2 gap-x-6 gap-y-2">
                                      <div>
                                        <p className="font-semibold text-sm">{member.name}</p>
                                        <p className="text-xs text-muted-foreground">
                                          {member.relationship} • {member.age} years
                                        </p>
                                      </div>
                                      <div className="text-sm">
                                        <p className="text-muted-foreground">UHID: <span className="font-medium text-foreground">{member.uhid}</span></p>
                                      </div>
                                      <div className="text-sm">
                                        <p className="text-muted-foreground">Risk Start: <span className="font-medium text-foreground">{member.memberStartDate}</span></p>
                                      </div>
                                      <div className="text-sm">
                                        <p className="text-muted-foreground">Risk End: <span className="font-medium text-foreground">{member.memberEndDate}</span></p>
                                      </div>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            ))}
                          </RadioGroup>
                        </div>
                      )}
                      
                      {/* Collapsed member summary when policy not selected */}
                      {selectedPolicy?.id !== policy.id && (
                        <div>
                          <p className="text-sm font-medium mb-2">Insured Members:</p>
                          <div className="flex flex-wrap gap-2">
                            {policy.members.map((member, idx) => (
                              <Badge key={idx} variant="outline" className="text-sm py-1">
                                {member.name} ({member.relationship}, {member.age}y)
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </RadioGroup>

          {/* Selected Policy and Member Confirmation */}
          {selectedPolicy && selectedMember && (
            <Alert className="border-primary bg-primary/5">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              <AlertDescription>
                <div className="space-y-1">
                  <div><span className="font-medium">Selected Policy:</span> {selectedPolicy.policyNumber}</div>
                  <div><span className="font-medium">Selected Member:</span> {selectedMember.name} ({selectedMember.uhid})</div>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-4">
            <Button 
              variant="outline" 
              onClick={() => {
                setShowPolicySelection(false);
                setSelectedPolicy(null);
                setSelectedMember(null);
                setFoundPolicies([]);
              }}
            >
              Back to Search
            </Button>
            <Button 
              onClick={handleConfirmSelection}
              disabled={!selectedPolicy || !selectedMember}
              className="px-8"
            >
              Continue
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientIdentificationStep;