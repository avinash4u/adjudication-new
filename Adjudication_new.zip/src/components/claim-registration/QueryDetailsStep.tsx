import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Building2, User, Calendar, Users } from 'lucide-react';
import { Badge } from "@/components/ui/badge";

interface QueryDetailsStepProps {
  policyData: any;
  memberData: any;
  onNext: (data: any) => void;
  onBack: () => void;
  onCancel: () => void;
}

const QueryDetailsStep: React.FC<QueryDetailsStepProps> = ({
  policyData,
  memberData,
  onNext,
  onBack,
  onCancel,
}) => {
  const [queryDetails, setQueryDetails] = useState('');

  const handleContinue = () => {
    if (queryDetails.trim().length === 0) {
      return;
    }
    onNext({
      queryDetails,
      policy: policyData,
      member: memberData,
    });
  };

  return (
    <div className="space-y-6">
      {/* Query Details Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Query Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="query-details" className="text-sm">
              Describe your coverage related query *
            </Label>
            <Textarea
              id="query-details"
              placeholder="Enter your query details here... (e.g. Is dental treatment covered? What is the co-payment for consultation?)"
              value={queryDetails}
              onChange={(e) => setQueryDetails(e.target.value)}
              className="min-h-[150px] resize-y"
            />
            <p className="text-xs text-muted-foreground">
              Please provide detailed information about your coverage query
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex justify-between pt-4">
        <Button variant="outline" onClick={onBack}>
          Back
        </Button>
        <div className="flex space-x-3">
          <Button variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
          <Button 
            onClick={handleContinue} 
            className="px-8"
            disabled={queryDetails.trim().length === 0}
          >
            Continue to Upload Documents
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QueryDetailsStep;
