import * as React from "react";
import { cn } from "@/lib/utils";
import { Check } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

interface AIFilledIndicatorProps {
  confidence?: number; // 0-100
  isModified?: boolean; // Has human reviewed/modified
  className?: string;
  size?: "sm" | "md";
}

export function AIFilledIndicator({
  confidence = 85,
  isModified = false,
  className,
  size = "sm",
}: AIFilledIndicatorProps) {
  const getDotColor = () => {
    if (confidence >= 90) return "bg-green-500";
    if (confidence >= 70) return "bg-amber-500";
    return "bg-red-500";
  };

  const getConfidenceLabel = () => {
    if (confidence >= 90) return "High";
    if (confidence >= 70) return "Medium";
    return "Low";
  };

  if (isModified) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge
            variant="outline"
            className={cn(
              "inline-flex items-center gap-1 font-normal border",
              "text-amber-700 bg-amber-50 border-amber-200",
              size === "sm" ? "h-5 px-1.5 text-[10px]" : "h-6 px-2 text-xs",
              className
            )}
          >
            <Check className={cn(size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5")} />
            Edited
          </Badge>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-[200px]">
          <p className="text-xs">This field was edited by the user</p>
        </TooltipContent>
      </Tooltip>
    );
  }

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span
          className={cn(
            "inline-block rounded-full cursor-help",
            getDotColor(),
            size === "sm" ? "w-2.5 h-2.5" : "w-3 h-3",
            className
          )}
        />
      </TooltipTrigger>
      <TooltipContent side="top">
        <p className="text-xs font-medium">AI Confidence: {getConfidenceLabel()}</p>
      </TooltipContent>
    </Tooltip>
  );
}

// Legend component for the card header
export function AIConfidenceLegend({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-3 text-xs text-muted-foreground", className)}>
      <span className="font-medium">AI Confidence:</span>
      <div className="flex items-center gap-1.5">
        <span className="w-2.5 h-2.5 rounded-full bg-green-500" />
        <span>High</span>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
        <span>Medium</span>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
        <span>Low</span>
      </div>
    </div>
  );
}

interface AIFilledFieldWrapperProps {
  children: React.ReactNode;
  isAIFilled?: boolean;
  confidence?: number;
  isModified?: boolean;
  className?: string;
}

export function AIFilledFieldWrapper({
  children,
  isAIFilled = false,
  confidence = 85,
  isModified = false,
  className,
}: AIFilledFieldWrapperProps) {
  if (!isAIFilled) {
    return <>{children}</>;
  }

  const getBorderColor = () => {
    if (isModified) return "ring-primary/30";
    if (confidence >= 90) return "ring-green-300";
    if (confidence >= 70) return "ring-amber-300";
    return "ring-orange-300";
  };

  return (
    <div className={cn("relative", className)}>
      <div className={cn("ring-2 ring-offset-1 rounded-md", getBorderColor())}>
        {children}
      </div>
      <div className="absolute -top-2.5 right-2 z-10">
        <AIFilledIndicator
          confidence={confidence}
          isModified={isModified}
        />
      </div>
    </div>
  );
}

export { AIFilledIndicator as default };
