import React, { useState } from 'react';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, X, CornerUpLeft } from 'lucide-react';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('All');

  const filters = [
    'All',
    'Claim ID',
    'Task ID', 
    'Customer name',
    'Customer phone',
    'UHID',
    'Policy ID'
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl p-0 gap-0">
        <div className="flex flex-col h-[600px]">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search claims, customers, policies..."
                className="pl-12 text-base h-12 border-0 shadow-none focus-visible:ring-0"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                autoFocus
              />
            </div>
            <div className="flex items-center gap-4 ml-4">
              <Button variant="ghost" className="text-muted-foreground gap-2">
                <CornerUpLeft className="h-4 w-4" />
                Return
              </Button>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Filter Section */}
          <div className="px-6 py-4 border-b">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium">Filter by</h3>
              <Button variant="ghost" size="sm" onClick={() => setSelectedFilter('All')}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {filters.map((filter) => (
                <Badge
                  key={filter}
                  variant={selectedFilter === filter ? "default" : "outline"}
                  className={`cursor-pointer px-4 py-2 text-sm ${
                    selectedFilter === filter 
                      ? "bg-primary text-primary-foreground" 
                      : "hover:bg-muted"
                  }`}
                  onClick={() => setSelectedFilter(filter)}
                >
                  {filter}
                </Badge>
              ))}
            </div>
          </div>

          {/* Content Area */}
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
            <div className="w-24 h-24 rounded-full bg-muted/20 flex items-center justify-center mb-6">
              <Search className="h-12 w-12 text-muted-foreground/40" />
            </div>
            <h3 className="text-xl font-medium text-muted-foreground mb-2">
              Start typing to search
            </h3>
            <p className="text-sm text-muted-foreground">
              Search for claims, customers, policies, and more
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};