import React, { useState, useRef, useMemo, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { format, differenceInDays } from "date-fns";
import { ArrowLeft, Download, Edit, CheckCircle, User, CreditCard, Building2, ChevronDown, ChevronUp, Save, X, FileText, FileImage, Plus, Info, ChevronLeft, ChevronRight, AlertCircle, CalendarIcon, CheckCircle2, ClipboardCheck, ZoomIn, ZoomOut, RotateCcw, RotateCw, Flag, Maximize2, Receipt, Calculator, Trash2, Pencil, Check, ChevronsUpDown, ExternalLink, Keyboard, PanelRightClose, PanelRightOpen, PanelLeftClose, PanelLeftOpen, MessageSquare, Mail, Phone, Paperclip, Clock, Search, Filter, StickyNote, MessageCircle, ArrowDownLeft, ArrowUpRight, History, Circle, Eye, Shield, Sparkles, Bell, FileUp, RefreshCw, HelpCircle } from 'lucide-react';
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { BillEntryExpandable, BillEntryExpandableHandle } from '@/components/BillEntryExpandable';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import PatientIdentificationStep from '@/components/claim-registration/PatientIdentificationStep';
import StatusNextActionCard from "@/components/StatusNextActionCard";
import { AIFilledIndicator, AIFilledFieldWrapper, AIConfidenceLegend } from "@/components/ui/ai-filled-indicator";

// AI Pre-fill tracking type
interface AIFieldState {
  isAIFilled: boolean;
  confidence: number;
  isModified: boolean;
}

interface ClaimDetailViewProps {
  claimId: string;
  onBack: () => void;
}

const ClaimDetailView: React.FC<ClaimDetailViewProps> = ({
  claimId,
  onBack
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const initialStep = (location.state as { step?: number })?.step || 1;
  const [isDetailsExpanded, setIsDetailsExpanded] = useState(false);
  const [isPatientPolicyOpen, setIsPatientPolicyOpen] = useState(false);
  const [isClaimDetailsOpen, setIsClaimDetailsOpen] = useState(false);
  const [isHospitalDetailsOpen, setIsHospitalDetailsOpen] = useState(false);
  const [isBankDetailsOpen, setIsBankDetailsOpen] = useState(false);
  const [isBillEntryOpen, setIsBillEntryOpen] = useState(false);
  const [isCodingOpen, setIsCodingOpen] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isPolicyEditing, setIsPolicyEditing] = useState(false);
  const [isPatientEditing, setIsPatientEditing] = useState(false);
  const [isHospitalEditing, setIsHospitalEditing] = useState(false);
  const [isBankEditing, setIsBankEditing] = useState(false);
  const [editingHospitalIndex, setEditingHospitalIndex] = useState<number | null>(null);
  const [isKeyboardShortcutsOpen, setIsKeyboardShortcutsOpen] = useState(false);
  const [isMoreDetailsModalOpen, setIsMoreDetailsModalOpen] = useState(false);
  const [lastSavedTime, setLastSavedTime] = useState<Date | null>(null);
  const [isDownloadDialogOpen, setIsDownloadDialogOpen] = useState(false);
  const [selectedExtension, setSelectedExtension] = useState<string>('');
  const [isRaiseQueryDialogOpen, setIsRaiseQueryDialogOpen] = useState(false);
  const [queryReasons, setQueryReasons] = useState<string[]>([]);
  const [queryFreeText, setQueryFreeText] = useState('');
  const { toast } = useToast();
  
  // Patient & Policy Modal states
  const [isPatientPolicyModalOpen, setIsPatientPolicyModalOpen] = useState(false);
  const [selectedPolicy, setSelectedPolicy] = useState<any>(null);
  const [selectedMember, setSelectedMember] = useState<any>(null);
  
  // Hospital management states
  const [selectedHospitals, setSelectedHospitals] = useState([
    {
      hospitalName: 'Apollo Hospital',
      hospitalLocation: 'Delhi',
      networkType: 'Network',
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 11 2692 5858',
      hospitalAddress: 'Sarita Vihar, Delhi Mathura Road, New Delhi - 110076',
      isApproved: true
    }
  ]);
  const [isAddingHospital, setIsAddingHospital] = useState(false);
  const [hospitalSearchTerm, setHospitalSearchTerm] = useState('');
  const [showHospitalNotFound, setShowHospitalNotFound] = useState(false);
  const [isAdvancedSearch, setIsAdvancedSearch] = useState(false);
  const [advancedSearchFilters, setAdvancedSearchFilters] = useState({
    city: '',
    state: '',
    pincode: ''
  });
  const [newHospitalData, setNewHospitalData] = useState({
    hospitalName: '',
    hospitalLocation: '',
    networkType: 'Network',
    hospitalContact: '',
    hospitalAddress: '',
    city: '',
    state: '',
    pincode: '',
    rohini: ''
  });
  const [isAddHospitalDialogOpen, setIsAddHospitalDialogOpen] = useState(false);
  const [hospitalSearchOpen, setHospitalSearchOpen] = useState<{[key: number]: boolean}>({});
  const hospitalInputRefs = useRef<{ [key: number]: HTMLInputElement | null }>({});
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [addSubCategoryOpen, setAddSubCategoryOpen] = useState(false);
  const [nonMedicalExpensesCovered, setNonMedicalExpensesCovered] = useState(true);
  const [editingRowIndex, setEditingRowIndex] = useState<number | null>(null);
  const [editingDetailIndex, setEditingDetailIndex] = useState<number | null>(null);
  const [currentDocumentIndex, setCurrentDocumentIndex] = useState(0);
  const [addLineItemOpen, setAddLineItemOpen] = useState(false);
  const [newLineItem, setNewLineItem] = useState({
    category: '',
    tariffAmount: '',
    discount: '',
    billAmount: '',
    payableAmount: ''
  });
  const [newSubCategory, setNewSubCategory] = useState({
    name: '',
    days: '1',
    tariffAmount: '',
    discount: '',
    deductions: '',
    billAmount: '',
    payableAmount: ''
  });

  // Document zoom state
  const [documentZoom, setDocumentZoom] = useState(100);
  
  // Document rotation state
  const [documentRotation, setDocumentRotation] = useState(0);
  
  // Document overlay state
  const [documentOverlayOpen, setDocumentOverlayOpen] = useState(false);
  
  // Selected document state for dropdown
  const [selectedDocument, setSelectedDocument] = useState('0');
  
  // Document preview modal state
  const [isDocumentPreviewOpen, setIsDocumentPreviewOpen] = useState(false);
  const [previewDocumentIndex, setPreviewDocumentIndex] = useState(0);
  

  // Agent checklist state
  const [checklist, setChecklist] = useState({
    claimType: false,
    dateOfAdmission: false,
    dateOfDischarge: false,
    policyDetails: false,
    uhid: false,
    hospitalName: false,
    bankAccount: false,
    billEntryUpdate: false,
    documentTagging: false
  });

  // Bill entry expandable state for each sub-category
  const [expandedBillEntries, setExpandedBillEntries] = useState<{ [key: number]: boolean }>({});
  
  // Store detailed bills and deductions for each saved entry
  const [savedBillDetails, setSavedBillDetails] = useState<{ [key: string]: { bills: any[], deductions: any[] } }>({});
  
  // Store intermediate saved bills/deductions for temp item (before final save)
  const [tempSavedBills, setTempSavedBills] = useState<any[]>([]);
  const [tempSavedDeductions, setTempSavedDeductions] = useState<any[]>([]);
  
  const billEntryRef = useRef<BillEntryExpandableHandle>(null);
  
  // Summary modal state
  const [summaryModalOpen, setSummaryModalOpen] = useState(false);

  // Preview resize state
  const [previewHeight, setPreviewHeight] = useState(600);
  const [isResizing, setIsResizing] = useState(false);

  // Toggle for showing/hiding the left Document Review panel
  const [isDocumentReviewVisible, setIsDocumentReviewVisible] = useState(true);

  // Document tagging dialog state
  const [showDocumentTagDialog, setShowDocumentTagDialog] = useState(false);
  const [hasOtherClaimDocuments, setHasOtherClaimDocuments] = useState(false);
  const [showOtherPersonBillDialog, setShowOtherPersonBillDialog] = useState(false);
  const [isCreatingExtension, setIsCreatingExtension] = useState(false);
  const [showBackToLookup, setShowBackToLookup] = useState(false);

  // Workflow stage state (Stage 1: Review, Stage 2: Bill Entry)
  const [workflowStage, setWorkflowStage] = useState<'review' | 'billEntry'>('review');

  // Step-by-step wizard state for right panel
  // Step 1: Bill Entry (collapsed) + Clinical Details (expanded)
  // Step 2: Procedure Details (expanded) + Additional Details (collapsed)
  // Step 3: Status & Next Action (expanded) - shows Next for "Financial Adjudication", Done for others
  const [currentStep, setCurrentStep] = useState(initialStep);
  const [selectedStatusAction, setSelectedStatusAction] = useState<string | null>(null);
  const [isShowingChecklist, setIsShowingChecklist] = useState(true);
  const [isChecklistAnimationComplete, setIsChecklistAnimationComplete] = useState(false);
  const [hideChecklistTrigger, setHideChecklistTrigger] = useState(false);

  // Helper function to get action label for Done button
  const getActionLabel = (action: string | null) => {
    switch (action) {
      case "complete":
        return "Go to Financial Adjudication";
      case "query":
        return "Raise Query";
      case "investigation":
        return "Raise Investigation";
      case "crm":
        return "Refer to CRM";
      case "senior":
        return "Refer to Senior Adjudicator";
      case "uw":
        return "Refer to UW";
      case "reject":
        return "Reject Claim";
      default:
        return "Done";
    }
  };

  // AI Pre-fill tracking state - tracks which fields are AI-filled and their modification status
  const [aiFieldStates, setAiFieldStates] = useState<Record<string, AIFieldState>>({
    lineOfTreatment: { isAIFilled: true, confidence: 92, isModified: false },
    accident: { isAIFilled: true, confidence: 88, isModified: false },
    diagnosis: { isAIFilled: true, confidence: 85, isModified: false },
    primaryDisease: { isAIFilled: true, confidence: 91, isModified: false },
    procedureCode: { isAIFilled: true, confidence: 87, isModified: false },
    snomedCode: { isAIFilled: true, confidence: 89, isModified: false },
  });

  // Helper to mark a field as modified by human
  const markFieldAsModified = (fieldName: string) => {
    setAiFieldStates(prev => ({
      ...prev,
      [fieldName]: prev[fieldName] ? { ...prev[fieldName], isModified: true } : prev[fieldName]
    }));
  };

  // Helper to get AI field state
  const getAiFieldState = (fieldName: string): AIFieldState | undefined => {
    return aiFieldStates[fieldName];
  };

  // ICD Coding states - Pre-filled by AI
  const [lineOfTreatment, setLineOfTreatment] = useState<string>('surgical');
  const [procedureCode, setProcedureCode] = useState<{code: string, name: string} | null>(null);
  const [primaryDiseaseCode, setPrimaryDiseaseCode] = useState<{icd1: string, icd2: string, icd3: string} | null>({
    icd1: "Diseases of the digestive system (K00-K93)",
    icd2: "Diseases of appendix (K35-K38)",
    icd3: "Acute appendicitis (K35)"
  });
  const [secondaryDiseaseCodes, setSecondaryDiseaseCodes] = useState<Array<{icd1: string, icd2: string, icd3: string}>>([]);
  const [coMorbidityCodes, setCoMorbidityCodes] = useState<Array<{icd1: string, icd2: string, icd3: string}>>([]);
  
  // Show/hide states for optional disease sections
  const [showSecondaryDisease, setShowSecondaryDisease] = useState(false);
  const [showCoMorbidities, setShowCoMorbidities] = useState(false);
  
  const [procedureSearchTerm, setProcedureSearchTerm] = useState('');
  const [primarySearchTerm, setPrimarySearchTerm] = useState('');
  const [secondarySearchTerm, setSecondarySearchTerm] = useState('');
  const [comorbiditySearchTerm, setComorbiditySearchTerm] = useState('');
  
  const [openProcedureSearch, setOpenProcedureSearch] = useState(false);
  const [openPrimarySearch, setOpenPrimarySearch] = useState(false);
  const [openSecondarySearch, setOpenSecondarySearch] = useState(false);
  const [openComorbiditySearch, setOpenComorbiditySearch] = useState(false);
  
  // SNOMED Coding states - Pre-filled by AI
  const [snomedCode, setSnomedCode] = useState<{code: string, name: string} | null>({
    code: "74400008",
    name: "Appendicitis"
  });
  const [snomedSearchTerm, setSnomedSearchTerm] = useState('');
  const [openSnomedSearch, setOpenSnomedSearch] = useState(false);
  
  // Maternity states
  const [isMaternityCase, setIsMaternityCase] = useState(false);
  const [dateOfDelivery, setDateOfDelivery] = useState<Date | undefined>(undefined);
  const [gravida, setGravida] = useState('');
  const [para, setPara] = useState('');
  const [living, setLiving] = useState('');
  const [abortions, setAbortions] = useState('');
  // Diagnosis - Pre-filled by AI
  const [diagnosis, setDiagnosis] = useState('Acute appendicitis with peritoneal abscess. Patient presented with right lower quadrant pain, fever, and elevated WBC count.');

  const [secondarySnomedCode, setSecondarySnomedCode] = useState<{code: string, name: string} | null>(null);
  const [secondarySnomedSearchTerm, setSecondarySnomedSearchTerm] = useState('');
  const [openSecondarySnomedSearch, setOpenSecondarySnomedSearch] = useState(false);

  const [coMorbiditySnomedCode, setCoMorbiditySnomedCode] = useState<{code: string, name: string} | null>(null);
  const [coMorbiditySnomedSearchTerm, setCoMorbiditySnomedSearchTerm] = useState('');
  const [openCoMorbiditySnomedSearch, setOpenCoMorbiditySnomedSearch] = useState(false);

  // Symptoms / Signs states
  const [symptomIcdCode, setSymptomIcdCode] = useState<{ icd1: string; icd2: string; icd3: string } | null>(null);
  const [symptomIcdSearchTerm, setSymptomIcdSearchTerm] = useState('');
  const [openSymptomIcdSearch, setOpenSymptomIcdSearch] = useState(false);

  const [symptomSnomedCode, setSymptomSnomedCode] = useState<{ code: string; name: string } | null>(null);
  const [symptomSnomedSearchTerm, setSymptomSnomedSearchTerm] = useState('');
  const [openSymptomSnomedSearch, setOpenSymptomSnomedSearch] = useState(false);

  const [symptomOtherDescription, setSymptomOtherDescription] = useState('');

  // Other Conditions / Risk Factors state
  const [otherConditions, setOtherConditions] = useState({
    familyHistory: '',
    personalHistory: {
      selectedItems: [] as string[],
      smokingFrequency: '',
      drinkingFrequency: '',
    },
    pastMedicalHistory: {
      selectedItems: [] as string[],
      details: {} as Record<string, string>,
    },
    pastSurgicalHistory: [] as Array<{code: string, name: string}>,
  });

  // Past Surgical History search state
  const [pastSurgicalSearchTerm, setPastSurgicalSearchTerm] = useState('');
  const [openPastSurgicalSearch, setOpenPastSurgicalSearch] = useState(false);

  // Vital Parameters state - now with search/select and date/time
  const [vitalParameterRecordings, setVitalParameterRecordings] = useState<
    Array<{ parameter: string; value: string; date: Date | null; time: string }>
  >([]);
  const [vitalParamSearchTerm, setVitalParamSearchTerm] = useState('');
  const [openVitalParamSearch, setOpenVitalParamSearch] = useState(false);

  const vitalParameterOptions = [
    { key: 'temperature', label: 'Temperature (°C)', placeholder: 'e.g. 98.6' },
    { key: 'pulseRate', label: 'Pulse rate (per min)', placeholder: 'e.g. 80' },
    { key: 'bp', label: 'BP (mmHg)', placeholder: 'e.g. 120/80' },
    { key: 'respiratoryRate', label: 'Respiratory Rate (per min)', placeholder: 'e.g. 18' },
    { key: 'spo2', label: 'SpO2', placeholder: 'e.g. 98%' },
    { key: 'eyeEnt', label: 'Eye/ENT', placeholder: 'Enter Eye/ENT findings' },
    { key: 'chest', label: 'Chest', placeholder: 'Enter chest examination findings' },
    { key: 'cvs', label: 'CVS (Cardiovascular system)', placeholder: 'Enter CVS findings' },
    { key: 'cns', label: 'CNS (Central nervous system)', placeholder: 'Enter CNS findings' },
    { key: 'pa', label: 'P/A (Per abdomen)', placeholder: 'Enter abdominal findings' },
    { key: 'le', label: 'L/E (Lower extremities)', placeholder: 'Enter lower extremity findings' },
  ];

  const filteredVitalParams = vitalParameterOptions.filter((param) =>
    param.label.toLowerCase().includes(vitalParamSearchTerm.toLowerCase())
  );

  // Investigations state - Pre-filled by AI
  const [investigations, setInvestigations] = useState({
    bloodGroup: '',
    accident: 'No',
    maternityG: '',
    maternityP: '',
    maternityL: '',
    maternityA: '',
    dateOfDelivery: null as Date | null,
  });

  // Investigation test options for search-select
  const investigationTestOptions = [
    "Blood Test (CBC)",
    "Blood Test (RBC)",
    "Blood Test (WBC)",
    "Urine C/S",
    "Urine R/M",
    "Blood Sugar (RBS)",
    "Blood Sugar (FBS)",
    "ECG/Echo",
    "TSH",
    "USG FHR",
    "USG AFI",
    "Other tests",
  ];

  // Investigation test recordings state
  const [investigationTestRecordings, setInvestigationTestRecordings] = useState<
    { test: string; value: string }[]
  >([]);

  const [openInvestigationTestSearch, setOpenInvestigationTestSearch] = useState(false);

  const addInvestigationTest = (test: string) => {
    setInvestigationTestRecordings((prev) => [
      ...prev,
      { test, value: "" },
    ]);
    setOpenInvestigationTestSearch(false);
  };

  const updateInvestigationTestValue = (index: number, value: string) => {
    setInvestigationTestRecordings((prev) =>
      prev.map((item, i) => (i === index ? { ...item, value } : item))
    );
  };

  const removeInvestigationTest = (index: number) => {
    setInvestigationTestRecordings((prev) => prev.filter((_, i) => i !== index));
  };

  // Anesthesia options
  const anesthesiaOptions = [
    "General Anesthesia",
    "Local Anesthesia",
    "Regional Anesthesia",
    "Spinal Anesthesia",
    "Epidural Anesthesia",
    "Sedation",
    "Others",
  ];

  // Implants/Devices options
  const implantsDevicesOptions = [
    "Cardiac Stent",
    "Pacemaker",
    "Orthopedic Implant",
    "Cochlear Implant",
    "Intraocular Lens",
    "Joint Replacement",
    "Surgical Mesh",
    "Catheter",
    "Others",
  ];

  // Medications options
  const medicationsOptions = [
    "Antibiotics",
    "Analgesics",
    "Anticoagulants",
    "Anesthetics",
    "Anti-inflammatory",
    "Sedatives",
    "Steroids",
    "Insulin",
    "Others",
  ];

  // Procedure details state - for selected items
  const [selectedAnesthesia, setSelectedAnesthesia] = useState<{ option: string; customValue?: string }[]>([]);
  const [selectedImplants, setSelectedImplants] = useState<{ option: string; customValue?: string }[]>([]);
  const [selectedMedications, setSelectedMedications] = useState<{ option: string; customValue?: string }[]>([]);

  const [openAnesthesiaSearch, setOpenAnesthesiaSearch] = useState(false);
  const [openImplantsSearch, setOpenImplantsSearch] = useState(false);
  const [openMedicationsSearch, setOpenMedicationsSearch] = useState(false);

  const addAnesthesia = (option: string) => {
    if (!selectedAnesthesia.some((a) => a.option === option)) {
      setSelectedAnesthesia((prev) => [...prev, { option, customValue: option === "Others" ? "" : undefined }]);
    }
    setOpenAnesthesiaSearch(false);
  };

  const removeAnesthesia = (option: string) => {
    setSelectedAnesthesia((prev) => prev.filter((a) => a.option !== option));
  };

  const updateAnesthesiaCustomValue = (option: string, value: string) => {
    setSelectedAnesthesia((prev) =>
      prev.map((a) => (a.option === option ? { ...a, customValue: value } : a))
    );
  };

  const addImplant = (option: string) => {
    if (!selectedImplants.some((i) => i.option === option)) {
      setSelectedImplants((prev) => [...prev, { option, customValue: option === "Others" ? "" : undefined }]);
    }
    setOpenImplantsSearch(false);
  };

  const removeImplant = (option: string) => {
    setSelectedImplants((prev) => prev.filter((i) => i.option !== option));
  };

  const updateImplantCustomValue = (option: string, value: string) => {
    setSelectedImplants((prev) =>
      prev.map((i) => (i.option === option ? { ...i, customValue: value } : i))
    );
  };

  const addMedication = (option: string) => {
    if (!selectedMedications.some((m) => m.option === option)) {
      setSelectedMedications((prev) => [...prev, { option, customValue: option === "Others" ? "" : undefined }]);
    }
    setOpenMedicationsSearch(false);
  };

  const removeMedication = (option: string) => {
    setSelectedMedications((prev) => prev.filter((m) => m.option !== option));
  };

  const updateMedicationCustomValue = (option: string, value: string) => {
    setSelectedMedications((prev) =>
      prev.map((m) => (m.option === option ? { ...m, customValue: value } : m))
    );
  };

  // Multiple procedures state - Pre-filled by AI
  const [procedures, setProcedures] = useState<
    { pcsCode: string; snomedCode: string; isAIFilled?: boolean; aiConfidence?: number; isModified?: boolean }[]
  >([{ 
    pcsCode: '0DTJ4ZZ - Appendectomy, laparoscopic', 
    snomedCode: '6025007 - Laparoscopic appendectomy',
    isAIFilled: true,
    aiConfidence: 89,
    isModified: false
  }]);

  const addProcedure = () => {
    setProcedures((prev) => [...prev, { pcsCode: '', snomedCode: '' }]);
  };

  const updateProcedure = (index: number, field: 'pcsCode' | 'snomedCode', value: string) => {
    setProcedures((prev) =>
      prev.map((p, i) => (i === index ? { ...p, [field]: value, isModified: true } : p))
    );
  };

  const removeProcedure = (index: number) => {
    setProcedures((prev) => prev.filter((_, i) => i !== index));
  };

  // Correlation state
  const [correlationDetails, setCorrelationDetails] = useState({
    icdPcs: {
      strength: '',
      comments: '',
      colorCode: '',
    },
    treatmentNecessity: {
      strength: '',
      comments: '',
      colorCode: '',
    },
    medicineCorrelation: {
      strength: '',
      comments: '',
      colorCode: '',
    },
  });

  // Follow up advice state
  const [followUpAdvice, setFollowUpAdvice] = useState({
    adviceCategory: '',
    adviceText: '',
    nextAppointmentDate: '',
  });

  // Follow up advice category options
  const adviceCategoryOptions = [
    "Food",
    "Exercise",
    "Lifestyle",
    "Rest",
    "Wound Care",
    "Physiotherapy",
    "Others",
  ];

  // Follow up medication state (search and select)
  const [selectedFollowUpMedications, setSelectedFollowUpMedications] = useState<{ option: string; customValue?: string }[]>([]);
  const [openFollowUpMedicationsSearch, setOpenFollowUpMedicationsSearch] = useState(false);

  const addFollowUpMedication = (option: string) => {
    if (!selectedFollowUpMedications.some((m) => m.option === option)) {
      setSelectedFollowUpMedications((prev) => [...prev, { option, customValue: option === "Others" ? "" : undefined }]);
    }
    setOpenFollowUpMedicationsSearch(false);
  };

  const removeFollowUpMedication = (option: string) => {
    setSelectedFollowUpMedications((prev) => prev.filter((m) => m.option !== option));
  };

  const updateFollowUpMedicationCustomValue = (option: string, value: string) => {
    setSelectedFollowUpMedications((prev) =>
      prev.map((m) => (m.option === option ? { ...m, customValue: value } : m))
    );
  };

  // Clinical Details sections open state (only one section open at a time)
  const [openClinicalSection, setOpenClinicalSection] = useState<
    | "diseaseCoding"
    | "otherConditions"
    | "symptomsSigns"
    | "vitalParameters"
    | "investigations"
    | "procedureDetails"
    | "correlation"
    | "followUpAdvice"
  >("diseaseCoding");

  // Admissibility states
  const [isAdmissibilityOpen, setIsAdmissibilityOpen] = useState(false);
  const [selectedCovers, setSelectedCovers] = useState<string[]>([]);
  const [otherCoverText, setOtherCoverText] = useState("");
  const [hasExclusion, setHasExclusion] = useState<boolean | null>(null);
  const [openCoversSearch, setOpenCoversSearch] = useState(false);
  const [coversSearchTerm, setCoversSearchTerm] = useState('');

  // Communications state
  const [isCommunicationsOpen, setIsCommunicationsOpen] = useState(false);

  // Audit Trail state
  const [isAuditTrailOpen, setIsAuditTrailOpen] = useState(false);

  // Filter states for Communications and Audit Trail
  const [commExtensionFilter, setCommExtensionFilter] = useState<string>('all');
  const [commDirectionFilter, setCommDirectionFilter] = useState<string>('all');
  const [auditExtensionFilter, setAuditExtensionFilter] = useState<string>('all');
  const [auditTypeFilter, setAuditTypeFilter] = useState<string>('all');

  // Claim extensions (phases)
  const claimExtensions = [
    { id: 'all', label: 'All Extensions' },
    { id: 'pre-auth', label: 'Pre-Authorization' },
    { id: 'enhancement-1', label: 'Enhancement #1' },
    { id: 'enhancement-2', label: 'Enhancement #2' },
    { id: 'final-claim', label: 'Final Claim' },
  ];

  // Audit Trail log data - with isNew flag for items since last adjudication
  const auditTrailLog = [
    {
      id: 'audit-1',
      action: 'Claim Registered',
      user: 'System',
      timestamp: '2024-01-15 10:00 AM',
      details: 'Claim CLM-2024-001234 registered via hospital portal',
      category: 'Registration',
      extension: 'pre-auth',
      type: 'system',
      isNew: false,
    },
    {
      id: 'audit-2',
      action: 'Documents Uploaded',
      user: 'Hospital Staff',
      timestamp: '2024-01-15 10:15 AM',
      details: '5 documents uploaded: Admission form, ID proof, Insurance card, Pre-auth form, Discharge summary',
      category: 'Documents',
      extension: 'pre-auth',
      type: 'system',
      isNew: false,
    },
    {
      id: 'audit-3',
      action: 'Claim Assigned',
      user: 'System',
      timestamp: '2024-01-15 10:30 AM',
      details: 'Claim assigned to Agent: Priya Gupta (AG-1234)',
      category: 'Assignment',
      extension: 'pre-auth',
      type: 'system',
      isNew: false,
    },
    {
      id: 'audit-note-1',
      action: 'Internal Note',
      user: 'Priya Gupta',
      timestamp: '2024-01-15 11:00 AM',
      details: 'Verified patient eligibility. Policy active with sufficient sum insured. No waiting period applicable.',
      category: 'Internal',
      extension: 'pre-auth',
      type: 'internal-note',
      isNew: false,
    },
    {
      id: 'audit-4',
      action: 'Disease Coding Updated',
      user: 'Priya Gupta',
      timestamp: '2024-01-15 11:45 AM',
      details: 'Primary ICD code set: K35.8 - Acute appendicitis',
      category: 'Clinical',
      extension: 'pre-auth',
      type: 'system',
      isNew: false,
    },
    {
      id: 'audit-query-1',
      action: 'Internal Note',
      user: 'Priya Gupta',
      timestamp: '2024-01-16 10:00 AM',
      details: 'Query to Medical Team: Please confirm if day care package applies for this procedure.',
      category: 'Internal',
      extension: 'pre-auth',
      type: 'internal-note',
      isNew: false,
    },
    {
      id: 'audit-query-response-1',
      action: 'Internal Note',
      user: 'Dr. Rajesh Kumar',
      timestamp: '2024-01-16 11:30 AM',
      details: 'Response: This is a full hospitalization case, not day care. Standard surgical package applies.',
      category: 'Internal',
      extension: 'pre-auth',
      type: 'internal-note',
      isNew: false,
    },
    {
      id: 'audit-5',
      action: 'Bill Entry Completed',
      user: 'Priya Gupta',
      timestamp: '2024-01-16 02:30 PM',
      details: 'Total claimed: ₹2,48,500 | Total approved: ₹2,35,000',
      category: 'Financial',
      extension: 'final-claim',
      type: 'system',
      isNew: false,
    },
    {
      id: 'audit-discussion-1',
      action: 'Internal Note',
      user: 'Team Discussion',
      timestamp: '2024-01-16 02:45 PM',
      details: 'Discussed deduction rationale with medical team. Agreed on ₹13,500 deduction for non-covered pharmacy items.',
      category: 'Internal',
      extension: 'final-claim',
      type: 'internal-note',
      isNew: false,
    },
    {
      id: 'audit-6',
      action: 'Query Raised',
      user: 'Priya Gupta',
      timestamp: '2024-01-16 03:00 PM',
      details: 'Query raised to hospital: Missing investigation reports',
      category: 'Query',
      extension: 'final-claim',
      type: 'system',
      isNew: false,
    },
    {
      id: 'audit-7',
      action: 'Query Resolved',
      user: 'Hospital Staff',
      timestamp: '2024-01-17 10:00 AM',
      details: 'Documents uploaded in response to query',
      category: 'Query',
      extension: 'final-claim',
      type: 'system',
      isNew: true, // New since last adjudication
    },
    {
      id: 'audit-note-2',
      action: 'Internal Note',
      user: 'CRM Team',
      timestamp: '2024-01-17 10:30 AM',
      details: 'Customer called to check status. Informed that documents are being reviewed.',
      category: 'Internal',
      extension: 'final-claim',
      type: 'internal-note',
      isNew: true, // New since last adjudication
    },
    {
      id: 'audit-8',
      action: 'Documents Uploaded',
      user: 'Hospital Staff',
      timestamp: '2024-01-17 11:00 AM',
      details: 'Query response documents uploaded: Updated bill summary, ICU justification letter',
      category: 'Documents',
      extension: 'final-claim',
      type: 'system',
      isNew: true, // New since last adjudication
    },
  ];

  // Communications log data
  const communicationsLog = [
    {
      id: 'comm-1',
      type: 'Email',
      direction: 'Outbound',
      recipient: 'patient@email.com',
      recipientType: 'Customer',
      subject: 'Claim Registration Confirmation',
      timestamp: '2024-01-15 10:30 AM',
      status: 'Delivered',
      hasAttachment: true,
      extension: 'pre-auth',
      content: 'Dear Customer,\n\nYour health insurance claim has been successfully registered with us.\n\nClaim Details:\n- Claim ID: CLM-2024-001234\n- Hospital: Apollo Hospital, Delhi\n- Date of Admission: 15-Jan-2024\n- Estimated Amount: ₹2,50,000\n\nWe will review your claim and update you on the status within 24-48 hours.\n\nFor any queries, please contact our helpline at 1800-XXX-XXXX.\n\nBest Regards,\nACKO Health Insurance Team',
    },
    {
      id: 'comm-2',
      type: 'SMS',
      direction: 'Outbound',
      recipient: '+91 98765 43210',
      recipientType: 'Customer',
      subject: 'Document Request',
      timestamp: '2024-01-15 02:15 PM',
      status: 'Delivered',
      hasAttachment: false,
      extension: 'pre-auth',
      content: 'Dear Customer, Please upload the following documents for your claim CLM-2024-001234: 1) Discharge Summary 2) Final Bill 3) Investigation Reports. Upload via ACKO app or reply to this message. - ACKO',
    },
    {
      id: 'comm-3',
      type: 'Email',
      direction: 'Outbound',
      recipient: 'billing@hospital.com',
      recipientType: 'Hospital',
      subject: 'Bill Verification Request',
      timestamp: '2024-01-16 09:00 AM',
      status: 'Delivered',
      hasAttachment: true,
      extension: 'pre-auth',
      content: 'Dear Hospital Billing Team,\n\nWe are processing a health insurance claim for patient admitted at your facility.\n\nPatient Details:\n- Name: Rahul Sharma\n- UHID: APL-2024-5678\n- Admission Date: 15-Jan-2024\n\nPlease verify and confirm the following:\n1. Final itemized bill breakdown\n2. Procedures performed\n3. Any pending investigations\n\nKindly respond within 24 hours.\n\nRegards,\nACKO Claims Processing Team',
    },
    {
      id: 'comm-4',
      type: 'Phone Call',
      direction: 'Inbound',
      recipient: '+91 98765 43210',
      recipientType: 'Customer',
      subject: 'Query about claim status',
      timestamp: '2024-01-16 11:45 AM',
      status: 'Completed',
      duration: '5 mins',
      hasAttachment: false,
      extension: 'pre-auth',
      content: 'Call Summary:\n\nCaller: Customer (Rahul Sharma)\nDuration: 5 minutes\n\nQuery: Customer called to inquire about claim status and expected settlement date.\n\nResolution: Informed customer that claim is under review. Documents have been verified and claim will be processed within 2-3 business days. Customer was satisfied with the update.\n\nAgent: Priya Gupta (Agent ID: AG-1234)',
    },
    {
      id: 'comm-5',
      type: 'Email',
      direction: 'Inbound',
      recipient: 'billing@hospital.com',
      recipientType: 'Hospital',
      subject: 'RE: Bill Verification Request',
      timestamp: '2024-01-17 03:30 PM',
      status: 'Received',
      hasAttachment: true,
      extension: 'final-claim',
      content: 'Dear ACKO Team,\n\nPlease find attached the verified bill details for patient Rahul Sharma.\n\nConfirmed Details:\n- Total Bill Amount: ₹2,48,500\n- Room Charges: ₹45,000 (3 days @ ₹15,000/day)\n- Procedure Charges: ₹1,50,000\n- Pharmacy: ₹35,000\n- Investigations: ₹18,500\n\nAll procedures are complete and patient is being discharged today.\n\nRegards,\nApollo Hospital Billing Team',
    },
  ];

  // Filtered communications
  const filteredCommunications = useMemo(() => {
    return communicationsLog.filter(comm => {
      const extensionMatch = commExtensionFilter === 'all' || comm.extension === commExtensionFilter;
      const directionMatch = commDirectionFilter === 'all' || comm.direction === commDirectionFilter;
      return extensionMatch && directionMatch;
    });
  }, [commExtensionFilter, commDirectionFilter]);

  // Filtered audit trail
  const filteredAuditTrail = useMemo(() => {
    let filtered = auditTrailLog;
    if (auditExtensionFilter !== 'all') {
      filtered = filtered.filter(event => event.extension === auditExtensionFilter);
    }
    if (auditTypeFilter === 'internal-notes') {
      filtered = filtered.filter(event => event.type === 'internal-note');
    }
    return filtered;
  }, [auditExtensionFilter, auditTypeFilter]);

  const getAuditTypeIcon = (type: string) => {
    switch (type) {
      case 'internal-note':
        return <StickyNote className="h-3 w-3" />;
      case 'internal-query':
        return <MessageCircle className="h-3 w-3" />;
      case 'internal-discussion':
        return <MessageSquare className="h-3 w-3" />;
      default:
        return null;
    }
  };

  const getAuditTypeBadge = (type: string) => {
    if (type === 'internal-note') {
      return <Badge variant="outline" className="text-[10px] bg-amber-50 text-amber-700 border-amber-200">Note</Badge>;
    }
    return null;
  };

  // Communication content dialog state
  const [selectedCommunication, setSelectedCommunication] = useState<typeof communicationsLog[0] | null>(null);

  // Mock ICD data
  const icdData = [
    {
      icd1: "Intestinal infectious diseases (A00-A09)",
      icd2: "Cholera (A00)",
      icd3: "Cholera due to Vibrio cholerae 01, biovar cholerae (A00.0)"
    },
    {
      icd1: "Intestinal infectious diseases (A00-A09)",
      icd2: "Cholera (A00)",
      icd3: "Cholera due to Vibrio cholerae 01, biovar eltor (A00.1)"
    },
    {
      icd1: "Intestinal infectious diseases (A00-A09)",
      icd2: "Cholera (A00)",
      icd3: "Cholera, unspecified (A00.9)"
    },
    {
      icd1: "Intestinal infectious diseases (A00-A09)",
      icd2: "Typhoid and paratyphoid fevers (A01)",
      icd3: "Typhoid fever (A01.0)"
    },
    {
      icd1: "Intestinal infectious diseases (A00-A09)",
      icd2: "Typhoid and paratyphoid fevers (A01)",
      icd3: "Paratyphoid fever A (A01.1)"
    },
    {
      icd1: "Tuberculosis (A15-A19)",
      icd2: "Respiratory tuberculosis (A15)",
      icd3: "Tuberculosis of lung (A15.0)"
    },
    {
      icd1: "Tuberculosis (A15-A19)",
      icd2: "Respiratory tuberculosis (A15)",
      icd3: "Tuberculosis of intrathoracic lymph nodes (A15.4)"
    },
    {
      icd1: "Malignant neoplasms (C00-C97)",
      icd2: "Malignant neoplasms of digestive organs (C15-C26)",
      icd3: "Malignant neoplasm of stomach (C16)"
    },
    {
      icd1: "Malignant neoplasms (C00-C97)",
      icd2: "Malignant neoplasms of respiratory and intrathoracic organs (C30-C39)",
      icd3: "Malignant neoplasm of bronchus and lung (C34)"
    },
    {
      icd1: "Diabetes mellitus (E10-E14)",
      icd2: "Type 1 diabetes mellitus (E10)",
      icd3: "Type 1 diabetes mellitus with ketoacidosis (E10.1)"
    },
    {
      icd1: "Diabetes mellitus (E10-E14)",
      icd2: "Type 2 diabetes mellitus (E11)",
      icd3: "Type 2 diabetes mellitus with kidney complications (E11.2)"
    },
    {
      icd1: "Ischaemic heart diseases (I20-I25)",
      icd2: "Angina pectoris (I20)",
      icd3: "Unstable angina (I20.0)"
    },
    {
      icd1: "Ischaemic heart diseases (I20-I25)",
      icd2: "Acute myocardial infarction (I21)",
      icd3: "ST elevation myocardial infarction of anterior wall (I21.0)"
    }
  ];

  // Mock procedure data
  const procedureData = [
    { code: "00.01", name: "Appendectomy - Laparoscopic" },
    { code: "00.02", name: "Appendectomy - Open" },
    { code: "00.10", name: "Cholecystectomy - Laparoscopic" },
    { code: "00.11", name: "Cholecystectomy - Open" },
    { code: "36.10", name: "Coronary Artery Bypass Graft (CABG)" },
    { code: "36.12", name: "Angioplasty - Single Vessel" },
    { code: "36.15", name: "Angioplasty - Multiple Vessel" },
    { code: "51.23", name: "Hernia Repair - Inguinal" },
    { code: "51.24", name: "Hernia Repair - Umbilical" },
    { code: "68.41", name: "Hysterectomy - Total Abdominal" },
    { code: "68.51", name: "Hysterectomy - Laparoscopic" },
    { code: "81.54", name: "Total Knee Replacement" },
    { code: "81.51", name: "Total Hip Replacement" },
    { code: "45.23", name: "Colonoscopy with Biopsy" },
    { code: "45.16", name: "Endoscopy - Upper GI" },
    { code: "37.51", name: "Heart Valve Replacement" },
    { code: "03.09", name: "Spinal Fusion" },
    { code: "85.21", name: "Mastectomy - Modified Radical" }
  ];

  // Mock SNOMED data
  const snomedData = [
    { code: "22298006", name: "Myocardial infarction" },
    { code: "73211009", name: "Diabetes mellitus" },
    { code: "38341003", name: "Hypertensive disorder" },
    { code: "195967001", name: "Asthma" },
    { code: "13645005", name: "Chronic obstructive pulmonary disease" },
    { code: "44054006", name: "Type 2 diabetes mellitus" },
    { code: "46635009", name: "Type 1 diabetes mellitus" },
    { code: "399211009", name: "History of myocardial infarction" },
    { code: "49436004", name: "Atrial fibrillation" },
    { code: "40055000", name: "Chronic kidney disease" },
    { code: "271737000", name: "Anemia" },
    { code: "414545008", name: "Ischemic heart disease" },
    { code: "427603009", name: "Intermittent asthma" },
    { code: "84114007", name: "Heart failure" },
    { code: "399957001", name: "Peripheral vascular disease" },
    { code: "230690007", name: "Cerebrovascular accident" },
    { code: "363406005", name: "Malignant neoplasm of colon" },
    { code: "93934004", name: "Primary malignant neoplasm of lung" },
    { code: "63650001", name: "Cholera" },
    { code: "4834000", name: "Typhoid fever" },
    { code: "56717001", name: "Tuberculosis of lung" },
    { code: "126926005", name: "Neoplasm of stomach" }
  ];

  // ICD to SNOMED mapping for auto-population
  const icdToSnomedMapping: { [key: string]: { code: string; name: string } } = {
    "A00.0": { code: "63650001", name: "Cholera" },
    "A00.1": { code: "63650001", name: "Cholera" },
    "A00.9": { code: "63650001", name: "Cholera" },
    "A01.0": { code: "4834000", name: "Typhoid fever" },
    "A01.1": { code: "4834000", name: "Typhoid fever" },
    "A15.0": { code: "56717001", name: "Tuberculosis of lung" },
    "A15.4": { code: "56717001", name: "Tuberculosis of lung" },
    "C16": { code: "126926005", name: "Neoplasm of stomach" },
    "C34": { code: "93934004", name: "Primary malignant neoplasm of lung" },
    "E10.1": { code: "46635009", name: "Type 1 diabetes mellitus" },
    "E11.2": { code: "44054006", name: "Type 2 diabetes mellitus" },
    "I20.0": { code: "414545008", name: "Ischemic heart disease" },
    "I21.0": { code: "22298006", name: "Myocardial infarction" }
  };

  // Helper function to extract ICD code from icd3 string
  const extractIcdCode = (icd3: string): string => {
    const match = icd3.match(/\(([^)]+)\)/);
    return match ? match[1] : '';
  };

  // Helper function to get SNOMED from ICD code
  const getSnomedFromIcd = (icdCode: { icd1: string; icd2: string; icd3: string }) => {
    const code = extractIcdCode(icdCode.icd3);
    return icdToSnomedMapping[code] || null;
  };

  // Mock covers data for Admissibility
  const coversData = [
    { id: "hospitalization", name: "Hospitalization Cover", description: "In-patient hospitalization expenses", icdTriggers: ["A00", "A01", "A15", "I20", "I21", "E10", "E11", "C"] },
    { id: "pre-hospitalization", name: "Pre-Hospitalization Cover", description: "Expenses 30-60 days before admission", icdTriggers: ["I20", "I21", "C"] },
    { id: "post-hospitalization", name: "Post-Hospitalization Cover", description: "Expenses 60-90 days after discharge", icdTriggers: ["I20", "I21", "C", "A15"] },
    { id: "daycare", name: "Day Care Cover", description: "Procedures not requiring 24hr hospitalization", pcsTriggers: ["45.23", "45.16", "36.12"] },
    { id: "domiciliary", name: "Domiciliary Cover", description: "Treatment at home when hospitalization not possible", icdTriggers: ["E10", "E11"] },
    { id: "ambulance", name: "Ambulance Cover", description: "Emergency ambulance charges", icdTriggers: ["I21"] },
    { id: "organ-donor", name: "Organ Donor Cover", description: "Medical expenses for organ donor", pcsTriggers: ["81.54", "81.51", "37.51"] },
    { id: "maternity", name: "Maternity Cover", description: "Pregnancy and childbirth expenses", icdTriggers: ["O"] },
    { id: "newborn", name: "New Born Baby Cover", description: "Coverage for newborn from day one", icdTriggers: ["P"] },
    { id: "critical-illness", name: "Critical Illness Cover", description: "Lump sum on diagnosis of critical illness", icdTriggers: ["C", "I21", "I20"] },
    { id: "ayush", name: "AYUSH Cover", description: "Ayurveda, Yoga, Unani, Siddha, Homeopathy treatment", icdTriggers: [] },
    { id: "others", name: "Others", description: "Other applicable covers not listed above", icdTriggers: [] }
  ];

  // Get recommended covers based on ICD and PCS codes
  const getRecommendedCovers = () => {
    const recommended: string[] = [];
    
    // Check primary disease code
    const allIcdCodes = [
      primaryDiseaseCode?.icd3,
      ...secondaryDiseaseCodes.map(d => d.icd3),
      ...coMorbidityCodes.map(d => d.icd3)
    ].filter(Boolean);
    
    // Extract ICD code prefixes (e.g., "A00.0" -> "A00", "I21.0" -> "I21")
    const icdPrefixes = allIcdCodes.map(code => {
      const match = code?.match(/\(([A-Z]\d+)/);
      return match ? match[1] : null;
    }).filter(Boolean);
    
    const pcsCode = procedureCode?.code;
    
    coversData.forEach(cover => {
      // Check ICD triggers
      if (cover.icdTriggers) {
        const hasIcdMatch = icdPrefixes.some(prefix => 
          cover.icdTriggers?.some(trigger => prefix?.startsWith(trigger))
        );
        if (hasIcdMatch && !recommended.includes(cover.id)) {
          recommended.push(cover.id);
        }
      }
      
      // Check PCS triggers
      if (cover.pcsTriggers && pcsCode) {
        if (cover.pcsTriggers.includes(pcsCode) && !recommended.includes(cover.id)) {
          recommended.push(cover.id);
        }
      }
    });
    
    // Always recommend hospitalization if any ICD code is present
    if (allIcdCodes.length > 0 && !recommended.includes("hospitalization")) {
      recommended.unshift("hospitalization");
    }
    
    return recommended;
  };

  const recommendedCovers = getRecommendedCovers();
  
  const filteredCovers = coversData.filter(cover =>
    cover.name.toLowerCase().includes(coversSearchTerm.toLowerCase()) ||
    cover.description.toLowerCase().includes(coversSearchTerm.toLowerCase())
  );

  const handleNewSubCategoryChange = (field: string, value: string) => {
    setNewSubCategory(prev => {
      const updated = { ...prev, [field]: value };
      
      // Auto-calculate bill amount and payable amount
      if (field === 'tariffAmount' || field === 'discount' || field === 'deductions' || field === 'days') {
        const tariff = parseFloat(updated.tariffAmount) || 0;
        const discount = parseFloat(updated.discount) || 0;
        const deductions = parseFloat(updated.deductions) || 0;
        const days = parseFloat(updated.days) || 1;
        const billAmount = tariff * days;
        const payableAmount = billAmount - deductions - discount;
        
        updated.billAmount = billAmount.toString();
        updated.payableAmount = payableAmount.toString();
      }
      
      return updated;
    });
  };

  const handleAddSubCategory = () => {
    // Add the new sub-category to the existing list
    const tariff = parseFloat(newSubCategory.tariffAmount) || 0;
    const discount = parseFloat(newSubCategory.discount) || 0;
    const days = parseFloat(newSubCategory.days) || 1;
    const billAmount = tariff * days;
    const payableAmount = billAmount - discount;
    
    const newCategory = {
      id: Date.now(),
      name: newSubCategory.name,
      days: newSubCategory.days,
      tariffAmount: newSubCategory.tariffAmount,
      discount: newSubCategory.discount,
      deductions: newSubCategory.deductions,
      billAmount: billAmount.toLocaleString(),
      payableAmount: payableAmount.toLocaleString()
    };
    
    setSubCategories(prev => [...prev, newCategory]);
    
    // Reset form and close modal
    setNewSubCategory({
      name: '',
      days: '1',
      tariffAmount: '',
      discount: '',
      deductions: '',
      billAmount: '',
      payableAmount: ''
    });
    setAddSubCategoryOpen(false);
  };

  const [documents, setDocuments] = useState([
    {
      id: 1,
      name: 'Medical_Report_001.pdf',
      type: 'PDF',
      size: '2.4 MB',
      uploadDate: '30 Mar 2025, 09:15 AM',
      status: 'Approved',
      icon: FileText,
      content: `DISCHARGE SUMMARY
Patient: Priya Sharma | Age: 34F | UHID: 12345
Admission: 28/03/2025 | Discharge: 30/03/2025

DIAGNOSIS: Acute Appendicitis with Laparoscopic Appendectomy
TREATMENT: Successful laparoscopic removal of inflamed appendix
MEDICATIONS: Antibiotics, Pain management
CONDITION: Stable, healing well
FOLLOW-UP: 7 days post-op visit scheduled`,
      category: 'Discharge Summary',
      readability: true,
      suspicious: false,
      irrelevant: false,
      isComplete: true,
      isNew: false,
      agentNotes: '',
      systemRecommendation: 'Document is clear and contains all required medical information. Recommend approval.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    },
    {
      id: 5,
      name: 'query_response1_merged_view',
      type: 'View',
      size: '0 KB',
      uploadDate: '30 Mar 2025, 10:00 AM',
      status: 'Available',
      icon: FileText,
      content: `QUERY RESPONSE - MERGED VIEW
Query ID: QR-2025-0328-001
Status: Resolved

Original Query: "Please clarify room category and justify ICU charges"
Response Date: 29/03/2025

RESPONSE SUMMARY:
✓ ICU charges justified - patient required post-op monitoring
✓ Room category: Semi-private as per policy coverage
✓ All supporting documents attached
✓ No additional clarification needed`,
      category: 'Query Response',
      readability: true,
      suspicious: false,
      irrelevant: false,
      isComplete: true,
      isNew: true, // New since last adjudication - query response document
      agentNotes: '',
      systemRecommendation: 'Query response merged view is available for review.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    },
    {
      id: 2,
      name: 'Prescription_Scan.jpg',
      type: 'Image',
      size: '1.8 MB',
      uploadDate: '30 Mar 2025, 09:20 AM',
      status: 'Pending',
      icon: FileImage,
      content: `PRESCRIPTION
Dr. Rajesh Kumar | MD General Surgery
Apollo Hospital, Delhi

Patient: Priya Sharma | Date: 28/03/2025

Rx:
1. Tab Ciprofloxacin 500mg - BD x 7 days
2. Tab Paracetamol 650mg - TDS x 5 days  
3. Tab Pantoprazole 40mg - OD x 10 days
4. Syp Lactulose 15ml - BD PRN

[Note: Image quality needs improvement for full verification]`,
      category: 'Prescription',
      readability: false,
      suspicious: false,
      irrelevant: false,
      isComplete: false,
      isNew: false,
      agentNotes: '',
      systemRecommendation: 'Image quality is poor. Request clearer scan for better readability before approval.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    },
    {
      id: 3,
      name: 'Lab_Results.pdf',
      type: 'PDF',
      size: '956 KB',
      uploadDate: '30 Mar 2025, 09:25 AM',
      status: 'Approved',
      icon: FileText,
      content: `LABORATORY REPORT
Apollo Diagnostics | Report Date: 28/03/2025
Patient: Priya Sharma | Age: 34F

PRE-OPERATIVE INVESTIGATIONS:
• Hemoglobin: 12.8 g/dL (Normal: 12-15)
• Total WBC Count: 8,500/μL (Normal: 4,000-11,000)
• Platelets: 2,85,000/μL (Normal: 1.5-4.5 lakh)
• Blood Sugar (Fasting): 95 mg/dL (Normal: <100)
• Serum Creatinine: 0.9 mg/dL (Normal: 0.6-1.2)

INTERPRETATION: All parameters within normal limits`,
      category: 'Lab Reports',
      readability: true,
      suspicious: false,
      irrelevant: false,
      isComplete: true,
      isNew: false,
      agentNotes: '',
      systemRecommendation: 'Lab results are within normal ranges and clearly documented. Safe to approve.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    },
    {
      id: 4,
      name: 'Old_Discharge_Summary.pdf',
      type: 'PDF',
      size: '1.2 MB',
      uploadDate: '28 Mar 2025, 01:00 PM',
      status: 'Rejected',
      icon: FileText,
      content: `DISCHARGE SUMMARY [REJECTED]
Patient: Unknown | Age: 35F | UHID: XXXXX
Admission: 15/02/2025 | Discharge: 17/02/2025

⚠️ DOCUMENT INCONSISTENCIES DETECTED:
- Date mismatch with current claim period
- Missing pages 2-3 (incomplete document)
- Hospital seal/signature unclear
- Patient details don't match claim

STATUS: REJECTED - Requires verification`,
      category: 'Discharge Summary',
      readability: true,
      suspicious: true,
      irrelevant: false,
      isComplete: false,
      isNew: false,
      agentNotes: 'Pages 2-3 appear to be missing from this document. Need complete discharge summary.',
      systemRecommendation: 'Document dates do not match claim period. Potential fraud risk - recommend further investigation.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: 'date-mismatch',
      suspiciousDetails: 'Document dates do not match claim period',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: 'missing-pages',
      missingDetails: 'Pages 2-3 appear to be missing'
    },
    {
      id: 6,
      name: 'Additional_Information.txt',
      type: 'Text',
      size: '2 KB',
      uploadDate: '30 Mar 2025, 09:30 AM',
      status: 'Approved',
      icon: FileText,
      content: `ADDITIONAL INFORMATION PROVIDED BY USER

Patient requested early discharge due to family emergency. All medications and follow-up instructions have been clearly understood and documented.

Note: Patient will be available for follow-up consultation via telemedicine if needed during recovery period.`,
      category: 'Additional Information',
      readability: true,
      suspicious: false,
      irrelevant: false,
      isComplete: true,
      isNew: false,
      agentNotes: '',
      systemRecommendation: 'Additional information provided by user during claim registration.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    },
    {
      id: 7,
      name: 'ICU_Justification_Letter.pdf',
      type: 'PDF',
      size: '450 KB',
      uploadDate: '31 Mar 2025, 02:30 PM',
      status: 'Pending',
      icon: FileText,
      content: `ICU JUSTIFICATION LETTER
Apollo Hospital, Delhi
Date: 31/03/2025

To Whom It May Concern,

This is to certify that the patient Priya Sharma (UHID: 12345) required ICU admission post appendectomy surgery due to:
- Post-operative monitoring requirement
- Risk of infection management
- Pain management protocol

Duration: 24 hours (28/03/2025 8PM - 29/03/2025 8PM)
ICU Charges: ₹15,000/day

Dr. Rajesh Kumar
MS, General Surgery`,
      category: 'Medical Certificate',
      readability: true,
      suspicious: false,
      irrelevant: false,
      isComplete: true,
      isNew: true, // New document uploaded in response to query
      agentNotes: '',
      systemRecommendation: 'ICU justification provided by hospital. Review for medical necessity.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    },
    {
      id: 8,
      name: 'Updated_Bill_Summary.pdf',
      type: 'PDF',
      size: '320 KB',
      uploadDate: '31 Mar 2025, 02:45 PM',
      status: 'Pending',
      icon: FileText,
      content: `UPDATED BILL SUMMARY
Apollo Hospital, Delhi
Bill No: APL/2025/03/5678 (Revised)

Patient: Priya Sharma | UHID: 12345
Admission: 28/03/2025 | Discharge: 30/03/2025

REVISED CHARGES:
Room Rent (Semi-Private): ₹8,000 x 2 days = ₹16,000
ICU Charges: ₹15,000 x 1 day = ₹15,000
Surgery Charges: ₹85,000
Anesthesia: ₹12,000
Medicines & Consumables: ₹18,500
Lab & Investigations: ₹8,500

TOTAL: ₹1,55,000

Note: Bill revised as per query response`,
      category: 'Bills',
      readability: true,
      suspicious: false,
      irrelevant: false,
      isComplete: true,
      isNew: true, // New document uploaded in response to query
      agentNotes: '',
      systemRecommendation: 'Updated bill summary uploaded. Compare with original bill for variance.',
      unreadableReason: '',
      unreadableDetails: '',
      suspiciousReason: '',
      suspiciousDetails: '',
      irrelevantReason: '',
      irrelevantDetails: '',
      missingReason: '',
      missingDetails: ''
    }
  ]);

  // Updates Summary state
  const [isUpdatesSummaryOpen, setIsUpdatesSummaryOpen] = useState(false);

  // Calculate updates summary
  const updatesSummary = useMemo(() => {
    const newDocuments = documents.filter(doc => doc.isNew);
    const newAuditEntries = auditTrailLog.filter(entry => entry.isNew);
    const newInternalNotes = newAuditEntries.filter(entry => entry.type === 'internal-note');
    const isFirstTimeAdjudication = !auditTrailLog.some(entry => entry.action.includes('Adjudication') || entry.action.includes('Bill Entry Completed'));
    
    return {
      newDocuments,
      newAuditEntries,
      newInternalNotes,
      totalNewItems: newDocuments.length + newAuditEntries.length,
      isFirstTimeAdjudication,
      claimStatus: 'Query Response', // This would come from claim data
    };
  }, [documents, auditTrailLog]);

  // Document category options
  const documentCategories = [
    'Prescription',
    'Medicine Bills',
    'Lab Reports',
    'Discharge Summary',
    'ID Proof',
    'Additional Information'
  ];

  const unreadableReasonLabels: Record<string, string> = {
    'entire-unreadable': 'Entire document is unreadable',
    'some-pages-unreadable': 'Some pages are not readable',
  };

  const suspiciousReasonLabels: Record<string, string> = {
    'document-edited': 'Document is edited',
    'past-claim-reused': 'Past claim document reused',
    'date-mismatch': 'Document dates do not match claim period',
  };

  const irrelevantReasonLabels: Record<string, string> = {
    'unrelated-document': 'Unrelated document e.g. random picture',
    'bill-not-needed': 'Bill entry not needed (Payment receipt, KYC, discharge summary, prescription etc.)',
    'name-not-matching': 'Bill is for some other person (Name not matching)',
    'claim-not-matching': 'Bill is for some other claim (Bill date/ number/details are not matching)',
    'duplicate': 'Duplicate document',
  };

  const missingReasonLabels: Record<string, string> = {
    'pages-missing': 'Few pages are missing',
    'info-missing': 'Information (e.g. signature/ stamp/ hospital/doctor name) is missing',
    'missing-pages': 'Pages are missing',
  };

  // Hierarchical category structure
  const categoryHierarchy = {
    "Room & Nursing Charges": {
      "Room Charges": ["Room Rent", "ICU Charges", "ICCU Charges", "NICU Charges", "PICU Charges", "HDU Charges", "Special Room Charges"],
      "Nursing Charges": ["Nursing fees", "Dressing", "Nebulization", "Injection charges", "Infusion pump charges", "Aya Charges", "Blood Transfusion Charges"]
    },
    "Surgery Charges": {
      "Surgeon Fees": [],
      "Anesthesia Charges": [],
      "OT Charges": []
    },
    "Investigations": {
      "Laboratory": [],
      "Radiology": [],
      "Pathology": []
    }
  };

  // Flat list of selected bill items
  const [selectedBillItems, setSelectedBillItems] = useState<Array<{
    id: string;
    fullPath: string;
    level1: string;
    level2: string;
    level3: string;
    documentId: number;
    documentName: string;
    days: string;
    tariffAmount: string;
    billAmount: string;
    eligibleAmount: string;
    discount: string;
    payableAmount: string;
  }>>([]);
  
  const [categorySearchOpen, setCategorySearchOpen] = useState(false);
  const [categorySearchValue, setCategorySearchValue] = useState("");
  
  // Keep old subcategories for summary calculations (backward compatibility)
  const [subCategories, setSubCategories] = useState([{
    id: 0,
    name: "Room Charges",
    tariffAmount: "8000",
    days: "3",
    discount: "0",
    deductions: "0",
    billAmount: "24,000",
    payableAmount: "24,000"
  }, {
    id: 1,
    name: "Nursing charges",
    type: "Medical",
    tariffAmount: "5000",
    discount: "0",
    deductions: "0",
    billAmount: "5,000",
    payableAmount: "5,000"
  }, {
    id: 2,
    name: "Duty Doctor fee",
    type: "Medical",
    tariffAmount: "3500",
    discount: "0",
    deductions: "0",
    billAmount: "3,500",
    payableAmount: "3,500"
  }, {
    id: 3,
    name: "Monitor charges",
    type: "Medical",
    tariffAmount: "2000",
    discount: "0",
    deductions: "0",
    billAmount: "2,000",
    payableAmount: "2,000"
  }]);

  // Room charge detail types
  const roomChargeTypes = [
    'General Ward charges',
    'Semi-private room charges',
    'Single Room charges',
    'Single Deluxe room charges',
    'Deluxe room charges',
    'Suite charges',
    'Electricity charges',
    'Bed sheet charges',
    'Hot water charges',
    'Establishment Charges',
    'Alpha/Water Bed Charges',
    'Attendant Bed Charges'
  ];

  // Nursing charge detail types
  const nursingChargeTypes = [
    'Nursing fees',
    'Dressing',
    'Nebulization',
    'Injection charges',
    'Infusion pump charges',
    'Aya Charges',
    'Blood Transfusion Charges'
  ];

  // Detail items for each sub-category (e.g., Room Charges details)
  const [roomChargeDetails, setRoomChargeDetails] = useState<Array<{
    id: number;
    type: string;
    days: string;
    tariffAmount: string;
    billAmount: string;
    deductions: string;
    discount: string;
  }>>([]);

  // Nursing charge details
  const [nursingChargeDetails, setNursingChargeDetails] = useState<Array<{
    id: number;
    type: string;
    days: string;
    tariffAmount: string;
    billAmount: string;
    deductions: string;
    discount: string;
  }>>([]);

  // Track which sub-category's details are expanded
  const [expandedSubCategoryDetails, setExpandedSubCategoryDetails] = useState<{[key: number]: boolean}>({});

  const handleEditRow = (index: number) => {
    // Toggle bill entry view for specific sub-category
    setExpandedBillEntries(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const handleSaveRow = (index: number) => {
    setEditingRowIndex(null);
  };

  const handleCancelEdit = () => {
    setEditingRowIndex(null);
  };

  // Helper function to generate search options
  const getSearchOptions = () => {
    const options: Array<{ value: string; label: string; level1: string; level2: string; level3: string }> = [];
    
    Object.entries(categoryHierarchy).forEach(([level1, level2Obj]) => {
      // Add L1 option
      options.push({
        value: `${level1}`,
        label: level1,
        level1,
        level2: "",
        level3: ""
      });
      
      Object.entries(level2Obj).forEach(([level2, level3Array]) => {
        // Add L2 option
        options.push({
          value: `${level1} -> ${level2}`,
          label: `${level1} -> ${level2}`,
          level1,
          level2,
          level3: ""
        });
        
        // Add L3 options
        level3Array.forEach((level3) => {
          options.push({
            value: `${level1} -> ${level2} -> ${level3}`,
            label: `${level1} -> ${level2} -> ${level3}`,
            level1,
            level2,
            level3
          });
        });
      });
    });
    
    return options;
  };

  const handleCategorySelect = (value: string) => {
    const option = getSearchOptions().find(opt => opt.value === value);
    if (!option) return;
    
    // Remove any existing temp entry first
    const filteredItems = selectedBillItems.filter(item => item.id !== 'temp');
    
    const currentDocument = documents[currentDocumentIndex];
    
    const newItem = {
      id: 'temp',
      fullPath: value,
      level1: option.level1,
      level2: option.level2,
      level3: option.level3,
      documentId: currentDocument.id,
      documentName: currentDocument.name,
      days: "",
      tariffAmount: "",
      billAmount: "",
      eligibleAmount: "",
      discount: "",
      payableAmount: ""
    };
    
    setSelectedBillItems([...filteredItems, newItem]);
    setCategorySearchOpen(false);
  };

  // Check if category is room-related
  const isRoomCategory = (item: any) => {
    const searchText = `${item.level1} ${item.level2} ${item.level3}`.toLowerCase();
    return searchText.includes('room') || searchText.includes('rent');
  };

  // Calculate auto-filled days between admission and discharge
  const getAutoCalculatedDays = () => {
    if (formData.admissionDate && formData.dischargeDate) {
      return differenceInDays(formData.dischargeDate, formData.admissionDate);
    }
    return 0;
  };

  // Calculate bill amount for a specific item
  const getAutoCalculatedBillAmount = (item: any) => {
    const days = parseFloat(item.days) || getAutoCalculatedDays();
    const tariff = parseFloat(item.tariffAmount) || 0;
    return days * tariff;
  };

  const handleBillItemChange = (id: string, field: string, value: string) => {
    setSelectedBillItems(items => items.map(item => {
      if (item.id !== id) return item;
      
      const updated = { ...item, [field]: value };
      
      // Auto-calculate billAmount when days or tariffAmount changes
      if (field === 'days' || field === 'tariffAmount') {
        const days = parseFloat(field === 'days' ? value : updated.days) || 0;
        const tariff = parseFloat(field === 'tariffAmount' ? value : updated.tariffAmount) || 0;
        updated.billAmount = (days * tariff).toString();
      }
      
      // Auto-calculate payableAmount
      const billAmt = parseFloat(updated.billAmount) || 0;
      const eligible = parseFloat(updated.eligibleAmount) || billAmt;
      const discount = parseFloat(updated.discount) || 0;
      updated.payableAmount = (eligible - discount).toString();
      
      return updated;
    }));
  };

  const handleDeleteBillItem = (id: string) => {
    setSelectedBillItems(items => items.filter(item => item.id !== id));
    const key = id;
    setExpandedBillEntries(prev => {
      const newObj = { ...prev };
      delete newObj[key as any];
      return newObj;
    });
  };

  const handleToggleBillEntry = (id: string) => {
    setExpandedBillEntries(prev => ({
      ...prev,
      [id as any]: !prev[id as any]
    }));
  };

  // Calculate bill summary from saved bill details
  const getBillSummary = (itemId: string) => {
    const billData = savedBillDetails[itemId];
    if (!billData) {
      return { totalDays: 0, totalRent: 0, totalBillAmount: 0, totalDeductions: 0, billAmountPostDeductions: 0 };
    }

    const totalDays = billData.bills.reduce((sum, bill) => sum + bill.days, 0);
    const totalRent = billData.bills.reduce((sum, bill) => sum + bill.rent, 0);
    const totalBillAmount = billData.bills.reduce((sum, bill) => sum + bill.amount, 0);
    const totalDeductions = billData.deductions?.reduce((sum, deduction) => sum + deduction.amount, 0) || 0;
    const billAmountPostDeductions = totalBillAmount - totalDeductions;

    return { totalDays, totalRent, totalBillAmount, totalDeductions, billAmountPostDeductions };
  };

  // Calculate eligible amount based on policy limit
  const getEligibleAmount = (itemId: string) => {
    const summary = getBillSummary(itemId);
    const billAmountPostDeductions = summary.billAmountPostDeductions;
    
    // Parse sum insured (remove ₹ and commas)
    const sumInsuredStr = formData.sumInsured.replace(/[₹,]/g, '');
    const policyCapping = parseFloat(sumInsuredStr) || 0;
    
    // Eligible is the lower of bill amount post deductions and policy capping
    const eligible = Math.min(billAmountPostDeductions, policyCapping);
    
    return {
      eligible,
      billAmountPostDeductions,
      policyCapping,
      reason: billAmountPostDeductions <= policyCapping 
        ? 'Bill amount is within policy limit' 
        : `Bill amount post deductions (₹${billAmountPostDeductions.toLocaleString()}) exceeds policy limit (₹${policyCapping.toLocaleString()})`
    };
  };

  const handleSaveBillEntry = (data: { bills: any[], deductions: any[] }) => {
    // In add mode, this handles intermediate saves
    // Add new entries to temp saved state
    setTempSavedBills(prev => [...prev, ...data.bills]);
    setTempSavedDeductions(prev => [...prev, ...data.deductions]);
  };

  const handleFinalSaveBillEntry = () => {
    // Get the current temp item (the one being edited)
    const tempItem = selectedBillItems.find(item => item.id === 'temp');
    if (!tempItem) return;

    // Flush any in-progress inputs from BillEntryExpandable
    const flushed = billEntryRef.current?.flushPending() ?? { bills: [], deductions: [] };

    // Combine with any previously temp-saved items
    const combinedBills = [...tempSavedBills, ...flushed.bills];
    const combinedDeductions = [...tempSavedDeductions, ...flushed.deductions];

    // Check if there's data to save
    if (combinedBills.length === 0 && combinedDeductions.length === 0) {
      toast({
        title: "No Data",
        description: "Please add at least one bill or deduction before saving.",
        variant: "destructive"
      });
      return;
    }

    // Create a new permanent entry with a unique ID
    const newId = `bill_${Date.now()}`;
    const newEntry = {
      ...tempItem,
      id: newId
    };

    // Save all bills and deductions to the new permanent entry
    setSavedBillDetails(prev => ({
      ...prev,
      [newId]: {
        bills: combinedBills,
        deductions: combinedDeductions
      }
    }));

    // Replace temp item with saved entry
    setSelectedBillItems(items => items.map(item => 
      item.id === 'temp' ? newEntry : item
    ));

    // Clear temp saved state
    setTempSavedBills([]);
    setTempSavedDeductions([]);

    toast({
      title: "Entry Saved",
      description: "Bill entry has been saved successfully and moved to Saved Entries."
    });
  };

  const handleUpdateSavedEntry = (itemId: string, data: { bills: any[], deductions: any[] }) => {
    // Add new bills and deductions to an already saved entry
    setSavedBillDetails(prev => {
      const existingData = prev[itemId] || { bills: [], deductions: [] };
      return {
        ...prev,
        [itemId]: {
          bills: [...existingData.bills, ...data.bills],
          deductions: [...existingData.deductions, ...data.deductions]
        }
      };
    });

    toast({
      title: "Entry Updated",
      description: "Bill and deduction entries have been added to this saved entry."
    });
  };
  
  const handleSubCategoryInputChange = (index: number, field: string, value: string) => {
    const updatedCategories = [...subCategories];
    updatedCategories[index] = {
      ...updatedCategories[index],
      [field]: value
    };
    
    // Calculate bill amount for Room Charges based on days * tariff amount
    if (updatedCategories[index].name === "Room Charges") {
      if (field === 'days' || field === 'tariffAmount') {
        const days = parseInt(updatedCategories[index].days || '1');
        const tariffAmount = parseInt(updatedCategories[index].tariffAmount || '0');
        const billAmount = days * tariffAmount;
        updatedCategories[index].billAmount = billAmount.toLocaleString();
        updatedCategories[index].payableAmount = billAmount.toLocaleString();
      }
    }
    
    setSubCategories(updatedCategories);
  };

  const handleAddRoomChargeDetail = () => {
    const newDetail = {
      id: roomChargeDetails.length,
      type: roomChargeTypes[0],
      days: '1',
      tariffAmount: '0',
      billAmount: '0',
      deductions: '0',
      discount: '0'
    };
    setRoomChargeDetails([...roomChargeDetails, newDetail]);
  };

  const handleRoomChargeDetailChange = (index: number, field: string, value: string) => {
    const updatedDetails = [...roomChargeDetails];
    updatedDetails[index] = {
      ...updatedDetails[index],
      [field]: value
    };
    
    // Calculate bill amount based on days * tariff amount
    if (field === 'days' || field === 'tariffAmount') {
      const days = parseInt(updatedDetails[index].days || '1');
      const tariffAmount = parseFloat(updatedDetails[index].tariffAmount.replace(/,/g, '') || '0');
      const billAmount = days * tariffAmount;
      updatedDetails[index].billAmount = billAmount.toLocaleString();
    }
    
    setRoomChargeDetails(updatedDetails);
  };

  const handleDeleteRoomChargeDetail = (index: number) => {
    setRoomChargeDetails(roomChargeDetails.filter((_, i) => i !== index));
  };

  const handleAddNursingChargeDetail = () => {
    const newDetail = {
      id: nursingChargeDetails.length,
      type: nursingChargeTypes[0],
      days: '1',
      tariffAmount: '0',
      billAmount: '0',
      deductions: '0',
      discount: '0'
    };
    setNursingChargeDetails([...nursingChargeDetails, newDetail]);
  };

  const handleNursingChargeDetailChange = (index: number, field: string, value: string) => {
    const updatedDetails = [...nursingChargeDetails];
    updatedDetails[index] = {
      ...updatedDetails[index],
      [field]: value
    };
    
    // Calculate bill amount based on days * tariff amount
    if (field === 'days' || field === 'tariffAmount') {
      const days = parseInt(updatedDetails[index].days || '1');
      const tariffAmount = parseFloat(updatedDetails[index].tariffAmount.replace(/,/g, '') || '0');
      const billAmount = days * tariffAmount;
      updatedDetails[index].billAmount = billAmount.toLocaleString();
    }
    
    setNursingChargeDetails(updatedDetails);
  };

  const handleDeleteNursingChargeDetail = (index: number) => {
    setNursingChargeDetails(nursingChargeDetails.filter((_, i) => i !== index));
  };

  const handleEditDetailRow = (index: number) => {
    setExpandedBillEntries(prev => ({
      ...prev,
      [`detail_${index}`]: !prev[`detail_${index}`]
    }));
  };

  const handleEditNursingDetailRow = (index: number) => {
    setExpandedBillEntries(prev => ({
      ...prev,
      [`nursing_detail_${index}`]: !prev[`nursing_detail_${index}`]
    }));
  };

  const handleSaveDetailRow = () => {
    setEditingDetailIndex(null);
  };

  const handleCancelDetailEdit = () => {
    setEditingDetailIndex(null);
  };

  const handleNewLineItemChange = (field: string, value: string) => {
    setNewLineItem(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAddLineItem = () => {
    // Here you would typically add the new line item to your data
    // For now, just close the modal and reset the form
    setAddLineItemOpen(false);
    setNewLineItem({
      category: '',
      tariffAmount: '',
      discount: '',
      billAmount: '',
      payableAmount: ''
    });
  };

  const handleCancelAddLineItem = () => {
    setAddLineItemOpen(false);
    setNewLineItem({
      category: '',
      tariffAmount: '',
      discount: '',
      billAmount: '',
      payableAmount: ''
    });
  };

  // Multiple policies data
  const [policiesData] = useState([
    {
      policyId: 'ACKO-HLTH-001234',
      planSelected: 'Individual Health',
      sumInsured: '₹5,00,000',
      remainingSI: '₹4,50,000',
      policyStart: '01 Jan 2025',
      policyEnd: '31 Dec 2025',
      deductible: 0,
      isActive: true
    },
    {
      policyId: 'ACKO-HLTH-001235',
      planSelected: 'Retail Health',
      sumInsured: '₹10,00,000',
      remainingSI: '₹9,50,000',
      policyStart: '15 Feb 2025',
      policyEnd: '14 Feb 2026',
      deductible: 0,
      isActive: true
    },
    {
      policyId: 'ACKO-HLTH-001236',
      planSelected: 'Group Health',
      sumInsured: '₹3,00,000',
      remainingSI: '₹2,80,000',
      policyStart: '01 Mar 2025',
      policyEnd: '28 Feb 2026',
      deductible: 0,
      isActive: true
    },
    {
      policyId: 'ACKO-STOP-001234',
      planSelected: 'Super top up',
      sumInsured: '₹20,00,000',
      remainingSI: '₹20,00,000',
      policyStart: '01 Jan 2025',
      policyEnd: '31 Dec 2025',
      deductible: 50000, // ₹50,000 deductible
      isActive: true
    }
  ]);

  // Calculate total claim amount from sub-categories
  const calculateTotalClaimAmount = () => {
    return subCategories.reduce((total, category) => {
      const payableAmount = parseFloat(category.payableAmount.replace(/,/g, '')) || 0;
      return total + payableAmount;
    }, 0); // Total from all line items
  };

  // Check if customer has super top up policy and should be nudged
  const shouldShowSuperTopUpNudge = () => {
    const totalClaimAmount = calculateTotalClaimAmount();
    const customerPolicies = policiesData.filter(policy => policy.isActive);
    const hasSuperTopUp = customerPolicies.some(policy => policy.planSelected === 'Super top up');
    const superTopUpPolicy = customerPolicies.find(policy => policy.planSelected === 'Super top up');
    
    if (hasSuperTopUp && superTopUpPolicy) {
      return totalClaimAmount > superTopUpPolicy.deductible;
    }
    return false;
  };

  // Get super top up policy details
  const getSuperTopUpPolicy = () => {
    return policiesData.find(policy => policy.planSelected === 'Super top up' && policy.isActive);
  };
  const [uhidData] = useState([
    {
      uhid: 'UHID001',
      name: 'Priya Sharma',
      age: '34 years',
      gender: 'Female',
      phone: '+91 98765 43210',
      email: 'priya.sharma@email.com'
    },
    {
      uhid: 'UHID002', 
      name: 'Rajesh Kumar',
      age: '28 years',
      gender: 'Male',
      phone: '+91 98765 43211',
      email: 'rajesh.kumar@email.com'
    },
    {
      uhid: 'UHID003',
      name: 'Anjali Patel', 
      age: '45 years',
      gender: 'Female',
      phone: '+91 98765 43212',
      email: 'anjali.patel@email.com'
    }
  ]);

  // Hospital data with associated details
  const [hospitalData, setHospitalData] = useState([
    {
      hospitalName: 'Apollo Hospital',
      hospitalLocation: 'Delhi',
      city: 'New Delhi',
      state: 'Delhi',
      pincode: '110076',
      networkType: 'Network',
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 11 2692 5858',
      hospitalAddress: 'Sarita Vihar, Delhi Mathura Road, New Delhi - 110076',
      isApproved: true
    },
    {
      hospitalName: 'Fortis Hospital',
      hospitalLocation: 'Gurgaon',
      city: 'Gurugram',
      state: 'Haryana',
      pincode: '122002',
      networkType: 'Network',
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 124 496 2200',
      hospitalAddress: 'Sector 44, Gurugram, Haryana - 122002',
      isApproved: true
    },
    {
      hospitalName: 'Max Healthcare',
      hospitalLocation: 'Noida',
      city: 'Noida',
      state: 'Uttar Pradesh',
      pincode: '201301',
      networkType: 'Network',
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 120 718 2000',
      hospitalAddress: 'B-22, Sector-62, Noida - 201301',
      isApproved: true
    },
    {
      hospitalName: 'AIIMS',
      hospitalLocation: 'Delhi',
      city: 'New Delhi',
      state: 'Delhi',
      pincode: '110029',
      networkType: 'Non-Network',
      networkStatus: 'non-network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 11 2658 8500',
      hospitalAddress: 'Ansari Nagar, New Delhi - 110029',
      isApproved: true
    },
    {
      hospitalName: 'Medanta Hospital',
      hospitalLocation: 'Gurgaon',
      city: 'Gurugram',
      state: 'Haryana',
      pincode: '122001',
      networkType: 'Network',
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: '+91 124 414 4444',
      hospitalAddress: 'Sector 38, Gurugram, Haryana - 122001',
      isApproved: true
    }
  ]);

  const [formData, setFormData] = useState({
    // Editable Claim Details
    claimType: 'Reimbursement',
    claimSubType: 'Hospitalisation (IPD)',
    mainClaimId: '', // For Pre-post claims
    requestType: 'Preauth Request', // Only used for Cashless claims
    opdSpecialty: '', // For Others (OPD) selection
    benefitType: '', // For GPA selection
    admissionDate: new Date('2025-03-25'),
    dischargeDate: new Date('2025-03-28'),
    claimAmount: '₹85,000',
    claimProgress: 75,
    // Policy Details
    policyId: 'ACKO-HLTH-001234',
    planSelected: 'Individual Health',
    sumInsured: '₹5,00,000',
    remainingSI: '₹4,50,000',
    policyStart: '01 Jan 2025',
    policyEnd: '31 Dec 2025',
    // Patient Details
    uhid: 'UHID001',
    customerName: 'Priya Sharma',
    customerAge: '34 years',
    customerGender: 'Female',
    riskStartDate: new Date('2025-01-01'),
    riskEndDate: new Date('2025-12-31'),
    customerPhone: '+91 98765 43210',
    customerEmail: 'priya.sharma@email.com',
    customerAddress: 'A-123, Sector 15, Noida, Uttar Pradesh - 201301',
    // Bank Account Details
    accountHolder: 'Priya Sharma',
    bankName: 'HDFC Bank',
    accountNo: '50200012345678',
    ifscCode: 'HDFC0001234',
    branch: 'Sector 18, Noida',
    upiId: 'priyasharma@hdfc',
    // Hospital Details
    hospitalName: 'Apollo Hospital',
    hospitalLocation: 'Delhi',
    networkType: 'Network',
    hospitalContact: '+91 11 2692 5858',
    treatingDoctor: 'Dr. Rajesh Patel',
    hospitalAddress: 'Sarita Vihar, Delhi Mathura Road, New Delhi - 110076',
    // Treatment Details
    primaryDiagnosis: 'Coronary Artery Disease',
    icdCode: 'I25.9',
    treatmentType: 'Surgical',
    roomType: 'Private AC',
    lengthOfStay: '3 days',
    emergency: 'Yes',
    procedures: 'Cardiac Catheterization, Angioplasty, Stent Placement'
  });

  // Hospital management functions
  const handleHospitalSearch = (searchTerm: string) => {
    setHospitalSearchTerm(searchTerm);
    const found = hospitalData.some(hospital => 
      hospital.hospitalName.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setShowHospitalNotFound(searchTerm.length > 2 && !found);
  };

  const addNewHospital = () => {
    // Combine address fields
    const fullAddress = `${newHospitalData.hospitalAddress}, ${newHospitalData.city}, ${newHospitalData.state} - ${newHospitalData.pincode}`;
    
    const newHospital = {
      hospitalName: newHospitalData.hospitalName,
      hospitalAddress: fullAddress,
      hospitalLocation: newHospitalData.hospitalLocation || '',
      city: newHospitalData.city,
      state: newHospitalData.state,
      pincode: newHospitalData.pincode,
      networkType: newHospitalData.networkType,
      networkStatus: 'network' as 'network' | 'non-network' | 'excluded',
      cashlessAnywhere: false,
      hospitalContact: newHospitalData.hospitalContact || '',
      isApproved: false
    };
    
    // Add to hospital data
    setHospitalData(prev => [...prev, newHospital]);
    
    // Add to selected hospitals  
    if (editingHospitalIndex !== null) {
      const updatedHospitals = [...selectedHospitals];
      updatedHospitals[editingHospitalIndex] = newHospital;
      setSelectedHospitals(updatedHospitals);
    } else {
      setSelectedHospitals(prev => [...prev, newHospital]);
    }
    
    // Reset form
    setNewHospitalData({
      hospitalName: '',
      hospitalLocation: '',
      networkType: 'Network',
      hospitalContact: '',
      hospitalAddress: '',
      city: '',
      state: '',
      pincode: '',
      rohini: ''
    });
    setIsAddHospitalDialogOpen(false);
    setEditingHospitalIndex(null);
    setIsAddingHospital(false);
    setHospitalSearchTerm('');
    setShowHospitalNotFound(false);
    
    // Show success toast
    toast({
      title: "Request Sent for Approval",
      description: "The hospital addition request has been sent to the provider team for approval.",
    });
  };

  const addExistingHospital = (hospital: any) => {
    const exists = selectedHospitals.some(h => h.hospitalName === hospital.hospitalName);
    if (!exists) {
      setSelectedHospitals(prev => [...prev, hospital]);
    }
    setIsAddingHospital(false);
    setHospitalSearchTerm('');
    setShowHospitalNotFound(false);
  };

  const removeHospital = (hospitalName: string) => {
    setSelectedHospitals(prev => prev.filter(h => h.hospitalName !== hospitalName));
  };

  const handleSave = () => {
    // Here you would typically save to backend
    setIsEditing(false);
    console.log('Saving form data:', formData);
  };

  const handleCancel = () => {
    setIsEditing(false);
    // Reset form data if needed
  };

  // Patient & Policy Modal handlers
  const handleOpenPatientPolicyModal = () => {
    setSelectedPolicy(null);
    setSelectedMember(null);
    setIsPatientPolicyModalOpen(true);
  };

  const handlePatientIdentificationNext = (data: any) => {
    // Update formData with the selected policy and member information
    if (data.policy && data.member) {
      setFormData(prev => ({
        ...prev,
        customerName: data.member.name || prev.customerName,
        uhid: data.member.uhid || prev.uhid,
        policyId: data.policy.policyNumber || prev.policyId,
        planSelected: data.policy.policyType || prev.planSelected,
        sumInsured: data.policy.sumInsured || prev.sumInsured
      }));
    }
    
    // Close modal and reset
    setIsPatientPolicyModalOpen(false);
    setSelectedPolicy(null);
    setSelectedMember(null);
    
    toast({
      title: "Claim Updated",
      description: "Patient and policy details have been updated successfully.",
    });
  };

  const handleModalClose = () => {
    setIsPatientPolicyModalOpen(false);
    setSelectedPolicy(null);
    setSelectedMember(null);
    setIsCreatingExtension(false);
    setShowBackToLookup(false);
  };

  const handleBackToLookupClick = () => {
    setShowBackToLookup(false);
    setIsCreatingExtension(false);
  };

  const handleInputChange = (field: string, value: string | number | Date) => {
    setFormData(prev => {
      const newData = {
        ...prev,
        [field]: value
      };
      
      // Reset claim sub type when claim type changes
      if (field === 'claimType') {
        const subTypeOptions = getClaimSubTypeOptions(value as string);
        newData.claimSubType = subTypeOptions[0];
        newData.opdSpecialty = ''; // Reset OPD specialty
      }
      
      // Reset OPD specialty when claim sub type changes and it's not Others (OPD)
      if (field === 'claimSubType' && value !== 'Others (OPD)') {
        newData.opdSpecialty = '';
      }
      
      // Reset Benefit type when claim sub type changes and it's not GPA
      if (field === 'claimSubType' && value !== 'GPA') {
        newData.benefitType = '';
      }
      
      // Update patient details when UHID changes
      if (field === 'uhid') {
        const selectedPatient = uhidData.find(patient => patient.uhid === value);
        if (selectedPatient) {
          newData.customerName = selectedPatient.name;
          newData.customerAge = selectedPatient.age;
          newData.customerGender = selectedPatient.gender;
          newData.customerPhone = selectedPatient.phone;
          newData.customerEmail = selectedPatient.email;
        }
      }
      
      // Update policy details when policy ID or plan changes
      if (field === 'policyId') {
        const selectedPolicy = policiesData.find(policy => policy.policyId === value);
        if (selectedPolicy) {
          newData.planSelected = selectedPolicy.planSelected;
          newData.sumInsured = selectedPolicy.sumInsured;
          newData.remainingSI = selectedPolicy.remainingSI;
          newData.policyStart = selectedPolicy.policyStart;
          newData.policyEnd = selectedPolicy.policyEnd;
        }
      }
      
      if (field === 'planSelected') {
        const selectedPolicy = policiesData.find(policy => policy.planSelected === value);
        if (selectedPolicy) {
          newData.policyId = selectedPolicy.policyId;
          newData.sumInsured = selectedPolicy.sumInsured;
          newData.remainingSI = selectedPolicy.remainingSI;
          newData.policyStart = selectedPolicy.policyStart;
          newData.policyEnd = selectedPolicy.policyEnd;
        }
      }

      // Update hospital details when hospital is selected
      if (field === 'hospitalName') {
        const selectedHospital = hospitalData.find(hospital => hospital.hospitalName === value);
        if (selectedHospital) {
          newData.hospitalLocation = selectedHospital.hospitalLocation;
          newData.networkType = selectedHospital.networkType;
          newData.hospitalContact = selectedHospital.hospitalContact;
          newData.hospitalAddress = selectedHospital.hospitalAddress;
        }
      }
      
      return newData;
    });
  };

  const getClaimSubTypeOptions = (claimType: string) => {
    if (claimType === 'Reimbursement') {
      return [
        'Hospitalisation (IPD)',
        'Day care (IPD)', 
        'Doctor consultation & Medicines (OPD)',
        'Lab tests (OPD)',
        'Pre-post hospitalisation',
        'Domiciliary treatment',
        'Others (OPD)',
        'GPA'
      ];
    } else if (claimType === 'Cashless') {
      return [
        'Hospitalisation (IPD)',
        'Day care (IPD)'
      ];
    }
    return [];
  };

  // Get available claim IDs for main claim dropdown (settled or in progress claims)
  const getAvailableClaimIds = () => {
    // Mock data for claim IDs that are settled or in progress
    return [
      'CLM2024001234',
      'CLM2024001235', 
      'CLM2024001236',
      'CLM2024001237',
      'CLM2024001238'
    ];
  };

  const handlePreviousDocument = () => {
    const newIndex = currentDocumentIndex > 0 ? currentDocumentIndex - 1 : documents.length - 1;
    setCurrentDocumentIndex(newIndex);
    setSelectedDocument(newIndex.toString());
    setDocumentRotation(0); // Reset rotation when changing documents
  };

  const handleNextDocument = () => {
    const newIndex = currentDocumentIndex < documents.length - 1 ? currentDocumentIndex + 1 : 0;
    setCurrentDocumentIndex(newIndex);
    setSelectedDocument(newIndex.toString());
    setDocumentRotation(0); // Reset rotation when changing documents
  };

  // Handle opening document in new tab
  const handleOpenInNewTab = () => {
    const currentDoc = documents[currentDocumentIndex];
    if (currentDoc) {
      // In a real app, this would be the actual document URL
      const documentUrl = `/documents/${currentDoc.id}/${currentDoc.name}`;
      window.open(documentUrl, '_blank');
    }
  };

  // Handle document selection from dropdown
  const handleDocumentSelect = (value: string) => {
    setSelectedDocument(value);
    if (value === 'merged_document') {
      // Handle merged document view - could set a special index or flag
      setCurrentDocumentIndex(0); // For now, just show first document
    } else {
      const docIndex = parseInt(value);
      setCurrentDocumentIndex(docIndex);
      setPreviewDocumentIndex(docIndex);
      setIsDocumentPreviewOpen(true);
    }
  };

  // Function to generate system recommendations based on document analysis
  const generateSystemRecommendation = (category: string, readability: boolean, suspicious: boolean, irrelevant: boolean) => {
    if (irrelevant) {
      return 'Document marked as irrelevant to this claim. May be excluded from processing.';
    }
    if (suspicious) {
      return 'Document flagged as suspicious. Recommend thorough review and verification before approval.';
    }
    if (!readability) {
      return 'Document readability is poor. Request clearer version or additional documentation.';
    }
    
    switch (category) {
      case 'Prescription':
        return 'Prescription is clear and readable. Verify doctor credentials and date validity.';
      case 'Medicine Bills':
        return 'Medicine bill is clear. Cross-verify with prescription and pricing standards.';
      case 'Lab Reports':
        return 'Lab results are clear and within acceptable ranges. Safe to approve.';
      case 'Discharge Summary':
        return 'Discharge summary is complete with all required medical information. Recommend approval.';
      case 'ID Proof':
        return 'ID proof is clear and valid. Identity verification complete.';
      default:
        return 'Document analysis complete. Please review manually for final approval.';
    }
  };

  // Handle document field updates
  const handleDocumentFieldUpdate = (field: string, value: any) => {
    const updatedDocuments = [...documents];
    updatedDocuments[currentDocumentIndex] = {
      ...updatedDocuments[currentDocumentIndex],
      [field]: value
    };
    
    // Update system recommendation when any field changes
    const currentDoc = updatedDocuments[currentDocumentIndex];
    updatedDocuments[currentDocumentIndex].systemRecommendation = generateSystemRecommendation(
      currentDoc.category,
      currentDoc.readability,
      currentDoc.suspicious,
      currentDoc.irrelevant
    );
    
    setDocuments(updatedDocuments);
    
    // Auto-update document tagging checklist when category is set
    if (field === 'category') {
      const allDocumentsTagged = updatedDocuments.every(doc => doc.category && doc.category.trim() !== '');
      if (allDocumentsTagged) {
        setChecklist(prev => ({
          ...prev,
          documentTagging: true
        }));
      }
    }
  };

  // Handle checklist item toggle
  const toggleChecklistItem = (item: string) => {
    setChecklist(prev => ({
      ...prev,
      [item]: !prev[item]
    }));
  };

  const currentDocument = documents[currentDocumentIndex];

  // Zoom handlers
  const handleZoomIn = () => {
    setDocumentZoom(prev => Math.min(prev + 25, 200));
  };

  const handleZoomOut = () => {
    setDocumentZoom(prev => Math.max(prev - 25, 50));
  };

  const handleZoomReset = () => {
    setDocumentZoom(100);
  };

  const handleDocumentRotate = () => {
    setDocumentRotation(prev => (prev + 90) % 360);
  };

  const handleSaveDraft = () => {
    // Save draft logic here
    setLastSavedTime(new Date());
    toast({
      title: "Draft saved",
      description: "Your changes have been saved successfully.",
    });
  };

  // Control section expansion based on current step
  useEffect(() => {
    switch (currentStep) {
      case 1:
        // Step 1: Bill Entry collapsed, Clinical Details expanded (disease coding)
        setIsBillEntryOpen(false);
        setIsCodingOpen(true);
        setOpenClinicalSection("diseaseCoding");
        setIsAdmissibilityOpen(false);
        // Show AI pre-fill toast
        toast({
          title: (
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              <span>AI has pre-filled a few fields</span>
            </div>
          ) as unknown as string,
          description: "Colored dots show confidence levels. Hover to see more.",
          duration: 5000,
        });
        break;
      case 2:
        // Step 2: Procedure Details expanded, Additional Details collapsed
        setIsCodingOpen(true);
        setOpenClinicalSection("procedureDetails");
        setIsAdmissibilityOpen(false);
        break;
      case 3:
        // Step 3: Status & Next Action
        setIsCodingOpen(false);
        setIsAdmissibilityOpen(false);
        break;
    }
  }, [currentStep, toast]);

  return (
    <div className="h-screen overflow-hidden bg-background flex flex-col">
      {/* Header */}
      <header className="border-b bg-card shadow-sm">
        <div className="flex h-16 items-center px-6">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-semibold">Claim #{claimId}</h1>
            {lastSavedTime && (
              <span className="text-sm text-muted-foreground">
                Last saved at {format(lastSavedTime, 'HH:mm:ss')} {format(lastSavedTime, 'dd MMM yyyy')}
              </span>
            )}
          </div>
          
          {/* Minimized Section Card - Stage 2 */}
          {workflowStage === 'billEntry' && (
            <Button 
              variant="outline" 
              className="ml-6 h-auto py-2 hover:bg-muted/50"
              onClick={() => setWorkflowStage('review')}
            >
              <div className="flex items-center gap-4 text-xs">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-primary flex-shrink-0" />
                  <div className="text-left">
                    <div className="font-medium">Priya Sharma</div>
                    <div className="text-muted-foreground">POL1234567</div>
                  </div>
                </div>
                
                <div className="h-8 w-px bg-border" />
                
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-primary flex-shrink-0" />
                  <div className="text-left">
                    <div className="font-medium">Cashless</div>
                    <div className="text-muted-foreground">28/03/2025</div>
                  </div>
                </div>
                
                <div className="h-8 w-px bg-border" />
                
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-primary flex-shrink-0" />
                  <div className="text-left">
                    <div className="font-medium">Apollo Hospital</div>
                    <div className="text-muted-foreground">Network</div>
                  </div>
                </div>
                
                <div className="h-8 w-px bg-border" />
                
                <div className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-primary flex-shrink-0" />
                  <div className="text-left">
                    <div className="font-medium">Bank Details</div>
                    <div className="text-muted-foreground">****5678</div>
                  </div>
                </div>
              </div>
            </Button>
          )}
          
          <div className="ml-auto flex items-center space-x-2">
            
            {/* Updates Summary Popover */}
            <Popover open={isUpdatesSummaryOpen} onOpenChange={setIsUpdatesSummaryOpen}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <PopoverTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="icon"
                      className={cn(
                        "relative h-8 w-8",
                        updatesSummary.totalNewItems > 0 && "border-primary"
                      )}
                    >
                      <Bell className="h-4 w-4" />
                      {updatesSummary.totalNewItems > 0 && (
                        <span className="absolute -top-1.5 -right-1.5 h-4 min-w-4 px-1 flex items-center justify-center rounded-full bg-primary text-primary-foreground text-[10px] font-medium">
                          {updatesSummary.totalNewItems}
                        </span>
                      )}
                    </Button>
                  </PopoverTrigger>
                </TooltipTrigger>
                <TooltipContent>Updates Summary</TooltipContent>
              </Tooltip>
              <PopoverContent align="end" className="w-[380px] p-0">
                <div className="p-4 border-b bg-muted/30">
                  <div className="flex items-center gap-2">
                    <div className={cn(
                      "p-2 rounded-full",
                      updatesSummary.totalNewItems > 0 ? "bg-primary/10" : "bg-muted"
                    )}>
                      {updatesSummary.totalNewItems > 0 ? (
                        <RefreshCw className="h-4 w-4 text-primary" />
                      ) : (
                        <CheckCircle className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm">
                        {updatesSummary.isFirstTimeAdjudication 
                          ? 'First Time Adjudication' 
                          : `Claim Status: ${updatesSummary.claimStatus}`}
                      </h4>
                      <p className="text-xs text-muted-foreground">
                        {updatesSummary.totalNewItems > 0 
                          ? `${updatesSummary.totalNewItems} new updates since last review`
                          : 'No new updates'}
                      </p>
                    </div>
                  </div>
                </div>
                
                {updatesSummary.totalNewItems > 0 ? (
                  <div className="p-3 space-y-3 max-h-[400px] overflow-auto">
                    {/* New Documents Section */}
                    {updatesSummary.newDocuments.length > 0 && (
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <FileUp className="h-4 w-4 text-primary" />
                          <span className="text-sm font-medium">New Documents</span>
                          <Badge variant="secondary" className="text-[10px]">{updatesSummary.newDocuments.length}</Badge>
                        </div>
                        <div className="space-y-2 pl-6">
                          {updatesSummary.newDocuments.map((doc) => (
                            <div 
                              key={doc.id} 
                              className="flex items-center gap-2 text-xs p-2 bg-muted/50 rounded-md cursor-pointer hover:bg-muted transition-colors"
                              onClick={() => {
                                const docIndex = documents.findIndex(d => d.id === doc.id);
                                if (docIndex !== -1) {
                                  setCurrentDocumentIndex(docIndex);
                                  setSelectedDocument(docIndex.toString());
                                }
                                setIsUpdatesSummaryOpen(false);
                              }}
                            >
                              <FileText className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                              <div className="flex-1 min-w-0">
                                <div className="font-medium truncate">{doc.name}</div>
                                <div className="text-muted-foreground">{doc.uploadDate}</div>
                              </div>
                              <Badge className="bg-primary/10 text-primary border-0 text-[10px]">NEW</Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* New Audit Trail Entries Section */}
                    {updatesSummary.newAuditEntries.length > 0 && (
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <History className="h-4 w-4 text-primary" />
                          <span className="text-sm font-medium">New Activity</span>
                          <Badge variant="secondary" className="text-[10px]">{updatesSummary.newAuditEntries.length}</Badge>
                        </div>
                        <div className="space-y-2 pl-6">
                          {updatesSummary.newAuditEntries.map((entry) => (
                            <div 
                              key={entry.id} 
                              className={cn(
                                "flex items-start gap-2 text-xs p-2 rounded-md cursor-pointer hover:bg-muted transition-colors",
                                entry.type === 'internal-note' ? "bg-amber-50/50 dark:bg-amber-950/20" : "bg-muted/50"
                              )}
                              onClick={() => {
                                setIsAuditTrailOpen(true);
                                setIsUpdatesSummaryOpen(false);
                              }}
                            >
                              {entry.type === 'internal-note' ? (
                                <StickyNote className="h-3.5 w-3.5 text-amber-600 flex-shrink-0 mt-0.5" />
                              ) : (
                                <Circle className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0 mt-0.5" />
                              )}
                              <div className="flex-1 min-w-0">
                                <div className="font-medium">{entry.action}</div>
                                <div className="text-muted-foreground line-clamp-2">{entry.details}</div>
                                <div className="text-muted-foreground mt-1">{entry.user} • {entry.timestamp}</div>
                              </div>
                              <Badge className="bg-primary/10 text-primary border-0 text-[10px] flex-shrink-0">NEW</Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-6 text-center">
                    <CheckCircle className="h-8 w-8 mx-auto text-muted-foreground/50 mb-2" />
                    <p className="text-sm text-muted-foreground">
                      {updatesSummary.isFirstTimeAdjudication 
                        ? 'This is the first time this claim is being adjudicated'
                        : 'No new documents or notes since last adjudication'}
                    </p>
                  </div>
                )}
                
                <div className="p-3 border-t bg-muted/30 flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1 text-xs"
                    onClick={() => {
                      setIsAuditTrailOpen(true);
                      setIsUpdatesSummaryOpen(false);
                    }}
                  >
                    <History className="h-3 w-3 mr-1" />
                    View Audit Trail
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1 text-xs"
                    onClick={() => {
                      // Navigate to first new document if any
                      if (updatesSummary.newDocuments.length > 0) {
                        const docIndex = documents.findIndex(d => d.id === updatesSummary.newDocuments[0].id);
                        if (docIndex !== -1) {
                          setCurrentDocumentIndex(docIndex);
                          setSelectedDocument(docIndex.toString());
                        }
                      }
                      setIsUpdatesSummaryOpen(false);
                    }}
                  >
                    <FileText className="h-3 w-3 mr-1" />
                    View Documents
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="outline" 
                  size="icon"
                  className="h-8 w-8"
                  onClick={handleSaveDraft}
                >
                  <Save className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Save Draft</TooltipContent>
            </Tooltip>
            {/* Need More Details Button */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="h-8 gap-2"
                  onClick={() => setIsMoreDetailsModalOpen(true)}
                >
                  <HelpCircle className="h-4 w-4" />
                  <span className="text-xs">Need more details?</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>Access past claims, declarations, policies, and more</TooltipContent>
            </Tooltip>
          </div>
        </div>
      </header>

      {/* Need More Details Modal */}
      <Dialog open={isMoreDetailsModalOpen} onOpenChange={setIsMoreDetailsModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <HelpCircle className="h-5 w-5 text-primary" />
              Need More Details?
            </DialogTitle>
            <DialogDescription>
              Access additional information about this claim
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 gap-3 py-4">
            {/* Past Claim Details */}
            <div className="space-y-2">
              <Button 
                variant="outline" 
                className="w-full justify-start h-auto py-3"
                asChild
                onClick={() => setIsMoreDetailsModalOpen(false)}
              >
                <Link to="/past-claims">
                  <Receipt className="h-5 w-5 mr-3 text-primary" />
                  <div className="text-left">
                    <div className="font-medium">View Past Claims</div>
                    <div className="text-xs text-muted-foreground">Browse all previous claims for this customer</div>
                  </div>
                </Link>
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start h-auto py-3"
                asChild
                onClick={() => setIsMoreDetailsModalOpen(false)}
              >
                <Link to={`/past-extensions?claimId=${claimId}`}>
                  <History className="h-5 w-5 mr-3 text-primary" />
                  <div className="text-left">
                    <div className="font-medium">View Past Extensions</div>
                    <div className="text-xs text-muted-foreground">Extensions to this specific claim</div>
                  </div>
                </Link>
              </Button>
            </div>

            {/* Declarations */}
            <Button 
              variant="outline" 
              className="w-full justify-start h-auto py-3"
              asChild
              onClick={() => setIsMoreDetailsModalOpen(false)}
            >
              <Link to="/declarations">
                <FileText className="h-5 w-5 mr-3 text-primary" />
                <div className="text-left">
                  <div className="font-medium">View Declarations</div>
                  <div className="text-xs text-muted-foreground">Customer declarations and medical history</div>
                </div>
              </Link>
            </Button>

            {/* All Policies */}
            <Button 
              variant="outline" 
              className="w-full justify-start h-auto py-3"
              asChild
              onClick={() => setIsMoreDetailsModalOpen(false)}
            >
              <Link to="/customer-policies">
                <Shield className="h-5 w-5 mr-3 text-primary" />
                <div className="text-left">
                  <div className="font-medium">View All Policies</div>
                  <div className="text-xs text-muted-foreground">Complete insurance portfolio for this customer</div>
                </div>
              </Link>
            </Button>

            {/* Communications */}
            <Button 
              variant="outline" 
              className="w-full justify-start h-auto py-3"
              onClick={() => {
                setIsMoreDetailsModalOpen(false);
                setIsCommunicationsOpen(true);
              }}
            >
              <MessageSquare className="h-5 w-5 mr-3 text-primary" />
              <div className="text-left flex-1">
                <div className="font-medium">Communications</div>
                <div className="text-xs text-muted-foreground">All communications with customer and hospital</div>
              </div>
              <Badge variant="secondary" className="ml-2">{communicationsLog.length}</Badge>
            </Button>

            {/* Audit Trail */}
            <Button 
              variant="outline" 
              className="w-full justify-start h-auto py-3"
              onClick={() => {
                setIsMoreDetailsModalOpen(false);
                setIsAuditTrailOpen(true);
              }}
            >
              <ClipboardCheck className="h-5 w-5 mr-3 text-primary" />
              <div className="text-left flex-1">
                <div className="font-medium">Audit Trail</div>
                <div className="text-xs text-muted-foreground">Complete history of actions and changes</div>
              </div>
              <Badge variant="secondary" className="ml-2">{auditTrailLog.length}</Badge>
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Communications Sheet (opened from modal) */}
      <Sheet open={isCommunicationsOpen} onOpenChange={setIsCommunicationsOpen}>
        <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-primary" />
              Communications Log
            </SheetTitle>
            <SheetDescription>
              All communications with customer and hospital for verification
            </SheetDescription>
          </SheetHeader>

          {/* Filters */}
          <div className="mt-4 flex flex-wrap gap-3 p-3 bg-muted/30 rounded-lg border">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Filters:</span>
            </div>
            <Select value={commExtensionFilter} onValueChange={setCommExtensionFilter}>
              <SelectTrigger className="w-[180px] h-8 text-xs">
                <SelectValue placeholder="Claim Extension" />
              </SelectTrigger>
              <SelectContent className="bg-background border shadow-lg z-50">
                {claimExtensions.map((ext) => (
                  <SelectItem key={ext.id} value={ext.id}>{ext.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={commDirectionFilter} onValueChange={setCommDirectionFilter}>
              <SelectTrigger className="w-[140px] h-8 text-xs">
                <SelectValue placeholder="Direction" />
              </SelectTrigger>
              <SelectContent className="bg-background border shadow-lg z-50">
                <SelectItem value="all">All Directions</SelectItem>
                <SelectItem value="Inbound">
                  <span className="flex items-center gap-2">
                    <ArrowDownLeft className="h-3 w-3 text-blue-600" />
                    Inbound (Customer/Hospital)
                  </span>
                </SelectItem>
                <SelectItem value="Outbound">
                  <span className="flex items-center gap-2">
                    <ArrowUpRight className="h-3 w-3 text-green-600" />
                    Outbound (ACKO)
                  </span>
                </SelectItem>
              </SelectContent>
            </Select>
            <Badge variant="secondary" className="text-xs">
              {filteredCommunications.length} of {communicationsLog.length}
            </Badge>
          </div>

          {/* Direction Legend */}
          <div className="mt-3 flex gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <ArrowDownLeft className="h-3.5 w-3.5 text-blue-600" />
              <span className="text-muted-foreground">Inbound = From Customer/Hospital</span>
            </div>
            <div className="flex items-center gap-1.5">
              <ArrowUpRight className="h-3.5 w-3.5 text-green-600" />
              <span className="text-muted-foreground">Outbound = From ACKO</span>
            </div>
          </div>

          <div className="mt-4 space-y-4">
            {filteredCommunications.map((comm) => (
              <div key={comm.id} className={cn(
                "flex items-start gap-3 p-4 rounded-lg border transition-colors",
                comm.direction === 'Inbound' 
                  ? "bg-blue-50/50 border-blue-200 dark:bg-blue-950/20 dark:border-blue-800" 
                  : "bg-green-50/50 border-green-200 dark:bg-green-950/20 dark:border-green-800"
              )}>
                <div className={cn(
                  "p-2.5 rounded-full shrink-0",
                  comm.type === 'Email' && "bg-blue-500/10 text-blue-600",
                  comm.type === 'SMS' && "bg-green-500/10 text-green-600",
                  comm.type === 'Phone Call' && "bg-orange-500/10 text-orange-600"
                )}>
                  {comm.type === 'Email' && <Mail className="h-4 w-4" />}
                  {comm.type === 'SMS' && <MessageSquare className="h-4 w-4" />}
                  {comm.type === 'Phone Call' && <Phone className="h-4 w-4" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-2">
                    {comm.direction === 'Inbound' ? (
                      <Badge className="text-xs bg-blue-100 text-blue-700 border-blue-300">
                        <ArrowDownLeft className="h-3 w-3 mr-1" />
                        From {comm.recipientType}
                      </Badge>
                    ) : (
                      <Badge className="text-xs bg-green-100 text-green-700 border-green-300">
                        <ArrowUpRight className="h-3 w-3 mr-1" />
                        To {comm.recipientType}
                      </Badge>
                    )}
                    {comm.hasAttachment && (
                      <Badge variant="secondary" className="text-xs">
                        <Paperclip className="h-3 w-3 mr-1" />
                        Attachment
                      </Badge>
                    )}
                    <Badge 
                      variant="outline" 
                      className={cn(
                        "text-xs",
                        comm.status === 'Delivered' && "border-green-500 text-green-600",
                        comm.status === 'Received' && "border-blue-500 text-blue-600",
                        comm.status === 'Completed' && "border-green-500 text-green-600"
                      )}
                    >
                      {comm.status}
                    </Badge>
                  </div>
                  <p className="font-medium text-sm">{comm.subject}</p>
                  <div className="flex items-center gap-2 mt-1.5 text-xs text-muted-foreground">
                    <span className={cn(
                      "px-1.5 py-0.5 rounded font-medium",
                      comm.recipientType === 'Customer' && "bg-primary/10 text-primary",
                      comm.recipientType === 'Hospital' && "bg-purple-500/10 text-purple-600"
                    )}>
                      {comm.recipientType}
                    </span>
                    <span>{comm.recipient}</span>
                    {comm.duration && <span>• Duration: {comm.duration}</span>}
                  </div>
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {comm.timestamp}
                    </span>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="h-7 text-xs"
                      onClick={() => setSelectedCommunication(comm)}
                    >
                      <ExternalLink className="h-3 w-3 mr-1" />
                      View Content
                    </Button>
                  </div>
                </div>
              </div>
            ))}
            {filteredCommunications.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No communications match the selected filters</p>
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>

      {/* Audit Trail Sheet (opened from modal) */}
      <Sheet open={isAuditTrailOpen} onOpenChange={setIsAuditTrailOpen}>
        <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <History className="h-5 w-5 text-primary" />
              Audit Trail
            </SheetTitle>
            <SheetDescription>
              Complete history of all actions and changes including internal notes and discussions
            </SheetDescription>
          </SheetHeader>

          {/* Filter */}
          <div className="mt-4 flex flex-wrap gap-3 p-3 bg-muted/30 rounded-lg border">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Filter:</span>
            </div>
            <Select value={auditExtensionFilter} onValueChange={setAuditExtensionFilter}>
              <SelectTrigger className="w-[180px] h-8 text-xs">
                <SelectValue placeholder="Claim Extension" />
              </SelectTrigger>
              <SelectContent className="bg-background border shadow-lg z-50">
                {claimExtensions.map((ext) => (
                  <SelectItem key={ext.id} value={ext.id}>{ext.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={auditTypeFilter} onValueChange={setAuditTypeFilter}>
              <SelectTrigger className="w-[160px] h-8 text-xs">
                <SelectValue placeholder="Entry Type" />
              </SelectTrigger>
              <SelectContent className="bg-background border shadow-lg z-50">
                <SelectItem value="all">All Entries</SelectItem>
                <SelectItem value="internal-notes">
                  <span className="flex items-center gap-2">
                    <StickyNote className="h-3 w-3 text-amber-600" />
                    Internal Notes Only
                  </span>
                </SelectItem>
              </SelectContent>
            </Select>
            <Badge variant="secondary" className="text-xs">
              {filteredAuditTrail.length} of {auditTrailLog.length}
            </Badge>
          </div>

          {/* Legend for internal items */}
          <div className="mt-3 flex flex-wrap gap-3 text-xs">
            <div className="flex items-center gap-1.5">
              <StickyNote className="h-3.5 w-3.5 text-amber-600" />
              <span className="text-muted-foreground">Internal Note</span>
            </div>
          </div>

          <div className="mt-4 relative">
            {/* Timeline line */}
            <div className="absolute left-[15px] top-2 bottom-2 w-0.5 bg-border" />
            
            <div className="space-y-4">
              {filteredAuditTrail.map((audit) => (
                <div key={audit.id} className={cn(
                  "relative flex gap-4 p-3 rounded-lg transition-colors",
                  audit.type === 'internal-note' && "bg-amber-50/50 border border-amber-200 dark:bg-amber-950/20 dark:border-amber-800",
                  audit.type === 'system' && "bg-transparent border"
                )}>
                  {/* Timeline dot */}
                  <div className="relative z-10 flex-shrink-0">
                    {audit.type === 'internal-note' ? (
                      <div className="h-7 w-7 rounded-full bg-amber-100 border-2 border-amber-500 flex items-center justify-center">
                        <StickyNote className="h-3.5 w-3.5 text-amber-600" />
                      </div>
                    ) : (
                      <div className={cn(
                        "h-7 w-7 rounded-full border-2 flex items-center justify-center",
                        audit.category === 'Registration' && "bg-blue-100 border-blue-500",
                        audit.category === 'Documents' && "bg-green-100 border-green-500",
                        audit.category === 'Assignment' && "bg-purple-100 border-purple-500",
                        audit.category === 'Clinical' && "bg-orange-100 border-orange-500",
                        audit.category === 'Financial' && "bg-emerald-100 border-emerald-500",
                        audit.category === 'Query' && "bg-yellow-100 border-yellow-500",
                        audit.category === 'Status' && "bg-primary/20 border-primary"
                      )}>
                        <CheckCircle className="h-3.5 w-3.5" />
                      </div>
                    )}
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 pb-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-sm">{audit.action}</span>
                      {audit.isNew && (
                        <Badge className="bg-primary/10 text-primary border-0 text-[10px] px-1.5 py-0">NEW</Badge>
                      )}
                      {getAuditTypeBadge(audit.type)}
                      <Badge variant="outline" className="text-xs">
                        {audit.category}
                      </Badge>
                    </div>
                    <p className={cn(
                      "text-sm mt-1.5 text-muted-foreground",
                      audit.type === 'internal-note' && "italic"
                    )}>
                      {audit.details}
                    </p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <User className="h-3 w-3" />
                        {audit.user}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {audit.timestamp}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
              {filteredAuditTrail.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <History className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No audit events match the selected filter</p>
                </div>
              )}
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {/* Split Screen Layout with Resizable Panels */}
      <ResizablePanelGroup direction="horizontal" className="flex-1 min-h-0 overflow-hidden">
        {/* Left Side: Document Viewer */}
        {isDocumentReviewVisible && (
          <>
            <ResizablePanel defaultSize={60} minSize={40} className="bg-card overflow-hidden min-h-0 min-w-0">
              <ScrollArea className="h-full">
                <div className="p-4 border-b">
                  <div className="flex items-center justify-between flex-wrap gap-3">
                    <h2 className="text-lg font-semibold">Document Review</h2>
                    <div className="flex items-center gap-2 flex-wrap">
                      {/* Download Documents Button */}
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setIsDownloadDialogOpen(true)}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                      
                      
                      {/* Document Selection Dropdown */}
                      <Select value={selectedDocument} onValueChange={handleDocumentSelect}>
                        <SelectTrigger className="w-[200px]">
                          <SelectValue placeholder="Select document to review" />
                        </SelectTrigger>
                        <SelectContent className="bg-background">
                          {documents.map((doc, index) => (
                            <SelectItem key={index} value={index.toString()}>
                              <span className="flex items-center gap-2">
                                {doc.name}
                                {doc.isNew && (
                                  <span className="px-1.5 py-0.5 text-[10px] font-medium rounded bg-primary/10 text-primary">NEW</span>
                                )}
                              </span>
                            </SelectItem>
                          ))}
                          <SelectItem value="merged_document">
                            📄 Merged Document View
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <div className="flex items-center gap-1 border rounded-md p-1">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={handleZoomOut}
                          disabled={documentZoom <= 50}
                        >
                          <ZoomOut className="h-3 w-3" />
                        </Button>
                        <span className="text-xs text-muted-foreground px-2 min-w-[3rem] text-center">
                          {documentZoom}%
                        </span>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={handleZoomIn}
                          disabled={documentZoom >= 200}
                        >
                          <ZoomIn className="h-3 w-3" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={handleZoomReset}
                        >
                          <RotateCcw className="h-3 w-3" />
                        </Button>
                      </div>
                      
                      {/* Document Rotation */}
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={handleDocumentRotate}
                      >
                        <RotateCw className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => setDocumentOverlayOpen(true)}
                      >
                        <Maximize2 className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={handleOpenInNewTab}
                        title="Open in new tab"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                      {/* View Policy Document Button */}
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => window.open('/policy-document', '_blank')}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        Policy Document
                      </Button>
                    </div>
                  </div>
                </div>
                
                {/* Document Display */}
                <div className="p-4">
                  <div className={`relative border-2 border-dashed border-muted-foreground/30 rounded-lg flex items-center justify-center bg-muted/20`} 
                       style={{ height: `${previewHeight}px` }}>
                    {/* Previous Document Navigation */}
                    <Button 
                      variant="outline" 
                      size="icon"
                      className="absolute left-3 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-background/90 shadow-md hover:bg-background z-10"
                      onClick={handlePreviousDocument}
                      disabled={documents.length <= 1}
                    >
                      <ChevronLeft className="h-5 w-5" />
                    </Button>
                    
                    {/* Next Document Navigation */}
                    <Button 
                      variant="outline" 
                      size="icon"
                      className="absolute right-3 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-background/90 shadow-md hover:bg-background z-10"
                      onClick={handleNextDocument}
                      disabled={documents.length <= 1}
                    >
                      <ChevronRight className="h-5 w-5" />
                    </Button>
                    
                    <div className="text-center space-y-4" style={{ transform: `scale(${documentZoom / 100})` }}>
                      <div className="bg-background/80 rounded-full p-6 mx-auto w-fit">
                        <currentDocument.icon className="h-16 w-16 text-muted-foreground" />
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-foreground text-lg">
                            {currentDocument.name}
                          </p>
                          {currentDocument.isNew && (
                            <Badge className="bg-primary/10 text-primary border-0 text-xs">NEW</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {currentDocument.type} • {currentDocument.size} • {currentDocument.uploadDate}
                        </p>
                        <p className="text-sm text-muted-foreground max-w-md">
                          {currentDocument.content}
                        </p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                </div>
                
                {/* Document Analysis Panel */}
                <div className="p-4 border-t bg-muted/20">
                  <h4 className="font-medium text-sm mb-3">Document Analysis</h4>

                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-muted-foreground">Category</label>
                      <div className="inline-flex items-center rounded-full border bg-background px-2.5 py-0.5 text-xs">
                        <span>{currentDocument.category || 'Not categorized'}</span>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-medium text-muted-foreground">Readability</label>
                      <div className="flex items-center gap-2">
                        <Badge variant={!currentDocument.readability ? 'destructive' : 'success'} className="text-xs">
                          {!currentDocument.readability ? 'Unreadable' : 'Readable'}
                        </Badge>
                      </div>
                      {!currentDocument.readability && currentDocument.unreadableReason && (
                        <p className="text-xs text-muted-foreground">
                          {unreadableReasonLabels[currentDocument.unreadableReason] || currentDocument.unreadableReason}
                        </p>
                      )}
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-medium text-muted-foreground">Suspicion</label>
                      <div className="flex items-center gap-2">
                        <Badge variant={currentDocument.suspicious ? 'destructive' : 'success'} className="text-xs">
                          {currentDocument.suspicious ? 'Suspicious' : 'Clear'}
                        </Badge>
                      </div>
                      {currentDocument.suspicious && currentDocument.suspiciousReason && (
                        <p className="text-xs text-muted-foreground">
                          {suspiciousReasonLabels[currentDocument.suspiciousReason] || currentDocument.suspiciousReason}
                        </p>
                      )}
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-medium text-muted-foreground">Relevancy</label>
                      <div className="flex items-center gap-2">
                        <Badge variant={currentDocument.irrelevant ? 'destructive' : 'success'} className="text-xs">
                          {currentDocument.irrelevant ? 'Irrelevant' : 'Relevant'}
                        </Badge>
                      </div>
                      {currentDocument.irrelevant && currentDocument.irrelevantReason && (
                        <p className="text-xs text-muted-foreground">
                          {irrelevantReasonLabels[currentDocument.irrelevantReason] || currentDocument.irrelevantReason}
                        </p>
                      )}
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-medium text-muted-foreground">Completeness</label>
                      <div className="flex items-center gap-2">
                        <Badge variant={!currentDocument.isComplete ? 'destructive' : 'success'} className="text-xs">
                          {!currentDocument.isComplete ? 'Missing' : 'Complete'}
                        </Badge>
                      </div>
                      {!currentDocument.isComplete && currentDocument.missingReason && (
                        <p className="text-xs text-muted-foreground">
                          {missingReasonLabels[currentDocument.missingReason] || currentDocument.missingReason}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="mt-4">
                    <label className="text-sm font-medium text-muted-foreground">Agent Notes</label>
                    <div className="mt-1 rounded-md border bg-background px-3 py-2">
                      {currentDocument.agentNotes ? (
                        <p className="text-sm whitespace-pre-wrap">{currentDocument.agentNotes}</p>
                      ) : (
                        <p className="text-sm text-muted-foreground">No agent notes added for this document.</p>
                      )}
                    </div>
                  </div>
                </div>

              </ScrollArea>
            </ResizablePanel>

            <ResizableHandle withHandle />
          </>
        )}

        {/* Divider Toggle Button - positioned on the edge between panels */}
        <div className="relative flex items-center">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setIsDocumentReviewVisible((prev) => !prev)}
                className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 h-8 w-8 rounded-full border-2 border-border bg-background hover:bg-muted shadow-md"
              >
                {isDocumentReviewVisible ? (
                  <PanelLeftClose className="h-4 w-4" />
                ) : (
                  <PanelLeftOpen className="h-4 w-4" />
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="right">
              {isDocumentReviewVisible ? 'Hide document review' : 'Show document review'}
            </TooltipContent>
          </Tooltip>
        </div>

        {/* Right Side: Claim Information Panels */}
        <ResizablePanel defaultSize={40} minSize={30} className="bg-muted/10 h-full overflow-hidden min-h-0 min-w-0 flex flex-col">
          <ScrollArea className="flex-1">
            <div className="p-4 pb-24 space-y-4 min-h-full">

              {/* Sticky Header Section */}
              {workflowStage === 'review' && (
                <div className="sticky top-0 z-10 space-y-2 bg-background pb-2 -mx-4 px-4 pt-0">
                  {/* Claim Summary Card - View Only */}
                  <Card className="border-muted overflow-hidden">
                    <CardContent className="py-3 px-4 overflow-hidden">
                      <div className="flex items-center gap-3 min-w-0">
                        {/* Name - can wrap */}
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <User className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                          <span className="text-sm font-medium">{formData.customerName}</span>
                        </div>

                        <Separator orientation="vertical" className="h-4 flex-shrink-0" />

                        {/* Policy ID with tooltip */}
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="text-sm text-muted-foreground truncate max-w-[120px] cursor-default">{formData.policyId}</span>
                          </TooltipTrigger>
                          <TooltipContent side="bottom">
                            <p>{formData.policyId}</p>
                          </TooltipContent>
                        </Tooltip>

                        <Separator orientation="vertical" className="h-4 flex-shrink-0" />

                        {/* Claim Type Tags - flex-shrink to allow compression */}
                        <div className="flex items-center gap-1.5 flex-shrink min-w-0 overflow-hidden">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Badge className="text-xs bg-blue-100 text-blue-700 hover:bg-blue-100 border-0 truncate max-w-[100px]">
                                {formData.claimType}
                              </Badge>
                            </TooltipTrigger>
                            <TooltipContent side="bottom">
                              <p>{formData.claimType}</p>
                            </TooltipContent>
                          </Tooltip>
                          {formData.claimSubType && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Badge className="text-xs bg-purple-100 text-purple-700 hover:bg-purple-100 border-0 truncate max-w-[120px]">
                                  {formData.claimSubType}
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent side="bottom">
                                <p>{formData.claimSubType}</p>
                              </TooltipContent>
                            </Tooltip>
                          )}
                          {formData.claimType === 'Cashless' && formData.requestType && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Badge className="text-xs bg-amber-100 text-amber-700 hover:bg-amber-100 border-0 truncate max-w-[100px]">
                                  {formData.requestType}
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent side="bottom">
                                <p>{formData.requestType}</p>
                              </TooltipContent>
                            </Tooltip>
                          )}
                          <Badge className="text-xs bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-0 flex-shrink-0">
                            ACKO_existing
                          </Badge>
                        </div>

                        <Separator orientation="vertical" className="h-4 flex-shrink-0" />

                        {/* Hospital & Bank with tooltips */}
                        <div className="flex items-center gap-2 min-w-0 flex-shrink">
                          <Building2 className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="text-sm truncate max-w-[140px] cursor-default">{selectedHospitals[0]?.hospitalName || 'N/A'}</span>
                            </TooltipTrigger>
                            <TooltipContent side="bottom">
                              <p>{selectedHospitals[0]?.hospitalName || 'N/A'}</p>
                            </TooltipContent>
                          </Tooltip>
                          {formData.claimType === 'Reimbursement' && formData.accountNo && (
                            <>
                              <span className="text-muted-foreground flex-shrink-0">•</span>
                              <CreditCard className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                              <span className="text-sm text-muted-foreground flex-shrink-0">****{formData.accountNo.slice(-4)}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* AI Confidence Legend - Sticky below claim summary */}
                  {currentStep === 1 && (
                    <div className="bg-muted/50 rounded-md px-3 py-2 border">
                      <AIConfidenceLegend />
                    </div>
                  )}
                </div>
              )}

              {/* Expanded View - All Sections */}
              {workflowStage === 'review' && isDetailsExpanded && (
                <>
                  {/* Collapse Button */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setIsDetailsExpanded(false);
                      setIsPatientPolicyOpen(false);
                      setIsClaimDetailsOpen(false);
                      setIsHospitalDetailsOpen(false);
                      setIsBankDetailsOpen(false);
                      setIsBillEntryOpen(false);
                    }}
                    className="w-full mb-2"
                  >
                    <ChevronUp className="h-4 w-4 mr-2" />
                    Collapse Bill Entry Details
                  </Button>

                  {/* Patient & Policy Details */}
                  <Collapsible open={isPatientPolicyOpen} onOpenChange={setIsPatientPolicyOpen}>
                <div className="flex items-center space-x-2">
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="flex-1 justify-between">
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4 text-primary" />
                        <span className="font-medium">Patient & Policy Details</span>
                      </div>
                      {isPatientPolicyOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  
                  <Button variant="outline" size="sm" onClick={handleOpenPatientPolicyModal} className="flex-shrink-0">
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>

                <CollapsibleContent className="mt-2">
                  {/* Super Top Up Policy Nudge */}
                  {shouldShowSuperTopUpNudge() && (
                    <Alert className="bg-amber-50 border-amber-200 mb-4">
                      <AlertCircle className="h-4 w-4 text-amber-600" />
                      <AlertDescription>
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="font-medium text-amber-800 mb-1">Super Top Up Policy Available</p>
                            <p className="text-sm text-amber-700 mb-2">
                              Claim amount (₹{calculateTotalClaimAmount().toLocaleString()}) exceeds the deductible amount 
                              (₹{getSuperTopUpPolicy()?.deductible.toLocaleString()}) for the Super Top Up policy.
                            </p>
                            <p className="text-sm text-amber-700">
                              <strong>Recommendation:</strong> Consider utilizing the Super Top Up policy 
                              ({getSuperTopUpPolicy()?.policyId}) in addition to the base policy for better coverage.
                            </p>
                          </div>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="space-y-3">
                    {/* Policy Overview */}
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Policy Overview</CardTitle>
                      </CardHeader>
                      <CardContent className="p-4 space-y-3 text-sm">
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Policy No:</span>
                          {isPatientEditing ? (
                            <Select value={formData.policyId} onValueChange={value => handleInputChange('policyId', value)}>
                              <SelectTrigger className="w-40 h-8">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {policiesData.map(policy => (
                                  <SelectItem key={policy.policyId} value={policy.policyId}>{policy.policyId}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className="font-medium">{formData.policyId}</span>
                          )}
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">SI:</span>
                          <span className="font-medium">{formData.sumInsured}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Plan Name:</span>
                          {isPatientEditing ? (
                            <Select value={formData.planSelected} onValueChange={value => handleInputChange('planSelected', value)}>
                              <SelectTrigger className="w-40 h-8">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Individual Health">Individual Health</SelectItem>
                                <SelectItem value="Retail Health">Retail Health</SelectItem>
                                <SelectItem value="Group Health">Group Health</SelectItem>
                                <SelectItem value="Super top up">Super top up</SelectItem>
                                <SelectItem value="Arogya Sanjeevani">Arogya Sanjeevani</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className="font-medium">{formData.planSelected}</span>
                          )}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Policyholder Details */}
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Policyholder Details</CardTitle>
                      </CardHeader>
                      <CardContent className="p-4 space-y-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Name:</span>
                          <span className="font-medium">{formData.customerName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Email:</span>
                          <span className="font-medium">{formData.customerEmail}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Phone:</span>
                          <span className="font-medium">{formData.customerPhone}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Start Date:</span>
                          <span className="font-medium">{formData.policyStart}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">End Date:</span>
                          <span className="font-medium">{formData.policyEnd}</span>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Patient Details */}
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Patient Details</CardTitle>
                      </CardHeader>
                      <CardContent className="p-4 space-y-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Name:</span>
                          <span className="font-medium">{formData.customerName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">UHID:</span>
                          <span className="font-medium">{formData.uhid}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Risk Start Date:</span>
                          <span className="font-medium">{formData.riskStartDate instanceof Date ? format(formData.riskStartDate, 'dd MMM yyyy') : formData.riskStartDate}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Risk End Date:</span>
                          <span className="font-medium">{formData.riskEndDate instanceof Date ? format(formData.riskEndDate, 'dd MMM yyyy') : formData.riskEndDate}</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CollapsibleContent>
              </Collapsible>

              {/* Claim Details */}
              <Collapsible open={isClaimDetailsOpen} onOpenChange={setIsClaimDetailsOpen}>
                <div className="flex items-center space-x-2">
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="flex-1 justify-between">
                       <div className="flex items-center space-x-2">
                         <FileText className="h-4 w-4 text-primary" />
                         <span className="font-medium">Claim Details</span>
                       </div>
                      {isClaimDetailsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  
                  {!isEditing ? (
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(true)} className="flex-shrink-0">
                      <Edit className="h-4 w-4" />
                    </Button>
                  ) : (
                    <div className="flex items-center space-x-1">
                      <Button variant="outline" size="sm" onClick={handleSave} className="flex-shrink-0">
                        <Save className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={handleCancel} className="flex-shrink-0">
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>

                <CollapsibleContent className="mt-2">
                  <Card>
                    <CardContent className="p-4 space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Claim ID:</span>
                        <span className="font-medium">HLTHCR8472</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Claim Type:</span>
                        {isEditing ? (
                          <Select value={formData.claimType} onValueChange={value => handleInputChange('claimType', value)}>
                            <SelectTrigger className="w-32 h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Reimbursement">Reimbursement</SelectItem>
                              <SelectItem value="Cashless">Cashless</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          <span className="font-medium">{formData.claimType}</span>
                        )}
                      </div>
                      
                      {formData.claimType === 'Cashless' && (
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Request Type:</span>
                          {isEditing ? (
                            <Select value={formData.requestType} onValueChange={value => handleInputChange('requestType', value)}>
                              <SelectTrigger className="w-40 h-8">
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Preauth Initial">Preauth Initial</SelectItem>
                                <SelectItem value="Enhancement">Enhancement</SelectItem>
                                <SelectItem value="Final">Final</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className="font-medium">{formData.requestType}</span>
                          )}
                        </div>
                      )}
                      
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Claim Sub Type:</span>
                        {isEditing ? (
                          <Select value={formData.claimSubType} onValueChange={value => handleInputChange('claimSubType', value)}>
                            <SelectTrigger className="w-32 h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {getClaimSubTypeOptions(formData.claimType).map(option => (
                                <SelectItem key={option} value={option}>{option}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        ) : (
                          <span className="font-medium">{formData.claimSubType}</span>
                        )}
                      </div>
                      
                      {formData.claimSubType === 'Others (OPD)' && (
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">OPD Specialty:</span>
                          {isEditing ? (
                            <Select value={formData.opdSpecialty} onValueChange={value => handleInputChange('opdSpecialty', value)}>
                              <SelectTrigger className="w-32 h-8">
                                <SelectValue placeholder="Select specialty" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="dental">Dental</SelectItem>
                                <SelectItem value="eye/vision">Eye/Vision</SelectItem>
                                <SelectItem value="ante/post natal">Ante/Post Natal</SelectItem>
                                <SelectItem value="vaccination">Vaccination</SelectItem>
                                <SelectItem value="mental illness">Mental Illness</SelectItem>
                                <SelectItem value="infertility">Infertility</SelectItem>
                                <SelectItem value="physiotherapy">Physiotherapy</SelectItem>
                                <SelectItem value="autism">Autism</SelectItem>
                                <SelectItem value="oral chemo">Oral Chemo</SelectItem>
                                <SelectItem value="ayush">Ayush</SelectItem>
                                <SelectItem value="animal bite">Animal Bite</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className="font-medium">{formData.opdSpecialty}</span>
                          )}
                        </div>
                      )}
                      
                      {formData.claimSubType === 'GPA' && (
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Benefit Type:</span>
                          {isEditing ? (
                            <Select value={formData.benefitType} onValueChange={value => handleInputChange('benefitType', value)}>
                              <SelectTrigger className="w-48 h-8">
                                <SelectValue placeholder="Select benefit type" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Temporary_total_disability">Temporary_total_disability</SelectItem>
                                <SelectItem value="Permanent_total_disability">Permanent_total_disability</SelectItem>
                                <SelectItem value="permanent_partial_disabiity">permanent_partial_disabiity</SelectItem>
                                <SelectItem value="opd_treatment">opd_treatment</SelectItem>
                                <SelectItem value="Accidental Death">Accidental Death</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className="font-medium">{formData.benefitType}</span>
                          )}
                        </div>
                      )}
                      
                      {/* Main Claim field - conditional on Pre-post sub type */}
                      {formData.claimSubType === 'Pre-post hospitalisation' && (
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Main Claim:</span>
                          {isEditing ? (
                            <Select value={formData.mainClaimId} onValueChange={value => handleInputChange('mainClaimId', value)}>
                              <SelectTrigger className="w-32 h-8">
                                <SelectValue placeholder="Select claim" />
                              </SelectTrigger>
                              <SelectContent>
                                {getAvailableClaimIds().map(claimId => (
                                  <SelectItem key={claimId} value={claimId}>{claimId}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className="font-medium">{formData.mainClaimId || 'Not selected'}</span>
                          )}
                        </div>
                      )}
                      
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">
                          {formData.claimSubType === 'GPA' ? 'Date of accident:' : 'DOA:'}
                        </span>
                        {isEditing ? (
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button variant="outline" className="w-32 h-8 text-left font-normal">
                                <CalendarIcon className="mr-2 h-3 w-3" />
                                {format(formData.admissionDate, "dd/MM/yyyy")}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <Calendar
                                mode="single"
                                selected={formData.admissionDate}
                                onSelect={(date) => date && handleInputChange('admissionDate', date)}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                        ) : (
                          <span className="font-medium">{format(formData.admissionDate, "PPP")}</span>
                        )}
                      </div>
                      
                      {formData.claimSubType !== 'GPA' && (
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">DOD:</span>
                          {isEditing ? (
                            <Popover>
                              <PopoverTrigger asChild>
                                <Button variant="outline" className="w-32 h-8 text-left font-normal">
                                  <CalendarIcon className="mr-2 h-3 w-3" />
                                  {format(formData.dischargeDate, "dd/MM/yyyy")}
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0">
                                <Calendar
                                  mode="single"
                                  selected={formData.dischargeDate}
                                  onSelect={(date) => date && handleInputChange('dischargeDate', date)}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                          ) : (
                            <span className="font-medium">{format(formData.dischargeDate, "PPP")}</span>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  </CollapsibleContent>
              </Collapsible>

              {/* Hospital Details */}
              <Collapsible open={isHospitalDetailsOpen} onOpenChange={setIsHospitalDetailsOpen}>
                <div className="flex items-center space-x-2">
                  <CollapsibleTrigger asChild>
                    <Button 
                      variant="outline" 
                      className="flex-1 justify-between"
                    >
                      <div className="flex items-center space-x-2">
                        <Building2 className="h-4 w-4 text-primary" />
                        <span className="font-medium">Hospital Details</span>
                        {selectedHospitals.length > 1 && (
                          <Badge variant="secondary" className="text-xs">
                            {selectedHospitals.length} hospitals
                          </Badge>
                        )}
                      </div>
                      {isHospitalDetailsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  
                  {!isHospitalEditing ? (
                    <Button variant="outline" size="sm" onClick={() => {
                      setIsHospitalEditing(true);
                      setEditingHospitalIndex(null);
                    }} className="flex-shrink-0">
                      <Edit className="h-4 w-4" />
                    </Button>
                  ) : (
                    <div className="flex items-center space-x-1">
                      <Button variant="outline" size="sm" onClick={() => {
                        setIsHospitalEditing(false);
                        setEditingHospitalIndex(null);
                      }} className="flex-shrink-0">
                        <Save className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => {
                        setIsHospitalEditing(false);
                        setEditingHospitalIndex(null);
                      }} className="flex-shrink-0">
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>

                <CollapsibleContent className="mt-2">
                  <div className="space-y-3">
                    {selectedHospitals.map((hospital, index) => (
                      <Card key={`${hospital.hospitalName}-${index}`}>
                         <CardHeader className="pb-2">
                           <div className="flex items-center justify-between">
                             <CardTitle className="text-sm font-medium">
                               Hospital {selectedHospitals.length > 1 ? `${index + 1}` : ''} Information
                             </CardTitle>
                             {isHospitalEditing && selectedHospitals.length > 1 && (
                               <Button 
                                 variant="ghost" 
                                 size="sm" 
                                 onClick={() => removeHospital(hospital.hospitalName)}
                                 className="text-destructive hover:text-destructive"
                               >
                                 <X className="h-4 w-4" />
                               </Button>
                             )}
                           </div>
                          {!hospital.isApproved && (
                            <Alert className="mt-2">
                              <AlertCircle className="h-4 w-4" />
                              <AlertDescription className="text-xs">
                                This hospital will be sent for approval before confirmation
                              </AlertDescription>
                            </Alert>
                          )}
                        </CardHeader>
                        <CardContent className="p-4 space-y-3 text-sm">
                          {isHospitalEditing ? (
                            <div className="space-y-3">
                              <div>
                                <label className="block text-xs font-medium text-muted-foreground mb-1">
                                  {formData.claimType === 'Reimbursement' && formData.claimSubType === 'Doctor consultation & Medicines (OPD)' 
                                    ? 'Hospital/ Clinic name'
                                    : formData.claimType === 'Reimbursement' && formData.claimSubType === 'Lab tests (OPD)'
                                    ? 'Diagnostic centre/ Lab name'
                                    : 'Hospital name'}
                                </label>
                                <div className="space-y-2">
                                  <div className="flex items-center gap-2">
                                    <div className="relative flex-1">
                                      <Input
                                        placeholder="Type to search hospital..."
                                        ref={(el) => { hospitalInputRefs.current[index] = el; }}
                                        className="text-xs"
                                        value={hospital.hospitalName ? hospital.hospitalName : hospitalSearchTerm}
                                        onChange={(e) => {
                                          const value = e.target.value;
                                          setHospitalSearchTerm(value);
                                          
                                          // Clear selected hospital when user starts editing
                                          if (hospital.hospitalName) {
                                            const updatedHospitals = [...selectedHospitals];
                                            updatedHospitals[index] = {
                                              ...updatedHospitals[index],
                                              hospitalName: '',
                                            };
                                            setSelectedHospitals(updatedHospitals);
                                          }
                                          
                                          // Open dropdown when typing, close when empty
                                          setHospitalSearchOpen({...hospitalSearchOpen, [index]: value.length > 0});
                                        }}
                                        onClick={() => {
                                          // If there's a selected hospital, prepare for editing
                                          if (hospital.hospitalName) {
                                            setHospitalSearchTerm(hospital.hospitalName);
                                            const updatedHospitals = [...selectedHospitals];
                                            updatedHospitals[index] = {
                                              ...updatedHospitals[index],
                                              hospitalName: '',
                                            };
                                            setSelectedHospitals(updatedHospitals);
                                          }
                                        }}
                                      />
                                    </div>
                                    <Button 
                                      variant={isAdvancedSearch ? "default" : "outline"}
                                      size="sm"
                                      onClick={() => {
                                        setIsAdvancedSearch(!isAdvancedSearch);
                                        if (isAdvancedSearch) {
                                          setAdvancedSearchFilters({ city: '', state: '', pincode: '' });
                                        }
                                      }}
                                      className="text-xs whitespace-nowrap"
                                    >
                                      Advanced
                                    </Button>
                                  </div>
                                  
                                  {isAdvancedSearch && (
                                    <div className="grid grid-cols-3 gap-2">
                                      <Input
                                        placeholder="City"
                                        className="text-xs"
                                        value={advancedSearchFilters.city}
                                        onChange={(e) => {
                                          setAdvancedSearchFilters(prev => ({ ...prev, city: e.target.value }));
                                          setHospitalSearchOpen({...hospitalSearchOpen, [index]: true});
                                        }}
                                      />
                                      <Input
                                        placeholder="State"
                                        className="text-xs"
                                        value={advancedSearchFilters.state}
                                        onChange={(e) => {
                                          setAdvancedSearchFilters(prev => ({ ...prev, state: e.target.value }));
                                          setHospitalSearchOpen({...hospitalSearchOpen, [index]: true});
                                        }}
                                      />
                                      <Input
                                        placeholder="Pincode"
                                        className="text-xs"
                                        value={advancedSearchFilters.pincode}
                                        onChange={(e) => {
                                          setAdvancedSearchFilters(prev => ({ ...prev, pincode: e.target.value }));
                                          setHospitalSearchOpen({...hospitalSearchOpen, [index]: true});
                                        }}
                                      />
                                    </div>
                                  )}
                                  
                                  <Popover 
                                    open={!!hospitalSearchOpen[index]} 
                                    onOpenChange={(open) => {
                                      setHospitalSearchOpen({...hospitalSearchOpen, [index]: open});
                                    }}
                                  >
                                    <PopoverContent
                                      className="w-full p-0"
                                      align="start"
                                      onInteractOutside={(e) => {
                                        const target = e.target as Node;
                                        const inputEl = hospitalInputRefs.current[index];
                                        if (inputEl && (target === inputEl || inputEl.contains(target))) {
                                          e.preventDefault();
                                        }
                                      }}
                                    >
                                      <Command shouldFilter={false}>
                                        <CommandList className="max-h-[200px]">
                                          {hospitalSearchTerm.length === 0 && !isAdvancedSearch ? (
                                            <div className="p-2 text-xs text-muted-foreground text-center">
                                              Start typing to search hospitals...
                                            </div>
                                           ) : hospitalData.filter(h => {
                                            const nameMatch = h.hospitalName.toLowerCase().includes(hospitalSearchTerm.toLowerCase());
                                            const cityMatch = !isAdvancedSearch || !advancedSearchFilters.city || 
                                              h.city?.toLowerCase().includes(advancedSearchFilters.city.toLowerCase());
                                            const stateMatch = !isAdvancedSearch || !advancedSearchFilters.state || 
                                              h.state?.toLowerCase().includes(advancedSearchFilters.state.toLowerCase());
                                            const pincodeMatch = !isAdvancedSearch || !advancedSearchFilters.pincode || 
                                              h.pincode?.includes(advancedSearchFilters.pincode);
                                            return nameMatch && cityMatch && stateMatch && pincodeMatch;
                                          }).length === 0 ? (
                                          <div 
                                            className="p-2 hover:bg-muted cursor-pointer text-xs"
                                            onClick={() => {
                                              // Pre-fill the dialog with search data
                                              setNewHospitalData({
                                                hospitalName: hospitalSearchTerm,
                                                hospitalLocation: advancedSearchFilters.city || '',
                                                networkType: 'Network',
                                                hospitalContact: '',
                                                hospitalAddress: '',
                                                city: advancedSearchFilters.city || '',
                                                state: advancedSearchFilters.state || '',
                                                pincode: advancedSearchFilters.pincode || '',
                                                rohini: ''
                                              });
                                              
                                              // Set which hospital index we're editing
                                              setEditingHospitalIndex(index);
                                              
                                              // Close the search dropdown
                                              setHospitalSearchOpen({...hospitalSearchOpen, [index]: false});
                                              
                                              // Open the add hospital dialog
                                              setIsAddHospitalDialogOpen(true);
                                            }}
                                          >
                                            <div className="flex items-center font-medium text-primary">
                                              <Plus className="h-4 w-4 mr-2" />
                                              Hospital not found - Add hospital
                                            </div>
                                          </div>
                                          ) : (
                                            <CommandGroup>
                                              {hospitalData
                                                .filter(h => {
                                                  const nameMatch = h.hospitalName.toLowerCase().includes(hospitalSearchTerm.toLowerCase());
                                                  const cityMatch = !isAdvancedSearch || !advancedSearchFilters.city || 
                                                    h.city?.toLowerCase().includes(advancedSearchFilters.city.toLowerCase());
                                                  const stateMatch = !isAdvancedSearch || !advancedSearchFilters.state || 
                                                    h.state?.toLowerCase().includes(advancedSearchFilters.state.toLowerCase());
                                                  const pincodeMatch = !isAdvancedSearch || !advancedSearchFilters.pincode || 
                                                    h.pincode?.includes(advancedSearchFilters.pincode);
                                                  const notAlreadySelected = !selectedHospitals.some(s => s.hospitalName === h.hospitalName) || h.hospitalName === hospital.hospitalName;
                                                  return nameMatch && cityMatch && stateMatch && pincodeMatch && notAlreadySelected;
                                                })
                                                .map((h) => (
                                              <CommandItem
                                                key={h.hospitalName}
                                                value={h.hospitalName}
                                                onSelect={() => {
                                                  const updatedHospitals = [...selectedHospitals];
                                                  updatedHospitals[index] = {
                                                    ...updatedHospitals[index],
                                                    hospitalName: h.hospitalName,
                                                    hospitalAddress: h.hospitalAddress,
                                                    hospitalLocation: h.hospitalLocation,
                                                    networkType: h.networkType,
                                                    hospitalContact: h.hospitalContact,
                                                    isApproved: h.isApproved
                                                  };
                                                  setSelectedHospitals(updatedHospitals);
                                                  setHospitalSearchOpen({...hospitalSearchOpen, [index]: false});
                                                  setHospitalSearchTerm('');
                                                }}
                                                className="text-xs"
                                              >
                                                <Check
                                                  className={cn(
                                                    "mr-2 h-4 w-4",
                                                    hospital.hospitalName === h.hospitalName ? "opacity-100" : "opacity-0"
                                                  )}
                                                />
                                                  <div>
                                                    <div className="font-medium">{h.hospitalName}</div>
                                                    <div className="text-muted-foreground">
                                                      {h.city}, {h.state} - {h.pincode}
                                                    </div>
                                                  </div>
                                              </CommandItem>
                                            ))}
                                          </CommandGroup>
                                        )}
                                      </CommandList>
                                      </Command>
                                    </PopoverContent>
                                  </Popover>
                                </div>
                              </div>
                              <div>
                                <label className="block text-xs font-medium text-muted-foreground mb-1">Address</label>
                                <Textarea
                                  value={hospital.hospitalAddress || ''}
                                  onChange={(e) => {
                                    const updatedHospitals = [...selectedHospitals];
                                    updatedHospitals[index] = { ...updatedHospitals[index], hospitalAddress: e.target.value };
                                    setSelectedHospitals(updatedHospitals);
                                  }}
                                  className="text-xs min-h-[60px]"
                                  placeholder="Enter address"
                                />
                              </div>
                              <div>
                                <label className="block text-xs font-medium text-muted-foreground mb-1">Network Status</label>
                                <Select 
                                  value={hospital.networkStatus || 'network'} 
                                  onValueChange={(value: 'network' | 'non-network' | 'excluded') => {
                                    const updatedHospitals = [...selectedHospitals];
                                    updatedHospitals[index] = { 
                                      ...updatedHospitals[index], 
                                      networkStatus: value,
                                      cashlessAnywhere: value === 'non-network' ? updatedHospitals[index].cashlessAnywhere : false
                                    };
                                    setSelectedHospitals(updatedHospitals);
                                  }}
                                  disabled
                                >
                                  <SelectTrigger className="text-xs h-8">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="network">Network</SelectItem>
                                    <SelectItem value="non-network">Non-Network</SelectItem>
                                    <SelectItem value="excluded">Excluded</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              {hospital.networkStatus === 'non-network' && (
                                <div className="flex items-center justify-between p-3 border rounded-md bg-muted/30">
                                  <div className="flex-1">
                                    <label className="text-xs font-medium">Cashless Anywhere</label>
                                    <p className="text-xs text-muted-foreground mt-0.5">Enable cashless treatment at this non-network hospital</p>
                                  </div>
                                  <Switch 
                                    checked={hospital.cashlessAnywhere || false}
                                    onCheckedChange={(checked) => {
                                      if (checked) {
                                        toast({
                                          title: "Cashless Anywhere Enabled",
                                          description: "Backend workflow has been initiated for cashless anywhere processing.",
                                        });
                                        // TODO: Trigger backend workflow here
                                        console.log('Initiating cashless anywhere workflow for hospital:', hospital.hospitalName);
                                      }
                                      const updatedHospitals = [...selectedHospitals];
                                      updatedHospitals[index] = { ...updatedHospitals[index], cashlessAnywhere: checked };
                                      setSelectedHospitals(updatedHospitals);
                                    }}
                                  />
                                </div>
                              )}
                            </div>
                          ) : (
                            <>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">
                                  {formData.claimType === 'Reimbursement' && formData.claimSubType === 'Doctor consultation & Medicines (OPD)' 
                                    ? 'Hospital/ Clinic:'
                                    : formData.claimType === 'Reimbursement' && formData.claimSubType === 'Lab tests (OPD)'
                                    ? 'Diagnostic centre/ Lab:'
                                    : 'Hospital:'}
                                </span>
                                <span className="font-medium">{hospital.hospitalName}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Address:</span>
                                <span className="font-medium text-xs">{hospital.hospitalAddress || 'N/A'}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Network Status:</span>
                                <div className="flex items-center gap-2">
                                  <Badge variant={
                                    hospital.networkStatus === 'network' ? 'default' : 
                                    hospital.networkStatus === 'excluded' ? 'destructive' : 
                                    'secondary'
                                  } className="text-xs">
                                    {hospital.networkStatus === 'network' ? 'Network' : 
                                     hospital.networkStatus === 'excluded' ? 'Excluded' : 
                                     'Non-Network'}
                                  </Badge>
                                  {hospital.networkStatus === 'non-network' && hospital.cashlessAnywhere && (
                                    <Badge variant="outline" className="text-xs border-green-500 text-green-700">
                                      Cashless Anywhere
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CollapsibleContent>
              </Collapsible>

              {/* Bank Account Details */}
              <Collapsible open={isBankDetailsOpen} onOpenChange={setIsBankDetailsOpen}>
                <div className="flex items-center space-x-2">
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="flex-1 justify-between">
                      <div className="flex items-center space-x-2">
                        <CreditCard className="h-4 w-4 text-primary" />
                        <span className="font-medium">Bank Account Details</span>
                      </div>
                      {isBankDetailsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  
                  {!isBankEditing ? (
                    <Button variant="outline" size="sm" onClick={() => setIsBankEditing(true)} className="flex-shrink-0">
                      <Edit className="h-4 w-4" />
                    </Button>
                  ) : (
                    <div className="flex items-center space-x-1">
                      <Button variant="outline" size="sm" onClick={() => setIsBankEditing(false)} className="flex-shrink-0">
                        <Save className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => setIsBankEditing(false)} className="flex-shrink-0">
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>

                <CollapsibleContent className="mt-2">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Bank Information</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Account Holder:</span>
                        <span className="font-medium">{formData.accountHolder}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Bank Name:</span>
                        <span className="font-medium">{formData.bankName}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Account No:</span>
                        {isBankEditing ? (
                          <Input 
                            value={formData.accountNo} 
                            onChange={(e) => handleInputChange('accountNo', e.target.value)}
                            className="w-32 h-8 text-right text-xs"
                            placeholder="Account number"
                          />
                        ) : (
                          <span className="font-medium text-xs">{formData.accountNo}</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </CollapsibleContent>
              </Collapsible>

              {/* Bill Line Items - Step 1 only, collapsed */}
              {currentStep === 1 && (
              <Collapsible open={isBillEntryOpen} onOpenChange={setIsBillEntryOpen}>
                <div className="flex items-center space-x-2">
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="flex-1 justify-between">
                      <div className="flex items-center space-x-2">
                        <Receipt className="h-4 w-4 text-primary" />
                        <span className="font-medium">Bill Line Items</span>
                      </div>
                      {isBillEntryOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                </div>
                
                <CollapsibleContent className="mt-2">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Bill Line Items</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 space-y-6">
                      {/* Section 1: Search and Add Category */}
                      <div className="space-y-4 border rounded-lg p-4 bg-muted/20">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <div className="h-2 w-2 rounded-full bg-primary"></div>
                            <Label className="text-sm font-semibold">Search and Add Category</Label>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="h-7 text-xs gap-1"
                            onClick={() => navigate('/hospital-tariff')}
                          >
                            <ExternalLink className="h-3 w-3" />
                            View Tariff
                          </Button>
                        </div>
                        
                        <div className="space-y-2">
                          <Label className="text-xs text-muted-foreground">Select Category/Subcategory</Label>
                          <Command className="border rounded-lg">
                            <CommandInput 
                              placeholder="Type to search categories..." 
                              value={categorySearchValue}
                              onValueChange={setCategorySearchValue}
                            />
                            {categorySearchValue && (
                              <CommandList>
                                <CommandEmpty>No category found.</CommandEmpty>
                                <CommandGroup>
                                  {getSearchOptions().map((option) => (
                                    <CommandItem
                                      key={option.value}
                                      value={option.label}
                                      onSelect={() => {
                                        handleCategorySelect(option.value);
                                        setCategorySearchValue("");
                                      }}
                                    >
                                      <Check
                                        className={cn(
                                          "mr-2 h-4 w-4",
                                          selectedBillItems.length > 0 && 
                                          selectedBillItems[selectedBillItems.length - 1].id === 'temp' &&
                                          selectedBillItems[selectedBillItems.length - 1].fullPath === option.value
                                            ? "opacity-100"
                                            : "opacity-0"
                                        )}
                                      />
                                      {option.label}
                                    </CommandItem>
                                  ))}
                                </CommandGroup>
                              </CommandList>
                            )}
                          </Command>
                        </div>

                        {/* Bill and Deduction Entry Form - Shows when a category is selected */}
                        {selectedBillItems.length > 0 && selectedBillItems[selectedBillItems.length - 1].id === 'temp' && (
                          <div className="space-y-4 border-t pt-4">
                            {/* Category Header */}
                            <div className="bg-muted/50 px-3 py-2 rounded-lg">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-medium">
                                  {selectedBillItems[selectedBillItems.length - 1].level1}
                                </span>
                                {selectedBillItems[selectedBillItems.length - 1].level2 && (
                                  <>
                                    <span className="text-muted-foreground">→</span>
                                    <span className="text-sm text-muted-foreground">
                                      {selectedBillItems[selectedBillItems.length - 1].level2}
                                    </span>
                                  </>
                                )}
                                {selectedBillItems[selectedBillItems.length - 1].level3 && (
                                  <>
                                    <span className="text-muted-foreground">→</span>
                                    <span className="text-sm text-muted-foreground">
                                      {selectedBillItems[selectedBillItems.length - 1].level3}
                                    </span>
                                  </>
                                )}
                              </div>
                            </div>
                            
<BillEntryExpandable 
  ref={billEntryRef}
  isExpanded={true}
  onToggle={() => {}}
  currentAmount={parseFloat(selectedBillItems[selectedBillItems.length - 1].payableAmount) || 0}
  onSave={handleSaveBillEntry}
  savedBills={tempSavedBills}
  savedDeductions={tempSavedDeductions}
  onUpdateBill={(billId, updatedBill) => {
    setTempSavedBills(prev => prev.map(bill => bill.id === billId ? updatedBill : bill));
  }}
  onDeleteBill={(billId) => {
    setTempSavedBills(prev => prev.filter(bill => bill.id !== billId));
  }}
  onUpdateDeduction={(deductionId, updatedDeduction) => {
    setTempSavedDeductions(prev => prev.map(ded => ded.id === deductionId ? updatedDeduction : ded));
  }}
  onDeleteDeduction={(deductionId) => {
    setTempSavedDeductions(prev => prev.filter(ded => ded.id !== deductionId));
  }}
/>
                            <div className="flex justify-end mt-2">
                              <Button size="sm" onClick={handleFinalSaveBillEntry} className="h-7">
                                Save Entry
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Section 2: Saved Entries */}
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className="h-2 w-2 rounded-full bg-primary"></div>
                            <Label className="text-sm font-semibold">Saved Entries</Label>
                          </div>
                          <Button variant="outline" size="sm" className="gap-1 h-7 text-xs" onClick={() => setSummaryModalOpen(true)}>
                            <Calculator className="h-3 w-3" />
                            View Summary
                          </Button>
                        </div>

                        {selectedBillItems.filter(item => item.id !== 'temp').length > 0 ? (
                          <div className="space-y-6">
                            {/* Group items by document */}
                            {(() => {
                              // Group bill items by documentId
                              const itemsByDocument = selectedBillItems
                                .filter(item => item.id !== 'temp')
                                .reduce((acc, item) => {
                                  const docId = item.documentId || 'unknown';
                                  if (!acc[docId]) {
                                    acc[docId] = {
                                      documentName: item.documentName || 'Unknown Document',
                                      items: []
                                    };
                                  }
                                  acc[docId].items.push(item);
                                  return acc;
                                }, {} as Record<string, { documentName: string; items: any[] }>);

                              return Object.entries(itemsByDocument).map(([docId, { documentName, items }]) => (
                                <div key={docId} className="space-y-3">
                                  {/* Document Header */}
                                  <div className="flex items-center gap-2 px-3 py-2 bg-primary/5 border border-primary/20 rounded-lg">
                                    <FileText className="h-4 w-4 text-primary" />
                                    <span className="text-sm font-semibold text-primary">{documentName}</span>
                                    <Badge variant="outline" className="ml-auto text-xs">
                                      {items.length} {items.length === 1 ? 'entry' : 'entries'}
                                    </Badge>
                                  </div>

                                  {/* Items under this document */}
                                  <Accordion type="single" collapsible className="w-full space-y-2">
                                    {items.map((item) => {
                                      const summary = getBillSummary(item.id);
                                      const eligibleData = getEligibleAmount(item.id);
                                      const discount = parseFloat(item.discount) || 0;
                                      const payable = eligibleData.eligible - discount;
                                      
                                      return (
                                        <AccordionItem key={item.id} value={item.id} className="border rounded-lg">
                                          <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-muted/50">
                                            <div className="flex items-center justify-between w-full pr-4">
                                              <div className="flex items-center space-x-3">
                                                <div className="flex items-center justify-center h-6 w-6 rounded-full bg-primary/10">
                                                  <span className="text-primary text-xs font-medium">+</span>
                                                </div>
                                                <span className="font-medium text-sm">{item.fullPath}</span>
                                              </div>
                                              <div className="flex items-center space-x-4">
                                                <Badge variant="secondary" className="text-xs">
                                                  ₹{Math.max(0, payable).toLocaleString()}
                                                </Badge>
                                              </div>
                                            </div>
                                          </AccordionTrigger>
                                          <AccordionContent className="px-4 pb-4">
                                            <div className="space-y-4 pt-2">
                                              {/* Summary Section */}
                                              <div className="grid grid-cols-2 gap-4 p-4 bg-muted/30 rounded-lg">
                                                <div className="space-y-3">
                                                  <div className="flex justify-between items-center">
                                                    <span className="text-xs text-muted-foreground">Bill Amount:</span>
                                                    <span className="text-sm font-medium">
                                                      {summary.totalBillAmount ? `₹${summary.totalBillAmount.toLocaleString()}` : '-'}
                                                    </span>
                                                  </div>
                                                  <div className="flex justify-between items-center">
                                                    <span className="text-xs text-muted-foreground">Deductions:</span>
                                                    <span className="text-sm font-medium">
                                                      {summary.totalDeductions ? `₹${summary.totalDeductions.toLocaleString()}` : '-'}
                                                    </span>
                                                  </div>
                                                  <div className="flex justify-between items-center">
                                                    <span className="text-xs text-muted-foreground">Post Deductions:</span>
                                                    <span className="text-sm font-medium">
                                                      {summary.billAmountPostDeductions ? `₹${summary.billAmountPostDeductions.toLocaleString()}` : '-'}
                                                    </span>
                                                  </div>
                                                </div>
                                                <div className="space-y-3">
                                                  <div className="flex justify-between items-center">
                                                    <span className="text-xs text-muted-foreground">Eligible:</span>
                                                    <span className="text-sm font-medium">₹{eligibleData.eligible.toLocaleString()}</span>
                                                  </div>
                                                  <div className="flex justify-between items-center">
                                                    <span className="text-xs text-muted-foreground">Discount:</span>
                                                    <Input
                                                      type="number"
                                                      value={item.discount}
                                                      onChange={(e) => handleBillItemChange(item.id, 'discount', e.target.value)}
                                                      className="h-7 w-24 text-xs text-right"
                                                    />
                                                  </div>
                                                  <div className="flex justify-between items-center pt-2 border-t">
                                                    <span className="text-xs font-semibold">Payable Amount:</span>
                                                    <span className="text-sm font-bold text-primary">
                                                      ₹{Math.max(0, payable).toLocaleString()}
                                                    </span>
                                                  </div>
                                                </div>
                                              </div>

                                              {/* Bill & Deduction Details */}
                                              <div className="space-y-3">
                                                <div className="flex items-center justify-between">
                                                  <span className="text-xs font-semibold text-muted-foreground">Bill & Deduction Details</span>
                                                  <Button
                                                    variant="outline"
                                                    size="sm"
                                                    onClick={() => handleToggleBillEntry(item.id)}
                                                    className="h-7"
                                                  >
                                                    {expandedBillEntries[item.id as any] ? 'Hide Details' : 'Show Details'}
                                          </Button>
                                        </div>

                                        {expandedBillEntries[item.id as any] && (
                                          <div className="border rounded-lg p-4 bg-background">
                                            <BillEntryExpandable 
                                              isExpanded={true}
                                              onToggle={() => handleToggleBillEntry(item.id)}
                                              currentAmount={parseFloat(item.payableAmount) || 0}
                                              savedBills={savedBillDetails[item.id]?.bills || []}
                                              savedDeductions={savedBillDetails[item.id]?.deductions || []}
                                              mode="edit"
                                              onDeleteBill={(billId) => {
                                                setSavedBillDetails(prev => ({
                                                  ...prev,
                                                  [item.id]: {
                                                    ...prev[item.id],
                                                    bills: prev[item.id]?.bills.filter(b => b.id !== billId) || []
                                                  }
                                                }));
                                                toast({
                                                  title: "Bill Deleted",
                                                  description: "The bill entry has been removed."
                                                });
                                              }}
                                              onDeleteDeduction={(deductionId) => {
                                                setSavedBillDetails(prev => ({
                                                  ...prev,
                                                  [item.id]: {
                                                    ...prev[item.id],
                                                    deductions: prev[item.id]?.deductions.filter(d => d.id !== deductionId) || []
                                                  }
                                                }));
                                                toast({
                                                  title: "Deduction Deleted",
                                                  description: "The deduction entry has been removed."
                                                });
                                              }}
                                              onUpdateBill={(billId, updatedBill) => {
                                                setSavedBillDetails(prev => ({
                                                  ...prev,
                                                  [item.id]: {
                                                    ...prev[item.id],
                                                    bills: prev[item.id]?.bills.map(b => b.id === billId ? updatedBill : b) || []
                                                  }
                                                }));
                                                toast({
                                                  title: "Bill Updated",
                                                  description: "The bill entry has been updated successfully."
                                                });
                                              }}
                                              onUpdateDeduction={(deductionId, updatedDeduction) => {
                                                setSavedBillDetails(prev => ({
                                                  ...prev,
                                                  [item.id]: {
                                                    ...prev[item.id],
                                                    deductions: prev[item.id]?.deductions.map(d => d.id === deductionId ? updatedDeduction : d) || []
                                                  }
                                                }));
                                                toast({
                                                  title: "Deduction Updated",
                                                  description: "The deduction entry has been updated successfully."
                                                });
                                              }}
                                            />
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  </AccordionContent>
                                </AccordionItem>
                              );
                            })}
                          </Accordion>
                        </div>
                      ));
                            })()}
                          </div>
                        ) : (
                          <div className="text-center py-8 text-muted-foreground border rounded-lg bg-muted/10">
                            <p className="text-sm">No saved entries yet. Add entries using the search above.</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </CollapsibleContent>
              </Collapsible>
              )}

              {/* Close the expanded view fragment */}
              </>
              )}

              {/* Clinical Details - Step 1 only (Disease Coding) */}
              {workflowStage === 'review' && currentStep === 1 && (
              <Collapsible open={isCodingOpen} onOpenChange={setIsCodingOpen}>
                <div className="flex items-center space-x-2">
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="flex-1 justify-between">
                      <div className="flex items-center space-x-2">
                        <ClipboardCheck className="h-4 w-4 text-primary" />
                        <span className="font-medium">Clinical Details</span>
                      </div>
                      <span className="text-lg font-medium leading-none">
                        {isCodingOpen ? "−" : "+"}
                      </span>
                    </Button>
                  </CollapsibleTrigger>
                </div>
                
                <CollapsibleContent className="mt-2 space-y-4">
                  
                  {/* MANDATORY SECTIONS - Always shown upfront */}
                  
                  {/* Disease Coding (ICD) - Mandatory */}
                  <Card>
                    <CardHeader className="pb-2">
                      <button
                        type="button"
                        className="flex w-full items-center justify-between text-left"
                        onClick={() => setOpenClinicalSection("diseaseCoding")}
                      >
                        <CardTitle className="text-sm">Disease Coding (ICD)</CardTitle>
                        <span className="text-lg font-medium leading-none">
                          {openClinicalSection === "diseaseCoding" ? "−" : "+"}
                        </span>
                      </button>
                    </CardHeader>
                    {openClinicalSection === "diseaseCoding" && (
                    <CardContent className="p-4 space-y-6">
                      {/* Line of Treatment */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Label className="text-sm font-semibold">Line of Treatment</Label>
                          <Badge variant="outline" className="text-xs">Required</Badge>
                          {getAiFieldState('lineOfTreatment')?.isAIFilled && (
                            <AIFilledIndicator 
                              confidence={getAiFieldState('lineOfTreatment')?.confidence || 0}
                              isModified={getAiFieldState('lineOfTreatment')?.isModified || false}
                            />
                          )}
                        </div>
                        <div className="flex flex-wrap gap-3">
                          {[
                            { value: 'surgical', label: 'Surgical' },
                            { value: 'daycare', label: 'Daycare' },
                            { value: 'medical', label: 'Medical' },
                          ].map((option) => (
                            <button
                              key={option.value}
                              type="button"
                              onClick={() => {
                                setLineOfTreatment(option.value);
                                markFieldAsModified('lineOfTreatment');
                              }}
                              className={cn(
                                "inline-flex items-center gap-2 px-4 py-2 rounded-md border text-sm transition-colors",
                                lineOfTreatment === option.value
                                  ? "bg-primary text-primary-foreground border-primary"
                                  : "bg-background border-border hover:bg-muted"
                              )}
                            >
                              <div className={cn(
                                "w-4 h-4 rounded-full border-2 flex items-center justify-center",
                                lineOfTreatment === option.value
                                  ? "border-primary-foreground"
                                  : "border-muted-foreground"
                              )}>
                                {lineOfTreatment === option.value && (
                                  <div className="w-2 h-2 rounded-full bg-primary-foreground" />
                                )}
                              </div>
                              {option.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Accident */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Label className="text-sm font-semibold">Accident</Label>
                          {getAiFieldState('accident')?.isAIFilled && (
                            <AIFilledIndicator 
                              confidence={getAiFieldState('accident')?.confidence || 0}
                              isModified={getAiFieldState('accident')?.isModified || false}
                            />
                          )}
                        </div>
                        <div className="flex flex-wrap gap-3">
                          {[
                            { value: 'Yes', label: 'Yes' },
                            { value: 'No', label: 'No' },
                          ].map((option) => (
                            <button
                              key={option.value}
                              type="button"
                              onClick={() => {
                                setInvestigations((prev) => ({
                                  ...prev,
                                  accident: option.value,
                                }));
                                markFieldAsModified('accident');
                              }}
                              className={cn(
                                "inline-flex items-center gap-2 px-4 py-2 rounded-md border text-sm transition-colors",
                                investigations.accident === option.value
                                  ? "bg-primary text-primary-foreground border-primary"
                                  : "bg-background border-border hover:bg-muted"
                              )}
                            >
                              <div className={cn(
                                "w-4 h-4 rounded-full border-2 flex items-center justify-center",
                                investigations.accident === option.value
                                  ? "border-primary-foreground"
                                  : "border-muted-foreground"
                              )}>
                                {investigations.accident === option.value && (
                                  <div className="w-2 h-2 rounded-full bg-primary-foreground" />
                                )}
                              </div>
                              {option.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Diagnosis */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Label className="text-sm font-semibold">Diagnosis</Label>
                          {getAiFieldState('diagnosis')?.isAIFilled && (
                            <AIFilledIndicator 
                              confidence={getAiFieldState('diagnosis')?.confidence || 0}
                              isModified={getAiFieldState('diagnosis')?.isModified || false}
                            />
                          )}
                        </div>
                        <AIFilledFieldWrapper
                          isAIFilled={getAiFieldState('diagnosis')?.isAIFilled && !getAiFieldState('diagnosis')?.isModified}
                          confidence={getAiFieldState('diagnosis')?.confidence || 0}
                          isModified={getAiFieldState('diagnosis')?.isModified || false}
                        >
                          <Textarea
                            placeholder="Enter diagnosis details..."
                            value={diagnosis}
                            onChange={(e) => {
                              setDiagnosis(e.target.value);
                              markFieldAsModified('diagnosis');
                            }}
                            className="min-h-[60px] resize-none"
                          />
                        </AIFilledFieldWrapper>
                      </div>

                      {/* Primary Disease Section */}
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Label className="text-sm font-semibold">Primary Disease</Label>
                          <Badge variant="outline" className="text-xs">Required</Badge>
                          {getAiFieldState('primaryDisease')?.isAIFilled && (
                            <AIFilledIndicator 
                              confidence={getAiFieldState('primaryDisease')?.confidence || 0}
                              isModified={getAiFieldState('primaryDisease')?.isModified || false}
                            />
                          )}
                        </div>

                        <div className="space-y-2">
                          <Popover open={openPrimarySearch} onOpenChange={setOpenPrimarySearch}>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                role="combobox"
                                aria-expanded={openPrimarySearch}
                                className="w-full justify-between"
                              >
                                <span
                                  className={
                                    primaryDiseaseCode ? "text-foreground" : "text-muted-foreground"
                                  }
                                >
                                  {primaryDiseaseCode
                                    ? `${primaryDiseaseCode.icd1.split('(')[0].trim()} → ${primaryDiseaseCode.icd2
                                        .split('(')[0]
                                        .trim()}`
                                    : "Search by disease name or ICD code..."}
                                </span>
                                <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-[500px] p-0" align="start">
                              <Command>
                                <CommandInput
                                  placeholder="Type disease name or code..."
                                  value={primarySearchTerm}
                                  onValueChange={setPrimarySearchTerm}
                                />
                                <CommandList>
                                  <CommandEmpty>No disease codes found.</CommandEmpty>
                                  <CommandGroup heading="ICD Codes">
                                    {icdData
                                      .filter((item) => {
                                        const search = primarySearchTerm.toLowerCase();
                                        return (
                                          item.icd1.toLowerCase().includes(search) ||
                                          item.icd2.toLowerCase().includes(search) ||
                                          item.icd3.toLowerCase().includes(search)
                                        );
                                      })
                                      .map((item, index) => (
                                        <CommandItem
                                          key={index}
                                          value={`${item.icd1} -> ${item.icd2} -> ${item.icd3}`}
                                          onSelect={() => {
                                            setPrimaryDiseaseCode(item);
                                            markFieldAsModified('primaryDisease');
                                            // Auto-populate SNOMED code based on ICD selection
                                            const matchedSnomed = getSnomedFromIcd(item);
                                            if (matchedSnomed) {
                                              setSnomedCode(matchedSnomed);
                                            }
                                            setOpenPrimarySearch(false);
                                            setPrimarySearchTerm('');
                                            toast({
                                              title: "Primary Disease Set",
                                              description: matchedSnomed 
                                                ? "Primary disease and SNOMED code have been set."
                                                : "Primary disease code has been set successfully.",
                                            });
                                          }}
                                          className="flex flex-col items-start py-3 cursor-pointer"
                                        >
                                          <div className="text-xs text-muted-foreground font-medium mb-1">
                                            ICD1 → ICD2 → ICD3
                                          </div>
                                          <div className="text-sm">
                                            {item.icd1.split('(')[0].trim()} → {item.icd2
                                              .split('(')[0]
                                              .trim()} → {item.icd3.split('(')[0].trim()}
                                          </div>
                                          <div className="text-xs text-muted-foreground mt-1">
                                            {item.icd1.match(/\(([^)]+)\)/)?.[1]} →{' '}
                                            {item.icd2.match(/\(([^)]+)\)/)?.[1]} →{' '}
                                            {item.icd3.match(/\(([^)]+)\)/)?.[1]}
                                          </div>
                                        </CommandItem>
                                      ))}
                                  </CommandGroup>
                                </CommandList>
                              </Command>
                            </PopoverContent>
                          </Popover>

                          {primaryDiseaseCode && (
                            <Card className={cn(
                              "border-primary/40 bg-primary/5",
                              getAiFieldState('primaryDisease')?.isAIFilled && !getAiFieldState('primaryDisease')?.isModified && "ring-2 ring-green-300 ring-offset-1"
                            )}>
                              <CardContent className="p-3">
                                <div className="flex items-start justify-between gap-2">
                                  <div className="flex-1 space-y-1 text-xs">
                                    <div className="font-medium text-primary">
                                      ICD1: {primaryDiseaseCode.icd1}
                                    </div>
                                    <div className="text-muted-foreground pl-4">
                                      ICD2: {primaryDiseaseCode.icd2}
                                    </div>
                                    <div className="text-muted-foreground pl-8">
                                      ICD3: {primaryDiseaseCode.icd3}
                                    </div>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-6 w-6 p-0"
                                    onClick={() => {
                                      setPrimaryDiseaseCode(null);
                                      markFieldAsModified('primaryDisease');
                                      toast({
                                        title: "Primary Disease Removed",
                                        description: "Primary disease code has been removed.",
                                      });
                                    }}
                                  >
                                    <X className="h-3 w-3" />
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          )}
                        </div>
                      </div>

                      {/* Maternity Toggle */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label htmlFor="maternity-checkbox" className="text-sm font-semibold cursor-pointer">Maternity</Label>
                          <Checkbox
                            id="maternity-checkbox"
                            checked={isMaternityCase}
                            onCheckedChange={(checked) => setIsMaternityCase(checked === true)}
                            className="rounded-none h-5 w-5"
                          />
                        </div>
                        
                        {isMaternityCase && (
                          <div className="grid gap-4 grid-cols-2 p-4 border rounded-lg bg-muted/30">
                            {/* Date of Delivery */}
                            <div className="space-y-2">
                              <Label className="text-sm">Date of Delivery</Label>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button
                                    variant="outline"
                                    className={cn(
                                      "w-full justify-start text-left font-normal",
                                      !dateOfDelivery && "text-muted-foreground"
                                    )}
                                  >
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {dateOfDelivery ? format(dateOfDelivery, "PPP") : <span>Select date</span>}
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                  <Calendar
                                    mode="single"
                                    selected={dateOfDelivery}
                                    onSelect={setDateOfDelivery}
                                    initialFocus
                                    className={cn("p-3 pointer-events-auto")}
                                  />
                                </PopoverContent>
                              </Popover>
                            </div>
                            
                            {/* G, P, L, A */}
                            <div className="space-y-1.5">
                              <Label className="text-sm">G, P, L, A</Label>
                              <div className="flex gap-2">
                                <div className="flex-1">
                                  <div className="relative">
                                    <span className="absolute left-2 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-medium">G</span>
                                    <Input
                                      className="pl-6 h-9 text-center"
                                      placeholder="0"
                                      value={gravida}
                                      onChange={(e) => setGravida(e.target.value)}
                                    />
                                  </div>
                                </div>
                                <div className="flex-1">
                                  <div className="relative">
                                    <span className="absolute left-2 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-medium">P</span>
                                    <Input
                                      className="pl-6 h-9 text-center"
                                      placeholder="0"
                                      value={para}
                                      onChange={(e) => setPara(e.target.value)}
                                    />
                                  </div>
                                </div>
                                <div className="flex-1">
                                  <div className="relative">
                                    <span className="absolute left-2 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-medium">L</span>
                                    <Input
                                      className="pl-6 h-9 text-center"
                                      placeholder="0"
                                      value={living}
                                      onChange={(e) => setLiving(e.target.value)}
                                    />
                                  </div>
                                </div>
                                <div className="flex-1">
                                  <div className="relative">
                                    <span className="absolute left-2 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-medium">A</span>
                                    <Input
                                      className="pl-6 h-9 text-center"
                                      placeholder="0"
                                      value={abortions}
                                      onChange={(e) => setAbortions(e.target.value)}
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Secondary Disease Section */}
                      {!showSecondaryDisease ? (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-fit"
                          onClick={() => setShowSecondaryDisease(true)}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Secondary Disease
                          <Badge variant="outline" className="text-xs ml-2">Optional</Badge>
                        </Button>
                      ) : (
                        <div className="space-y-3 p-4 border border-dashed border-border rounded-lg">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Label className="text-sm font-semibold">Secondary Disease</Label>
                              <Badge variant="outline" className="text-xs">Optional</Badge>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              onClick={() => {
                                setShowSecondaryDisease(false);
                                setSecondaryDiseaseCodes([]);
                                setSecondarySnomedCode(null);
                              }}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>

                          <div className="grid gap-3 grid-cols-[repeat(auto-fit,minmax(260px,1fr))]">
                            {/* Secondary Disease ICD column */}
                            <div className="space-y-2">
                              <Popover open={openSecondarySearch} onOpenChange={setOpenSecondarySearch}>
                                <PopoverTrigger asChild>
                                  <Button
                                    variant="outline"
                                    role="combobox"
                                    aria-expanded={openSecondarySearch}
                                    className="w-full justify-between"
                                  >
                                    <span className="text-muted-foreground">
                                      Search by disease name or ICD code...
                                    </span>
                                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-[500px] p-0" align="start">
                                  <Command>
                                    <CommandInput
                                      placeholder="Type disease name or code..."
                                      value={secondarySearchTerm}
                                      onValueChange={setSecondarySearchTerm}
                                    />
                                    <CommandList>
                                      <CommandEmpty>No disease codes found.</CommandEmpty>
                                      <CommandGroup heading="ICD Codes">
                                        {icdData
                                          .filter((item) => {
                                            const search = secondarySearchTerm.toLowerCase();
                                            return (
                                              item.icd1.toLowerCase().includes(search) ||
                                              item.icd2.toLowerCase().includes(search) ||
                                              item.icd3.toLowerCase().includes(search)
                                            );
                                          })
                                          .map((item, index) => (
                                            <CommandItem
                                              key={index}
                                              value={`${item.icd1} -> ${item.icd2} -> ${item.icd3}`}
                                              onSelect={() => {
                                                setSecondaryDiseaseCodes([...secondaryDiseaseCodes, item]);
                                                // Auto-populate SNOMED code based on ICD selection
                                                const matchedSnomed = getSnomedFromIcd(item);
                                                if (matchedSnomed) {
                                                  setSecondarySnomedCode(matchedSnomed);
                                                }
                                                setOpenSecondarySearch(false);
                                                setSecondarySearchTerm('');
                                                toast({
                                                  title: "Secondary Disease Added",
                                                  description: matchedSnomed
                                                    ? "Secondary disease and SNOMED code have been set."
                                                    : "Secondary disease code has been added successfully.",
                                                });
                                              }}
                                              className="flex flex-col items-start py-3 cursor-pointer"
                                            >
                                              <div className="text-xs text-muted-foreground font-medium mb-1">
                                                ICD1 → ICD2 → ICD3
                                              </div>
                                              <div className="text-sm">
                                                {item.icd1.split('(')[0].trim()} → {item.icd2
                                                  .split('(')[0]
                                                  .trim()} → {item.icd3.split('(')[0].trim()}
                                              </div>
                                              <div className="text-xs text-muted-foreground mt-1">
                                                {item.icd1.match(/\(([^)]+)\)/)?.[1]} →{' '}
                                                {item.icd2.match(/\(([^)]+)\)/)?.[1]} →{' '}
                                                {item.icd3.match(/\(([^)]+)\)/)?.[1]}
                                              </div>
                                            </CommandItem>
                                          ))}
                                      </CommandGroup>
                                    </CommandList>
                                  </Command>
                                </PopoverContent>
                              </Popover>

                              {secondaryDiseaseCodes.length > 0 && (
                                <div className="space-y-2">
                                  {secondaryDiseaseCodes.map((code, index) => (
                                    <Card key={index} className="border-primary/20">
                                      <CardContent className="p-3">
                                        <div className="flex items-start justify-between gap-2">
                                          <div className="flex-1 space-y-1 text-xs">
                                            <div className="font-medium text-primary">ICD1: {code.icd1}</div>
                                            <div className="text-muted-foreground pl-4">ICD2: {code.icd2}</div>
                                            <div className="text-muted-foreground pl-8">ICD3: {code.icd3}</div>
                                          </div>
                                          <Button
                                            variant="ghost"
                                            size="sm"
                                            className="h-6 w-6 p-0"
                                            onClick={() => {
                                              setSecondaryDiseaseCodes(
                                                secondaryDiseaseCodes.filter((_, i) => i !== index),
                                              );
                                              toast({
                                                title: "Secondary Disease Removed",
                                                description: "Secondary disease code has been removed.",
                                              });
                                            }}
                                          >
                                            <X className="h-3 w-3" />
                                          </Button>
                                        </div>
                                      </CardContent>
                                    </Card>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Secondary Disease SNOMED column */}
                            <div className="space-y-2">
                              <div className="space-y-1">
                                <Label className="text-xs text-muted-foreground">
                                  SNOMED code (optional)
                                </Label>
                                <Popover
                                  open={openSecondarySnomedSearch}
                                  onOpenChange={setOpenSecondarySnomedSearch}
                                >
                                  <PopoverTrigger asChild>
                                    <Button
                                      variant="outline"
                                      role="combobox"
                                      aria-expanded={openSecondarySnomedSearch}
                                      className="w-full justify-between"
                                    >
                                      <span
                                        className={
                                          secondarySnomedCode ? "text-foreground" : "text-muted-foreground"
                                        }
                                      >
                                        {secondarySnomedCode
                                          ? `${secondarySnomedCode.code} - ${secondarySnomedCode.name}`
                                          : "Search by SNOMED name or code..."}
                                      </span>
                                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                    </Button>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-[500px] p-0" align="start">
                                    <Command>
                                      <CommandInput
                                        placeholder="Type SNOMED name or code..."
                                        value={secondarySnomedSearchTerm}
                                        onValueChange={setSecondarySnomedSearchTerm}
                                      />
                                      <CommandList>
                                        <CommandEmpty>No SNOMED concepts found.</CommandEmpty>
                                        <CommandGroup heading="SNOMED Concepts">
                                          {snomedData
                                            .filter((item) => {
                                              const search = secondarySnomedSearchTerm.toLowerCase();
                                              return (
                                                item.code.toLowerCase().includes(search) ||
                                                item.name.toLowerCase().includes(search)
                                              );
                                            })
                                            .map((item) => (
                                              <CommandItem
                                                key={item.code}
                                                value={`${item.code} ${item.name}`}
                                                onSelect={() => {
                                                  setSecondarySnomedCode(item);
                                                  setOpenSecondarySnomedSearch(false);
                                                  setSecondarySnomedSearchTerm('');
                                                  toast({
                                                    title: "Secondary SNOMED Set",
                                                    description:
                                                      "Secondary disease SNOMED code has been set successfully.",
                                                  });
                                                }}
                                                className="flex flex-col items-start py-3 cursor-pointer"
                                              >
                                                <div className="text-sm font-medium">{item.code}</div>
                                                <div className="text-xs text-muted-foreground">{item.name}</div>
                                              </CommandItem>
                                            ))}
                                        </CommandGroup>
                                      </CommandList>
                                    </Command>
                                  </PopoverContent>
                                </Popover>
                              </div>

                              {secondarySnomedCode && (
                                <Card className="border-primary/20">
                                  <CardContent className="p-3">
                                    <div className="flex items-start justify-between gap-2">
                                      <div className="flex-1 space-y-1 text-xs">
                                        <div className="font-medium text-primary">
                                          {secondarySnomedCode.code}
                                        </div>
                                        <div className="text-muted-foreground">
                                          {secondarySnomedCode.name}
                                        </div>
                                      </div>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        className="h-6 w-6 p-0"
                                        onClick={() => {
                                          setSecondarySnomedCode(null);
                                          toast({
                                            title: "Secondary SNOMED Removed",
                                            description:
                                              "Secondary disease SNOMED code has been removed.",
                                          });
                                        }}
                                      >
                                        <X className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  </CardContent>
                                </Card>
                              )}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Co-morbidities Section */}
                      {!showCoMorbidities ? (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-fit"
                          onClick={() => setShowCoMorbidities(true)}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Co-morbidities
                          <Badge variant="outline" className="text-xs ml-2">Optional</Badge>
                        </Button>
                      ) : (
                        <div className="space-y-3 p-4 border border-dashed border-border rounded-lg">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Label className="text-sm font-semibold">Co-morbidities</Label>
                              <Badge variant="outline" className="text-xs">Optional</Badge>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              onClick={() => {
                                setShowCoMorbidities(false);
                                setCoMorbidityCodes([]);
                                setCoMorbiditySnomedCode(null);
                              }}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>

                          <div className="grid gap-3 grid-cols-[repeat(auto-fit,minmax(260px,1fr))]">
                            {/* Co-morbidities ICD column */}
                            <div className="space-y-2">
                              <Popover open={openComorbiditySearch} onOpenChange={setOpenComorbiditySearch}>
                                <PopoverTrigger asChild>
                                  <Button
                                    variant="outline"
                                    role="combobox"
                                    aria-expanded={openComorbiditySearch}
                                    className="w-full justify-between"
                                  >
                                    <span className="text-muted-foreground">
                                      Search by disease name or ICD code...
                                    </span>
                                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-[500px] p-0" align="start">
                                  <Command>
                                    <CommandInput
                                      placeholder="Type disease name or code..."
                                      value={comorbiditySearchTerm}
                                      onValueChange={setComorbiditySearchTerm}
                                    />
                                    <CommandList>
                                      <CommandEmpty>No disease codes found.</CommandEmpty>
                                      <CommandGroup heading="ICD Codes">
                                        {icdData
                                          .filter((item) => {
                                            const search = comorbiditySearchTerm.toLowerCase();
                                            return (
                                              item.icd1.toLowerCase().includes(search) ||
                                              item.icd2.toLowerCase().includes(search) ||
                                              item.icd3.toLowerCase().includes(search)
                                            );
                                          })
                                          .map((item, index) => (
                                            <CommandItem
                                              key={index}
                                              value={`${item.icd1} -> ${item.icd2} -> ${item.icd3}`}
                                              onSelect={() => {
                                                setCoMorbidityCodes([...coMorbidityCodes, item]);
                                                // Auto-populate SNOMED code based on ICD selection
                                                const matchedSnomed = getSnomedFromIcd(item);
                                                if (matchedSnomed) {
                                                  setCoMorbiditySnomedCode(matchedSnomed);
                                                }
                                                setOpenComorbiditySearch(false);
                                                setComorbiditySearchTerm('');
                                                toast({
                                                  title: "Co-morbidity Added",
                                                  description: matchedSnomed
                                                    ? "Co-morbidity and SNOMED code have been set."
                                                    : "Co-morbidity code has been added successfully.",
                                                });
                                              }}
                                              className="flex flex-col items-start py-3 cursor-pointer"
                                            >
                                              <div className="text-xs text-muted-foreground font-medium mb-1">
                                                ICD1 → ICD2 → ICD3
                                              </div>
                                              <div className="text-sm">
                                                {item.icd1.split('(')[0].trim()} → {item.icd2
                                                  .split('(')[0]
                                                  .trim()} → {item.icd3.split('(')[0].trim()}
                                              </div>
                                              <div className="text-xs text-muted-foreground mt-1">
                                                {item.icd1.match(/\(([^)]+)\)/)?.[1]} →{' '}
                                                {item.icd2.match(/\(([^)]+)\)/)?.[1]} →{' '}
                                                {item.icd3.match(/\(([^)]+)\)/)?.[1]}
                                              </div>
                                            </CommandItem>
                                          ))}
                                      </CommandGroup>
                                    </CommandList>
                                  </Command>
                                </PopoverContent>
                              </Popover>

                              {coMorbidityCodes.length > 0 && (
                                <div className="space-y-2">
                                  {coMorbidityCodes.map((code, index) => (
                                    <Card key={index} className="border-primary/20">
                                      <CardContent className="p-3">
                                        <div className="flex items-start justify-between gap-2">
                                          <div className="flex-1 space-y-1 text-xs">
                                            <div className="font-medium text-primary">ICD1: {code.icd1}</div>
                                            <div className="text-muted-foreground pl-4">ICD2: {code.icd2}</div>
                                            <div className="text-muted-foreground pl-8">ICD3: {code.icd3}</div>
                                          </div>
                                          <Button
                                            variant="ghost"
                                            size="sm"
                                            className="h-6 w-6 p-0"
                                            onClick={() => {
                                              setCoMorbidityCodes(
                                                coMorbidityCodes.filter((_, i) => i !== index),
                                              );
                                              toast({
                                                title: "Co-morbidity Removed",
                                                description: "Co-morbidity code has been removed.",
                                              });
                                            }}
                                          >
                                            <X className="h-3 w-3" />
                                          </Button>
                                        </div>
                                      </CardContent>
                                    </Card>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Co-morbidities SNOMED column */}
                            <div className="space-y-2">
                              <div className="space-y-1">
                                <Label className="text-xs text-muted-foreground">
                                  SNOMED code (optional)
                                </Label>
                                <Popover
                                  open={openCoMorbiditySnomedSearch}
                                  onOpenChange={setOpenCoMorbiditySnomedSearch}
                                >
                                  <PopoverTrigger asChild>
                                    <Button
                                      variant="outline"
                                      role="combobox"
                                      aria-expanded={openCoMorbiditySnomedSearch}
                                      className="w-full justify-between"
                                    >
                                      <span
                                        className={
                                          coMorbiditySnomedCode ? "text-foreground" : "text-muted-foreground"
                                        }
                                      >
                                        {coMorbiditySnomedCode
                                          ? `${coMorbiditySnomedCode.code} - ${coMorbiditySnomedCode.name}`
                                          : "Search by SNOMED name or code..."}
                                      </span>
                                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                    </Button>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-[500px] p-0" align="start">
                                    <Command>
                                      <CommandInput
                                        placeholder="Type SNOMED name or code..."
                                        value={coMorbiditySnomedSearchTerm}
                                        onValueChange={setCoMorbiditySnomedSearchTerm}
                                      />
                                      <CommandList>
                                        <CommandEmpty>No SNOMED concepts found.</CommandEmpty>
                                        <CommandGroup heading="SNOMED Concepts">
                                          {snomedData
                                            .filter((item) => {
                                              const search = coMorbiditySnomedSearchTerm.toLowerCase();
                                              return (
                                                item.code.toLowerCase().includes(search) ||
                                                item.name.toLowerCase().includes(search)
                                              );
                                            })
                                            .map((item) => (
                                              <CommandItem
                                                key={item.code}
                                                value={`${item.code} ${item.name}`}
                                                onSelect={() => {
                                                  setCoMorbiditySnomedCode(item);
                                                  setOpenCoMorbiditySnomedSearch(false);
                                                  setCoMorbiditySnomedSearchTerm('');
                                                  toast({
                                                    title: "Co-morbidity SNOMED Set",
                                                    description:
                                                      "Co-morbidity SNOMED code has been set successfully.",
                                                  });
                                                }}
                                                className="flex flex-col items-start py-3 cursor-pointer"
                                              >
                                                <div className="text-sm font-medium">{item.code}</div>
                                                <div className="text-xs text-muted-foreground">{item.name}</div>
                                              </CommandItem>
                                            ))}
                                        </CommandGroup>
                                      </CommandList>
                                    </Command>
                                  </PopoverContent>
                                </Popover>
                              </div>

                              {coMorbiditySnomedCode && (
                                <Card className="border-primary/20">
                                  <CardContent className="p-3">
                                    <div className="flex items-start justify-between gap-2">
                                      <div className="flex-1 space-y-1 text-xs">
                                        <div className="font-medium text-primary">
                                          {coMorbiditySnomedCode.code}
                                        </div>
                                        <div className="text-muted-foreground">
                                          {coMorbiditySnomedCode.name}
                                        </div>
                                      </div>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        className="h-6 w-6 p-0"
                                        onClick={() => {
                                          setCoMorbiditySnomedCode(null);
                                          toast({
                                            title: "Co-morbidity SNOMED Removed",
                                            description:
                                              "Co-morbidity SNOMED code has been removed.",
                                          });
                                        }}
                                      >
                                        <X className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  </CardContent>
                                </Card>
                              )}
                            </div>
                          </div>
                        </div>
                      )}

                    </CardContent>
                    )}
                  </Card>



                </CollapsibleContent>
              </Collapsible>
              )}

              {/* Procedure Details (expanded) + Additional Details (collapsed) - Now in Step 1 */}
              {workflowStage === 'review' && currentStep === 1 && (
              <div className="space-y-4">
                {/* Procedure Details Card - Expanded */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <ClipboardCheck className="h-4 w-4 text-primary" />
                      Procedure Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 space-y-4">
                    {/* Multiple Procedures */}
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-semibold">Procedures</Label>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={addProcedure}
                          className="h-8"
                        >
                          <Plus className="h-4 w-4 mr-1" />
                          Add Procedure
                        </Button>
                      </div>

                      {procedures.map((procedure, idx) => (
                        <div 
                          key={idx} 
                          className={cn(
                            "border rounded-lg p-3 space-y-3 relative",
                            procedure.isAIFilled && !procedure.isModified && "ring-2 ring-amber-300 ring-offset-1"
                          )}
                        >
                          {procedures.length > 1 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeProcedure(idx)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          )}
                          <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground mb-2">
                            Procedure {idx + 1}
                            {procedure.isAIFilled && (
                              <AIFilledIndicator 
                                confidence={procedure.aiConfidence || 0}
                                isModified={procedure.isModified || false}
                              />
                            )}
                          </div>
                          <div className="grid gap-3 md:grid-cols-2">
                            <div className="space-y-1">
                              <Label className="text-sm font-semibold">Procedure code (PCS)</Label>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button
                                    variant="outline"
                                    role="combobox"
                                    className="w-full justify-between"
                                  >
                                    <span className={procedure.pcsCode ? "text-foreground" : "text-muted-foreground"}>
                                      {procedure.pcsCode || "Search and select procedure code"}
                                    </span>
                                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-[480px] p-0" align="start">
                                  <Command>
                                    <CommandInput placeholder="Type procedure name or code..." />
                                    <CommandList>
                                      <CommandEmpty>No procedure codes found.</CommandEmpty>
                                      <CommandGroup heading="Procedure Codes">
                                        {procedureData.map((item, index) => (
                                          <CommandItem
                                            key={index}
                                            value={`${item.code} ${item.name}`}
                                            onSelect={() =>
                                              updateProcedure(idx, 'pcsCode', `${item.code} - ${item.name}`)
                                            }
                                            className="flex flex-col items-start py-3 cursor-pointer"
                                          >
                                            <div className="text-sm font-medium">{item.code}</div>
                                            <div className="text-xs text-muted-foreground">{item.name}</div>
                                          </CommandItem>
                                        ))}
                                      </CommandGroup>
                                    </CommandList>
                                  </Command>
                                </PopoverContent>
                              </Popover>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* More details - Collapsible section */}
                    <Collapsible defaultOpen={false}>
                      <CollapsibleTrigger className="flex items-center justify-between w-full py-2 text-sm font-semibold hover:bg-muted/50 rounded-md px-2 transition-colors">
                        <span>More details</span>
                        <ChevronDown className="h-4 w-4 transition-transform duration-200 [[data-state=open]>&]:rotate-180" />
                      </CollapsibleTrigger>
                      <CollapsibleContent className="space-y-4 pt-2">
                        {/* Anesthesia details */}
                        <div className="space-y-2">
                          <Label className="text-sm font-semibold">Anesthesia details</Label>
                          <Popover open={openAnesthesiaSearch} onOpenChange={setOpenAnesthesiaSearch}>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                role="combobox"
                                className="w-full justify-between"
                              >
                                <span className="text-muted-foreground">
                                  Search and select anesthesia type
                                </span>
                                <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-[400px] p-0" align="start">
                              <Command>
                                <CommandInput placeholder="Search anesthesia types..." />
                                <CommandList>
                                  <CommandEmpty>No options found.</CommandEmpty>
                                  <CommandGroup heading="Anesthesia Types">
                                    {anesthesiaOptions
                                      .filter((opt) => !selectedAnesthesia.some((a) => a.option === opt))
                                      .map((opt) => (
                                        <CommandItem
                                          key={opt}
                                          value={opt}
                                          onSelect={() => addAnesthesia(opt)}
                                        >
                                          <Plus className="mr-2 h-4 w-4" />
                                          {opt}
                                        </CommandItem>
                                      ))}
                                  </CommandGroup>
                                </CommandList>
                              </Command>
                            </PopoverContent>
                          </Popover>

                          {selectedAnesthesia.length > 0 && (
                            <div className="space-y-2 mt-2">
                              {selectedAnesthesia.map((item) => (
                                <div key={item.option} className="flex items-start gap-2 p-2 border rounded-md bg-muted/30">
                                  <div className="flex-1">
                                    <div className="flex items-center justify-between">
                                      <span className="text-sm font-medium">{item.option}</span>
                                      <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        className="h-6 w-6"
                                        onClick={() => removeAnesthesia(item.option)}
                                      >
                                        <X className="h-4 w-4" />
                                      </Button>
                                    </div>
                                    {item.option === "Others" && (
                                      <Input
                                        placeholder="Enter custom anesthesia details"
                                        value={item.customValue || ""}
                                        onChange={(e) => updateAnesthesiaCustomValue(item.option, e.target.value)}
                                        className="mt-2"
                                      />
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Implants / Devices Used */}
                        <div className="space-y-2">
                          <Label className="text-sm font-semibold">Implants / Devices Used</Label>
                          <Popover open={openImplantsSearch} onOpenChange={setOpenImplantsSearch}>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                role="combobox"
                                className="w-full justify-between"
                              >
                                <span className="text-muted-foreground">
                                  Search and select implants/devices
                                </span>
                                <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-[400px] p-0" align="start">
                              <Command>
                                <CommandInput placeholder="Search implants/devices..." />
                                <CommandList>
                                  <CommandEmpty>No options found.</CommandEmpty>
                                  <CommandGroup heading="Implants / Devices">
                                    {implantsDevicesOptions
                                      .filter((opt) => !selectedImplants.some((i) => i.option === opt))
                                      .map((opt) => (
                                        <CommandItem
                                          key={opt}
                                          value={opt}
                                          onSelect={() => addImplant(opt)}
                                        >
                                          <Plus className="mr-2 h-4 w-4" />
                                          {opt}
                                        </CommandItem>
                                      ))}
                                  </CommandGroup>
                                </CommandList>
                              </Command>
                            </PopoverContent>
                          </Popover>

                          {selectedImplants.length > 0 && (
                            <div className="space-y-2 mt-2">
                              {selectedImplants.map((item) => (
                                <div key={item.option} className="flex items-start gap-2 p-2 border rounded-md bg-muted/30">
                                  <div className="flex-1">
                                    <div className="flex items-center justify-between">
                                      <span className="text-sm font-medium">{item.option}</span>
                                      <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        className="h-6 w-6"
                                        onClick={() => removeImplant(item.option)}
                                      >
                                        <X className="h-4 w-4" />
                                      </Button>
                                    </div>
                                    {item.option === "Others" && (
                                      <Input
                                        placeholder="Enter custom implant/device details"
                                        value={item.customValue || ""}
                                        onChange={(e) => updateImplantCustomValue(item.option, e.target.value)}
                                        className="mt-2"
                                      />
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Medications during treatment */}
                        <div className="space-y-2">
                          <Label className="text-sm font-semibold">Medications during treatment</Label>
                          <Popover open={openMedicationsSearch} onOpenChange={setOpenMedicationsSearch}>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                role="combobox"
                                className="w-full justify-between"
                              >
                                <span className="text-muted-foreground">
                                  Search and select medications
                                </span>
                                <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-[400px] p-0" align="start">
                              <Command>
                                <CommandInput placeholder="Search medications..." />
                                <CommandList>
                                  <CommandEmpty>No options found.</CommandEmpty>
                                  <CommandGroup heading="Medications">
                                    {medicationsOptions
                                      .filter((opt) => !selectedMedications.some((m) => m.option === opt))
                                      .map((opt) => (
                                        <CommandItem
                                          key={opt}
                                          value={opt}
                                          onSelect={() => addMedication(opt)}
                                        >
                                          <Plus className="mr-2 h-4 w-4" />
                                          {opt}
                                        </CommandItem>
                                      ))}
                                  </CommandGroup>
                                </CommandList>
                              </Command>
                            </PopoverContent>
                          </Popover>

                          {selectedMedications.length > 0 && (
                            <div className="space-y-2 mt-2">
                              {selectedMedications.map((item) => (
                                <div key={item.option} className="flex items-start gap-2 p-2 border rounded-md bg-muted/30">
                                  <div className="flex-1">
                                    <div className="flex items-center justify-between">
                                      <span className="text-sm font-medium">{item.option}</span>
                                      <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        className="h-6 w-6"
                                        onClick={() => removeMedication(item.option)}
                                      >
                                        <X className="h-4 w-4" />
                                      </Button>
                                    </div>
                                    {item.option === "Others" && (
                                      <Input
                                        placeholder="Enter custom medication details"
                                        value={item.customValue || ""}
                                        onChange={(e) => updateMedicationCustomValue(item.option, e.target.value)}
                                        className="mt-2"
                                      />
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  </CardContent>
                </Card>

                {/* Additional Details - Collapsed */}
                <Collapsible defaultOpen={false}>
                  <CollapsibleTrigger className="flex items-center justify-between w-full py-3 px-4 text-sm font-semibold bg-muted/50 hover:bg-muted rounded-lg border transition-colors">
                    <span>Additional Details (Optional)</span>
                    <ChevronDown className="h-4 w-4 transition-transform duration-200 [[data-state=open]>&]:rotate-180" />
                  </CollapsibleTrigger>
                  <CollapsibleContent className="pt-2 space-y-4">

                    {/* Correlation */}
                    <Card>
                      <CardHeader className="pb-2">
                        <button
                          type="button"
                          className="flex w-full items-center justify-between text-left"
                          onClick={() => setOpenClinicalSection("correlation")}
                        >
                          <CardTitle className="text-sm">Correlation</CardTitle>
                          <span className="text-lg font-medium leading-none">
                            {openClinicalSection === "correlation" ? "−" : "+"}
                          </span>
                        </button>
                      </CardHeader>
                      {openClinicalSection === "correlation" && (
                      <CardContent className="p-4 space-y-4">
                        <div className="space-y-3">
                          <div className="space-y-1">
                            <Label className="text-sm font-semibold">ICD - PCS</Label>
                            <div className="grid gap-3 md:grid-cols-2">
                              <div className="space-y-1">
                                <Label className="text-xs text-muted-foreground">Correlation</Label>
                                <Select
                                  value={correlationDetails.icdPcs.strength}
                                  onValueChange={(value) =>
                                    setCorrelationDetails((prev) => ({
                                      ...prev,
                                      icdPcs: { ...prev.icdPcs, strength: value },
                                    }))
                                  }
                                >
                                  <SelectTrigger className="h-9 text-sm">
                                    <SelectValue placeholder="Select" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="strong">Strong correlation</SelectItem>
                                    <SelectItem value="weak">Weak correlation</SelectItem>
                                    <SelectItem value="none">No correlation</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-1">
                                <Label className="text-xs text-muted-foreground">Comments</Label>
                                <Textarea
                                  className="min-h-[60px]"
                                  placeholder="Add comments"
                                  value={correlationDetails.icdPcs.comments}
                                  onChange={(e) =>
                                    setCorrelationDetails((prev) => ({
                                      ...prev,
                                      icdPcs: { ...prev.icdPcs, comments: e.target.value },
                                    }))
                                  }
                                />
                              </div>
                            </div>
                          </div>

                          <div className="space-y-1">
                            <Label className="text-sm font-semibold">Treatment necessity</Label>
                            <div className="grid gap-3 md:grid-cols-2">
                              <div className="space-y-1">
                                <Label className="text-xs text-muted-foreground">Correlation</Label>
                                <Select
                                  value={correlationDetails.treatmentNecessity.strength}
                                  onValueChange={(value) =>
                                    setCorrelationDetails((prev) => ({
                                      ...prev,
                                      treatmentNecessity: { ...prev.treatmentNecessity, strength: value },
                                    }))
                                  }
                                >
                                  <SelectTrigger className="h-9 text-sm">
                                    <SelectValue placeholder="Select" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="strong">Strong correlation</SelectItem>
                                    <SelectItem value="weak">Weak correlation</SelectItem>
                                    <SelectItem value="none">No correlation</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-1">
                                <Label className="text-xs text-muted-foreground">Comments</Label>
                                <Textarea
                                  className="min-h-[60px]"
                                  placeholder="Add comments"
                                  value={correlationDetails.treatmentNecessity.comments}
                                  onChange={(e) =>
                                    setCorrelationDetails((prev) => ({
                                      ...prev,
                                      treatmentNecessity: { ...prev.treatmentNecessity, comments: e.target.value },
                                    }))
                                  }
                                />
                              </div>
                            </div>
                          </div>

                          <div className="space-y-1">
                            <Label className="text-sm font-semibold">Medicine correlation</Label>
                            <div className="grid gap-3 md:grid-cols-2">
                              <div className="space-y-1">
                                <Label className="text-xs text-muted-foreground">Correlation</Label>
                                <Select
                                  value={correlationDetails.medicineCorrelation.strength}
                                  onValueChange={(value) =>
                                    setCorrelationDetails((prev) => ({
                                      ...prev,
                                      medicineCorrelation: { ...prev.medicineCorrelation, strength: value },
                                    }))
                                  }
                                >
                                  <SelectTrigger className="h-9 text-sm">
                                    <SelectValue placeholder="Select" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="strong">Strong correlation</SelectItem>
                                    <SelectItem value="weak">Weak correlation</SelectItem>
                                    <SelectItem value="none">No correlation</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-1">
                                <Label className="text-xs text-muted-foreground">Comments</Label>
                                <Textarea
                                  className="min-h-[60px]"
                                  placeholder="Add comments"
                                  value={correlationDetails.medicineCorrelation.comments}
                                  onChange={(e) =>
                                    setCorrelationDetails((prev) => ({
                                      ...prev,
                                      medicineCorrelation: { ...prev.medicineCorrelation, comments: e.target.value },
                                    }))
                                  }
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                      )}
                    </Card>

                    {/* Other Conditions / Risk Factors */}
                    <Card>
                      <CardHeader className="pb-2">
                        <button
                          type="button"
                          className="flex w-full items-center justify-between text-left"
                          onClick={() => setOpenClinicalSection("otherConditions")}
                        >
                          <CardTitle className="text-sm">Other Conditions / Risk Factors</CardTitle>
                          <span className="text-lg font-medium leading-none">
                            {openClinicalSection === "otherConditions" ? "−" : "+"}
                          </span>
                        </button>
                      </CardHeader>
                      {openClinicalSection === "otherConditions" && (
                      <CardContent className="p-4 space-y-6">
                        {/* Family History */}
                        <div className="space-y-2">
                          <Label className="text-sm font-semibold">Family History</Label>
                          <Textarea
                            placeholder="Enter relevant family history..."
                            value={otherConditions.familyHistory}
                            onChange={(e) =>
                              setOtherConditions((prev) => ({
                                ...prev,
                                familyHistory: e.target.value,
                              }))
                            }
                          />
                        </div>

                        {/* Personal History */}
                        <div className="space-y-3">
                          <Label className="text-sm font-semibold">Personal History</Label>
                          <div className="flex flex-wrap gap-2">
                            {[
                              { key: 'smoking', label: 'Smoking' },
                              { key: 'drinking', label: 'Drinking' },
                              { key: 'tobacco', label: 'Tobacco' },
                            ].map((item) => {
                              const isSelected = otherConditions.personalHistory.selectedItems.includes(item.key);
                              return (
                                <button
                                  key={item.key}
                                  type="button"
                                  onClick={() => {
                                    setOtherConditions((prev) => {
                                      const currentItems = prev.personalHistory.selectedItems;
                                      const newItems = isSelected
                                        ? currentItems.filter((i) => i !== item.key)
                                        : [...currentItems, item.key];
                                      return {
                                        ...prev,
                                        personalHistory: {
                                          ...prev.personalHistory,
                                          selectedItems: newItems,
                                          ...(item.key === 'smoking' && !newItems.includes('smoking') ? { smokingFrequency: '' } : {}),
                                          ...(item.key === 'drinking' && !newItems.includes('drinking') ? { drinkingFrequency: '' } : {}),
                                        },
                                      };
                                    });
                                  }}
                                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm border transition-colors ${
                                    isSelected
                                      ? 'bg-primary text-primary-foreground border-primary'
                                      : 'bg-background border-border hover:bg-muted'
                                  }`}
                                >
                                  {isSelected && <Check className="h-3.5 w-3.5" />}
                                  {item.label}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      </CardContent>
                      )}
                    </Card>

                    {/* Vital parameters */}
                    <Card>
                      <CardHeader className="pb-2">
                        <button
                          type="button"
                          className="flex w-full items-center justify-between text-left"
                          onClick={() => setOpenClinicalSection("vitalParameters")}
                        >
                          <CardTitle className="text-sm">Vital parameters</CardTitle>
                          <span className="text-lg font-medium leading-none">
                            {openClinicalSection === "vitalParameters" ? "−" : "+"}
                          </span>
                        </button>
                      </CardHeader>
                      {openClinicalSection === "vitalParameters" && (
                      <CardContent className="p-4 space-y-4">
                        <div className="space-y-2">
                          <Label className="text-sm font-semibold">Add Parameter</Label>
                          <Popover open={openVitalParamSearch} onOpenChange={setOpenVitalParamSearch}>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                role="combobox"
                                aria-expanded={openVitalParamSearch}
                                className="w-full justify-between"
                              >
                                <span className="text-muted-foreground">Search and select parameter...</span>
                                <Search className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-full p-0 z-50" align="start">
                              <Command>
                                <CommandInput
                                  placeholder="Search parameters..."
                                  value={vitalParamSearchTerm}
                                  onValueChange={setVitalParamSearchTerm}
                                />
                                <CommandList>
                                  <CommandEmpty>No parameter found.</CommandEmpty>
                                  <CommandGroup>
                                    {filteredVitalParams.map((param) => (
                                      <CommandItem
                                        key={param.key}
                                        value={param.label}
                                        onSelect={() => {
                                          setVitalParameterRecordings((prev) => [
                                            ...prev,
                                            {
                                              parameter: param.key,
                                              value: '',
                                              date: new Date(),
                                              time: format(new Date(), 'HH:mm'),
                                            },
                                          ]);
                                          setVitalParamSearchTerm('');
                                          setOpenVitalParamSearch(false);
                                        }}
                                      >
                                        {param.label}
                                      </CommandItem>
                                    ))}
                                  </CommandGroup>
                                </CommandList>
                              </Command>
                            </PopoverContent>
                          </Popover>
                        </div>

                        {vitalParameterRecordings.length > 0 && (
                          <div className="space-y-3">
                            {vitalParameterRecordings.map((recording, index) => {
                              const paramInfo = vitalParameterOptions.find(
                                (p) => p.key === recording.parameter
                              );
                              return (
                                <div
                                  key={`${recording.parameter}-${index}`}
                                  className="border rounded-lg p-3 space-y-2 bg-muted/30"
                                >
                                  <div className="flex items-center justify-between">
                                    <Label className="text-sm font-semibold">
                                      {paramInfo?.label || recording.parameter}
                                    </Label>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() =>
                                        setVitalParameterRecordings((prev) =>
                                          prev.filter((_, i) => i !== index)
                                        )
                                      }
                                      className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                                    >
                                      <X className="h-4 w-4" />
                                    </Button>
                                  </div>
                                  <div className="grid gap-2 md:grid-cols-3">
                                    <div className="space-y-1">
                                      <Label className="text-xs text-muted-foreground">Reading</Label>
                                      <Input
                                        placeholder={paramInfo?.placeholder || 'Enter value'}
                                        value={recording.value}
                                        onChange={(e) =>
                                          setVitalParameterRecordings((prev) =>
                                            prev.map((r, i) =>
                                              i === index ? { ...r, value: e.target.value } : r
                                            )
                                          )
                                        }
                                      />
                                    </div>
                                    <div className="space-y-1">
                                      <Label className="text-xs text-muted-foreground">Date</Label>
                                      <Popover>
                                        <PopoverTrigger asChild>
                                          <Button
                                            variant="outline"
                                            className={cn(
                                              "w-full justify-start text-left font-normal",
                                              !recording.date && "text-muted-foreground"
                                            )}
                                          >
                                            <CalendarIcon className="mr-2 h-4 w-4" />
                                            {recording.date
                                              ? format(recording.date, "PPP")
                                              : "Pick a date"}
                                          </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-auto p-0 z-50" align="start">
                                          <Calendar
                                            mode="single"
                                            selected={recording.date || undefined}
                                            onSelect={(date) =>
                                              setVitalParameterRecordings((prev) =>
                                                prev.map((r, i) =>
                                                  i === index ? { ...r, date: date || null } : r
                                                )
                                              )
                                            }
                                            initialFocus
                                            className="p-3 pointer-events-auto"
                                          />
                                        </PopoverContent>
                                      </Popover>
                                    </div>
                                    <div className="space-y-1">
                                      <Label className="text-xs text-muted-foreground">Time</Label>
                                      <Input
                                        type="time"
                                        value={recording.time}
                                        onChange={(e) =>
                                          setVitalParameterRecordings((prev) =>
                                            prev.map((r, i) =>
                                              i === index ? { ...r, time: e.target.value } : r
                                            )
                                          )
                                        }
                                      />
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </CardContent>
                      )}
                    </Card>

                    {/* Follow up advice */}
                    <Card>
                      <CardHeader className="pb-2">
                        <button
                          type="button"
                          className="flex w-full items-center justify-between text-left"
                          onClick={() => setOpenClinicalSection("followUpAdvice")}
                        >
                          <CardTitle className="text-sm">Follow up advice</CardTitle>
                          <span className="text-lg font-medium leading-none">
                            {openClinicalSection === "followUpAdvice" ? "−" : "+"}
                          </span>
                        </button>
                      </CardHeader>
                      {openClinicalSection === "followUpAdvice" && (
                      <CardContent className="p-4 space-y-4">
                        <div className="space-y-2">
                          <Label className="text-sm font-semibold">Advice</Label>
                          <div className="flex gap-2">
                            <Select
                              value={followUpAdvice.adviceCategory}
                              onValueChange={(value) =>
                                setFollowUpAdvice((prev) => ({
                                  ...prev,
                                  adviceCategory: value,
                                }))
                              }
                            >
                              <SelectTrigger className="w-[180px]">
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                              <SelectContent>
                                {adviceCategoryOptions.map((cat) => (
                                  <SelectItem key={cat} value={cat}>
                                    {cat}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Textarea
                              className="flex-1 min-h-[80px]"
                              placeholder="Enter follow-up advice details"
                              value={followUpAdvice.adviceText}
                              onChange={(e) =>
                                setFollowUpAdvice((prev) => ({
                                  ...prev,
                                  adviceText: e.target.value,
                                }))
                              }
                            />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <Label className="text-sm font-semibold">Next appointment</Label>
                          <Input
                            type="date"
                            value={followUpAdvice.nextAppointmentDate}
                            onChange={(e) =>
                              setFollowUpAdvice((prev) => ({
                                ...prev,
                                nextAppointmentDate: e.target.value,
                              }))
                            }
                          />
                        </div>
                      </CardContent>
                      )}
                    </Card>

                  </CollapsibleContent>
                </Collapsible>
              </div>
              )}


              {/* Admissibility Section - Hidden */}
              {false && workflowStage === 'review' && (
              <Collapsible open={isAdmissibilityOpen} onOpenChange={setIsAdmissibilityOpen}>
                <div className="flex items-center space-x-2">
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="flex-1 justify-between">
                      <div className="flex items-center space-x-2">
                        <Flag className="h-4 w-4 text-primary" />
                        <span className="font-medium">Admissibility</span>
                      </div>
                      {isAdmissibilityOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                </div>
                
                <CollapsibleContent className="mt-2">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Claim Admissibility Assessment</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 space-y-4">
                      {/* Recommendation Section */}
                      {recommendedCovers.length > 0 && (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Info className="h-4 w-4 text-primary" />
                            <Label className="text-sm font-semibold text-primary">Recommended Covers</Label>
                            <Badge variant="outline" className="text-xs">Based on ICD/PCS</Badge>
                          </div>
                          <div className="flex flex-wrap gap-2 p-3 rounded-lg bg-primary/5 border border-primary/20">
                            {recommendedCovers.map(coverId => {
                              const cover = coversData.find(c => c.id === coverId);
                              const isSelected = selectedCovers.includes(coverId);
                              return cover ? (
                                <Badge 
                                  key={coverId} 
                                  variant={isSelected ? "default" : "outline"}
                                  className={cn(
                                    "text-xs cursor-pointer transition-colors",
                                    !isSelected && "hover:bg-primary/10"
                                  )}
                                  onClick={() => {
                                    if (!isSelected) {
                                      setSelectedCovers([...selectedCovers, coverId]);
                                    }
                                  }}
                                >
                                  {isSelected && <Check className="h-3 w-3 mr-1" />}
                                  {cover.name}
                                  {!isSelected && <Plus className="h-3 w-3 ml-1" />}
                                </Badge>
                              ) : null;
                            })}
                          </div>
                        </div>
                      )}

                      {/* Covers Selection Section */}
                      <div className="space-y-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <Label className="text-sm font-semibold">Applicable Covers</Label>
                            <Badge variant="outline" className="text-xs">Select all that apply</Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">Listing all covers from your ACKO health policy for {formData.customerName}</p>
                        </div>
                        
                        {/* Searchable Dropdown */}
                        <Popover open={openCoversSearch} onOpenChange={setOpenCoversSearch}>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              role="combobox"
                              aria-expanded={openCoversSearch}
                              className="w-full justify-between h-10"
                            >
                              <span className="text-muted-foreground">Search and select covers...</span>
                              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-[400px] p-0" align="start">
                            <Command>
                              <CommandInput 
                                placeholder="Search covers..." 
                                value={coversSearchTerm}
                                onValueChange={setCoversSearchTerm}
                              />
                              <CommandList>
                                <CommandEmpty>No covers found.</CommandEmpty>
                                <CommandGroup>
                                  {filteredCovers.map((cover) => (
                                    <CommandItem
                                      key={cover.id}
                                      value={cover.name}
                                      onSelect={() => {
                                        if (selectedCovers.includes(cover.id)) {
                                          setSelectedCovers(selectedCovers.filter(c => c !== cover.id));
                                        } else {
                                          setSelectedCovers([...selectedCovers, cover.id]);
                                        }
                                      }}
                                      className="flex items-start gap-2 py-2"
                                    >
                                      <div className={cn(
                                        "mt-0.5 h-4 w-4 rounded border flex items-center justify-center shrink-0",
                                        selectedCovers.includes(cover.id)
                                          ? "bg-primary border-primary"
                                          : "border-muted-foreground/30"
                                      )}>
                                        {selectedCovers.includes(cover.id) && (
                                          <Check className="h-3 w-3 text-primary-foreground" />
                                        )}
                                      </div>
                                      <div className="flex-1">
                                        <div className="text-sm font-medium">{cover.name}</div>
                                        <div className="text-xs text-muted-foreground">{cover.description}</div>
                                      </div>
                                    </CommandItem>
                                  ))}
                                </CommandGroup>
                              </CommandList>
                            </Command>
                          </PopoverContent>
                        </Popover>

                        {/* Selected Covers Display */}
                        {selectedCovers.length > 0 && (
                          <div className="flex flex-wrap gap-2">
                            {selectedCovers.map(coverId => {
                              const cover = coversData.find(c => c.id === coverId);
                              return cover ? (
                                <Badge key={coverId} variant="secondary" className="text-xs">
                                  {cover.name}
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-4 w-4 p-0 ml-1"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSelectedCovers(selectedCovers.filter(c => c !== coverId));
                                    }}
                                  >
                                    <X className="h-3 w-3" />
                                  </Button>
                                </Badge>
                              ) : null;
                            })}
                          </div>
                        )}

                        {/* Free text input for Others */}
                        {selectedCovers.includes("others") && (
                          <div className="space-y-2">
                            <Label className="text-sm">Specify Other Cover</Label>
                            <Input
                              placeholder="Please describe the applicable cover..."
                              value={otherCoverText}
                              onChange={(e) => setOtherCoverText(e.target.value)}
                            />
                          </div>
                        )}
                      </div>

                    </CardContent>
                  </Card>
                </CollapsibleContent>
              </Collapsible>
              )}

              
              {/* Step 3: Status & Next Action */}
              {workflowStage === 'review' && currentStep === 2 && (
                <StatusNextActionCard 
                  onReadyToComplete={() => navigate('/financial-adjudication')} 
                  onStatusChange={(action: string) => setSelectedStatusAction(action)}
                  onChecklistViewChange={(showing, animComplete) => {
                    setIsShowingChecklist(showing);
                    setIsChecklistAnimationComplete(animComplete);
                    // Reset trigger when checklist view changes
                    if (!showing) setHideChecklistTrigger(false);
                  }}
                  externalHideChecklistTrigger={hideChecklistTrigger}
                  skipChecklistAnimation={false}
                  hideActionButton={true}
                />
              )}
              
              {/* Done Action - Moved into StatusNextActionCard */}

            </div>
           </ScrollArea>
           
           {/* Navigation Buttons - Fixed at bottom */}
           {workflowStage === 'review' && (
              <div className="px-4 py-3 border-t bg-background flex-shrink-0">
                <div className="flex items-center justify-between gap-3">
                  {currentStep > 1 ? (
                    <Button
                      variant="outline"
                      onClick={() => setCurrentStep(currentStep - 1)}
                      className="flex items-center gap-2"
                    >
                      <ChevronLeft className="h-4 w-4" />
                      Back
                    </Button>
                  ) : (
                    <div />
                  )}
                  
                  {/* Step Indicator - Inline */}
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1.5">
                      {[1, 2].map((step) => (
                        <div
                          key={step}
                          className={cn(
                            "h-1.5 w-6 rounded-full transition-colors",
                            step === currentStep
                              ? "bg-primary"
                              : step < currentStep
                              ? "bg-primary/40"
                              : "bg-muted"
                          )}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-muted-foreground">
                      Step {currentStep} of 2 · {currentStep === 1 ? "Clinical Details" : "Status & Next Action"}
                    </span>
                  </div>
                  
                  {currentStep < 2 ? (
                    <Button
                       onClick={() => setCurrentStep(currentStep + 1)}
                       className="flex items-center gap-2"
                     >
                       Next
                       <ChevronRight className="h-4 w-4" />
                     </Button>
                  ) : (
                    isShowingChecklist ? (
                      <Button
                        onClick={() => {
                          // Trigger the StatusNextActionCard to hide checklist
                          setHideChecklistTrigger(true);
                        }}
                        className="flex items-center gap-2"
                        disabled={!isChecklistAnimationComplete}
                      >
                        Next
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    ) : selectedStatusAction === 'complete' ? (
                      <Button
                        onClick={() => navigate('/financial-adjudication')}
                        className="flex items-center gap-2"
                      >
                        Done, go to financial adjudication
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    ) : (
                       <Button
                         onClick={() => {
                           toast({
                             title: "Task Completed",
                             description: "The claim task has been closed with the selected status.",
                           });
                         }}
                         className="flex items-center gap-2"
                         disabled={!selectedStatusAction}
                       >
                         {getActionLabel(selectedStatusAction)}
                         <Check className="h-4 w-4" />
                       </Button>
                    )
                  )}
                </div>
              </div>
           )}
        </ResizablePanel>
      </ResizablePanelGroup>

      {/* Document Overlay */}
      <Dialog open={documentOverlayOpen} onOpenChange={setDocumentOverlayOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] p-0">
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-semibold">Document Viewer</h2>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 border rounded-md p-1">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleZoomOut}
                    disabled={documentZoom <= 50}
                  >
                    <ZoomOut className="h-3 w-3" />
                  </Button>
                  <span className="text-xs text-muted-foreground px-2 min-w-[3rem] text-center">
                    {documentZoom}%
                  </span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleZoomIn}
                    disabled={documentZoom >= 200}
                  >
                    <ZoomIn className="h-3 w-3" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleZoomReset}
                  >
                    <RotateCcw className="h-3 w-3" />
                  </Button>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handlePreviousDocument}
                  disabled={documents.length === 0}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm text-muted-foreground">
                  {currentDocumentIndex + 1} of {documents.length}
                </span>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleNextDocument}
                  disabled={documents.length === 0}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setDocumentOverlayOpen(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <ScrollArea className="flex-1 p-4">
              <div className="border-2 border-dashed border-muted-foreground/30 rounded-lg flex items-center justify-center bg-muted/20 min-h-[500px]">
                <div className="text-center space-y-4" style={{ transform: `scale(${documentZoom / 100})` }}>
                  <div className="bg-background/80 rounded-full p-6 mx-auto w-fit">
                    <currentDocument.icon className="h-24 w-24 text-muted-foreground" />
                  </div>
                  <div className="space-y-2">
                    <p className="font-medium text-foreground text-xl">
                      {currentDocument.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {currentDocument.type} • {currentDocument.size} • {currentDocument.uploadDate}
                    </p>
                    <p className="text-sm text-muted-foreground max-w-md">
                      {currentDocument.content}
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialogs and modals */}

      {/* Add Sub-Category Modal */}
      <Dialog open={addSubCategoryOpen} onOpenChange={setAddSubCategoryOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold">Add New Sub-Category</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Sub-Category Name</label>
                <Input 
                  value={newSubCategory.name}
                  onChange={(e) => handleNewSubCategoryChange('name', e.target.value)}
                  placeholder="Enter sub-category name"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Days</label>
                <Input
                  type="number"
                  value={newSubCategory.days}
                  onChange={(e) => handleNewSubCategoryChange('days', e.target.value)}
                  placeholder="Number of days"
                  min="1"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Tariff Amount (₹)</label>
                <Input 
                  type="number"
                  value={newSubCategory.tariffAmount}
                  onChange={(e) => handleNewSubCategoryChange('tariffAmount', e.target.value)}
                  placeholder="Enter tariff amount"
                  min="0"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Deductions (₹)</label>
                <Input 
                  type="number"
                  value={newSubCategory.deductions}
                  onChange={(e) => handleNewSubCategoryChange('deductions', e.target.value)}
                  placeholder="Enter deductions amount"
                  min="0"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Discount (₹)</label>
                <Input 
                  type="number"
                  value={newSubCategory.discount}
                  onChange={(e) => handleNewSubCategoryChange('discount', e.target.value)}
                  placeholder="Enter discount amount"
                  min="0"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Bill Amount (₹)</label>
                <Input 
                  value={newSubCategory.billAmount}
                  placeholder="Auto-calculated"
                  disabled
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Payable Amount (₹)</label>
              <Input 
                value={newSubCategory.payableAmount}
                placeholder="Auto-calculated"
                disabled
              />
            </div>
            
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => setAddSubCategoryOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleAddSubCategory}
                disabled={!newSubCategory.name || !newSubCategory.tariffAmount}
              >
                Add Sub-Category
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Line Item Modal */}
      <Dialog open={addLineItemOpen} onOpenChange={setAddLineItemOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader className="flex flex-row items-center justify-between border-b pb-4">
            <DialogTitle className="text-xl font-semibold">
              Add New Line Item
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCancelAddLineItem}
              className="h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogHeader>
          
          <div className="space-y-4 pt-4">
            <div>
              <label className="text-sm font-medium">Category</label>
              <Select value={newLineItem.category} onValueChange={(value) => handleNewLineItemChange('category', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="accommodation">Room & Nursing Charges</SelectItem>
                  <SelectItem value="icu">ICU Charges</SelectItem>
                  <SelectItem value="ot">OT Charges</SelectItem>
                  <SelectItem value="pharmacy">Medicine & Consumables charges</SelectItem>
                  <SelectItem value="professional">Professional fees charges</SelectItem>
                  <SelectItem value="investigation">Investigation Charges</SelectItem>
                  <SelectItem value="ambulance">Ambulance Charges</SelectItem>
                  <SelectItem value="miscellaneous">Miscellaneous charges</SelectItem>
                  <SelectItem value="package">Package Charges</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium">Tariff Amount (₹)</label>
              <Input
                type="number"
                placeholder="0"
                value={newLineItem.tariffAmount}
                onChange={(e) => handleNewLineItemChange('tariffAmount', e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm font-medium">Discount (₹)</label>
              <Input
                type="number"
                placeholder="0"
                value={newLineItem.discount}
                onChange={(e) => handleNewLineItemChange('discount', e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Bill Amount (₹)</label>
                <Input
                  type="number"
                  placeholder="0"
                  value={newLineItem.billAmount}
                  onChange={(e) => handleNewLineItemChange('billAmount', e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Payable Amount (₹)</label>
                <Input
                  type="number"
                  placeholder="0"
                  value={newLineItem.payableAmount}
                  onChange={(e) => handleNewLineItemChange('payableAmount', e.target.value)}
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={handleCancelAddLineItem} className="flex-1">
                Cancel
              </Button>
              <Button onClick={handleAddLineItem} className="flex-1">
                Add Line Item
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Document Overlay Dialog */}
      <Dialog open={documentOverlayOpen} onOpenChange={setDocumentOverlayOpen}>
        <DialogContent className="max-w-6xl w-[90vw] h-[90vh] p-0">
          <div className="h-full flex flex-col">
            <DialogHeader className="p-4 border-b flex-shrink-0">
              <div className="flex items-center justify-between">
                <DialogTitle className="text-lg font-semibold">
                  {currentDocument.name}
                </DialogTitle>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 border rounded-md p-1">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handleZoomOut}
                      disabled={documentZoom <= 50}
                    >
                      <ZoomOut className="h-3 w-3" />
                    </Button>
                    <span className="text-xs text-muted-foreground px-2 min-w-[3rem] text-center">
                      {documentZoom}%
                    </span>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handleZoomIn}
                      disabled={documentZoom >= 200}
                    >
                      <ZoomIn className="h-3 w-3" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handleZoomReset}
                    >
                      <RotateCcw className="h-3 w-3" />
                    </Button>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handlePreviousDocument}
                    disabled={documents.length === 0}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm text-muted-foreground">
                    {currentDocumentIndex + 1} of {documents.length}
                  </span>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleNextDocument}
                    disabled={documents.length === 0}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </DialogHeader>
            
            <div className="flex-1 p-6 overflow-auto">
              <div className="h-full flex items-center justify-center">
                <div className="text-center space-y-6" style={{ transform: `scale(${documentZoom / 100})` }}>
                  <div className="bg-background/80 rounded-full p-8 mx-auto w-fit">
                    <currentDocument.icon className="h-24 w-24 text-muted-foreground" />
                  </div>
                  <div className="space-y-3">
                    <p className="font-medium text-foreground text-2xl">
                      {currentDocument.name}
                    </p>
                    <p className="text-base text-muted-foreground">
                      {currentDocument.type} • {currentDocument.size} • {currentDocument.uploadDate}
                    </p>
                    <p className="text-base text-muted-foreground max-w-2xl mx-auto">
                      {currentDocument.content}
                    </p>
                  </div>
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Download Full Size
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Summary Modal */}
      <Dialog open={summaryModalOpen} onOpenChange={setSummaryModalOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Bill Summary & Breakup
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            {/* Bills Breakdown by Category */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-foreground">Bills Breakdown by Category:</h4>
              <div className="bg-muted/20 p-4 rounded-lg space-y-4">
                {selectedBillItems.filter(item => item.id !== 'temp').map((item) => {
                  const billData = savedBillDetails[item.id];
                  const summary = getBillSummary(item.id);
                  
                  return (
                    <div key={item.id} className="space-y-2">
                      <div className="font-semibold text-sm border-b pb-1">{item.fullPath}</div>
                      {billData?.bills && billData.bills.length > 0 ? (
                        <div className="space-y-1 pl-4">
                          {billData.bills.map((bill: any, idx: number) => (
                            <div key={idx} className="flex justify-between items-center text-xs">
                              <span className="text-muted-foreground">
                                {bill.itemName} ({bill.days} days × ₹{bill.rent})
                              </span>
                              <span className="font-medium">₹{bill.amount.toLocaleString()}</span>
                            </div>
                          ))}
                          <div className="flex justify-between items-center text-sm font-medium pt-1 border-t">
                            <span>Subtotal:</span>
                            <span>₹{summary.totalBillAmount.toLocaleString()}</span>
                          </div>
                        </div>
                      ) : (
                        <div className="text-xs text-muted-foreground pl-4">No bills added</div>
                      )}
                    </div>
                  );
                })}
                <div className="border-t pt-2 mt-3">
                  <div className="flex justify-between items-center text-sm font-semibold">
                    <span>Total Billed Amount:</span>
                    <span>₹{selectedBillItems
                      .filter(item => item.id !== 'temp')
                      .reduce((sum, item) => sum + getBillSummary(item.id).totalBillAmount, 0)
                      .toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Deductions Breakdown */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-foreground">Deductions Breakdown:</h4>
              <div className="bg-red-50 dark:bg-red-950/20 p-4 rounded-lg space-y-4">
                {selectedBillItems.filter(item => item.id !== 'temp').map((item) => {
                  const billData = savedBillDetails[item.id];
                  const summary = getBillSummary(item.id);
                  
                  if (!billData?.deductions || billData.deductions.length === 0) return null;
                  
                  return (
                    <div key={item.id} className="space-y-2">
                      <div className="font-semibold text-sm border-b pb-1">{item.fullPath}</div>
                      <div className="space-y-1 pl-4">
                        {billData.deductions.map((deduction: any, idx: number) => (
                          <div key={idx} className="flex justify-between items-center text-xs">
                            <span className="text-muted-foreground">{deduction.deductionName}</span>
                            <span className="font-medium text-destructive">- ₹{deduction.amount.toLocaleString()}</span>
                          </div>
                        ))}
                        <div className="flex justify-between items-center text-sm font-medium pt-1 border-t">
                          <span>Subtotal Deductions:</span>
                          <span className="text-destructive">- ₹{summary.totalDeductions.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div className="border-t pt-2 mt-3">
                  <div className="flex justify-between items-center text-sm font-semibold">
                    <span>Total Deductions:</span>
                    <span className="text-destructive">- ₹{selectedBillItems
                      .filter(item => item.id !== 'temp')
                      .reduce((sum, item) => sum + getBillSummary(item.id).totalDeductions, 0)
                      .toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Policy Limit & Discounts */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-foreground">Policy Limit & Discounts:</h4>
              <div className="bg-muted/20 p-4 rounded-lg space-y-2">
                {selectedBillItems.filter(item => item.id !== 'temp').map((item) => {
                  const summary = getBillSummary(item.id);
                  const eligibleData = getEligibleAmount(item.id);
                  const discount = parseFloat(item.discount) || 0;
                  const policyExcess = eligibleData.billAmountPostDeductions - eligibleData.eligible;
                  
                  return (
                    <div key={item.id} className="space-y-1">
                      <div className="font-semibold text-xs">{item.fullPath}</div>
                      <div className="pl-4 space-y-1">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-muted-foreground">Bill Amount (post deductions):</span>
                          <span>₹{summary.billAmountPostDeductions.toLocaleString()}</span>
                        </div>
                        {policyExcess > 0 && (
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-muted-foreground">Policy limit excess:</span>
                            <span className="text-destructive">- ₹{policyExcess.toLocaleString()}</span>
                          </div>
                        )}
                        {discount > 0 && (
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-muted-foreground">Network discount:</span>
                            <span className="text-green-600">- ₹{discount.toLocaleString()}</span>
                          </div>
                        )}
                        <div className="flex justify-between items-center text-sm font-medium pt-1 border-t">
                          <span>Payable:</span>
                          <span className="text-primary">₹{(eligibleData.eligible - discount).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Final Summary */}
            <div className="bg-primary/10 p-4 rounded-lg">
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span>Total Billed Amount:</span>
                  <span className="font-medium">₹{selectedBillItems
                    .filter(item => item.id !== 'temp')
                    .reduce((sum, item) => sum + getBillSummary(item.id).totalBillAmount, 0)
                    .toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span>Total Deductions:</span>
                  <span className="font-medium text-destructive">- ₹{selectedBillItems
                    .filter(item => item.id !== 'temp')
                    .reduce((sum, item) => sum + getBillSummary(item.id).totalDeductions, 0)
                    .toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span>Total Policy Excess:</span>
                  <span className="font-medium text-destructive">- ₹{selectedBillItems
                    .filter(item => item.id !== 'temp')
                    .reduce((sum, item) => {
                      const eligibleData = getEligibleAmount(item.id);
                      return sum + (eligibleData.billAmountPostDeductions - eligibleData.eligible);
                    }, 0)
                    .toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span>Total Discounts:</span>
                  <span className="font-medium text-green-600">- ₹{selectedBillItems
                    .filter(item => item.id !== 'temp')
                    .reduce((sum, item) => sum + (parseFloat(item.discount || '0') || 0), 0)
                    .toLocaleString()}</span>
                </div>
                <div className="border-t pt-2">
                  <div className="flex justify-between items-center">
                    <span className="text-base font-bold">Final Payable Amount:</span>
                    <span className="text-lg font-bold text-primary">₹{selectedBillItems
                      .filter(item => item.id !== 'temp')
                      .reduce((sum, item) => {
                        const eligibleData = getEligibleAmount(item.id);
                        const discount = parseFloat(item.discount) || 0;
                        return sum + (eligibleData.eligible - discount);
                      }, 0)
                      .toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <Button variant="outline" onClick={() => setSummaryModalOpen(false)} className="flex-1">
                Close
              </Button>
              <Button className="flex-1">
                Export Summary
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Keyboard Shortcuts Dialog */}
      <Dialog open={isKeyboardShortcutsOpen} onOpenChange={setIsKeyboardShortcutsOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Keyboard Shortcuts</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="space-y-3">
              <h3 className="text-sm font-semibold">Document Controls</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span>Zoom in</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + Plus</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Zoom out</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + Minus</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Reset zoom</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + Zero</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Rotate clockwise</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + R</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Rotate counterclockwise</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + Shift + R</kbd>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-sm font-semibold">Navigation</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span>Navigate to next/previous document</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Right/Left arrow</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Navigate to the next section/block</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Tab</kbd>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-sm font-semibold">Text Field Entry Shortcuts</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span>Open relevant tabs (Policy details, customer details etc.)</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + Shift + 1/2/3/4</kbd>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-sm font-semibold">For Any Block</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span>Edit</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + E</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Navigate to the next section/block</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Tab</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Save</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + S</kbd>
                </div>
                <div className="flex justify-between items-center">
                  <span>Cancel</span>
                  <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl + L</kbd>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Patient & Policy Update Modal */}
      <Dialog open={isPatientPolicyModalOpen} onOpenChange={setIsPatientPolicyModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <DialogTitle className="text-xl font-semibold">
              {isCreatingExtension ? 'Select Policy for Extension' : 'Update Claim Details'}
            </DialogTitle>
            <div className="flex items-center gap-2">
              {showBackToLookup && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleBackToLookupClick}
                  className="gap-2"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Back to Lookup
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={handleModalClose}
                className="h-6 w-6"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          <div className="space-y-6">
            <PatientIdentificationStep
              onNext={handlePatientIdentificationNext}
              onCancel={handleModalClose}
              onBackToLookup={handleBackToLookupClick}
              initialPatientData={isCreatingExtension ? {
                uhid: formData.uhid,
                customerName: formData.customerName,
                customerPhone: formData.customerPhone,
                customerEmail: formData.customerEmail
              } : undefined}
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Hospital Dialog */}
      <Dialog open={isAddHospitalDialogOpen} onOpenChange={setIsAddHospitalDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add New Hospital</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="hospitalName">Hospital Name</Label>
              <Input
                id="hospitalName"
                value={newHospitalData.hospitalName}
                onChange={(e) => setNewHospitalData(prev => ({...prev, hospitalName: e.target.value}))}
                placeholder="Enter hospital name"
              />
            </div>
            <div>
              <Label htmlFor="hospitalAddress">Address</Label>
              <Input
                id="hospitalAddress"
                value={newHospitalData.hospitalAddress}
                onChange={(e) => setNewHospitalData(prev => ({...prev, hospitalAddress: e.target.value}))}
                placeholder="Street address, building name, etc."
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  value={newHospitalData.city}
                  onChange={(e) => setNewHospitalData(prev => ({...prev, city: e.target.value}))}
                  placeholder="Enter city"
                />
              </div>
              <div>
                <Label htmlFor="state">State</Label>
                <Input
                  id="state"
                  value={newHospitalData.state}
                  onChange={(e) => setNewHospitalData(prev => ({...prev, state: e.target.value}))}
                  placeholder="Enter state"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="pincode">Pincode</Label>
              <Input
                id="pincode"
                value={newHospitalData.pincode}
                onChange={(e) => setNewHospitalData(prev => ({...prev, pincode: e.target.value}))}
                placeholder="Enter pincode"
                maxLength={6}
              />
            </div>
            <div>
              <Label htmlFor="rohini">ROHINI (Optional)</Label>
              <Input
                id="rohini"
                value={newHospitalData.rohini}
                onChange={(e) => setNewHospitalData(prev => ({...prev, rohini: e.target.value}))}
                placeholder="Enter ROHINI"
              />
            </div>
            <div className="flex items-center space-x-2 pt-2">
              <Button 
                onClick={addNewHospital}
                disabled={!newHospitalData.hospitalName || !newHospitalData.hospitalAddress || !newHospitalData.city || !newHospitalData.state || !newHospitalData.pincode}
                className="flex-1"
              >
                Save
              </Button>
              <Button 
                variant="outline"
                onClick={() => {
                  setIsAddHospitalDialogOpen(false);
                  setNewHospitalData({
                    hospitalName: '',
                    hospitalLocation: '',
                    networkType: 'Network',
                    hospitalContact: '',
                    hospitalAddress: '',
                    city: '',
                    state: '',
                    pincode: '',
                    rohini: ''
                  });
                }}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Download Documents Dialog */}
      <Dialog open={isDownloadDialogOpen} onOpenChange={setIsDownloadDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Download Claim Documents</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Select Claim Extension</Label>
              <Select value={selectedExtension} onValueChange={setSelectedExtension}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select extension to download" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="HLTHCR5474-1">HLTHCR5474-1</SelectItem>
                  <SelectItem value="HLTHCR5474-2">HLTHCR5474-2</SelectItem>
                  <SelectItem value="HLTHCR5474-3">HLTHCR5474-3</SelectItem>
                  <SelectItem value="all">All Extensions</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {selectedExtension && (
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-3">Document Preview</h3>
                <ScrollArea className="h-[300px]">
                  <div className="space-y-2">
                    {documents.map((doc, index) => (
                      <div 
                        key={index}
                        className="flex items-center justify-between p-3 border rounded-md hover:bg-accent/50 transition-colors cursor-pointer"
                        onClick={() => {
                          setPreviewDocumentIndex(index);
                          setIsDocumentPreviewOpen(true);
                        }}
                      >
                        <div className="flex items-center gap-3">
                          {doc.type === 'pdf' || doc.type === 'PDF' ? (
                            <FileText className="h-5 w-5 text-red-500" />
                          ) : (
                            <FileImage className="h-5 w-5 text-blue-500" />
                          )}
                          <div>
                            <p className="font-medium text-sm">{doc.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {doc.type.toUpperCase()} • {doc.size}
                            </p>
                          </div>
                        </div>
                        <Badge variant="outline">
                          {selectedExtension === 'all' ? `Extension ${(index % 3) + 1}` : selectedExtension}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
                
                <div className="mt-4 pt-4 border-t">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm text-muted-foreground">
                      {selectedExtension === 'all' 
                        ? `${documents.length} documents from all extensions` 
                        : `${documents.length} documents from ${selectedExtension}`}
                    </p>
                    <p className="text-sm font-medium">
                      Total: ~{Math.floor(documents.length * 250)}KB
                    </p>
                  </div>
                  <Button 
                    onClick={() => {
                      toast({
                        title: "Download Started",
                        description: `Preparing ${selectedExtension === 'all' ? 'all documents' : selectedExtension + ' documents'} as ZIP file...`,
                      });
                      // Simulate download
                      setTimeout(() => {
                        toast({
                          title: "Download Complete",
                          description: `Documents downloaded successfully as ${selectedExtension === 'all' ? 'all_extensions' : selectedExtension}.zip`,
                        });
                        setIsDownloadDialogOpen(false);
                      }, 2000);
                    }}
                    className="w-full"
                    disabled={!selectedExtension}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download as ZIP
                  </Button>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Document Preview Modal */}
      <Dialog open={isDocumentPreviewOpen} onOpenChange={setIsDocumentPreviewOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Document Preview
            </DialogTitle>
            <DialogDescription>
              View and review document details, content, and metadata
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[70vh]">
            <div className="space-y-4 p-4">
              {/* Document Header */}
              <div className="flex items-start justify-between pb-4 border-b">
                <div className="space-y-1">
                  <h3 className="text-lg font-semibold">{documents[previewDocumentIndex]?.name}</h3>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <span>{documents[previewDocumentIndex]?.type}</span>
                    <span>•</span>
                    <span>{documents[previewDocumentIndex]?.size}</span>
                    <span>•</span>
                    <span>{documents[previewDocumentIndex]?.uploadDate}</span>
                  </div>
                  <Badge variant={
                    documents[previewDocumentIndex]?.status === 'Approved' ? 'default' :
                    documents[previewDocumentIndex]?.status === 'Rejected' ? 'destructive' : 'secondary'
                  }>
                    {documents[previewDocumentIndex]?.status}
                  </Badge>
                </div>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </div>

              {/* Document Content Preview */}
              <div className="border rounded-lg p-6 bg-muted/20 min-h-[400px]">
                <div className="flex flex-col items-center justify-center space-y-4">
                  {(() => {
                    const IconComponent = documents[previewDocumentIndex]?.icon;
                    return IconComponent ? <IconComponent className="h-20 w-20 text-muted-foreground" /> : null;
                  })()}
                  <div className="text-center max-w-2xl">
                    <pre className="whitespace-pre-wrap text-sm text-foreground font-mono bg-background/50 p-4 rounded-md text-left">
                      {documents[previewDocumentIndex]?.content}
                    </pre>
                  </div>
                </div>
              </div>

              {/* Document Metadata */}
              <div className="space-y-3 pt-4 border-t">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">Category</Label>
                    <p className="text-sm font-medium mt-1">{documents[previewDocumentIndex]?.category}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Document Status</Label>
                    <div className="flex items-center gap-2 mt-1">
                      {documents[previewDocumentIndex]?.readability && (
                        <Badge variant="outline" className="text-xs">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Readable
                        </Badge>
                      )}
                      {documents[previewDocumentIndex]?.suspicious && (
                        <Badge variant="destructive" className="text-xs">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Suspicious
                        </Badge>
                      )}
                      {documents[previewDocumentIndex]?.isComplete && (
                        <Badge variant="default" className="text-xs">
                          <Check className="h-3 w-3 mr-1" />
                          Complete
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
                
                {documents[previewDocumentIndex]?.systemRecommendation && (
                  <div>
                    <Label className="text-xs text-muted-foreground">System Recommendation</Label>
                    <p className="text-sm mt-1">{documents[previewDocumentIndex]?.systemRecommendation}</p>
                  </div>
                )}
                
                {documents[previewDocumentIndex]?.agentNotes && (
                  <div>
                    <Label className="text-xs text-muted-foreground">Agent Notes</Label>
                    <p className="text-sm mt-1">{documents[previewDocumentIndex]?.agentNotes}</p>
                  </div>
                )}
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Document Tagging Alert Dialog */}
      <AlertDialog open={showDocumentTagDialog} onOpenChange={setShowDocumentTagDialog}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl font-semibold">
              Other Claim Documents Detected
            </AlertDialogTitle>
            <AlertDialogDescription className="text-base leading-relaxed pt-2">
              Some documents are tagged as <span className="font-semibold text-foreground">"Bills for some other claims or person"</span>. 
              <br /><br />
              Would you like to create a new claim or add an extension to the existing claim?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col sm:flex-col gap-2 sm:gap-2">
            <AlertDialogAction
              className="w-full"
              onClick={() => {
                setShowDocumentTagDialog(false);
                toast({
                  title: "Creating New Claim",
                  description: "Redirecting to create a new claim with the tagged documents.",
                });
                // Navigate to create new claim
                navigate('/register-new-claim');
              }}
            >
              Create a New Claim
            </AlertDialogAction>
            <AlertDialogAction
              className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/80"
              onClick={() => {
                setShowDocumentTagDialog(false);
                toast({
                  title: "Creating Extension",
                  description: "Adding an extension to the current claim with the tagged documents.",
                });
                // Logic to create extension
                if (onBack) onBack();
              }}
            >
              Create Extension to Same Claim
            </AlertDialogAction>
            <AlertDialogCancel className="w-full mt-0">
              Cancel
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Other Person Bill Alert Dialog */}
      <AlertDialog open={showOtherPersonBillDialog} onOpenChange={setShowOtherPersonBillDialog}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl font-semibold">
              Bill for Different Person Detected
            </AlertDialogTitle>
            <AlertDialogDescription className="text-base leading-relaxed pt-2">
              You have marked one or more documents as <span className="font-semibold text-foreground">"Bill is for some other person (Name not matching)"</span>. 
              <br /><br />
              Would you like to create a new claim or add an extension to the existing claim?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col sm:flex-col gap-2 sm:gap-2">
            <AlertDialogAction
              className="w-full"
              onClick={() => {
                setShowOtherPersonBillDialog(false);
                toast({
                  title: "Creating New Claim",
                  description: "Redirecting to create a new claim for the different person.",
                });
                navigate('/register-claim');
              }}
            >
              Create a New Claim
            </AlertDialogAction>
            <AlertDialogAction
              className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/80"
              onClick={() => {
                setShowOtherPersonBillDialog(false);
                setIsCreatingExtension(true);
                setShowBackToLookup(true);
                setIsPatientPolicyModalOpen(true);
                toast({
                  title: "Creating Extension",
                  description: "Please select a policy for the extension to the current claim.",
                });
              }}
            >
              Create Extension to Same Claim
            </AlertDialogAction>
            <AlertDialogCancel className="w-full mt-0">
              Cancel
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Raise Query Dialog */}
      <Dialog open={isRaiseQueryDialogOpen} onOpenChange={setIsRaiseQueryDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Raise Query</DialogTitle>
            <DialogDescription>
              Select the reason(s) for raising a query and provide additional details if needed.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Standard Query Reasons */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Reason for Query</Label>
              <div className="space-y-2">
                {[
                  'Documents are not readable/clear',
                  'Mandatory documents are missing',
                  'Documents are not relevant to the claim',
                  'Patient name mismatch in documents',
                  'Bill dates are inconsistent',
                  'Treatment details are unclear',
                  'Other'
                ].map((reason) => (
                  <div key={reason} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={reason}
                      checked={queryReasons.includes(reason)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setQueryReasons([...queryReasons, reason]);
                        } else {
                          setQueryReasons(queryReasons.filter(r => r !== reason));
                        }
                      }}
                      className="h-4 w-4 rounded border-input"
                    />
                    <Label htmlFor={reason} className="text-sm font-normal cursor-pointer">
                      {reason}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Free Text Area */}
            <div className="space-y-2">
              <Label htmlFor="query-details" className="text-sm font-medium">
                Additional Details
              </Label>
              <Textarea
                id="query-details"
                placeholder="Provide any additional information about the query..."
                value={queryFreeText}
                onChange={(e) => setQueryFreeText(e.target.value)}
                rows={4}
                className="resize-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setIsRaiseQueryDialogOpen(false);
                setQueryReasons([]);
                setQueryFreeText('');
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (queryReasons.length === 0 && !queryFreeText.trim()) {
                  toast({
                    title: "Error",
                    description: "Please select at least one reason or provide details.",
                    variant: "destructive"
                  });
                  return;
                }
                
                toast({
                  title: "Query Raised Successfully",
                  description: "The query has been submitted for review.",
                });
                
                setIsRaiseQueryDialogOpen(false);
                setQueryReasons([]);
                setQueryFreeText('');
              }}
            >
              Submit Query
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Communication Content Dialog */}
      <Dialog open={!!selectedCommunication} onOpenChange={(open) => !open && setSelectedCommunication(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <div className="flex items-center gap-2">
              <div className={cn(
                "p-2 rounded-full",
                selectedCommunication?.type === 'Email' && "bg-blue-500/10 text-blue-600",
                selectedCommunication?.type === 'SMS' && "bg-green-500/10 text-green-600",
                selectedCommunication?.type === 'Phone Call' && "bg-orange-500/10 text-orange-600"
              )}>
                {selectedCommunication?.type === 'Email' && <Mail className="h-4 w-4" />}
                {selectedCommunication?.type === 'SMS' && <MessageSquare className="h-4 w-4" />}
                {selectedCommunication?.type === 'Phone Call' && <Phone className="h-4 w-4" />}
              </div>
              <div>
                <DialogTitle className="text-base">{selectedCommunication?.subject}</DialogTitle>
                <DialogDescription className="text-xs">
                  {selectedCommunication?.type} • {selectedCommunication?.direction} • {selectedCommunication?.timestamp}
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>
          
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm">
              <Badge variant="outline" className={cn(
                "text-xs",
                selectedCommunication?.recipientType === 'Customer' && "border-primary text-primary",
                selectedCommunication?.recipientType === 'Hospital' && "border-purple-500 text-purple-600"
              )}>
                {selectedCommunication?.recipientType}
              </Badge>
              <span className="text-muted-foreground">{selectedCommunication?.recipient}</span>
              {selectedCommunication?.hasAttachment && (
                <Badge variant="secondary" className="text-xs">
                  <Paperclip className="h-3 w-3 mr-1" />
                  Attachment
                </Badge>
              )}
            </div>
            
            <div className="border rounded-lg p-4 bg-muted/30 max-h-[300px] overflow-y-auto">
              <pre className="whitespace-pre-wrap text-sm font-sans">{selectedCommunication?.content}</pre>
            </div>
            
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>Status: <Badge variant="outline" className="text-xs ml-1">{selectedCommunication?.status}</Badge></span>
              {selectedCommunication?.duration && <span>Duration: {selectedCommunication.duration}</span>}
            </div>
          </div>
        </DialogContent>
      </Dialog>

    </div>
  );
};

export default ClaimDetailView;