import React, { useEffect, useState, useRef } from "react";
import { CheckCircle2, XCircle, HelpCircle, Loader2 } from "lucide-react";

type CheckStatus = 'passed' | 'failed' | 'inconclusive';

interface ChecklistSubItem {
  label: string;
  status: CheckStatus;
  detail?: string;
  reference?: string;
}

interface ChecklistCategory {
  id: string;
  title: string;
  objective: string;
  status: CheckStatus;
  items: ChecklistSubItem[];
  riskFlags?: ChecklistSubItem[];
  example?: string;
}

interface AnimatedEligibilityChecklistProps {
  categories: ChecklistCategory[];
  onAnimationComplete?: () => void;
  skipAnimation?: boolean;
  postAnimationDelay?: number; // Delay in ms before calling onAnimationComplete
}

export const AnimatedEligibilityChecklist: React.FC<AnimatedEligibilityChecklistProps> = ({
  categories,
  onAnimationComplete,
  skipAnimation = false,
  postAnimationDelay = 2000, // Default 2 second delay after animation completes
}) => {
  const [currentCategoryIndex, setCurrentCategoryIndex] = useState(skipAnimation ? categories.length : 0);
  const [currentSubItemIndex, setCurrentSubItemIndex] = useState(0);
  const [completedCategories, setCompletedCategories] = useState<Set<number>>(
    skipAnimation ? new Set(categories.map((_, i) => i)) : new Set()
  );
  const [completedSubItems, setCompletedSubItems] = useState<Map<number, Set<number>>>(
    skipAnimation 
      ? new Map(categories.map((cat, i) => [i, new Set(cat.items.map((_, j) => j))]))
      : new Map()
  );
  const [animationComplete, setAnimationComplete] = useState(skipAnimation);
  
  // Refs for auto-scrolling to current category
  const categoryRefs = useRef<Map<number, HTMLDivElement | null>>(new Map());

  // Auto-scroll to current category when it changes
  useEffect(() => {
    if (skipAnimation || animationComplete) return;
    
    const currentRef = categoryRefs.current.get(currentCategoryIndex);
    if (currentRef) {
      currentRef.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
      });
    }
  }, [currentCategoryIndex, skipAnimation, animationComplete]);

  useEffect(() => {
    if (skipAnimation || animationComplete) return;

    const currentCategory = categories[currentCategoryIndex];
    if (!currentCategory) {
      setAnimationComplete(true);
      // Add delay before calling onAnimationComplete
      const delayTimer = setTimeout(() => {
        onAnimationComplete?.();
      }, postAnimationDelay);
      return () => clearTimeout(delayTimer);
    }

    const timer = setTimeout(() => {
      // Mark current sub-item as completed
      setCompletedSubItems(prev => {
        const newMap = new Map(prev);
        const categorySet = newMap.get(currentCategoryIndex) || new Set();
        categorySet.add(currentSubItemIndex);
        newMap.set(currentCategoryIndex, categorySet);
        return newMap;
      });

      if (currentSubItemIndex < currentCategory.items.length - 1) {
        // Move to next sub-item
        setCurrentSubItemIndex(prev => prev + 1);
      } else {
        // Category complete, move to next category
        setCompletedCategories(prev => new Set([...prev, currentCategoryIndex]));
        if (currentCategoryIndex < categories.length - 1) {
          setCurrentCategoryIndex(prev => prev + 1);
          setCurrentSubItemIndex(0);
        } else {
          setAnimationComplete(true);
          // Add delay before calling onAnimationComplete
          const delayTimer = setTimeout(() => {
            onAnimationComplete?.();
          }, postAnimationDelay);
          return () => clearTimeout(delayTimer);
        }
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [currentCategoryIndex, currentSubItemIndex, categories, skipAnimation, animationComplete, onAnimationComplete, postAnimationDelay]);

  const getStatusIcon = (status: CheckStatus, size: string = "h-5 w-5") => {
    switch (status) {
      case 'passed':
        return <CheckCircle2 className={`${size} text-emerald-600`} />;
      case 'failed':
        return <XCircle className={`${size} text-destructive`} />;
      case 'inconclusive':
        return <HelpCircle className={`${size} text-amber-600`} />;
    }
  };

  return (
    <div className="space-y-4">
      {/* Header - changes based on animation state */}
      <h3 className="text-lg font-semibold text-foreground leading-tight">
        {animationComplete ? (
          "Eligibility check complete."
        ) : (
          "This will take just a few mins, we are checking the eligibility."
        )}
      </h3>
      
      {/* Checklist categories with sub-items */}
      <div className="space-y-4">
        {categories.map((category, categoryIdx) => {
          const isCurrentCategory = categoryIdx === currentCategoryIndex && !animationComplete;
          const isCategoryCompleted = completedCategories.has(categoryIdx);
          const isPendingCategory = categoryIdx > currentCategoryIndex && !animationComplete;
          const categorySubItems = completedSubItems.get(categoryIdx) || new Set();

          return (
            <div 
              key={category.id}
              ref={(el) => categoryRefs.current.set(categoryIdx, el)}
              className={`transition-opacity duration-300 ${
                isPendingCategory ? 'opacity-30' : 'opacity-100'
              }`}
            >
              {/* Category Header */}
              <div className="flex items-start gap-3 mb-2">
                {/* Category Icon */}
                <div className="flex-shrink-0 mt-0.5">
                  {isCategoryCompleted ? (
                    <div className="animate-scale-in">
                      {getStatusIcon(category.status)}
                    </div>
                  ) : isCurrentCategory ? (
                    <Loader2 className="h-5 w-5 text-primary animate-spin" />
                  ) : (
                    <div className="h-5 w-5 rounded-full border-2 border-muted-foreground/30" />
                  )}
                </div>
                
                {/* Category Title */}
                <p className={`font-medium text-sm ${
                  isCategoryCompleted
                    ? category.status === 'passed' 
                      ? 'text-foreground' 
                      : category.status === 'failed' 
                        ? 'text-destructive' 
                        : 'text-amber-700 dark:text-amber-400'
                    : isCurrentCategory
                      ? 'text-foreground'
                      : 'text-muted-foreground'
                }`}>
                  {category.title}
                </p>
              </div>

              {/* Sub-items - show when category is current or completed */}
              {(isCurrentCategory || isCategoryCompleted) && (
                <div className="ml-8 space-y-1.5">
                  {category.items.map((item, itemIdx) => {
                    const isSubItemCompleted = categorySubItems.has(itemIdx);
                    const isCurrentSubItem = isCurrentCategory && itemIdx === currentSubItemIndex && !isSubItemCompleted;
                    const isPendingSubItem = isCurrentCategory && itemIdx > currentSubItemIndex;

                    // Don't show pending sub-items
                    if (isPendingSubItem && !isCategoryCompleted) return null;

                    return (
                      <div 
                        key={itemIdx}
                        className={`flex items-start gap-2 animate-fade-in ${
                          isCurrentSubItem ? 'opacity-70' : 'opacity-100'
                        }`}
                      >
                        {/* Sub-item Icon */}
                        <div className="flex-shrink-0 mt-0.5">
                          {isSubItemCompleted ? (
                            <div className="animate-scale-in">
                              {getStatusIcon(item.status, "h-4 w-4")}
                            </div>
                          ) : isCurrentSubItem ? (
                            <Loader2 className="h-4 w-4 text-primary animate-spin" />
                          ) : null}
                        </div>
                        
                        {/* Sub-item Content */}
                        <div className="flex-1">
                          <p className={`text-xs ${
                            isSubItemCompleted
                              ? item.status === 'passed' 
                                ? 'text-muted-foreground' 
                                : item.status === 'failed' 
                                  ? 'text-destructive' 
                                  : 'text-amber-700 dark:text-amber-400'
                              : 'text-muted-foreground'
                          }`}>
                            {item.label}
                            {item.detail && (
                              <span className="opacity-70 ml-1">({item.detail})</span>
                            )}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AnimatedEligibilityChecklist;
