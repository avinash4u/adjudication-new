import React, { useEffect, useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { useToast } from "@/components/ui/use-toast";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { AlertCircle, Mail, CalendarIcon, Sparkles, CheckCircle2, XCircle, HelpCircle, Search, Users, AlertTriangle, Info, ShieldCheck, Send, ExternalLink } from "lucide-react";
import { format } from "date-fns";
import { AnimatedEligibilityChecklist } from "./AnimatedEligibilityChecklist";

type StatusAction =
  | "complete"
  | "query"
  | "investigation"
  | "crm"
  | "senior"
  | "uw"
  | "reject";

interface ReasonOption {
  id: string;
  label: string;
  template: string;
  clause?: string;
}

const QUERY_REASON_OPTIONS: ReasonOption[] = [
  {
    id: "missing-documents",
    label: "Missing or illegible documents",
    template:
      "We have observed that certain supporting documents are missing or not clearly legible for bill {billNumber} dated {billDate}.",
  },
  {
    id: "amount-mismatch",
    label: "Mismatch in billed and claimed amount",
    template:
      "There appears to be a mismatch between the billed amount and the amount claimed for bill {billNumber} dated {billDate}.",
  },
  {
    id: "clarification-diagnosis",
    label: "Clarification on diagnosis / treatment",
    template:
      "We require further clarification on the diagnosis and line of treatment mentioned in the claim documents.",
  },
];

const INVESTIGATION_REASON_OPTIONS: ReasonOption[] = [
  {
    id: "high-cost",
    label: "High value / high utilisation case",
    template:
      "The claim falls under a high value / high utilisation category and needs detailed investigation.",
  },
  {
    id: "clinical-doubt",
    label: "Clinical appropriateness doubts",
    template:
      "There are doubts regarding the clinical appropriateness of the treatment and length of stay.",
  },
  {
    id: "fraud-trigger",
    label: "Potential fraud trigger",
    template:
      "Certain red flags in the claim details have triggered the need for an investigation.",
  },
];

const REJECTION_REASON_OPTIONS: ReasonOption[] = [
  {
    id: "non-disclosure",
    label: "Non-disclosure of material facts",
    template:
      "The claim is being rejected due to non-disclosure of material facts at the time of policy inception.",
    clause:
      "As per Policy Terms & Conditions on Non-disclosure, any misrepresentation or non-disclosure of material information shall render the claim inadmissible.",
  },
  {
    id: "waiting-period",
    label: "Within waiting period",
    template:
      "The ailment/procedure falls within the applicable waiting period under the policy.",
    clause:
      "Waiting Period Clause: Illnesses and procedures listed under the waiting period section are not payable during the specified waiting period from policy inception.",
  },
  {
    id: "exclusion",
    label: "Policy exclusion applies",
    template:
      "The ailment/procedure is specifically excluded under the policy terms and conditions.",
    clause:
      "Exclusion Clause: Expenses incurred towards diseases/conditions listed under permanent exclusions are not payable under the policy.",
  },
];

const CRM_REASON_OPTIONS: ReasonOption[] = [
  {
    id: "customer-complaint",
    label: "Customer complaint",
    template: "Customer has raised a complaint regarding the claim processing.",
  },
  {
    id: "escalation-request",
    label: "Escalation request",
    template: "Customer has requested escalation of the claim to higher authority.",
  },
  {
    id: "policy-clarification",
    label: "Policy clarification needed",
    template: "Customer needs clarification on policy terms and coverage.",
  },
  {
    id: "special-consideration",
    label: "Special consideration request",
    template: "Customer has requested special consideration for claim approval.",
  },
];

const SENIOR_ADJUDICATOR_REASON_OPTIONS: ReasonOption[] = [
  {
    id: "complex-case",
    label: "Complex case",
    template: "The claim involves complex medical or policy scenarios requiring senior review.",
  },
  {
    id: "high-value-claim",
    label: "High value claim",
    template: "The claim amount exceeds the threshold for standard adjudication.",
  },
  {
    id: "policy-interpretation",
    label: "Policy interpretation required",
    template: "The case requires senior guidance on policy interpretation.",
  },
  {
    id: "exception-approval",
    label: "Exception approval needed",
    template: "The claim requires exception approval beyond standard guidelines.",
  },
];

const UW_REASON_OPTIONS: ReasonOption[] = [
  {
    id: "pre-existing-review",
    label: "Pre-existing condition review",
    template: "The claim requires underwriting review for pre-existing conditions.",
  },
  {
    id: "non-disclosure-assessment",
    label: "Non-disclosure assessment",
    template: "Potential non-disclosure of material facts needs underwriting assessment.",
  },
  {
    id: "policy-terms-review",
    label: "Policy terms review",
    template: "The claim requires review of policy terms and conditions by underwriting.",
  },
  {
    id: "risk-assessment",
    label: "Risk assessment required",
    template: "Additional risk assessment is needed for this claim.",
  },
];

const MOCK_BILL_NUMBERS = ["BILL-001", "BILL-002", "BILL-003"];

// Checklist item status
type CheckStatus = 'passed' | 'failed' | 'inconclusive';

interface ChecklistSubItem {
  label: string;
  status: CheckStatus;
  detail?: string;
}

interface ChecklistCategory {
  id: string;
  title: string;
  objective: string;
  status: CheckStatus;
  items: ChecklistSubItem[];
  riskFlags?: ChecklistSubItem[];
  example?: string;
}

// Waiver interface
interface Waiver {
  id: string;
  type: 'document' | 'investigation' | 'waiting_period' | 'medical_checkup' | 'other';
  label: string;
  reason: string;
  approvedBy?: string;
  approvedOn?: string;
}

// System recommendation interface
interface SystemRecommendation {
  recommendedAction: StatusAction;
  confidence: 'high' | 'medium' | 'low';
  rationale?: string[]; // Deprecated
  keyFactors?: string[]; // Deprecated
  categories?: ChecklistCategory[];
  checklist?: ChecklistSubItem[]; // Backward compatibility for simple flat list
  aiSummary?: string;
  waivers?: Waiver[];
}

// Mock system recommendation with 8 organized categories
const MOCK_SYSTEM_RECOMMENDATION: SystemRecommendation = {
  recommendedAction: "complete",
  confidence: "high",
  categories: [
    {
      id: "member-policy",
      title: "Member & Policy Eligibility Checks",
      objective: "Confirm the claimant and policy are eligible for coverage.",
      status: "passed",
      items: [
        { label: "Member covered under policy on Date of Admission (DoA)", status: "passed", detail: "DoA: 15-Jan-2024 | Member: Rahul Sharma (UHID: MH-2024-78542)" },
        { label: "Policy active and valid during treatment period", status: "passed", detail: "Policy: ACKO-HLT-2023-456789 | Valid: 01-Apr-2023 to 31-Mar-2024" },
        { label: "Correct policy type applied (Retail / GMC / GPA)", status: "passed", detail: "Policy Type: Retail Health | Plan: Platinum Plus" },
        { label: "Insured person details match policy records", status: "passed", detail: "Name, DOB (15-Mar-1985), Gender (M) verified" },
        { label: "Coverage applicable for claimed benefit type (IPD/OPD/Daycare)", status: "passed", detail: "Benefit Type: IPD | Covered: Yes" },
      ],
    },
    {
      id: "disease-treatment",
      title: "Disease / Treatment Eligibility Checks",
      objective: "Validate medical appropriateness and coverage eligibility.",
      status: "passed",
      items: [
        { label: "Treatment covered under policy terms", status: "passed", detail: "Diagnosis: Acute Appendicitis | Treatment: Laparoscopic Appendectomy" },
        { label: "Correct ICD / procedure mapping", status: "passed", detail: "ICD-10: K35.80 | Procedure: 0DTJ4ZZ | Match: Valid" },
      ],
    },
    {
      id: "waiting-exclusion",
      title: "Waiting Period & Exclusion Checks",
      objective: "Ensure no policy restrictions are violated.",
      status: "passed",
      items: [
        { label: "No initial waiting period violation", status: "passed", detail: "Policy Start: 01-Apr-2023 | DoA: 15-Jan-2024 | Waiting: 30 days (Cleared)" },
        { label: "No disease-specific waiting period breach", status: "passed", detail: "Appendicitis: No specific waiting period applicable" },
        { label: "No pre-existing disease (PED) violation", status: "passed", detail: "PED Declaration: None | History: No prior conditions disclosed" },
        { label: "No permanent exclusion applicable", status: "passed", detail: "Exclusion Check: Appendectomy not in exclusion list" },
        { label: "No sub-limit breach specific to disease/procedure", status: "passed", detail: "Procedure Sub-limit: None | Full coverage applicable" },
      ],
    },
    {
      id: "hospital-network",
      title: "Hospital & Network Validation",
      objective: "Validate provider legitimacy and network applicability.",
      status: "passed",
      items: [
        { label: "Hospital empanelled / network status verified", status: "passed", detail: "Hospital: Max Super Speciality, Saket | ROHINI ID: HOSP-DEL-4521" },
        { label: "Correct hospital category applied (Network / Non-network)", status: "passed", detail: "Category: Network Hospital | Tier: A | Discount: 15%" },
      ],
    },
    {
      id: "financial-tariff",
      title: "Financial & Tariff Compliance Checks",
      objective: "Ensure claimed amounts are reasonable and policy-compliant.",
      status: "passed",
      items: [
        { label: "Sum Insured sufficient", status: "passed", detail: "SI: ₹9,00,000 | Utilized: ₹1,10,200 (12%) | Available: ₹7,89,800" },
        { label: "Tariff rates compliant with agreed network pricing", status: "passed", detail: "Package: Appendectomy Lap | Agreed: ₹85,000 | Claimed: ₹82,500" },
        { label: "Room rent eligibility complied with", status: "passed", detail: "Entitled: ₹5,000/day | Availed: ₹4,500/day | Days: 3" },
        { label: "Procedure/package charges within limits", status: "passed", detail: "Package Limit: ₹1,00,000 | Billed: ₹82,500 | Within Limit: Yes" },
        { label: "Non-payables correctly excluded", status: "passed", detail: "Non-payables Identified: ₹4,500 (Toiletries, Registration)" },
      ],
    },
    {
      id: "prior-claims",
      title: "Prior Claims & History Analysis",
      objective: "Detect duplication, recurrence, or abuse patterns.",
      status: "passed",
      items: [
        { label: "No duplicate claim detected", status: "passed", detail: "Claims Search: No matching claims in last 12 months" },
        { label: "No related claims for same condition in recent period", status: "passed", detail: "Related Claims: None for Appendicitis or GI conditions" },
      ],
    },
    {
      id: "fraud-abuse",
      title: "Fraud & Abuse Risk Assessment",
      objective: "Identify signals requiring deeper scrutiny.",
      status: "passed",
      items: [
        { label: "Documents internally consistent", status: "passed", detail: "Cross-check: Discharge Summary ↔ Bills ↔ Reports | Status: Consistent" },
        { label: "No altered, forged, or templated documents", status: "passed", detail: "Document Analysis: Original hospital letterhead, unique formatting" },
        { label: "Billing consistent with clinical notes", status: "passed", detail: "Procedure Notes match billing items | No discrepancy found" },
        { label: "Length of stay appropriate for diagnosis", status: "passed", detail: "LoS: 3 days | Expected for Lap Appendectomy: 2-4 days | Appropriate" },
        { label: "No unusual cost inflation", status: "passed", detail: "Cost Variance: -3% below average | Benchmark: ₹85,000" },
        { label: "No known fraud patterns triggered", status: "passed", detail: "Pattern Match: 0 of 47 fraud indicators triggered" },
        { label: "Provider and member risk scores within acceptable range", status: "passed", detail: "Hospital Risk: Low (12/100) | Member Risk: Low (8/100)" },
      ],
    },
    {
      id: "documentation",
      title: "Documentation Completeness & Quality",
      objective: "Ensure decision can be defended.",
      status: "passed",
      items: [
        { label: "All mandatory documents submitted", status: "passed", detail: "Submitted: Claim Form, Discharge Summary, Bills, KYC, Pre-auth" },
        { label: "Documents legible and verifiable", status: "passed", detail: "Quality Score: 94/100 | All documents clear and readable" },
        { label: "Dates and timelines consistent", status: "passed", detail: "Admission: 15-Jan | Discharge: 18-Jan | Bills: 18-Jan | Claim: 20-Jan" },
      ],
    },
  ],
  aiSummary: "All eligibility criteria have been verified and the claim is recommended for approval. Documentation is complete, treatment is appropriate for the diagnosis, and no policy restrictions apply.",
  waivers: [
    {
      id: "waiver-1",
      type: "document",
      label: "Document Waiver",
      reason: "Original discharge summary not available; certified copy accepted",
      approvedBy: "System Auto-approval",
      approvedOn: "2024-01-15",
    },
    {
      id: "waiver-2",
      type: "investigation",
      label: "Investigation Waiver",
      reason: "Low-value claim below ₹50,000 threshold; investigation not required",
      approvedBy: "System Auto-Approval",
      approvedOn: "2024-01-14",
    },
  ],
};

const getRecommendationIcon = (action: StatusAction) => {
  switch (action) {
    case "complete":
      return <CheckCircle2 className="h-4 w-4" />;
    case "reject":
      return <XCircle className="h-4 w-4" />;
    case "query":
      return <HelpCircle className="h-4 w-4" />;
    case "investigation":
      return <Search className="h-4 w-4" />;
    default:
      return <Users className="h-4 w-4" />;
  }
};

const getRecommendationColor = (action: StatusAction) => {
  switch (action) {
    case "complete":
      return "bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-400";
    case "reject":
      return "bg-destructive/10 border-destructive/30 text-destructive";
    case "query":
    case "investigation":
      return "bg-amber-500/10 border-amber-500/30 text-amber-700 dark:text-amber-400";
    default:
      return "bg-blue-500/10 border-blue-500/30 text-blue-700 dark:text-blue-400";
  }
};

const getConfidenceBadge = (confidence: 'high' | 'medium' | 'low') => {
  switch (confidence) {
    case "high":
      return { label: "High Confidence", className: "bg-emerald-500/20 text-emerald-700 dark:text-emerald-400" };
    case "medium":
      return { label: "Medium Confidence", className: "bg-amber-500/20 text-amber-700 dark:text-amber-400" };
    case "low":
      return { label: "Low Confidence", className: "bg-red-500/20 text-red-700 dark:text-red-400" };
  }
};

// Mock deductions from financial adjudication
const MOCK_DEDUCTIONS = [
  { id: 1, category: "Room Rent Capping", billedAmount: 8000, allowedAmount: 5000, deduction: 3000, reason: "Room rent exceeds policy limit of ₹5,000/day" },
  { id: 2, category: "Non-Medical Items", billedAmount: 4500, allowedAmount: 0, deduction: 4500, reason: "Toiletries, tissue papers as per exclusion list" },
  { id: 3, category: "Consumables", billedAmount: 12000, allowedAmount: 9600, deduction: 2400, reason: "20% capping on consumables as per policy" },
  { id: 4, category: "Investigation Charges", billedAmount: 15000, allowedAmount: 12000, deduction: 3000, reason: "Repeat investigations not medically necessary" },
  { id: 5, category: "Pharmacy", billedAmount: 8000, allowedAmount: 6100, deduction: 1900, reason: "Brand to generic substitution applied" },
];

const getActionLabel = (action: StatusAction, customCompleteLabel?: string) => {
  switch (action) {
    case "complete":
      return customCompleteLabel || "Done, go to financial adjudication";
    case "query":
      return "Raise query";
    case "investigation":
      return "Raise investigation";
    case "crm":
      return "Refer to CRM";
    case "senior":
      return "Refer to Senior Adjudicator";
    case "uw":
      return "Refer to UW";
    case "reject":
      return "Reject claim";
    default:
      return "Update status";
  }
};

const getStatusBadgeVariant = (
  action: StatusAction,
): "success" | "warning" | "destructive" => {
  if (action === "complete") return "success";
  if (action === "reject") return "destructive";
  return "warning";
};

interface StatusNextActionCardProps {
  onReadyToComplete?: () => void;
  showDeductions?: boolean;
  completeActionLabel?: string;
  onStatusChange?: (action: StatusAction) => void;
  onChecklistViewChange?: (isShowingChecklist: boolean, isAnimationComplete: boolean) => void;
  onHideChecklist?: () => void; // Callback to notify when checklist should be hidden
  externalHideChecklistTrigger?: boolean; // External trigger to hide checklist
  systemRecommendation?: SystemRecommendation;
  defaultAction?: StatusAction;
  claimType?: 'Cashless' | 'Reimbursement';
  skipChecklistAnimation?: boolean; // Skip checklist animation and show AI summary directly
  hideActionButton?: boolean; // Hide the action button (used when footer button handles action)
}

const StatusNextActionCard: React.FC<StatusNextActionCardProps> = ({
  onReadyToComplete,
  showDeductions = false,
  completeActionLabel,
  onStatusChange,
  onChecklistViewChange,
  externalHideChecklistTrigger,
  systemRecommendation = MOCK_SYSTEM_RECOMMENDATION,
  defaultAction = "query",
  claimType = 'Cashless',
  skipChecklistAnimation = false,
  hideActionButton = false,
}) => {
  const { toast } = useToast();

  // Default to AI recommendation if available, otherwise use defaultAction prop
  const [selectedAction, setSelectedAction] = useState<StatusAction>(
    systemRecommendation?.recommendedAction || defaultAction
  );
  const [queryReasons, setQueryReasons] = useState<string[]>([]);
  const [investigationReasons, setInvestigationReasons] = useState<string[]>([]);
  const [rejectionReasons, setRejectionReasons] = useState<string[]>([]);
  const [crmReasons, setCrmReasons] = useState<string[]>([]);
  const [seniorReasons, setSeniorReasons] = useState<string[]>([]);
  const [uwReasons, setUwReasons] = useState<string[]>([]);
  const [emailContent, setEmailContent] = useState("");
  const [internalNotes, setInternalNotes] = useState("");
  const [billNumberInput, setBillNumberInput] = useState("");
  const [selectedBillDate, setSelectedBillDate] = useState<Date | undefined>();
  // If skipChecklistAnimation is true, start with animation complete and checklist hidden
  const [checklistAnimationComplete, setChecklistAnimationComplete] = useState(skipChecklistAnimation);
  const [showChecklistView, setShowChecklistView] = useState(!skipChecklistAnimation); // Skip checklist view if animation is skipped

  // Notify parent when checklist view state or animation state changes
  useEffect(() => {
    onChecklistViewChange?.(showChecklistView, checklistAnimationComplete);
  }, [showChecklistView, checklistAnimationComplete, onChecklistViewChange]);

  // Respond to external trigger to hide checklist view
  useEffect(() => {
    if (externalHideChecklistTrigger && showChecklistView && checklistAnimationComplete) {
      setShowChecklistView(false);
    }
  }, [externalHideChecklistTrigger, showChecklistView, checklistAnimationComplete]);

  // Get reason options for the current action
  const getReasonOptionsForAction = (action: StatusAction): ReasonOption[] => {
    switch (action) {
      case "query":
        return QUERY_REASON_OPTIONS;
      case "investigation":
        return INVESTIGATION_REASON_OPTIONS;
      case "crm":
        return CRM_REASON_OPTIONS;
      case "senior":
        return SENIOR_ADJUDICATOR_REASON_OPTIONS;
      case "uw":
        return UW_REASON_OPTIONS;
      case "reject":
        return REJECTION_REASON_OPTIONS;
      default:
        return [];
    }
  };

  // Get selected reasons for the current action
  const getSelectedReasonsForAction = (action: StatusAction): string[] => {
    switch (action) {
      case "query":
        return queryReasons;
      case "investigation":
        return investigationReasons;
      case "crm":
        return crmReasons;
      case "senior":
        return seniorReasons;
      case "uw":
        return uwReasons;
      case "reject":
        return rejectionReasons;
      default:
        return [];
    }
  };

  // Set selected reasons for the current action
  const setSelectedReasonsForAction = (action: StatusAction, reasons: string[]) => {
    switch (action) {
      case "query":
        setQueryReasons(reasons);
        break;
      case "investigation":
        setInvestigationReasons(reasons);
        break;
      case "crm":
        setCrmReasons(reasons);
        break;
      case "senior":
        setSeniorReasons(reasons);
        break;
      case "uw":
        setUwReasons(reasons);
        break;
      case "reject":
        setRejectionReasons(reasons);
        break;
    }
  };
  

  const buildEmailFromReasons = (
    action: StatusAction,
    reasonIds: string[],
  ) => {
    const mapOptions = getReasonOptionsForAction(action);

    const selected = mapOptions.filter((opt) => reasonIds.includes(opt.id));

    if (selected.length === 0) {
      return "";
    }

    const formatTemplate = (template: string) =>
      template
        .replace(/\{billNumber\}/g, "[bill number]")
        .replace(/\{billDate\}/g, "[bill date]");

    const reasonsText = selected
      .map((opt, index) => `${index + 1}. ${formatTemplate(opt.template)}`)
      .join("\n");

    if (action === "reject") {
      const clausesText = selected
        .map((opt, index) => {
          const clause = opt.clause ?? formatTemplate(opt.template);
          return `${index + 1}. ${clause}\nPolicy clause hyperlink: [Insert link to relevant clause in policy document]`;
        })
        .join("\n\n");
      return clausesText;
    }

    return reasonsText;
  };

  // Notify parent of status changes
  useEffect(() => {
    onStatusChange?.(selectedAction);
  }, [selectedAction, onStatusChange]);

  useEffect(() => {
    const currentReasons = getSelectedReasonsForAction(selectedAction);
    if (selectedAction !== "complete" && currentReasons.length > 0) {
      setEmailContent(buildEmailFromReasons(selectedAction, currentReasons));
    } else {
      setEmailContent("");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedAction, queryReasons, investigationReasons, rejectionReasons, crmReasons, seniorReasons, uwReasons]);

  const handleSubmit = () => {
    const currentReasons = getSelectedReasonsForAction(selectedAction);
    
    if (selectedAction === "complete") {
      if (onReadyToComplete) {
        onReadyToComplete();
      }
      toast({
        title: "Proceeding to next step",
        description: "Moving to financial adjudication.",
      });
      return;
    }
    
    // For actions that require reasons
    if (currentReasons.length === 0 && !emailContent.trim()) {
      toast({
        title: "Select a reason",
        description: `Please choose a reason for ${getActionLabel(selectedAction)}.`,
        variant: "destructive",
      });
      return;
    }

    const selectedReasonLabel = currentReasons.length > 0 
      ? getReasonOptionsForAction(selectedAction).find(o => o.id === currentReasons[0])?.label 
      : "";

    if (selectedAction === "query") {
      toast({
        title: "Query raised",
        description: `Query raised: ${selectedReasonLabel}`,
      });
    } else if (selectedAction === "investigation") {
      toast({
        title: "Investigation raised",
        description: `Investigation raised: ${selectedReasonLabel}`,
      });
    } else if (selectedAction === "crm") {
      toast({
        title: "Referred to CRM",
        description: `Reason: ${selectedReasonLabel}`,
      });
    } else if (selectedAction === "senior") {
      toast({
        title: "Referred to Senior Adjudicator",
        description: `Reason: ${selectedReasonLabel}`,
      });
    } else if (selectedAction === "uw") {
      toast({
        title: "Referred to UW",
        description: `Reason: ${selectedReasonLabel}`,
      });
    } else if (selectedAction === "reject") {
      toast({
        title: "Claim rejected",
        description: `Rejection reason: ${selectedReasonLabel}`,
      });
    }

    // reset action-specific fields but keep the last selected action
    setInternalNotes("");
  };

  const renderReasonSelector = (
    options: ReasonOption[],
    values: string[],
    onChange: (next: string[]) => void,
  ) => (
    <div className="space-y-2">
      <div className="border border-border rounded-md p-3 bg-background max-h-48 overflow-y-auto">
        <div className="space-y-2">
          {options.map((reason) => {
            const checked = values.includes(reason.id);
            return (
              <label
                key={reason.id}
                className="flex items-start gap-2 cursor-pointer hover:bg-muted/50 rounded p-1.5 -mx-1.5 transition-colors"
              >
                <Checkbox
                  checked={checked}
                  onCheckedChange={(isChecked) => {
                    if (isChecked) {
                      onChange([...values, reason.id]);
                    } else {
                      onChange(values.filter((id) => id !== reason.id));
                    }
                  }}
                  className="mt-0.5"
                />
                <span className="text-xs leading-snug text-foreground">{reason.label}</span>
              </label>
            );
          })}
        </div>
      </div>
    </div>
  );

  const selectedRejectionClauses = REJECTION_REASON_OPTIONS.filter((opt) =>
    rejectionReasons.includes(opt.id),
  );

  const hasBillNumberPlaceholder = /\[bill number\]/i.test(emailContent);
  const hasBillDatePlaceholder = /\[bill date\]/i.test(emailContent);

  const applyBillNumber = (value: string) => {
    if (!value.trim()) return;
    setEmailContent((prev) => prev.replace(/\[bill number\]/gi, value.trim()));
  };

  const applyBillDate = (date: Date | undefined) => {
    if (!date) return;
    const formatted = format(date, "dd/MM/yyyy");
    setSelectedBillDate(date);
    setEmailContent((prev) => prev.replace(/\[bill date\]/gi, formatted));
  };

  return (
    <Card className="mt-2 overflow-visible">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <CardTitle className="text-sm flex items-center gap-2">
              <Mail className="h-4 w-4 text-primary" />
              Status &amp; Next Action
            </CardTitle>
            <p className="mt-1 text-xs text-muted-foreground">
              Capture the next action on this claim and prepare the communication.
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4 overflow-visible">
        {/* Show Checklist View during animation */}
        {showChecklistView && (
          <div className={`p-3 rounded-lg border overflow-visible ${
            checklistAnimationComplete 
              ? getRecommendationColor(systemRecommendation.recommendedAction)
              : 'bg-muted/30 border-border text-foreground'
          }`}>
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-0.5">
                <div className={`p-1.5 rounded-full ${checklistAnimationComplete ? 'bg-current/10' : 'bg-primary/10'}`}>
                  <Sparkles className={`h-4 w-4 ${checklistAnimationComplete ? '' : 'text-primary'}`} />
                </div>
              </div>
              <div className="flex-1 space-y-2 overflow-visible">
                {/* Header - shows "Checking..." during animation, shows recommendation after complete */}
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  {checklistAnimationComplete ? (
                    <>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold">System Recommendation:</span>
                        <div className="flex items-center gap-1.5">
                          {getRecommendationIcon(systemRecommendation.recommendedAction)}
                          <span className="text-xs font-medium">
                            {getActionLabel(systemRecommendation.recommendedAction, completeActionLabel)}
                          </span>
                        </div>
                      </div>
                      <Badge variant="secondary" className={`text-[10px] ${getConfidenceBadge(systemRecommendation.confidence).className}`}>
                        {getConfidenceBadge(systemRecommendation.confidence).label}
                      </Badge>
                    </>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-muted-foreground">Admissibility check in progress...</span>
                    </div>
                  )}
                </div>
                
                {/* Animated Category-based Eligibility Checklist */}
                {systemRecommendation.categories && systemRecommendation.categories.length > 0 && (
                  <AnimatedEligibilityChecklist 
                    categories={systemRecommendation.categories}
                    onAnimationComplete={() => {
                      setChecklistAnimationComplete(true);
                      // Auto-transition to status view after animation completes
                      setTimeout(() => setShowChecklistView(false), 800);
                    }}
                    skipAnimation={checklistAnimationComplete}
                  />
                )}
                
                {/* Fallback for flat checklist (backward compatibility) */}
                {!systemRecommendation.categories && systemRecommendation.checklist && systemRecommendation.checklist.length > 0 && (
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-medium opacity-80">Eligibility Checklist:</p>
                    <div className="space-y-1">
                      {systemRecommendation.checklist.map((item, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-[11px]">
                          <div className="flex-shrink-0 mt-0.5">
                            {item.status === 'passed' && (
                              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                            )}
                            {item.status === 'failed' && (
                              <XCircle className="h-3.5 w-3.5 text-destructive" />
                            )}
                            {item.status === 'inconclusive' && (
                              <HelpCircle className="h-3.5 w-3.5 text-amber-600" />
                            )}
                          </div>
                          <div className="flex-1">
                            <span className={`${item.status === 'passed' ? 'opacity-75' : item.status === 'failed' ? 'text-destructive font-medium' : 'text-amber-700 font-medium'}`}>
                              {item.label}
                            </span>
                            {item.detail && (
                              <span className="text-[10px] opacity-60 ml-1">({item.detail})</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Fallback for legacy rationale format */}
                {!systemRecommendation.categories && !systemRecommendation.checklist && systemRecommendation.rationale && (
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-medium opacity-80">Rationale:</p>
                    <ul className="space-y-0.5">
                      {systemRecommendation.rationale.map((item, idx) => (
                        <li key={idx} className="text-[11px] opacity-75 flex items-start gap-1.5">
                          <span className="text-current mt-0.5">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {/* AI Summary - only shows after checklist animation completes */}
                {checklistAnimationComplete && systemRecommendation.aiSummary && (
                  <div className="pt-3 border-t border-current/10 animate-fade-in">
                    <p className="text-[11px] font-medium opacity-80 mb-1">AI Summary:</p>
                    <p className="text-[12px] opacity-85 leading-relaxed">{systemRecommendation.aiSummary}</p>
                  </div>
                )}
                
                {/* Applicable Waivers Section - only shows after checklist animation completes */}
                {checklistAnimationComplete && systemRecommendation.waivers && systemRecommendation.waivers.length > 0 && (
                  <div className="pt-3 border-t border-current/10 animate-fade-in">
                    <div className="flex items-center gap-1.5 mb-2">
                      <ShieldCheck className="h-3.5 w-3.5 text-blue-600" />
                      <p className="text-[11px] font-medium opacity-80">Applicable Waivers:</p>
                    </div>
                    <div className="space-y-2">
                      {systemRecommendation.waivers.map((waiver) => (
                        <div 
                          key={waiver.id} 
                          className="bg-blue-500/10 border border-blue-500/20 rounded-md p-2"
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <Badge 
                              variant="secondary" 
                              className="text-[9px] bg-blue-500/20 text-blue-700 dark:text-blue-400 px-1.5 py-0"
                            >
                              {waiver.label}
                            </Badge>
                            {waiver.approvedBy && (
                              <span className="text-[9px] text-muted-foreground">
                                by {waiver.approvedBy}
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] opacity-75">{waiver.reason}</p>
                          {waiver.approvedOn && (
                            <p className="text-[9px] text-muted-foreground mt-0.5">
                              Approved on: {waiver.approvedOn}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Show Status Section after checklist animation completes */}
        {!showChecklistView && (
          <div className="animate-fade-in space-y-4">
            {/* AI Recommendation Summary - shows prominently after checklist completes */}
            {systemRecommendation && (
              <div className={`p-3 rounded-lg border ${getRecommendationColor(systemRecommendation.recommendedAction)}`}>
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 mt-0.5">
                    <div className="p-1.5 rounded-full bg-current/10">
                      <Sparkles className="h-4 w-4" />
                    </div>
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold">AI Recommendation:</span>
                        <div className="flex items-center gap-1.5">
                          {getRecommendationIcon(systemRecommendation.recommendedAction)}
                          <span className="text-xs font-medium">
                            {getActionLabel(systemRecommendation.recommendedAction, completeActionLabel)}
                          </span>
                        </div>
                      </div>
                      <Badge variant="secondary" className={`text-[10px] ${getConfidenceBadge(systemRecommendation.confidence).className}`}>
                        {getConfidenceBadge(systemRecommendation.confidence).label}
                      </Badge>
                    </div>
                    
                    {/* AI Summary */}
                    {systemRecommendation.aiSummary && (
                      <div className="pt-2 border-t border-current/10">
                        <p className="text-[12px] opacity-85 leading-relaxed">{systemRecommendation.aiSummary}</p>
                      </div>
                    )}
                    
                    {/* Applicable Waivers Section */}
                    {systemRecommendation.waivers && systemRecommendation.waivers.length > 0 && (
                      <div className="pt-2 border-t border-current/10">
                        <div className="flex items-center gap-1.5 mb-2">
                          <ShieldCheck className="h-3.5 w-3.5 text-blue-600" />
                          <p className="text-[11px] font-medium opacity-80">Applicable Waivers:</p>
                        </div>
                        <div className="space-y-2">
                          {systemRecommendation.waivers.map((waiver) => (
                            <div 
                              key={waiver.id} 
                              className="bg-blue-500/10 border border-blue-500/20 rounded-md p-2"
                            >
                              <div className="flex items-center gap-2 mb-1">
                                <Badge 
                                  variant="secondary" 
                                  className="text-[9px] bg-blue-500/20 text-blue-700 dark:text-blue-400 px-1.5 py-0"
                                >
                                  {waiver.label}
                                </Badge>
                                {waiver.approvedBy && (
                                  <span className="text-[9px] text-muted-foreground">
                                    by {waiver.approvedBy}
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] opacity-75">{waiver.reason}</p>
                              {waiver.approvedOn && (
                                <p className="text-[9px] text-muted-foreground mt-0.5">
                                  Approved on: {waiver.approvedOn}
                                </p>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Link to view eligibility check details */}
            <button
              type="button"
              onClick={() => setShowChecklistView(true)}
              className="flex items-center gap-1.5 text-xs text-primary hover:underline"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              View eligibility check details
            </button>

            {/* Action selector - Pill-based selection */}
            <div className="space-y-3">
              <div className="space-y-2">
                <Label className="text-xs">Status</Label>
                <div className="flex flex-wrap gap-2">
                  {/* Complete/Approve pill */}
                  <button
                    type="button"
                    onClick={() => setSelectedAction("complete")}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
                      selectedAction === "complete"
                        ? "bg-success/20 border-success text-success ring-2 ring-success/30"
                        : "bg-muted/50 border-border text-muted-foreground hover:bg-muted hover:border-muted-foreground/30"
                    }`}
                  >
                    <span className={`h-2 w-2 rounded-full ${selectedAction === "complete" ? "bg-success" : "bg-success/50"}`} />
                    {completeActionLabel || "Done, go to financial adjudication"}
                  </button>

                  {/* Query pill */}
                  <button
                    type="button"
                    onClick={() => setSelectedAction("query")}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
                      selectedAction === "query"
                        ? "bg-warning/20 border-warning text-warning ring-2 ring-warning/30"
                        : "bg-muted/50 border-border text-muted-foreground hover:bg-muted hover:border-muted-foreground/30"
                    }`}
                  >
                    <span className={`h-2 w-2 rounded-full ${selectedAction === "query" ? "bg-warning" : "bg-warning/50"}`} />
                    Raise query
                  </button>

                  {/* Investigation pill */}
                  <button
                    type="button"
                    onClick={() => setSelectedAction("investigation")}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
                      selectedAction === "investigation"
                        ? "bg-warning/20 border-warning text-warning ring-2 ring-warning/30"
                        : "bg-muted/50 border-border text-muted-foreground hover:bg-muted hover:border-muted-foreground/30"
                    }`}
                  >
                    <span className={`h-2 w-2 rounded-full ${selectedAction === "investigation" ? "bg-warning" : "bg-warning/50"}`} />
                    Raise investigation
                  </button>

                  {/* CRM pill */}
                  <button
                    type="button"
                    onClick={() => setSelectedAction("crm")}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
                      selectedAction === "crm"
                        ? "bg-warning/20 border-warning text-warning ring-2 ring-warning/30"
                        : "bg-muted/50 border-border text-muted-foreground hover:bg-muted hover:border-muted-foreground/30"
                    }`}
                  >
                    <span className={`h-2 w-2 rounded-full ${selectedAction === "crm" ? "bg-warning" : "bg-warning/50"}`} />
                    Refer to CRM
                  </button>

                  {/* Senior Adjudicator pill */}
                  <button
                    type="button"
                    onClick={() => setSelectedAction("senior")}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
                      selectedAction === "senior"
                        ? "bg-warning/20 border-warning text-warning ring-2 ring-warning/30"
                        : "bg-muted/50 border-border text-muted-foreground hover:bg-muted hover:border-muted-foreground/30"
                    }`}
                  >
                    <span className={`h-2 w-2 rounded-full ${selectedAction === "senior" ? "bg-warning" : "bg-warning/50"}`} />
                    Refer to Senior
                  </button>

                  {/* UW pill */}
                  <button
                    type="button"
                    onClick={() => setSelectedAction("uw")}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
                      selectedAction === "uw"
                        ? "bg-warning/20 border-warning text-warning ring-2 ring-warning/30"
                        : "bg-muted/50 border-border text-muted-foreground hover:bg-muted hover:border-muted-foreground/30"
                    }`}
                  >
                    <span className={`h-2 w-2 rounded-full ${selectedAction === "uw" ? "bg-warning" : "bg-warning/50"}`} />
                    Refer to UW
                  </button>

                  {/* Reject pill */}
                  <button
                    type="button"
                    onClick={() => setSelectedAction("reject")}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
                      selectedAction === "reject"
                        ? "bg-destructive/20 border-destructive text-destructive ring-2 ring-destructive/30"
                        : "bg-muted/50 border-border text-muted-foreground hover:bg-muted hover:border-muted-foreground/30"
                    }`}
                  >
                    <span className={`h-2 w-2 rounded-full ${selectedAction === "reject" ? "bg-destructive" : "bg-destructive/50"}`} />
                    Reject claim
                  </button>
                </div>
              </div>

              {/* Secondary reason dropdown - shown for actions that have reasons (except query, reject) */}
              {selectedAction !== "complete" && selectedAction !== "query" && selectedAction !== "reject" && getReasonOptionsForAction(selectedAction).length > 0 && (
                <div className="space-y-1">
                  <Label className="text-xs">Reason</Label>
                  <Select
                    value={getSelectedReasonsForAction(selectedAction)[0] || ""}
                    onValueChange={(value) => {
                      if (value) {
                        setSelectedReasonsForAction(selectedAction, [value]);
                      }
                    }}
                  >
                    <SelectTrigger className="h-8 text-xs w-64">
                      <SelectValue placeholder="Select reason" />
                    </SelectTrigger>
                    <SelectContent>
                      {getReasonOptionsForAction(selectedAction).map((option) => (
                        <SelectItem key={option.id} value={option.id}>
                          <span className="text-xs">{option.label}</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <p className="text-[11px] text-muted-foreground">
                Choose the status and reason. Email content is auto-drafted based on selection.
              </p>
            </div>

            {/* Deductions Summary - shown when Approve claim is selected and showDeductions is true */}
            {selectedAction === "complete" && showDeductions && (
              <div className="space-y-3 p-4 bg-muted/30 rounded-lg border">
                <div className="flex items-center justify-between">
                  <Label className="text-xs font-medium">Deductions Summary</Label>
                  <Badge variant="secondary" className="text-xs">
                    Total: ₹{MOCK_DEDUCTIONS.reduce((sum, d) => sum + d.deduction, 0).toLocaleString()}
                  </Badge>
                </div>
                <div className="space-y-2">
                  {MOCK_DEDUCTIONS.map((deduction) => (
                    <div 
                      key={deduction.id} 
                      className="flex items-start justify-between gap-4 p-2 bg-background rounded border text-xs"
                    >
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{deduction.category}</span>
                          <span className="text-destructive font-medium">-₹{deduction.deduction.toLocaleString()}</span>
                        </div>
                        <p className="text-muted-foreground text-[11px]">{deduction.reason}</p>
                        <div className="flex gap-4 text-[11px] text-muted-foreground">
                          <span>Billed: ₹{deduction.billedAmount.toLocaleString()}</span>
                          <span>Allowed: ₹{deduction.allowedAmount.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-2 border-t text-sm">
                  <div className="space-y-1">
                    <div className="flex gap-6">
                      <span className="text-muted-foreground">Total Billed: <span className="font-medium text-foreground">₹1,25,000</span></span>
                      <span className="text-muted-foreground">Total Deductions: <span className="font-medium text-destructive">₹14,800</span></span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-muted-foreground">Net Payable: </span>
                    <span className="font-semibold text-primary text-base">₹1,10,200</span>
                  </div>
                </div>
              </div>
            )}

            {/* Action-specific sections */}
            {selectedAction === "query" && (
              <div className="space-y-3">
                <div className="space-y-1">
                  <Label className="text-xs">Query reasons</Label>
                  {renderReasonSelector(QUERY_REASON_OPTIONS, queryReasons, setQueryReasons)}
                </div>

                <div className="space-y-1">
                  <Label className="text-xs">Query comments</Label>
                  <Textarea
                    rows={6}
                    value={emailContent}
                    onChange={(e) => setEmailContent(e.target.value)}
                  />
                </div>

                {(hasBillNumberPlaceholder || hasBillDatePlaceholder) && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {hasBillNumberPlaceholder && (
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-6 text-[11px] px-2"
                            type="button"
                          >
                            [bill number]
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-64 space-y-2 p-3" align="start">
                          <Label className="text-[11px]">Select or enter bill number</Label>
                          <Input
                            value={billNumberInput}
                            onChange={(e) => setBillNumberInput(e.target.value)}
                            placeholder="Type bill number"
                            className="h-7 text-xs"
                          />
                          <div className="flex flex-wrap gap-1 pt-1">
                            {MOCK_BILL_NUMBERS.map((bill) => (
                              <Button
                                key={bill}
                                type="button"
                                size="sm"
                                variant="outline"
                                className="h-6 text-[11px] px-2"
                                onClick={() => applyBillNumber(bill)}
                              >
                                {bill}
                              </Button>
                            ))}
                          </div>
                          <div className="flex justify-end pt-1">
                            <Button
                              type="button"
                              size="sm"
                              onClick={() => applyBillNumber(billNumberInput)}
                            >
                              Apply
                            </Button>
                          </div>
                        </PopoverContent>
                      </Popover>
                    )}

                    {hasBillDatePlaceholder && (
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-6 text-[11px] px-2"
                            type="button"
                          >
                            [bill date]
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-2" align="start">
                          <div className="space-y-2">
                            <Label className="text-[11px] flex items-center gap-1">
                              <CalendarIcon className="h-3 w-3" />
                              Pick bill date
                            </Label>
                            <Calendar
                              mode="single"
                              selected={selectedBillDate}
                              onSelect={applyBillDate}
                              className="p-3 pointer-events-auto"
                            />
                          </div>
                        </PopoverContent>
                      </Popover>
                    )}
                  </div>
                )}
              </div>
            )}

            {(selectedAction === "crm" ||
              selectedAction === "senior" ||
              selectedAction === "uw") && (
              <div className="space-y-2">
                <Alert className="flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 mt-0.5 text-primary" />
                  <AlertDescription className="text-xs">
                    This action will be recorded internally and a task will be created for the
                    selected team. No external communication is generated from here.
                  </AlertDescription>
                </Alert>
              </div>
            )}

            {selectedAction === "reject" && (
              <div className="space-y-3">
                <div className="space-y-1">
                  <Label className="text-xs">Rejection reasons</Label>
                  {renderReasonSelector(
                    REJECTION_REASON_OPTIONS,
                    rejectionReasons,
                    setRejectionReasons,
                  )}
                </div>

                {selectedRejectionClauses.length > 0 && (
                  <div className="space-y-2">
                    <Label className="text-xs">Related rejection clauses</Label>
                    <div className="space-y-2">
                      {selectedRejectionClauses.map((reason) => (
                        <Alert
                          key={reason.id}
                          className="border-destructive/30 bg-destructive/5"
                        >
                          <AlertDescription className="text-xs">
                            <span className="font-semibold block mb-1">
                              {reason.label}
                            </span>
                            {reason.clause}
                          </AlertDescription>
                        </Alert>
                      ))}
                    </div>
                  </div>
                )}

                <div className="space-y-1">
                  <Label className="text-xs">Rejection comments</Label>
                  <Textarea
                    rows={6}
                    value={emailContent}
                    onChange={(e) => setEmailContent(e.target.value)}
                  />
                </div>
              </div>
            )}

            {/* Internal notes */}
            <div className="space-y-1">
              <Label className="text-xs">Internal notes (not shared with customer)</Label>
              <Textarea
                rows={3}
                value={internalNotes}
                onChange={(e) => setInternalNotes(e.target.value)}
                placeholder="Add any adjudication notes or context for the next handler."
              />
            </div>

            {/* Notification message for customer-facing actions */}
            {['query', 'investigation', 'complete', 'reject'].includes(selectedAction) && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-muted/50 border border-border/50 text-xs text-muted-foreground">
                <Send className="h-3.5 w-3.5 flex-shrink-0" />
                <span>
                  {claimType === 'Cashless' 
                    ? 'Hospital will be notified for this status change through multi-channel communications.'
                    : 'Customer will be notified for this status change through multi-channel communications.'}
                </span>
              </div>
            )}

            {!hideActionButton && (
              <div className="flex justify-end pt-2">
                <Button 
                  size="sm" 
                  type="button" 
                  onClick={() => {
                    if (showChecklistView) {
                      // When viewing checklist, just move to status section
                      setShowChecklistView(false);
                    } else if (selectedAction === "complete") {
                      if (onReadyToComplete) {
                        onReadyToComplete();
                      }
                    } else {
                      handleSubmit();
                    }
                  }}
                >
                  {showChecklistView ? "Next" : getActionLabel(selectedAction, completeActionLabel)}
                </Button>
              </div>
            )}
          </div>
        )}

      </CardContent>
    </Card>
  );
};

export default StatusNextActionCard;
