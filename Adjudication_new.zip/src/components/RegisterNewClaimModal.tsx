import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { X } from 'lucide-react';
import PatientIdentificationStep from './claim-registration/PatientIdentificationStep';
import DocumentUploadStep from './claim-registration/DocumentUploadStep';
import QueryDetailsStep from './claim-registration/QueryDetailsStep';

interface RegisterNewClaimModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const RegisterNewClaimModal: React.FC<RegisterNewClaimModalProps> = ({
  open,
  onOpenChange,
}) => {
  const [activeTab, setActiveTab] = useState('claim');
  
  // Claim registration states
  const [currentStep, setCurrentStep] = useState(0);
  const [patientData, setPatientData] = useState<any>(null);
  const [selectedPolicy, setSelectedPolicy] = useState<any>(null);
  const [selectedMember, setSelectedMember] = useState<any>(null);
  const [uploadedDocuments, setUploadedDocuments] = useState<any[]>([]);
  
  // Query registration states
  const [currentQueryStep, setCurrentQueryStep] = useState(0);
  const [querySelectedPolicy, setQuerySelectedPolicy] = useState<any>(null);
  const [querySelectedMember, setQuerySelectedMember] = useState<any>(null);
  const [queryDetails, setQueryDetails] = useState('');

  const steps = ['Patient Identification', 'Document Upload'];

  const handleNext = (data?: any) => {
    if (currentStep === 0) {
      // Patient Identification Step - capture policy and member
      setSelectedPolicy(data.policy);
      setSelectedMember(data.member);
      setCurrentStep(prev => Math.min(prev + 1, steps.length - 1));
    }
  };

  const handleSubmit = (data: any) => {
    console.log('Claim registered:', {
      policy: selectedPolicy,
      member: selectedMember,
      documents: data.documents,
    });
    handleClose();
  };

  const handleQuerySubmit = (data: any) => {
    console.log('Query registered:', {
      policy: querySelectedPolicy,
      member: querySelectedMember,
      queryDetails: queryDetails,
      documents: data.documents,
    });
    handleClose();
  };

  const handleQueryIdentificationNext = (data: any) => {
    setQuerySelectedPolicy(data.policy);
    setQuerySelectedMember(data.member);
    setCurrentQueryStep(1);
  };

  const handleQueryDetailsNext = (data: any) => {
    setQueryDetails(data.queryDetails);
    setCurrentQueryStep(2);
  };

  const handleQueryBack = () => {
    setCurrentQueryStep(prev => Math.max(prev - 1, 0));
  };

  const handleBack = () => {
    setCurrentStep(prev => Math.max(prev - 1, 0));
  };

  const handleClose = () => {
    setCurrentStep(0);
    setPatientData(null);
    setSelectedPolicy(null);
    setSelectedMember(null);
    setUploadedDocuments([]);
    setCurrentQueryStep(0);
    setQuerySelectedPolicy(null);
    setQuerySelectedMember(null);
    setQueryDetails('');
    setActiveTab('claim');
    onOpenChange(false);
  };

  const renderQueryStepContent = () => {
    switch (currentQueryStep) {
      case 0:
        return (
          <PatientIdentificationStep
            onNext={handleQueryIdentificationNext}
            onCancel={handleClose}
          />
        );
      case 1:
        return (
          <QueryDetailsStep
            policyData={querySelectedPolicy}
            memberData={querySelectedMember}
            onNext={handleQueryDetailsNext}
            onBack={handleQueryBack}
            onCancel={handleClose}
          />
        );
      case 2:
        return (
          <DocumentUploadStep
            policyData={querySelectedPolicy}
            memberData={querySelectedMember}
            onSubmit={handleQuerySubmit}
            onBack={handleQueryBack}
            onCancel={handleClose}
            isOptional={true}
          />
        );
      default:
        return null;
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <PatientIdentificationStep
            onNext={handleNext}
            onCancel={handleClose}
          />
        );
      case 1:
        return (
          <DocumentUploadStep
            policyData={selectedPolicy}
            memberData={selectedMember}
            onSubmit={handleSubmit}
            onBack={handleBack}
            onCancel={handleClose}
          />
        );
      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <DialogTitle className="text-xl font-semibold">
            Registration
          </DialogTitle>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleClose}
            className="h-6 w-6"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <div className="space-y-6">
          <RadioGroup value={activeTab} onValueChange={setActiveTab} className="flex flex-col space-y-3">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="claim" id="claim" />
              <Label htmlFor="claim" className="cursor-pointer font-normal">
                Register New Health Claim
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="query" id="query" />
              <Label htmlFor="query" className="cursor-pointer font-normal">
                Register Coverage Related Query
              </Label>
            </div>
          </RadioGroup>

          {activeTab === 'claim' && (
            <div className="space-y-6">
              {renderStepContent()}
            </div>
          )}
          
          {activeTab === 'query' && (
            <div className="space-y-6">
              {renderQueryStepContent()}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default RegisterNewClaimModal;