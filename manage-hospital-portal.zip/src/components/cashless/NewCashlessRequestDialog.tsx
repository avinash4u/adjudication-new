import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Plus, Search, Building2, Mail, MapPin, IndianRupee, Calendar, FileText, User, Shield, CheckCircle2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";

// Mock data for claims
const mockClaims = [
  {
    id: "CLM001",
    uhid: "UH12345",
    patientName: "Rajesh Kumar",
    mobile: "+91 98765 43210",
    email: "rajesh.kumar@email.com",
    policyNumber: "POL/2024/123456",
    policyHolder: "Rajesh Kumar",
    insuranceCompany: "Star Health Insurance",
    sumInsured: "₹5,00,000",
    availableLimit: "₹4,75,000",
    hospital: {
      name: "Apollo Hospital",
      address: "21, Greams Lane, Off Greams Road, Chennai - 600006",
      email: "cashless@apollochennai.com",
      tariff: "Premium Network - 15% discount"
    }
  },
  {
    id: "CLM002",
    uhid: "UH67890",
    patientName: "Priya Sharma",
    mobile: "+91 87654 32109",
    email: "priya.sharma@email.com",
    policyNumber: "POL/2024/789012",
    policyHolder: "Amit Sharma",
    insuranceCompany: "HDFC ERGO",
    sumInsured: "₹10,00,000",
    availableLimit: "₹9,50,000",
    hospital: {
      name: "Fortis Hospital",
      address: "Sector 62, Phase VIII, Mohali - 160062",
      email: "claims@fortismohali.com",
      tariff: "Standard Network - 10% discount"
    }
  }
];

type Step = "search" | "claimDetails" | "treatmentDetails" | "hospitalReview" | "finalConfirm";

export function NewCashlessRequestDialog() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<Step>("search");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchType, setSearchType] = useState<"claimId" | "mobile" | "email" | "uhid">("claimId");
  const [searchResults, setSearchResults] = useState<typeof mockClaims>([]);
  const [selectedClaim, setSelectedClaim] = useState<typeof mockClaims[0] | null>(null);
  
  // Treatment details form
  const [treatmentType, setTreatmentType] = useState("");
  const [estimatedCost, setEstimatedCost] = useState("");
  const [admissionDate, setAdmissionDate] = useState("");
  const [additionalNotes, setAdditionalNotes] = useState("");
  
  const { toast } = useToast();

  const handleSearch = () => {
    // Mock search - filter based on search query
    const results = mockClaims.filter(claim => {
      const query = searchQuery.toLowerCase();
      switch (searchType) {
        case "claimId":
          return claim.id.toLowerCase().includes(query);
        case "mobile":
          return claim.mobile.includes(query);
        case "email":
          return claim.email.toLowerCase().includes(query);
        case "uhid":
          return claim.uhid.toLowerCase().includes(query);
        default:
          return false;
      }
    });
    setSearchResults(results);
  };

  const handleSelectClaim = (claim: typeof mockClaims[0]) => {
    setSelectedClaim(claim);
    setStep("claimDetails");
  };

  const handleNextFromClaimDetails = () => {
    setStep("treatmentDetails");
  };

  const handleNextFromTreatmentDetails = () => {
    if (!treatmentType || !estimatedCost || !admissionDate) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    setStep("hospitalReview");
  };

  const handleNextFromHospitalReview = () => {
    setStep("finalConfirm");
  };

  const handleConfirm = () => {
    if (!selectedClaim) return;
    
    // Send email notification to hospital
    toast({
      title: "Request Initiated Successfully",
      description: `Cashless request has been sent to ${selectedClaim.hospital.name}. Hospital will receive notification at ${selectedClaim.hospital.email}`,
    });
    
    // Reset dialog
    handleClose();
  };

  const handleBack = () => {
    switch (step) {
      case "claimDetails":
        setStep("search");
        setSelectedClaim(null);
        break;
      case "treatmentDetails":
        setStep("claimDetails");
        break;
      case "hospitalReview":
        setStep("treatmentDetails");
        break;
      case "finalConfirm":
        setStep("hospitalReview");
        break;
    }
  };

  const handleClose = () => {
    setOpen(false);
    setStep("search");
    setSearchQuery("");
    setSearchResults([]);
    setSelectedClaim(null);
    setTreatmentType("");
    setEstimatedCost("");
    setAdmissionDate("");
    setAdditionalNotes("");
  };

  const getStepTitle = () => {
    switch (step) {
      case "search": return "Search Claim";
      case "claimDetails": return "Review Claim Details";
      case "treatmentDetails": return "Treatment Information";
      case "hospitalReview": return "Hospital Details";
      case "finalConfirm": return "Final Confirmation";
    }
  };

  const getStepDescription = () => {
    switch (step) {
      case "search": return "Search for a claim using Claim ID, Mobile, Email, or UHID";
      case "claimDetails": return "Review patient and policy information";
      case "treatmentDetails": return "Enter treatment details and estimated costs";
      case "hospitalReview": return "Review hospital details and applicable tariff";
      case "finalConfirm": return "Review all details before submitting the request";
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          New Request
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>{getStepTitle()}</DialogTitle>
          <DialogDescription>{getStepDescription()}</DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 max-h-[60vh]">
          <div className="pr-4">
            {step === "search" && (
              <div className="space-y-6 py-2">
                {/* Sample Search Values */}
                <Card className="p-4 bg-primary/5 border-primary/20">
                  <p className="text-sm font-medium mb-2">Try these sample values:</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-muted-foreground">Claim ID:</span>
                      <span className="font-mono ml-2">CLM001, CLM002</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Mobile:</span>
                      <span className="font-mono ml-2">98765, 87654</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Email:</span>
                      <span className="font-mono ml-2">rajesh.kumar@email.com</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">UHID:</span>
                      <span className="font-mono ml-2">UH12345, UH67890</span>
                    </div>
                  </div>
                </Card>

                {/* Search Section */}
                <div className="space-y-4">
                  <div className="flex gap-2">
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="searchQuery">Search by</Label>
                      <div className="flex gap-2">
                        <select
                          className="flex h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          value={searchType}
                          onChange={(e) => setSearchType(e.target.value as any)}
                        >
                          <option value="claimId">Claim ID</option>
                          <option value="mobile">Mobile</option>
                          <option value="email">Email</option>
                          <option value="uhid">UHID</option>
                        </select>
                        <Input
                          id="searchQuery"
                          placeholder={`Enter ${searchType}...`}
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                        />
                      </div>
                    </div>
                    <div className="self-end">
                      <Button onClick={handleSearch} className="gap-2">
                        <Search className="h-4 w-4" />
                        Search
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Search Results */}
                {searchResults.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="font-semibold text-sm">Search Results ({searchResults.length})</h3>
                    {searchResults.map((claim) => (
                      <Card
                        key={claim.id}
                        className="p-4 cursor-pointer hover:bg-accent transition-colors"
                        onClick={() => handleSelectClaim(claim)}
                      >
                        <div className="flex justify-between items-start">
                          <div className="space-y-2 flex-1">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">{claim.id}</Badge>
                              <Badge variant="secondary">{claim.uhid}</Badge>
                            </div>
                            <div>
                              <p className="font-semibold">{claim.patientName}</p>
                              <p className="text-sm text-muted-foreground">{claim.mobile}</p>
                              <p className="text-sm text-muted-foreground">{claim.email}</p>
                            </div>
                            <div className="pt-2 border-t">
                              <p className="text-sm font-medium">{claim.hospital.name}</p>
                            </div>
                          </div>
                          <Button size="sm" variant="ghost">
                            Select →
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}

                {searchQuery && searchResults.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No claims found matching your search.</p>
                  </div>
                )}
              </div>
            )}

            {step === "claimDetails" && selectedClaim && (
              <div className="space-y-6 py-2">
                {/* Patient Information */}
                <Card className="p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <User className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Patient Information</h3>
                  </div>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div>
                      <Label className="text-muted-foreground">Patient Name</Label>
                      <p className="font-medium mt-1">{selectedClaim.patientName}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">UHID</Label>
                      <p className="font-medium mt-1">{selectedClaim.uhid}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Mobile Number</Label>
                      <p className="font-medium mt-1">{selectedClaim.mobile}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Email</Label>
                      <p className="font-medium mt-1">{selectedClaim.email}</p>
                    </div>
                  </div>
                </Card>

                {/* Policy Information */}
                <Card className="p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <Shield className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Policy Information</h3>
                  </div>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div>
                      <Label className="text-muted-foreground">Policy Number</Label>
                      <p className="font-medium mt-1 font-mono text-sm">{selectedClaim.policyNumber}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Policy Holder</Label>
                      <p className="font-medium mt-1">{selectedClaim.policyHolder}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Insurance Company</Label>
                      <p className="font-medium mt-1">{selectedClaim.insuranceCompany}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Sum Insured</Label>
                      <p className="font-medium mt-1 text-success">{selectedClaim.sumInsured}</p>
                    </div>
                    <div className="md:col-span-2">
                      <Label className="text-muted-foreground">Available Limit</Label>
                      <p className="font-semibold mt-1 text-lg text-primary">{selectedClaim.availableLimit}</p>
                    </div>
                  </div>
                </Card>

                {/* Hospital Assignment */}
                <Card className="p-5 bg-muted/50">
                  <div className="flex items-center gap-2 mb-3">
                    <Building2 className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Assigned Hospital</h3>
                  </div>
                  <p className="font-medium">{selectedClaim.hospital.name}</p>
                  <p className="text-sm text-muted-foreground mt-1">{selectedClaim.hospital.address}</p>
                </Card>
              </div>
            )}

            {step === "treatmentDetails" && (
              <div className="space-y-6 py-2">
                <Card className="p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <FileText className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Treatment Details</h3>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="treatmentType">
                        Treatment Type <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="treatmentType"
                        placeholder="e.g., Cardiac Surgery, Orthopedic Treatment"
                        value={treatmentType}
                        onChange={(e) => setTreatmentType(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="estimatedCost">
                        Estimated Cost <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="estimatedCost"
                        placeholder="₹ Enter estimated amount"
                        value={estimatedCost}
                        onChange={(e) => setEstimatedCost(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="admissionDate">
                        Planned Admission Date <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="admissionDate"
                        type="date"
                        value={admissionDate}
                        onChange={(e) => setAdmissionDate(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="additionalNotes">Additional Notes (Optional)</Label>
                      <Textarea
                        id="additionalNotes"
                        placeholder="Add any relevant medical history, special requirements, or additional information..."
                        rows={4}
                        value={additionalNotes}
                        onChange={(e) => setAdditionalNotes(e.target.value)}
                      />
                    </div>
                  </div>
                </Card>

                {selectedClaim && (
                  <Card className="p-4 bg-primary/5 border-primary/20">
                    <p className="text-sm">
                      <strong>Available Limit:</strong> {selectedClaim.availableLimit}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Ensure estimated cost is within available policy limit
                    </p>
                  </Card>
                )}
              </div>
            )}

            {step === "hospitalReview" && selectedClaim && (
              <div className="space-y-6 py-2">
                <Card className="p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <Building2 className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Hospital Details</h3>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <Label className="text-muted-foreground">Hospital Name</Label>
                      <p className="font-semibold mt-1 text-lg">{selectedClaim.hospital.name}</p>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex gap-3">
                      <MapPin className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <Label className="text-muted-foreground">Address</Label>
                        <p className="text-sm mt-1">{selectedClaim.hospital.address}</p>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex gap-3">
                      <Mail className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <Label className="text-muted-foreground">Email</Label>
                        <p className="text-sm mt-1">{selectedClaim.hospital.email}</p>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex gap-3">
                      <IndianRupee className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <Label className="text-muted-foreground">Applicable Tariff</Label>
                        <Badge variant="secondary" className="mt-1">{selectedClaim.hospital.tariff}</Badge>
                      </div>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 bg-muted/50">
                  <p className="text-sm text-muted-foreground">
                    A notification will be sent to the hospital's email address to initiate the cashless approval process.
                  </p>
                </Card>
              </div>
            )}

            {step === "finalConfirm" && selectedClaim && (
              <div className="space-y-6 py-2">
                <Card className="p-5 border-primary/30 bg-primary/5">
                  <div className="flex items-center gap-2 mb-3">
                    <CheckCircle2 className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Review Summary</h3>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Please review all information before submitting the cashless request
                  </p>
                </Card>

                {/* Patient Summary */}
                <Card className="p-4">
                  <h4 className="font-semibold text-sm mb-3">Patient & Policy</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Patient:</span>
                      <span className="font-medium">{selectedClaim.patientName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">UHID:</span>
                      <span className="font-medium">{selectedClaim.uhid}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Policy:</span>
                      <span className="font-medium font-mono text-xs">{selectedClaim.policyNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Available Limit:</span>
                      <span className="font-semibold text-success">{selectedClaim.availableLimit}</span>
                    </div>
                  </div>
                </Card>

                {/* Treatment Summary */}
                <Card className="p-4">
                  <h4 className="font-semibold text-sm mb-3">Treatment Information</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Type:</span>
                      <span className="font-medium">{treatmentType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Estimated Cost:</span>
                      <span className="font-semibold">{estimatedCost}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Admission Date:</span>
                      <span className="font-medium">{admissionDate}</span>
                    </div>
                    {additionalNotes && (
                      <div className="pt-2 border-t">
                        <span className="text-muted-foreground block mb-1">Notes:</span>
                        <p className="text-xs">{additionalNotes}</p>
                      </div>
                    )}
                  </div>
                </Card>

                {/* Hospital Summary */}
                <Card className="p-4">
                  <h4 className="font-semibold text-sm mb-3">Hospital</h4>
                  <div className="space-y-2 text-sm">
                    <p className="font-medium">{selectedClaim.hospital.name}</p>
                    <p className="text-xs text-muted-foreground">{selectedClaim.hospital.address}</p>
                    <div className="flex justify-between items-center pt-2 border-t">
                      <span className="text-muted-foreground">Tariff:</span>
                      <Badge variant="secondary" className="text-xs">{selectedClaim.hospital.tariff}</Badge>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 bg-warning/10 border-warning/30">
                  <p className="text-sm font-medium">
                    ⚠️ Confirmation Notice
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Upon clicking "Submit Request", an email notification will be sent to <strong>{selectedClaim.hospital.email}</strong>. The hospital will review and process your cashless request.
                  </p>
                </Card>
              </div>
            )}
          </div>
        </ScrollArea>

        <div className="flex justify-between items-center mt-6 pt-4 border-t">
          {/* Progress indicator */}
          {step !== "search" && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <div className="flex gap-1">
                {["claimDetails", "treatmentDetails", "hospitalReview", "finalConfirm"].map((s, i) => (
                  <div
                    key={s}
                    className={`h-1.5 w-8 rounded-full ${
                      ["claimDetails", "treatmentDetails", "hospitalReview", "finalConfirm"].indexOf(step) >= i
                        ? "bg-primary"
                        : "bg-muted"
                    }`}
                  />
                ))}
              </div>
              <span>Step {["claimDetails", "treatmentDetails", "hospitalReview", "finalConfirm"].indexOf(step) + 1} of 4</span>
            </div>
          )}

          <div className="flex gap-3 ml-auto">
            {step === "search" ? (
              <Button type="button" variant="outline" onClick={handleClose}>
                Cancel
              </Button>
            ) : (
              <>
                <Button type="button" variant="outline" onClick={handleBack}>
                  Back
                </Button>
                {step === "claimDetails" && (
                  <Button onClick={handleNextFromClaimDetails}>
                    Next: Treatment Details
                  </Button>
                )}
                {step === "treatmentDetails" && (
                  <Button onClick={handleNextFromTreatmentDetails}>
                    Next: Hospital Review
                  </Button>
                )}
                {step === "hospitalReview" && (
                  <Button onClick={handleNextFromHospitalReview}>
                    Next: Final Review
                  </Button>
                )}
                {step === "finalConfirm" && (
                  <Button onClick={handleConfirm} className="gap-2">
                    <CheckCircle2 className="h-4 w-4" />
                    Submit Request
                  </Button>
                )}
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
