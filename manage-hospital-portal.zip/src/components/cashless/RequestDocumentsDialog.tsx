import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Mail } from "lucide-react";

interface RequestDocumentsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  hospital: string;
  claimId: string;
  patientName: string;
}

const COMMON_DOCUMENTS = [
  "Patient ID Proof",
  "Medical Reports",
  "Treatment Estimate",
  "Previous Medical History",
  "Diagnostic Test Results",
  "Prescription",
  "Admission Form",
  "Insurance Card Copy",
];

export function RequestDocumentsDialog({
  open,
  onOpenChange,
  hospital,
  claimId,
  patientName,
}: RequestDocumentsDialogProps) {
  const { toast } = useToast();
  const [selectedDocs, setSelectedDocs] = useState<string[]>([]);
  const [customMessage, setCustomMessage] = useState("");
  const [receiverEmail, setReceiverEmail] = useState("hospital@example.com");

  const handleToggleDoc = (doc: string) => {
    setSelectedDocs(prev =>
      prev.includes(doc)
        ? prev.filter(d => d !== doc)
        : [...prev, doc]
    );
  };

  const generateEmailTemplate = () => {
    const docsList = selectedDocs.length > 0
      ? selectedDocs.map((doc, idx) => `${idx + 1}. ${doc}`).join('\n')
      : "";

    return `Dear ${hospital} Team,

We are writing regarding the cashless claim request for:
- Claim ID: ${claimId}
- Patient Name: ${patientName}

To proceed with the approval, we require the following additional documents:

${docsList}

${customMessage ? `\nAdditional Notes:\n${customMessage}` : ''}

Please upload these documents at your earliest convenience to expedite the claim processing.

Thank you for your cooperation.

Best regards,
Claims Review Team`;
  };

  const handleSend = () => {
    if (selectedDocs.length === 0 && !customMessage.trim()) {
      toast({
        title: "No documents selected",
        description: "Please select at least one document or add a custom message.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Document Request Sent",
      description: `Email sent to ${hospital} requesting additional documents.`,
    });
    
    setSelectedDocs([]);
    setCustomMessage("");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Request Additional Documents
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Claim Info */}
          <div className="p-4 rounded-lg bg-muted/50 space-y-2">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Hospital:</span>
                <p className="font-medium">{hospital}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Claim ID:</span>
                <p className="font-medium">{claimId}</p>
              </div>
              <div className="col-span-2">
                <span className="text-muted-foreground">Patient:</span>
                <p className="font-medium">{patientName}</p>
              </div>
            </div>
          </div>

          {/* Email Details */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="sender-email">From (Sender)</Label>
              <Input
                id="sender-email"
                type="email"
                value="cashlessanywhere@acko.com"
                disabled
                className="bg-muted cursor-not-allowed"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="receiver-email">To (Hospital Email)</Label>
              <Input
                id="receiver-email"
                type="email"
                value={receiverEmail}
                onChange={(e) => setReceiverEmail(e.target.value)}
                placeholder="hospital@example.com"
              />
            </div>
          </div>

          {/* Document Selection */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Select Missing Documents</Label>
            <div className="grid grid-cols-2 gap-3">
              {COMMON_DOCUMENTS.map((doc) => (
                <div key={doc} className="flex items-center space-x-2">
                  <Checkbox
                    id={doc}
                    checked={selectedDocs.includes(doc)}
                    onCheckedChange={() => handleToggleDoc(doc)}
                  />
                  <label
                    htmlFor={doc}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {doc}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Custom Message */}
          <div className="space-y-3">
            <Label htmlFor="custom-message" className="text-base font-semibold">
              Additional Notes (Optional)
            </Label>
            <Textarea
              id="custom-message"
              placeholder="Add any specific requirements or notes..."
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              className="min-h-[100px]"
            />
          </div>

          {/* Email Preview */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Email Preview</Label>
            <div className="p-4 rounded-lg border bg-card text-sm whitespace-pre-wrap font-mono text-muted-foreground">
              {generateEmailTemplate()}
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSend}>
            Send Request
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
