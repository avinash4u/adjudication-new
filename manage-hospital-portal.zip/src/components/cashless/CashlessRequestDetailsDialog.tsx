import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Download, FileText, User, Clock, MessageSquare, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RequestDocumentsDialog } from "./RequestDocumentsDialog";
import { useState } from "react";

interface AuditLogEntry {
  id: number;
  action: string;
  user: string;
  timestamp: string;
  details?: string;
}

interface CashlessRequest {
  id: number;
  hospital: string;
  requestDate: string;
  completedDate?: string;
  claimId: string;
  patientName: string;
  estimatedAmount?: string;
  finalAmount?: string;
  status: string;
  outcome?: string;
  documents: string[];
}

interface CashlessRequestDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  request: CashlessRequest | null;
}

export function CashlessRequestDetailsDialog({
  open,
  onOpenChange,
  request,
}: CashlessRequestDetailsDialogProps) {
  const { toast } = useToast();
  const [requestDocsOpen, setRequestDocsOpen] = useState(false);

  if (!request) return null;

  const isPending = request.status === "Pending Review";

  const handleReject = () => {
    toast({
      title: "Request Rejected",
      description: `Cashless request ${request.claimId} has been rejected.`,
      variant: "destructive",
    });
    onOpenChange(false);
  };

  const handleApproveClaim = () => {
    toast({
      title: "Request Approved",
      description: `${request.claimId} approved for single claim processing.`,
    });
    onOpenChange(false);
  };

  const handleApproveOnboard = () => {
    toast({
      title: "Request Approved & Onboarding Initiated",
      description: `${request.hospital} will be onboarded to the network.`,
    });
    onOpenChange(false);
  };

  const auditLog: AuditLogEntry[] = [
    {
      id: 1,
      action: "Request Submitted",
      user: "Dr. Anil Kumar",
      timestamp: request.requestDate,
      details: "Initial cashless request created",
    },
    {
      id: 2,
      action: "Documents Uploaded",
      user: "Dr. Anil Kumar",
      timestamp: request.requestDate,
      details: "Medical reports and patient ID uploaded",
    },
    {
      id: 3,
      action: "Request Under Review",
      user: "System",
      timestamp: request.requestDate,
      details: "Assigned to review team",
    },
    {
      id: 4,
      action: "Hospital Verification",
      user: "Priya Sharma - Operations Team",
      timestamp: request.requestDate,
      details: "Hospital credentials verified",
    },
    ...(!isPending ? [{
      id: 5,
      action: "Comment Added",
      user: "Rahul Verma - Claims Manager",
      timestamp: request.completedDate || request.requestDate,
      details: request.status === "Rejected" 
        ? "Request rejected due to incomplete documentation. Patient ID proof and medical history were missing essential verification details."
        : "All documents verified and approved. Hospital credentials validated. Patient eligibility confirmed for the requested treatment.",
    }] : []),
    ...(!isPending ? [{
      id: 6,
      action: request.status === "Rejected" ? "Request Rejected" : "Request Approved",
      user: "Rahul Verma - Claims Manager",
      timestamp: request.completedDate,
      details: request.status === "Rejected" 
        ? request.outcome 
        : `Approved amount: ${request.finalAmount}`,
    }] : []),
  ];

  const documents = [
    { name: "Medical Report.pdf", size: "2.4 MB", uploadedBy: "Dr. Anil Kumar" },
    { name: "Patient ID Proof.pdf", size: "1.1 MB", uploadedBy: "Dr. Anil Kumar" },
    { name: "Treatment Estimate.pdf", size: "856 KB", uploadedBy: "Dr. Anil Kumar" },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Request Details</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Request Summary */}
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <p className="text-sm text-muted-foreground">Claim ID</p>
              <p className="font-semibold">{request.claimId}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Status</p>
              <Badge 
                variant="outline" 
                className={
                  request.status === "Pending Review"
                    ? "bg-warning/10 text-warning border-warning/20"
                    : request.status === "Completed"
                    ? "bg-success/10 text-success border-success/20"
                    : "bg-destructive/10 text-destructive border-destructive/20"
                }
              >
                {request.status}
              </Badge>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Hospital</p>
              <p className="font-medium">{request.hospital}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Patient Name</p>
              <p className="font-medium">{request.patientName}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">
                {isPending ? "Estimated Amount" : "Final Amount"}
              </p>
              <p className="font-semibold text-lg">
                {isPending ? request.estimatedAmount : request.finalAmount}
              </p>
            </div>
            {!isPending && request.outcome && (
              <div>
                <p className="text-sm text-muted-foreground">Outcome</p>
                <p className="font-medium">{request.outcome}</p>
              </div>
            )}
          </div>

          <Separator />

          {/* Documents Section */}
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Uploaded Documents
            </h3>
            <div className="space-y-3">
              {request.documents.map((docName, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 rounded-lg border bg-card"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded bg-primary/10">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{docName}</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="gap-2">
                    <Download className="h-4 w-4" />
                    Download
                  </Button>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Audit Timeline */}
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Activity Timeline
            </h3>
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border" />
              
              <div className="space-y-6">
                {auditLog.map((entry, index) => (
                  <div key={entry.id} className="relative pl-10">
                    {/* Timeline dot */}
                    <div className={`absolute left-2.5 top-1 w-3 h-3 rounded-full border-2 border-background ${
                      entry.action === "Comment Added" ? "bg-muted-foreground" : "bg-primary"
                    }`} />
                    
                    <div className={`p-4 rounded-lg border ${
                      entry.action === "Comment Added" ? "bg-muted/30" : "bg-card"
                    }`}>
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="font-semibold flex items-center gap-2">
                            {entry.action === "Comment Added" && <MessageSquare className="h-4 w-4" />}
                            {entry.action}
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <User className="h-3 w-3 text-muted-foreground" />
                            <p className="text-sm text-muted-foreground">{entry.user}</p>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground whitespace-nowrap">
                          {entry.timestamp}
                        </p>
                      </div>
                      {entry.details && (
                        <p className="text-sm text-muted-foreground mt-2">
                          {entry.details}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
                
                {/* Add Comment for Pending Requests */}
                {isPending && (
                  <div className="relative pl-10">
                    <div className="absolute left-2.5 top-1 w-3 h-3 rounded-full bg-muted-foreground border-2 border-background" />
                    
                    <div className="p-4 rounded-lg border bg-muted/30">
                      <Label htmlFor="reviewer-comment" className="font-semibold flex items-center gap-2 mb-3">
                        <MessageSquare className="h-4 w-4" />
                        Add Your Comment
                      </Label>
                      <Textarea
                        id="reviewer-comment"
                        placeholder="Add notes or comments about this request..."
                        className="min-h-[100px]"
                      />
                      <p className="text-sm text-muted-foreground mt-2">
                        Your comment will be saved with the decision
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {isPending && (
          <>
            <Separator />
            <DialogFooter className="gap-2 sm:gap-2 flex-wrap">
              <Button 
                variant="outline" 
                className="gap-2"
                onClick={() => setRequestDocsOpen(true)}
              >
                <Mail className="h-4 w-4" />
                Request Documents
              </Button>
              <div className="flex gap-2 ml-auto">
                <Button 
                  variant="outline" 
                  className="text-destructive border-destructive/20 hover:bg-destructive/10"
                  onClick={handleReject}
                >
                  Reject
                </Button>
                <Button 
                  className="bg-success hover:bg-success/90"
                  onClick={handleApproveClaim}
                >
                  Approve for Claim
                </Button>
                <Button onClick={handleApproveOnboard}>
                  Approve & Onboard
                </Button>
              </div>
            </DialogFooter>
          </>
        )}
      </DialogContent>

      <RequestDocumentsDialog
        open={requestDocsOpen}
        onOpenChange={setRequestDocsOpen}
        hospital={request.hospital}
        claimId={request.claimId}
        patientName={request.patientName}
      />
    </Dialog>
  );
}
