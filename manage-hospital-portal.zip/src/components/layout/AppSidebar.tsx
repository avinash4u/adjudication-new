import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Building2,
  DollarSign,
  CreditCard,
  Send,
  Settings,
  Activity,
  BarChart3,
  Palette,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";

const menuItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Provider Master", url: "/hospitals", icon: Building2 },
  { title: "Tariff Management", url: "/tariffs", icon: DollarSign },
  { title: "Manage Payment", url: "/payouts", icon: CreditCard },
  { title: "Cashless Anywhere", url: "/cashless", icon: Send },
  { title: "Manage Providers", url: "/manage", icon: Settings },
  { title: "Hospital Analytics", url: "/analytics", icon: BarChart3 },
  { title: "Design Variations", url: "/design-variations", icon: Palette },
];

export function AppSidebar() {
  const { open } = useSidebar();

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border p-4">
        <div className="flex items-center gap-2">
          <Activity className="h-6 w-6 text-sidebar-primary" />
          {open && (
            <div>
              <h2 className="font-semibold text-sidebar-foreground">ACKO</h2>
              <p className="text-xs text-sidebar-foreground/70">Hospital Portal</p>
            </div>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild tooltip={item.title}>
                    <NavLink
                      to={item.url}
                      end={item.url === "/"}
                      className={({ isActive }) =>
                        isActive
                          ? "bg-sidebar-accent text-sidebar-accent-foreground"
                          : "hover:bg-sidebar-accent/50"
                      }
                    >
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <div className="mt-auto border-t border-sidebar-border p-4">
        <SidebarTrigger className="w-full" />
      </div>
    </Sidebar>
  );
}
