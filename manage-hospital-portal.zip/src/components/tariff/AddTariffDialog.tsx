import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Plus, Upload, FileSpreadsheet, Check, ChevronsUpDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

import apolloHospitalImg from "@/assets/hospitals/apollo-hospital.jpg";
import fortisHospitalImg from "@/assets/hospitals/fortis-hospital.jpg";
import maxHospitalImg from "@/assets/hospitals/max-hospital.jpg";
import lilavatiHospitalImg from "@/assets/hospitals/lilavati-hospital.jpg";
import manipalHospitalImg from "@/assets/hospitals/manipal-hospital.jpg";
import medantaHospitalImg from "@/assets/hospitals/medanta-hospital.jpg";
import cloudnineHospitalImg from "@/assets/hospitals/cloudnine-hospital.jpg";
import kokilabenHospitalImg from "@/assets/hospitals/kokilaben-hospital.jpg";

const hospitals = [
  { id: 1, name: "Apollo Hospitals", image: apolloHospitalImg, location: "Multiple locations across India" },
  { id: 2, name: "Fortis Healthcare", image: fortisHospitalImg, location: "Multiple locations across India" },
  { id: 3, name: "Max Healthcare", image: maxHospitalImg, location: "Delhi NCR" },
  { id: 4, name: "Lilavati Hospital", image: lilavatiHospitalImg, location: "Mumbai" },
  { id: 5, name: "Manipal Hospitals", image: manipalHospitalImg, location: "Bangalore" },
  { id: 6, name: "Medanta - The Medicity", image: medantaHospitalImg, location: "Gurugram" },
  { id: 7, name: "Cloudnine Hospitals", image: cloudnineHospitalImg, location: "Multiple locations" },
  { id: 8, name: "Kokilaben Hospital", image: kokilabenHospitalImg, location: "Mumbai" },
];

export function AddTariffDialog() {
  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("manual");
  const [selectedHospital, setSelectedHospital] = useState("");
  const [comboboxOpen, setComboboxOpen] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    packageCode: "",
    packageName: "",
    opd: "",
    executiveOpd: "",
    general: "",
    twinSharing: "",
    semiPrivate: "",
    private: "",
    deluxe: "",
    superDeluxe: "",
    suite: "",
    presidentialSuite: "",
    vipRoom: "",
    vvipRoom: "",
    dayCare: "",
    ipdDiscount: "",
    opdDiscount: "",
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedHospital) {
      toast({
        title: "Error",
        description: "Please select a hospital",
        variant: "destructive",
      });
      return;
    }

    if (!formData.packageCode || !formData.packageName) {
      toast({
        title: "Error",
        description: "Package Code and Package Name are required",
        variant: "destructive",
      });
      return;
    }

    const hospital = hospitals.find(h => h.id.toString() === selectedHospital);
    toast({
      title: "Success",
      description: `Tariff added successfully for ${hospital?.name}`,
    });
    
    setFormData({
      packageCode: "",
      packageName: "",
      opd: "",
      executiveOpd: "",
      general: "",
      twinSharing: "",
      semiPrivate: "",
      private: "",
      deluxe: "",
      superDeluxe: "",
      suite: "",
      presidentialSuite: "",
      vipRoom: "",
      vvipRoom: "",
      dayCare: "",
      ipdDiscount: "",
      opdDiscount: "",
    });
    setSelectedHospital("");
    setOpen(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!selectedHospital) {
      toast({
        title: "Error",
        description: "Please select a hospital first",
        variant: "destructive",
      });
      e.target.value = "";
      return;
    }

    const validTypes = [
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/csv'
    ];

    if (!validTypes.includes(file.type)) {
      toast({
        title: "Error",
        description: "Please upload a valid Excel or CSV file",
        variant: "destructive",
      });
      return;
    }

    const hospital = hospitals.find(h => h.id.toString() === selectedHospital);
    toast({
      title: "Success",
      description: `File "${file.name}" uploaded successfully for ${hospital?.name}`,
    });
    
    setSelectedHospital("");
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <div className="inline-flex flex-col items-start gap-1">
        <DialogTrigger asChild>
          <Button className="gap-2 bg-muted text-muted-foreground hover:bg-muted cursor-not-allowed">
            <Plus className="h-4 w-4" />
            Add Tariff
          </Button>
        </DialogTrigger>
        <span className="text-xs text-muted-foreground ml-1">Not applicable in phase 1</span>
      </div>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Add Tariff</DialogTitle>
          <DialogDescription>
            Select a hospital and add tariff information
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2 mb-4">
          <Label htmlFor="hospital">
            Select Hospital <span className="text-destructive">*</span>
          </Label>
          <Popover open={comboboxOpen} onOpenChange={setComboboxOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                role="combobox"
                aria-expanded={comboboxOpen}
                className="w-full justify-between"
              >
                {selectedHospital
                  ? hospitals.find((hospital) => hospital.id.toString() === selectedHospital)?.name
                  : "Search and select hospital..."}
                <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[600px] p-0">
              <Command>
                <CommandInput placeholder="Search hospital by name or location..." />
                <CommandList>
                  <CommandEmpty>No hospital found.</CommandEmpty>
                  <CommandGroup>
                    {hospitals.map((hospital) => (
                      <CommandItem
                        key={hospital.id}
                        value={`${hospital.name} ${hospital.location}`}
                        onSelect={() => {
                          setSelectedHospital(hospital.id.toString());
                          setComboboxOpen(false);
                        }}
                      >
                        <Check
                          className={cn(
                            "mr-2 h-4 w-4",
                            selectedHospital === hospital.id.toString() ? "opacity-100" : "opacity-0"
                          )}
                        />
                        <div className="flex flex-col">
                          <span className="font-medium">{hospital.name}</span>
                          <span className="text-xs text-muted-foreground">{hospital.location}</span>
                        </div>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="manual">Manual Entry</TabsTrigger>
            <TabsTrigger value="upload">Bulk Upload</TabsTrigger>
          </TabsList>

          <TabsContent value="manual" className="mt-4">
            <form onSubmit={handleManualSubmit}>
              <ScrollArea className="h-[450px] pr-4">
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="packageCode">
                        Service/Package Code <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="packageCode"
                        placeholder="PKG000001"
                        value={formData.packageCode}
                        onChange={(e) => handleInputChange("packageCode", e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="packageName">
                        Service/Package Name <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="packageName"
                        placeholder="Package Name"
                        value={formData.packageName}
                        onChange={(e) => handleInputChange("packageName", e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="opd">OPD</Label>
                      <Input
                        id="opd"
                        type="number"
                        placeholder="0"
                        value={formData.opd}
                        onChange={(e) => handleInputChange("opd", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="executiveOpd">Executive OPD</Label>
                      <Input
                        id="executiveOpd"
                        type="number"
                        placeholder="0"
                        value={formData.executiveOpd}
                        onChange={(e) => handleInputChange("executiveOpd", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="general">General</Label>
                      <Input
                        id="general"
                        type="number"
                        placeholder="0"
                        value={formData.general}
                        onChange={(e) => handleInputChange("general", e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="twinSharing">Twin Sharing</Label>
                      <Input
                        id="twinSharing"
                        type="number"
                        placeholder="0"
                        value={formData.twinSharing}
                        onChange={(e) => handleInputChange("twinSharing", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="semiPrivate">Semi Private</Label>
                      <Input
                        id="semiPrivate"
                        type="number"
                        placeholder="0"
                        value={formData.semiPrivate}
                        onChange={(e) => handleInputChange("semiPrivate", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="private">Private</Label>
                      <Input
                        id="private"
                        type="number"
                        placeholder="0"
                        value={formData.private}
                        onChange={(e) => handleInputChange("private", e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="deluxe">Deluxe</Label>
                      <Input
                        id="deluxe"
                        type="number"
                        placeholder="0"
                        value={formData.deluxe}
                        onChange={(e) => handleInputChange("deluxe", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="superDeluxe">Super Deluxe</Label>
                      <Input
                        id="superDeluxe"
                        type="number"
                        placeholder="0"
                        value={formData.superDeluxe}
                        onChange={(e) => handleInputChange("superDeluxe", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="suite">Suite</Label>
                      <Input
                        id="suite"
                        type="number"
                        placeholder="0"
                        value={formData.suite}
                        onChange={(e) => handleInputChange("suite", e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="presidentialSuite">Presidential Suite</Label>
                      <Input
                        id="presidentialSuite"
                        type="number"
                        placeholder="0"
                        value={formData.presidentialSuite}
                        onChange={(e) => handleInputChange("presidentialSuite", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="vipRoom">VIP Room</Label>
                      <Input
                        id="vipRoom"
                        type="number"
                        placeholder="0"
                        value={formData.vipRoom}
                        onChange={(e) => handleInputChange("vipRoom", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="vvipRoom">VVIP Room</Label>
                      <Input
                        id="vvipRoom"
                        type="number"
                        placeholder="0"
                        value={formData.vvipRoom}
                        onChange={(e) => handleInputChange("vvipRoom", e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="dayCare">Day Care</Label>
                      <Input
                        id="dayCare"
                        type="number"
                        placeholder="0"
                        value={formData.dayCare}
                        onChange={(e) => handleInputChange("dayCare", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ipdDiscount">IPD Discount (%)</Label>
                      <Input
                        id="ipdDiscount"
                        placeholder="10"
                        value={formData.ipdDiscount}
                        onChange={(e) => handleInputChange("ipdDiscount", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="opdDiscount">OPD Discount (%)</Label>
                      <Input
                        id="opdDiscount"
                        placeholder="8"
                        value={formData.opdDiscount}
                        onChange={(e) => handleInputChange("opdDiscount", e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </ScrollArea>

              <div className="flex justify-end gap-2 mt-4 pt-4 border-t">
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Add Tariff</Button>
              </div>
            </form>
          </TabsContent>

          <TabsContent value="upload" className="mt-4">
            <div className="space-y-6">
              <div className="border-2 border-dashed rounded-lg p-12 text-center">
                <FileSpreadsheet className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">Upload Tariff Sheet</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Upload an Excel or CSV file containing service/package tariff information
                </p>
                <div className="flex flex-col items-center gap-2">
                  <Input
                    id="file-upload"
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    onChange={handleFileUpload}
                    className="max-w-xs"
                  />
                  <p className="text-xs text-muted-foreground">
                    Supported formats: .xlsx, .xls, .csv (Max 20MB)
                  </p>
                </div>
              </div>

              <div className="bg-muted/50 rounded-lg p-4">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <Upload className="h-4 w-4" />
                  File Format Requirements
                </h4>
                <ul className="text-sm text-muted-foreground space-y-1 ml-6 list-disc">
                  <li>First row should contain column headers</li>
                  <li>Required columns: Service/Package Code, Service/Package Name</li>
                  <li>Optional columns: All room types and discount fields</li>
                  <li>Numeric values should not include currency symbols</li>
                  <li>Discount values should be in percentage (e.g., 10 for 10%)</li>
                </ul>
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
