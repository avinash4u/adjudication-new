import { useState } from "react";
import { Check, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

const SPECIALTIES = [
  "Cardiology",
  "Neurology",
  "Orthopaedics",
  "Gastroenterology",
  "Nephrology",
  "Urology",
  "Oncology",
  "Pulmonology",
  "Endocrinology",
  "Rheumatology",
  "Dermatology",
  "Ophthalmology",
  "ENT",
  "Pediatrics",
  "Obstetrics & Gynecology",
  "General Surgery",
  "Plastic Surgery",
  "Neurosurgery",
  "Cardiac Surgery",
  "Emergency Medicine",
  "Anesthesiology",
  "Radiology",
  "Pathology",
  "Psychiatry",
  "Dentistry",
];

interface SpecialtySelectorProps {
  selectedSpecialties: string[];
  onSpecialtiesChange: (specialties: string[]) => void;
}

export function SpecialtySelector({ selectedSpecialties, onSpecialtiesChange }: SpecialtySelectorProps) {
  const [open, setOpen] = useState(false);

  const handleSelect = (specialty: string) => {
    if (selectedSpecialties.includes(specialty)) {
      onSpecialtiesChange(selectedSpecialties.filter((s) => s !== specialty));
    } else {
      onSpecialtiesChange([...selectedSpecialties, specialty]);
    }
  };

  const handleRemove = (specialty: string) => {
    onSpecialtiesChange(selectedSpecialties.filter((s) => s !== specialty));
  };

  return (
    <div className="space-y-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" className="w-full justify-start text-left font-normal">
            Select specialties...
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-full p-0" align="start">
          <Command>
            <CommandInput placeholder="Search specialties..." />
            <CommandList>
              <CommandEmpty>No specialty found.</CommandEmpty>
              <CommandGroup>
                {SPECIALTIES.map((specialty) => (
                  <CommandItem
                    key={specialty}
                    value={specialty}
                    onSelect={() => handleSelect(specialty)}
                  >
                    <Check
                      className={`mr-2 h-4 w-4 ${
                        selectedSpecialties.includes(specialty) ? "opacity-100" : "opacity-0"
                      }`}
                    />
                    {specialty}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>

      {selectedSpecialties.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {selectedSpecialties.map((specialty) => (
            <Badge key={specialty} variant="secondary" className="gap-1">
              {specialty}
              <X
                className="h-3 w-3 cursor-pointer hover:text-destructive"
                onClick={() => handleRemove(specialty)}
              />
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}
