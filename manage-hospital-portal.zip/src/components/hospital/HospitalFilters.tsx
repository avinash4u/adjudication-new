import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Filter, X, Check } from "lucide-react";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export interface HospitalFilterOptions {
  cities: string[];
  states: string[];
  pincodes: string[];
  taggingStatuses: string[];
  specialties: string[];
  otherTags: string[];
}

interface HospitalFiltersProps {
  filters: HospitalFilterOptions;
  onApplyFilters: (filters: HospitalFilterOptions) => void;
  availableCities: string[];
  availableStates: string[];
  availablePincodes: string[];
  availableSpecialties: string[];
  availableOtherTags: string[];
}

export default function HospitalFilters({
  filters,
  onApplyFilters,
  availableCities,
  availableStates,
  availablePincodes,
  availableSpecialties,
  availableOtherTags,
}: HospitalFiltersProps) {
  const [open, setOpen] = useState(false);
  const [localFilters, setLocalFilters] = useState<HospitalFilterOptions>(filters);
  const [cityOpen, setCityOpen] = useState(false);
  const [stateOpen, setStateOpen] = useState(false);
  const [pincodeOpen, setPincodeOpen] = useState(false);
  const [specialtyOpen, setSpecialtyOpen] = useState(false);

  const taggingStatuses = ["Network", "Non-Network", "Excluded"];

  const handleCityToggle = (city: string) => {
    setLocalFilters((prev) => ({
      ...prev,
      cities: prev.cities.includes(city)
        ? prev.cities.filter((c) => c !== city)
        : [...prev.cities, city],
    }));
  };

  const handleStateToggle = (state: string) => {
    setLocalFilters((prev) => ({
      ...prev,
      states: prev.states.includes(state)
        ? prev.states.filter((s) => s !== state)
        : [...prev.states, state],
    }));
  };

  const handlePincodeToggle = (pincode: string) => {
    setLocalFilters((prev) => ({
      ...prev,
      pincodes: prev.pincodes.includes(pincode)
        ? prev.pincodes.filter((p) => p !== pincode)
        : [...prev.pincodes, pincode],
    }));
  };

  const handleTaggingStatusToggle = (status: string) => {
    setLocalFilters((prev) => ({
      ...prev,
      taggingStatuses: prev.taggingStatuses.includes(status)
        ? prev.taggingStatuses.filter((s) => s !== status)
        : [...prev.taggingStatuses, status],
    }));
  };

  const handleSpecialtyToggle = (specialty: string) => {
    setLocalFilters((prev) => ({
      ...prev,
      specialties: prev.specialties.includes(specialty)
        ? prev.specialties.filter((s) => s !== specialty)
        : [...prev.specialties, specialty],
    }));
  };

  const handleOtherTagToggle = (tag: string) => {
    setLocalFilters((prev) => ({
      ...prev,
      otherTags: prev.otherTags.includes(tag)
        ? prev.otherTags.filter((t) => t !== tag)
        : [...prev.otherTags, tag],
    }));
  };

  const handleApply = () => {
    onApplyFilters(localFilters);
    setOpen(false);
  };

  const handleClear = () => {
    const clearedFilters = {
      cities: [],
      states: [],
      pincodes: [],
      taggingStatuses: [],
      specialties: [],
      otherTags: [],
    };
    setLocalFilters(clearedFilters);
    onApplyFilters(clearedFilters);
  };

  const activeFiltersCount =
    localFilters.cities.length +
    localFilters.states.length +
    localFilters.pincodes.length +
    localFilters.taggingStatuses.length +
    localFilters.specialties.length +
    localFilters.otherTags.length;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Filter className="h-4 w-4" />
          Filters
          {activeFiltersCount > 0 && (
            <span className="ml-1 rounded-full bg-primary px-2 py-0.5 text-xs text-primary-foreground">
              {activeFiltersCount}
            </span>
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[80vh] overflow-y-auto sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Filter Hospitals</DialogTitle>
          <DialogDescription>
            Select multiple criteria to filter the hospital list
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-6 py-4">
          {/* Cities */}
          <div className="space-y-2">
            <Label className="text-base font-semibold">City</Label>
            <Popover open={cityOpen} onOpenChange={setCityOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  {localFilters.cities.length > 0
                    ? `${localFilters.cities.length} selected`
                    : "Select cities..."}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[400px] p-0" align="start">
                <Command>
                  <CommandInput placeholder="Search cities..." />
                  <CommandList>
                    <CommandEmpty>No city found.</CommandEmpty>
                    <CommandGroup>
                      {availableCities.map((city) => (
                        <CommandItem
                          key={city}
                          onSelect={() => handleCityToggle(city)}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              localFilters.cities.includes(city) ? "opacity-100" : "opacity-0"
                            )}
                          />
                          {city}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
            {localFilters.cities.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {localFilters.cities.map((city) => (
                  <Badge key={city} variant="secondary" className="gap-1">
                    {city}
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => handleCityToggle(city)}
                    />
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* States */}
          <div className="space-y-2">
            <Label className="text-base font-semibold">State</Label>
            <Popover open={stateOpen} onOpenChange={setStateOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  {localFilters.states.length > 0
                    ? `${localFilters.states.length} selected`
                    : "Select states..."}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[400px] p-0" align="start">
                <Command>
                  <CommandInput placeholder="Search states..." />
                  <CommandList>
                    <CommandEmpty>No state found.</CommandEmpty>
                    <CommandGroup>
                      {availableStates.map((state) => (
                        <CommandItem
                          key={state}
                          onSelect={() => handleStateToggle(state)}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              localFilters.states.includes(state) ? "opacity-100" : "opacity-0"
                            )}
                          />
                          {state}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
            {localFilters.states.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {localFilters.states.map((state) => (
                  <Badge key={state} variant="secondary" className="gap-1">
                    {state}
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => handleStateToggle(state)}
                    />
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Pincodes */}
          <div className="space-y-2">
            <Label className="text-base font-semibold">Pincode</Label>
            <Popover open={pincodeOpen} onOpenChange={setPincodeOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  {localFilters.pincodes.length > 0
                    ? `${localFilters.pincodes.length} selected`
                    : "Select pincodes..."}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[400px] p-0" align="start">
                <Command>
                  <CommandInput placeholder="Search pincodes..." />
                  <CommandList>
                    <CommandEmpty>No pincode found.</CommandEmpty>
                    <CommandGroup>
                      {availablePincodes.map((pincode) => (
                        <CommandItem
                          key={pincode}
                          onSelect={() => handlePincodeToggle(pincode)}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              localFilters.pincodes.includes(pincode) ? "opacity-100" : "opacity-0"
                            )}
                          />
                          {pincode}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
            {localFilters.pincodes.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {localFilters.pincodes.map((pincode) => (
                  <Badge key={pincode} variant="secondary" className="gap-1">
                    {pincode}
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => handlePincodeToggle(pincode)}
                    />
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Tagging Status */}
          <div className="space-y-2">
            <Label className="text-base font-semibold">Tagging Status</Label>
            <div className="grid grid-cols-2 gap-3">
              {taggingStatuses.map((status) => (
                <div key={status} className="flex items-center space-x-2">
                  <Checkbox
                    id={`status-${status}`}
                    checked={localFilters.taggingStatuses.includes(status)}
                    onCheckedChange={() => handleTaggingStatusToggle(status)}
                  />
                  <label
                    htmlFor={`status-${status}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {status}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Specialties */}
          <div className="space-y-2">
            <Label className="text-base font-semibold">Specialties</Label>
            <Popover open={specialtyOpen} onOpenChange={setSpecialtyOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  {localFilters.specialties.length > 0
                    ? `${localFilters.specialties.length} selected`
                    : "Select specialties..."}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[400px] p-0" align="start">
                <Command>
                  <CommandInput placeholder="Search specialties..." />
                  <CommandList>
                    <CommandEmpty>No specialty found.</CommandEmpty>
                    <CommandGroup>
                      {availableSpecialties.map((specialty) => (
                        <CommandItem
                          key={specialty}
                          onSelect={() => handleSpecialtyToggle(specialty)}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              localFilters.specialties.includes(specialty) ? "opacity-100" : "opacity-0"
                            )}
                          />
                          {specialty}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
            {localFilters.specialties.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {localFilters.specialties.map((specialty) => (
                  <Badge key={specialty} variant="secondary" className="gap-1">
                    {specialty}
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => handleSpecialtyToggle(specialty)}
                    />
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Other Tags */}
          <div className="space-y-2">
            <Label className="text-base font-semibold">Other Tags</Label>
            <div className="grid grid-cols-2 gap-3">
              {availableOtherTags.map((tag) => (
                <div key={tag} className="flex items-center space-x-2">
                  <Checkbox
                    id={`tag-${tag}`}
                    checked={localFilters.otherTags.includes(tag)}
                    onCheckedChange={() => handleOtherTagToggle(tag)}
                  />
                  <label
                    htmlFor={`tag-${tag}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {tag}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={handleClear}>
            Clear All
          </Button>
          <Button onClick={handleApply}>Apply Filters</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
