import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AppLayout } from "./components/layout/AppLayout";
import Dashboard from "./pages/Dashboard";
import HospitalMaster from "./pages/HospitalMaster";
import HospitalDetails from "./pages/HospitalDetails";
import AddHospital from "./pages/AddHospital";

import TariffManagement from "./pages/TariffManagement";
import PayoutTracking from "./pages/PayoutTracking";
import PastPayouts from "./pages/PastPayouts";
import ProcessingPayouts from "./pages/ProcessingPayouts";
import PayoutDetails from "./pages/PayoutDetails";
import PayoutDetailsPage from "./pages/PayoutDetailsPage";
import CashlessAnywhere from "./pages/CashlessAnywhere";
import PastCashlessRequests from "./pages/PastCashlessRequests";
import ManageHospitals from "./pages/ManageHospitals";
import HospitalAnalytics from "./pages/HospitalAnalytics";
import DesignVariations from "./pages/DesignVariations";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AppLayout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/hospitals" element={<HospitalMaster />} />
            <Route path="/hospitals/add" element={<AddHospital />} />
            <Route path="/hospitals/:id" element={<HospitalDetails />} />
            
            <Route path="/tariffs" element={<TariffManagement />} />
            <Route path="/tariffs/:hospitalId" element={<TariffManagement />} />
            <Route path="/payouts" element={<PayoutTracking />} />
            <Route path="/payouts/:id" element={<PayoutDetailsPage />} />
            <Route path="/payouts/past" element={<PastPayouts />} />
            <Route path="/payouts/processing" element={<ProcessingPayouts />} />
            <Route path="/payouts/processing/:id" element={<PayoutDetails />} />
            <Route path="/cashless" element={<CashlessAnywhere />} />
            <Route path="/cashless/past" element={<PastCashlessRequests />} />
            <Route path="/manage" element={<ManageHospitals />} />
            <Route path="/analytics" element={<HospitalAnalytics />} />
            <Route path="/design-variations" element={<DesignVariations />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AppLayout>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
