import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LayoutDashboard, Building2, AlertTriangle, Clock, FileText, Wallet } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const networkHospitals = 2134;
  const nonNetworkHospitals = 713;
  const totalHospitals = networkHospitals + nonNetworkHospitals;

  const primaryActions = [
    {
      title: "Pending Approvals",
      value: "43",
      description: "Hospital onboarding and updates requiring action",
      icon: Clock,
      color: "text-warning",
      bgColor: "bg-warning/10",
      route: "/manage",
    },
    {
      title: "Cashless Anywhere Requests",
      value: "12",
      description: "New cashless treatment requests pending review",
      icon: FileText,
      color: "text-primary",
      bgColor: "bg-primary/10",
      route: "/cashless",
    },
    {
      title: "Pending Payments",
      value: "₹45 L",
      description: "Outstanding payments to hospitals",
      icon: Wallet,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
      route: "/payouts",
    },
  ];

  const secondaryStats = [
    {
      title: "Total Hospitals",
      value: totalHospitals.toLocaleString(),
      breakdown: [
        { label: "Network", value: networkHospitals.toLocaleString(), isStatic: true },
        { label: "Non-Network", value: nonNetworkHospitals.toLocaleString(), isStatic: true },
        { label: "Change from Yesterday", value: 12, isChange: true },
        { label: "Change from Last Week", value: 47, isChange: true },
      ],
      icon: Building2,
      inverseColors: false,
    },
    {
      title: "Excluded Hospitals",
      value: "18",
      breakdown: [
        { label: "Change from Yesterday", value: 2, isChange: true },
        { label: "Change from Last Week", value: 5, isChange: true },
      ],
      icon: AlertTriangle,
      inverseColors: true,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Dashboard"
        description="Overview of hospital network and operations"
        icon={LayoutDashboard}
      />

      <div className="container mx-auto px-6 py-8">
        {/* Primary Action Cards */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Action Required</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {primaryActions.map((action) => (
              <Card key={action.title} className="shadow-lg border-2 hover:shadow-xl transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <div className="space-y-1">
                    <CardTitle className="text-base font-semibold">
                      {action.title}
                      {action.title === "Pending Approvals" && (
                        <span className="text-xs font-normal text-muted-foreground ml-1">
                          (for Checker only)
                        </span>
                      )}
                    </CardTitle>
                    <CardDescription className="text-xs">
                      {action.description}
                    </CardDescription>
                  </div>
                  <div className={`rounded-lg p-3 ${action.bgColor}`}>
                    <action.icon className={`h-6 w-6 ${action.color}`} />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-end justify-between">
                    <div className="text-4xl font-bold">{action.value}</div>
                    <Link to={action.route}>
                      <Button size="sm" variant="default">
                        Review Now
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Secondary Stats */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Network Overview</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {secondaryStats.map((stat, index) => (
              <Card key={stat.title} className={`shadow-card ${index === 0 ? 'md:col-span-2' : 'md:col-span-1'}`}>
                <CardHeader className="flex flex-row items-center justify-between pb-3">
                  <CardTitle className="text-sm font-semibold text-muted-foreground">
                    {stat.title}
                  </CardTitle>
                  <stat.icon className="h-5 w-5 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-4">{stat.value}</div>
                  {stat.breakdown && (
                    <div className="grid grid-cols-2 gap-3">
                      {stat.breakdown.map((item) => {
                        const getChangeColor = (value: number, inverse: boolean = false) => {
                          if (value > 0) return inverse ? "text-destructive" : "text-success";
                          if (value < 0) return inverse ? "text-success" : "text-destructive";
                          return "text-warning";
                        };
                        
                        const formatValue = (value: number | string, isChange?: boolean) => {
                          if (!isChange) return value;
                          const numValue = typeof value === 'number' ? value : 0;
                          return numValue > 0 ? `+${numValue}` : numValue.toString();
                        };

                        return (
                          <div key={item.label} className="flex flex-col space-y-1">
                            <span className="text-xs text-muted-foreground">{item.label}</span>
                            <span className={`text-lg font-semibold ${item.isChange ? getChangeColor(typeof item.value === 'number' ? item.value : 0, stat.inverseColors) : ''}`}>
                              {formatValue(item.value, item.isChange)}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
