import { useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { TrendingUp, TrendingDown, Activity, DollarSign, FileText, Building2 } from "lucide-react";

// Mock data - replace with actual API calls
const claimVolumeData = [
  { month: "Jan", cashless: 1250, reimbursement: 890 },
  { month: "Feb", cashless: 1450, reimbursement: 920 },
  { month: "Mar", cashless: 1680, reimbursement: 1050 },
  { month: "Apr", cashless: 1820, reimbursement: 1180 },
  { month: "May", cashless: 1950, reimbursement: 1240 },
  { month: "Jun", cashless: 2100, reimbursement: 1320 },
];

const avgClaimSizeData = [
  { month: "Jan", cashless: 45000, reimbursement: 32000 },
  { month: "Feb", cashless: 47000, reimbursement: 33500 },
  { month: "Mar", cashless: 48500, reimbursement: 35000 },
  { month: "Apr", cashless: 50000, reimbursement: 36000 },
  { month: "May", cashless: 52000, reimbursement: 37500 },
  { month: "Jun", cashless: 54000, reimbursement: 38000 },
];

const topTreatmentsData = [
  { name: "Cardiac Surgery", value: 2340, claims: 156 },
  { name: "Orthopedic Surgery", value: 1890, claims: 234 },
  { name: "Cancer Treatment", value: 1650, claims: 89 },
  { name: "Kidney Transplant", value: 1200, claims: 45 },
  { name: "Neurosurgery", value: 980, claims: 67 },
];

const citiesData = [
  { city: "Mumbai", avgClaim: 58000, volume: 450 },
  { city: "Delhi", avgClaim: 52000, volume: 420 },
  { city: "Bangalore", avgClaim: 48000, volume: 380 },
  { city: "Hyderabad", avgClaim: 45000, volume: 340 },
  { city: "Chennai", avgClaim: 46000, volume: 320 },
  { city: "Pune", avgClaim: 43000, volume: 290 },
];

const providerTypeData = [
  { name: "Hospital", value: 45, color: "hsl(var(--primary))" },
  { name: "Clinic", value: 28, color: "hsl(var(--chart-2))" },
  { name: "Diagnostic Lab", value: 18, color: "hsl(var(--chart-3))" },
  { name: "Online Platform", value: 9, color: "hsl(var(--chart-4))" },
];

const policyTypeData = [
  { name: "Retail", value: 62, color: "hsl(var(--primary))" },
  { name: "GMC", value: 38, color: "hsl(var(--chart-2))" },
];

const hospitalChainData = [
  { name: "Hospital Chains", value: 58, color: "hsl(var(--primary))" },
  { name: "Non-Onboarded", value: 42, color: "hsl(var(--chart-2))" },
];

// Mock hospitals list
const hospitalsList = [
  { id: "all", name: "All Hospitals" },
  { id: "1", name: "Apollo Hospital, Mumbai" },
  { id: "2", name: "Fortis Hospital, Delhi" },
  { id: "3", name: "Max Hospital, Bangalore" },
  { id: "4", name: "Manipal Hospital, Hyderabad" },
  { id: "5", name: "Medanta Hospital, Gurgaon" },
];

export default function HospitalAnalytics() {
  const [timeRange, setTimeRange] = useState("6m");
  const [claimType, setClaimType] = useState("all");
  const [selectedHospital, setSelectedHospital] = useState("all");

  const kpiData = [
    {
      title: "Total Claims",
      value: "12,450",
      change: "+12.3%",
      trend: "up",
      icon: FileText,
      description: "vs last period",
    },
    {
      title: "Avg Claim Size",
      value: "₹48,500",
      change: "+8.5%",
      trend: "up",
      icon: DollarSign,
      description: "vs last period",
    },
    {
      title: "Claim Approval Rate",
      value: "94.5%",
      change: "-1.2%",
      trend: "down",
      icon: Activity,
      description: "vs last period",
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Hospital Analytics"
        description="Comprehensive analytics and insights across hospitals and time ranges"
      />

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <Select value={selectedHospital} onValueChange={setSelectedHospital}>
          <SelectTrigger className="w-[240px]">
            <SelectValue placeholder="Select Hospital" />
          </SelectTrigger>
          <SelectContent>
            {hospitalsList.map((hospital) => (
              <SelectItem key={hospital.id} value={hospital.id}>
                {hospital.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Time Range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1m">Last Month</SelectItem>
            <SelectItem value="3m">Last 3 Months</SelectItem>
            <SelectItem value="6m">Last 6 Months</SelectItem>
            <SelectItem value="1y">Last Year</SelectItem>
          </SelectContent>
        </Select>

        <Select value={claimType} onValueChange={setClaimType}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Claim Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Claims</SelectItem>
            <SelectItem value="cashless">Cashless</SelectItem>
            <SelectItem value="reimbursement">Reimbursement</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Hospital-specific info banner */}
      {selectedHospital !== "all" && (
        <Card className="bg-muted/50">
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">
                  {hospitalsList.find((h) => h.id === selectedHospital)?.name}
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Showing detailed analytics for this hospital
                </p>
              </div>
              <button
                onClick={() => setSelectedHospital("all")}
                className="text-sm text-primary hover:underline"
              >
                View All Hospitals
              </button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        {kpiData.map((kpi) => (
          <Card key={kpi.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{kpi.title}</CardTitle>
              <kpi.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{kpi.value}</div>
              <div className="flex items-center text-xs text-muted-foreground mt-1">
                {kpi.trend === "up" ? (
                  <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                ) : (
                  <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
                )}
                <span className={kpi.trend === "up" ? "text-green-500" : "text-red-500"}>
                  {kpi.change}
                </span>
                <span className="ml-1">{kpi.description}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Analytics */}
      <Tabs defaultValue="volume" className="space-y-4">
        <TabsList>
          <TabsTrigger value="volume">Volume & Size</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="treatments">Treatments</TabsTrigger>
          <TabsTrigger value="geography">Geography</TabsTrigger>
          <TabsTrigger value="segments">Segments</TabsTrigger>
        </TabsList>

        {/* Volume & Size Tab */}
        <TabsContent value="volume" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Claim Volume</CardTitle>
                <CardDescription>Cashless vs Reimbursement claims over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={claimVolumeData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="cashless" fill="hsl(var(--primary))" name="Cashless" />
                    <Bar dataKey="reimbursement" fill="hsl(var(--chart-2))" name="Reimbursement" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Average Claim Size</CardTitle>
                <CardDescription>Average claim amount by type</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={avgClaimSizeData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="cashless"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      name="Cashless"
                    />
                    <Line
                      type="monotone"
                      dataKey="reimbursement"
                      stroke="hsl(var(--chart-2))"
                      strokeWidth={2}
                      name="Reimbursement"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Trends Tab */}
        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Week-over-Week & Month-over-Month Trends</CardTitle>
              <CardDescription>Claim size growth patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <h4 className="font-semibold">Week-over-Week Growth</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Cashless Claims</span>
                        <span className="text-sm font-semibold text-green-500">+5.2%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Reimbursement Claims</span>
                        <span className="text-sm font-semibold text-green-500">+3.8%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Average Claim Size</span>
                        <span className="text-sm font-semibold text-green-500">+2.1%</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold">Month-over-Month Growth</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Cashless Claims</span>
                        <span className="text-sm font-semibold text-green-500">+12.3%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Reimbursement Claims</span>
                        <span className="text-sm font-semibold text-green-500">+8.5%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Average Claim Size</span>
                        <span className="text-sm font-semibold text-green-500">+6.2%</span>
                      </div>
                    </div>
                  </div>
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={avgClaimSizeData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="cashless"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      name="Cashless"
                    />
                    <Line
                      type="monotone"
                      dataKey="reimbursement"
                      stroke="hsl(var(--chart-2))"
                      strokeWidth={2}
                      name="Reimbursement"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Treatments Tab */}
        <TabsContent value="treatments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Top Treatments</CardTitle>
              <CardDescription>Most common diseases and procedures</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topTreatmentsData.map((treatment, index) => (
                  <div key={treatment.name} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold">#{index + 1}</span>
                        <span className="text-sm">{treatment.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-semibold">₹{treatment.value.toLocaleString()}</div>
                        <div className="text-xs text-muted-foreground">{treatment.claims} claims</div>
                      </div>
                    </div>
                    <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary"
                        style={{ width: `${(treatment.value / topTreatmentsData[0].value) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Geography Tab */}
        <TabsContent value="geography" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Claim Size by Top Cities</CardTitle>
              <CardDescription>Geographic distribution of claims across India</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={citiesData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="city" type="category" width={100} />
                  <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} />
                  <Bar dataKey="avgClaim" fill="hsl(var(--primary))" name="Avg Claim Size" />
                </BarChart>
              </ResponsiveContainer>
              <div className="mt-4 space-y-2">
                {citiesData.map((city) => (
                  <div key={city.city} className="flex justify-between text-sm">
                    <span>{city.city}</span>
                    <span className="text-muted-foreground">{city.volume} claims</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Segments Tab */}
        <TabsContent value="segments" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Provider Type</CardTitle>
                <CardDescription>Claims distribution by provider type</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={providerTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={(entry) => `${entry.name}: ${entry.value}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {providerTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Policy Type</CardTitle>
                <CardDescription>Retail vs GMC policies</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={policyTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={(entry) => `${entry.name}: ${entry.value}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {policyTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Hospital Chains</CardTitle>
                <CardDescription>Chains vs Non-Onboarded</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={hospitalChainData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={(entry) => `${entry.name}: ${entry.value}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {hospitalChainData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
