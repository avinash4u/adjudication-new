import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CreditCard, TrendingUp, Clock, CheckCircle, History, AlertCircle, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useState, useMemo } from "react";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, X } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export default function PayoutTracking() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [selectedPayouts, setSelectedPayouts] = useState<number[]>([]);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [selectedFailedPayouts, setSelectedFailedPayouts] = useState<number[]>([]);
  
  // Filter states for pending payouts
  const [pendingSearchFilter, setPendingSearchFilter] = useState("");
  const [pendingDateFrom, setPendingDateFrom] = useState<Date | undefined>();
  const [pendingDateTo, setPendingDateTo] = useState<Date | undefined>();
  
  // Filter states for failed payments
  const [failedSearchFilter, setFailedSearchFilter] = useState("");
  const [failedDateFrom, setFailedDateFrom] = useState<Date | undefined>();
  const [failedDateTo, setFailedDateTo] = useState<Date | undefined>();
  
  const stats = [
    { 
      label: "Total Payouts Completed (Today)", 
      icon: CheckCircle, 
      color: "text-success",
      metrics: [
        { label: "Number of payouts", value: "32" },
        { label: "Total value of payments", value: "₹12.5 L" }
      ]
    },
    { 
      label: "Total Pending Payments", 
      icon: Clock, 
      color: "text-warning",
      metrics: [
        { label: "Number of pending payouts", value: "5" },
        { label: "Value of pending payouts", value: "₹10.85 L" }
      ]
    },
  ];

  const payouts = [
    {
      id: 1,
      hospital: "Apollo Hospitals",
      claimId: "CLM-2025-001235",
      amount: "₹2,50,000",
      priority: "High",
      dueDate: "22-Jan-2025",
      paymentMode: "RTGS",
      verified: true,
    },
    {
      id: 2,
      hospital: "Fortis Healthcare",
      claimId: "CLM-2025-001240",
      amount: "₹1,75,000",
      priority: "Medium",
      dueDate: "23-Jan-2025",
      paymentMode: "NEFT",
      verified: true,
    },
    {
      id: 3,
      hospital: "Max Healthcare",
      claimId: "CLM-2025-001241",
      amount: "₹95,000",
      priority: "Low",
      dueDate: "25-Jan-2025",
      paymentMode: "IMPS",
      verified: false,
    },
    {
      id: 4,
      hospital: "Narayana Health",
      claimId: "CLM-2025-001242",
      amount: "₹3,20,000",
      priority: "High",
      dueDate: "22-Jan-2025",
      paymentMode: "RTGS",
      verified: true,
    },
    {
      id: 5,
      hospital: "Manipal Hospitals",
      claimId: "CLM-2025-001243",
      amount: "₹1,45,000",
      priority: "Medium",
      dueDate: "24-Jan-2025",
      paymentMode: "NEFT",
      verified: true,
    },
  ];

  const failedPayouts = [
    {
      id: 101,
      hospital: "Medanta Hospital",
      claimId: "CLM-2025-001180",
      amount: "₹1,85,000",
      priority: "High",
      failedDate: "20-Jan-2025",
      paymentMode: "RTGS",
      failureReason: "Invalid bank account details",
    },
    {
      id: 102,
      hospital: "Kokilaben Hospital",
      claimId: "CLM-2025-001195",
      amount: "₹2,10,000",
      priority: "Medium",
      failedDate: "19-Jan-2025",
      paymentMode: "NEFT",
      failureReason: "Insufficient funds in source account",
    },
    {
      id: 103,
      hospital: "Lilavati Hospital",
      claimId: "CLM-2025-001201",
      amount: "₹95,500",
      priority: "Low",
      failedDate: "18-Jan-2025",
      paymentMode: "IMPS",
      failureReason: "Transaction timeout - Bank server error",
    },
  ];

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedPayouts(payouts.map((p) => p.id));
    } else {
      setSelectedPayouts([]);
    }
  };

  const handleSelectPayout = (id: number, checked: boolean) => {
    if (checked) {
      setSelectedPayouts([...selectedPayouts, id]);
    } else {
      setSelectedPayouts(selectedPayouts.filter((payoutId) => payoutId !== id));
    }
  };

  const handleProcessPayouts = () => {
    if (selectedPayouts.length === 0) {
      toast({
        title: "No payouts selected",
        description: "Please select at least one payout to process.",
        variant: "destructive",
      });
      return;
    }
    setShowConfirmDialog(true);
  };

  const confirmProcessPayouts = () => {
    toast({
      title: "Payouts Processed",
      description: `Successfully initiated ${selectedPayouts.length} payout(s). They will be completed within 24-48 hours.`,
    });
    setSelectedPayouts([]);
    setShowConfirmDialog(false);
  };

  const handleSelectAllFailed = (checked: boolean) => {
    if (checked) {
      setSelectedFailedPayouts(failedPayouts.map((p) => p.id));
    } else {
      setSelectedFailedPayouts([]);
    }
  };

  const handleSelectFailedPayout = (id: number, checked: boolean) => {
    if (checked) {
      setSelectedFailedPayouts([...selectedFailedPayouts, id]);
    } else {
      setSelectedFailedPayouts(selectedFailedPayouts.filter((payoutId) => payoutId !== id));
    }
  };

  const handleReinitiatePayments = () => {
    if (selectedFailedPayouts.length === 0) {
      toast({
        title: "No payments selected",
        description: "Please select at least one failed payment to re-initiate.",
        variant: "destructive",
      });
      return;
    }
    toast({
      title: "Payments Re-initiated",
      description: `Successfully re-initiated ${selectedFailedPayouts.length} payment(s). They will be processed shortly.`,
    });
    setSelectedFailedPayouts([]);
  };

  const getPriorityBadge = (priority: string) => {
    const config: Record<string, string> = {
      High: "bg-destructive/10 text-destructive border-destructive/20",
      Medium: "bg-warning/10 text-warning border-warning/20",
      Low: "bg-muted text-muted-foreground border-border",
    };
    return (
      <Badge variant="outline" className={config[priority]}>
        {priority}
      </Badge>
    );
  };

  // Filter pending payouts
  const filteredPendingPayouts = useMemo(() => {
    return payouts.filter((payout) => {
      const matchesSearch = !pendingSearchFilter || 
        payout.hospital.toLowerCase().includes(pendingSearchFilter.toLowerCase()) ||
        payout.claimId.toLowerCase().includes(pendingSearchFilter.toLowerCase());
      
      const payoutDate = new Date(payout.dueDate);
      const matchesDateFrom = !pendingDateFrom || payoutDate >= pendingDateFrom;
      const matchesDateTo = !pendingDateTo || payoutDate <= pendingDateTo;
      
      return matchesSearch && matchesDateFrom && matchesDateTo;
    });
  }, [payouts, pendingSearchFilter, pendingDateFrom, pendingDateTo]);

  // Filter failed payouts
  const filteredFailedPayouts = useMemo(() => {
    return failedPayouts.filter((payout) => {
      const matchesSearch = !failedSearchFilter || 
        payout.hospital.toLowerCase().includes(failedSearchFilter.toLowerCase()) ||
        payout.claimId.toLowerCase().includes(failedSearchFilter.toLowerCase());
      
      const payoutDate = new Date(payout.failedDate);
      const matchesDateFrom = !failedDateFrom || payoutDate >= failedDateFrom;
      const matchesDateTo = !failedDateTo || payoutDate <= failedDateTo;
      
      return matchesSearch && matchesDateFrom && matchesDateTo;
    });
  }, [failedPayouts, failedSearchFilter, failedDateFrom, failedDateTo]);

  const totalAmount = payouts
    .filter((p) => selectedPayouts.includes(p.id))
    .reduce((sum, p) => {
      const amount = parseFloat(p.amount.replace(/[₹,]/g, ""));
      return sum + amount;
    }, 0);

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Payout Tracking"
        description="Monitor hospital payments and transaction history"
        icon={CreditCard}
        actions={
          <Button variant="outline" className="gap-2" onClick={() => navigate("/payouts/past")}>
            <History className="h-4 w-4" />
            View Past Payouts
          </Button>
        }
      />

      <div className="container mx-auto px-6 py-8">
        <h2 className="text-xl font-semibold mb-4">Current Snapshot</h2>
        <div className="grid gap-6 md:grid-cols-2 mb-8">
          {stats.map((stat) => (
            <Card key={stat.label} className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-base font-semibold text-foreground">{stat.label}</h3>
                  <stat.icon className={`h-6 w-6 ${stat.color} flex-shrink-0`} />
                </div>
                <div className="space-y-3">
                  {stat.metrics.map((metric) => (
                    <div key={metric.label} className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">{metric.label}</span>
                      <span className="text-lg font-bold">{metric.value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Summary Card */}
        <Card className="mb-8 shadow-card">
          <CardContent className="p-6">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Selected Payouts</p>
              <p className="text-3xl font-bold">
                {selectedPayouts.length} / {payouts.length}
              </p>
              {selectedPayouts.length > 0 && (
                <p className="text-sm text-muted-foreground">
                  Total Amount: ₹{totalAmount.toLocaleString("en-IN")}
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Payout Management</CardTitle>
            <CardDescription>Manage pending and failed payment transactions</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="pending" className="w-full">
              <TabsList className="grid w-full max-w-md grid-cols-2">
                <TabsTrigger value="pending">
                  Pending Payouts ({payouts.length})
                </TabsTrigger>
                <TabsTrigger value="failed">
                  Failed Payments ({failedPayouts.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="pending" className="mt-6">
                {/* Filters for Pending Payouts */}
                <div className="grid gap-4 md:grid-cols-4 mb-6">
                  <div className="md:col-span-1">
                    <Input
                      placeholder="Search hospital or claim ID..."
                      value={pendingSearchFilter}
                      onChange={(e) => setPendingSearchFilter(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <div className="md:col-span-1">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !pendingDateFrom && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {pendingDateFrom ? format(pendingDateFrom, "dd-MMM-yyyy") : "From date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={pendingDateFrom}
                          onSelect={setPendingDateFrom}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="md:col-span-1">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !pendingDateTo && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {pendingDateTo ? format(pendingDateTo, "dd-MMM-yyyy") : "To date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={pendingDateTo}
                          onSelect={setPendingDateTo}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="md:col-span-1 flex gap-2">
                    {(pendingSearchFilter || pendingDateFrom || pendingDateTo) && (
                      <Button
                        variant="outline"
                        onClick={() => {
                          setPendingSearchFilter("");
                          setPendingDateFrom(undefined);
                          setPendingDateTo(undefined);
                        }}
                        className="gap-2"
                      >
                        <X className="h-4 w-4" />
                        Clear Filters
                      </Button>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm text-muted-foreground">
                    Select payouts to process and initiate payment transfer
                  </p>
                  <Button 
                    className="gap-2" 
                    onClick={handleProcessPayouts}
                    disabled={selectedPayouts.length === 0}
                  >
                    <CheckCircle2 className="h-4 w-4" />
                    Process {selectedPayouts.length > 0 ? `${selectedPayouts.length} ` : ''}Payout{selectedPayouts.length !== 1 ? 's' : ''}
                  </Button>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">
                        <Checkbox
                          checked={selectedPayouts.length === payouts.length}
                          onCheckedChange={handleSelectAll}
                        />
                      </TableHead>
                      <TableHead>Hospital</TableHead>
                      <TableHead>Claim ID</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPendingPayouts.map((payout) => (
                      <TableRow key={payout.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedPayouts.includes(payout.id)}
                            onCheckedChange={(checked) =>
                              handleSelectPayout(payout.id, checked as boolean)
                            }
                          />
                        </TableCell>
                        <TableCell className="font-medium">{payout.hospital}</TableCell>
                        <TableCell className="font-mono text-sm">{payout.claimId}</TableCell>
                        <TableCell className="font-semibold">{payout.amount}</TableCell>
                        <TableCell>{getPriorityBadge(payout.priority)}</TableCell>
                        <TableCell>{payout.dueDate}</TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => navigate(`/payouts/${payout.id}`)}
                          >
                            View Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TabsContent>

              <TabsContent value="failed" className="mt-6">
                {/* Filters for Failed Payments */}
                <div className="grid gap-4 md:grid-cols-4 mb-6">
                  <div className="md:col-span-1">
                    <Input
                      placeholder="Search hospital or claim ID..."
                      value={failedSearchFilter}
                      onChange={(e) => setFailedSearchFilter(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <div className="md:col-span-1">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !failedDateFrom && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {failedDateFrom ? format(failedDateFrom, "dd-MMM-yyyy") : "From date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={failedDateFrom}
                          onSelect={setFailedDateFrom}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="md:col-span-1">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !failedDateTo && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {failedDateTo ? format(failedDateTo, "dd-MMM-yyyy") : "To date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={failedDateTo}
                          onSelect={setFailedDateTo}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="md:col-span-1 flex gap-2">
                    {(failedSearchFilter || failedDateFrom || failedDateTo) && (
                      <Button
                        variant="outline"
                        onClick={() => {
                          setFailedSearchFilter("");
                          setFailedDateFrom(undefined);
                          setFailedDateTo(undefined);
                        }}
                        className="gap-2"
                      >
                        <X className="h-4 w-4" />
                        Clear Filters
                      </Button>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm text-muted-foreground">
                    Review failed payments and re-initiate when issues are resolved
                  </p>
                  <Button 
                    className="gap-2" 
                    onClick={handleReinitiatePayments}
                    disabled={selectedFailedPayouts.length === 0}
                  >
                    <CheckCircle2 className="h-4 w-4" />
                    Re-initiate {selectedFailedPayouts.length > 0 ? `${selectedFailedPayouts.length} ` : ''}Payment{selectedFailedPayouts.length !== 1 ? 's' : ''}
                  </Button>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">
                        <Checkbox
                          checked={selectedFailedPayouts.length === failedPayouts.length}
                          onCheckedChange={handleSelectAllFailed}
                        />
                      </TableHead>
                      <TableHead>Hospital</TableHead>
                      <TableHead>Claim ID</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Failed Date</TableHead>
                      <TableHead>Failure Reason</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredFailedPayouts.map((payout) => (
                      <TableRow key={payout.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedFailedPayouts.includes(payout.id)}
                            onCheckedChange={(checked) =>
                              handleSelectFailedPayout(payout.id, checked as boolean)
                            }
                          />
                        </TableCell>
                        <TableCell className="font-medium">{payout.hospital}</TableCell>
                        <TableCell className="font-mono text-sm">{payout.claimId}</TableCell>
                        <TableCell className="font-semibold">{payout.amount}</TableCell>
                        <TableCell>{getPriorityBadge(payout.priority)}</TableCell>
                        <TableCell>{payout.failedDate}</TableCell>
                        <TableCell>
                          <div className="flex items-start gap-2">
                            <AlertCircle className="h-4 w-4 text-destructive mt-0.5 flex-shrink-0" />
                            <span className="text-sm">{payout.failureReason}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => navigate(`/payouts/${payout.id}`)}
                          >
                            View Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Info Card */}
        <Card className="mt-6 shadow-card border-primary/20">
          <CardContent className="p-6">
            <div className="flex gap-4">
              <AlertCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold text-foreground">Processing Information</p>
                <p className="text-sm text-muted-foreground">
                  Once you process the selected payouts, the payment will be initiated immediately
                  and should reach the hospital accounts within 24-48 hours depending on the
                  payment mode selected. All transactions are logged and auditable.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Payout Processing</AlertDialogTitle>
            <AlertDialogDescription>
              You are about to process {selectedPayouts.length} payout(s) with a total amount of
              ₹{totalAmount.toLocaleString("en-IN")}. This action will initiate the payment
              transfer and cannot be undone. Are you sure you want to continue?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmProcessPayouts}>
              Confirm & Process
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
