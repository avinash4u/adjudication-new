import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Settings, Clock, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useState } from "react";

export default function ManageHospitals() {
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const onboardingRequests = [
    {
      id: 1,
      type: "Onboarding",
      hospital: "Sunshine Hospital",
      requestedBy: "Network Operations",
      requestDate: "20-Jan-2025",
      changes: "New hospital onboarding request",
      status: "Pending Approval",
      details: {
        hospitalName: "Sunshine Hospital",
        address: "123 Medical Plaza, Mumbai, Maharashtra 400001",
        contactPerson: "Dr. Rajesh Kumar",
        phone: "+91 22 1234 5678",
        email: "admin@sunshinehospital.com",
        specialties: ["Cardiology", "Neurology", "Orthopedics"],
        bedCount: 150,
        icuBeds: 20,
        emergencyServices: true
      },
    },
    {
      id: 2,
      type: "Onboarding",
      hospital: "Care Hospital",
      requestedBy: "Network Expansion Team",
      requestDate: "18-Jan-2025",
      changes: "Multi-specialty hospital onboarding",
      status: "Pending Approval",
      details: {
        hospitalName: "Care Hospital",
        address: "456 Healthcare Road, Delhi 110001",
        contactPerson: "Dr. Priya Sharma",
        phone: "+91 11 9876 5432",
        email: "contact@carehospital.com",
        specialties: ["Oncology", "Gastroenterology", "Pediatrics", "ENT"],
        bedCount: 200,
        icuBeds: 30,
        emergencyServices: true
      },
    },
  ];

  const detailsEditRequests = [
    {
      id: 1,
      type: "Update",
      hospital: "Apollo Hospitals",
      requestedBy: "Claims Team",
      requestDate: "19-Jan-2025",
      changes: "Updated contact information and bed count",
      status: "Pending Approval",
      details: {
        before: {
          phone: "+91 80 1234 5678",
          email: "old@apollohospitals.com",
          bedCount: 180
        },
        after: {
          phone: "+91 80 9999 8888",
          email: "contact@apollohospitals.com",
          bedCount: 200
        }
      },
    },
    {
      id: 2,
      type: "Update",
      hospital: "Max Healthcare",
      requestedBy: "Operations Team",
      requestDate: "17-Jan-2025",
      changes: "Updated specialties and infrastructure details",
      status: "Under Review",
      details: {
        before: {
          specialties: ["Cardiology", "Neurology"],
          icuBeds: 15
        },
        after: {
          specialties: ["Cardiology", "Neurology", "Nephrology", "Urology"],
          icuBeds: 25
        }
      },
    },
  ];

  const deboardingRequests = [
    {
      id: 1,
      type: "Deboarding",
      hospital: "Old City Clinic",
      requestedBy: "Fraud Detection",
      requestDate: "18-Jan-2025",
      changes: "Request to remove from network due to suspicious activity",
      status: "Under Review",
      details: {
        reason: "Multiple instances of fraudulent claims and billing irregularities detected",
        casesReported: 12,
        totalAmountInvolved: "₹45,00,000",
        investigationStatus: "Ongoing",
        recommendedAction: "Immediate suspension pending investigation completion"
      },
    },
  ];

  const auditLog = [
    {
      id: 1,
      hospital: "Max Healthcare",
      action: "Tariff Updated",
      editor: "Priya Sharma",
      date: "20-Jan-2025 14:30",
      changeType: "Manual",
      before: "Package rate: ₹1,50,000",
      after: "Package rate: ₹1,75,000",
    },
    {
      id: 2,
      hospital: "Fortis Healthcare",
      action: "Status Changed",
      editor: "Amit Patel",
      date: "19-Jan-2025 11:15",
      changeType: "Manual",
      before: "Status: Pending",
      after: "Status: Active",
    },
    {
      id: 3,
      hospital: "Narayana Health",
      action: "Contact Info Updated",
      editor: "System API",
      date: "18-Jan-2025 09:45",
      changeType: "Auto via API",
      before: "Phone: +91 80 1234 5678",
      after: "Phone: +91 80 9876 5432",
    },
  ];

  const getTypeBadge = (type: string) => {
    const config: Record<string, string> = {
      Onboarding: "bg-success/10 text-success border-success/20",
      Update: "bg-primary/10 text-primary border-primary/20",
      Deboarding: "bg-destructive/10 text-destructive border-destructive/20",
    };
    return (
      <Badge variant="outline" className={config[type]}>
        {type}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Manage Providers (For Checkers only)"
        description="Onboarding, updates, and approval workflows"
        icon={Settings}
      />

      <div className="container mx-auto px-6 py-8">
        <Tabs defaultValue="onboarding" className="space-y-6">
          <TabsList>
            <TabsTrigger value="onboarding">Hospital Onboarding</TabsTrigger>
            <TabsTrigger value="deboarding">Hospital Deboarding</TabsTrigger>
            <TabsTrigger value="details-edit">Hospital Details Edit</TabsTrigger>
            <TabsTrigger value="audit">Audit Log</TabsTrigger>
          </TabsList>

          <TabsContent value="onboarding" className="space-y-4">
            <Card className="shadow-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Onboarding Requests</CardTitle>
                    <CardDescription>Review new hospital onboarding</CardDescription>
                  </div>
                  <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                    {onboardingRequests.length} Pending
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {onboardingRequests.map((action) => (
                  <div
                    key={action.id}
                    className="rounded-lg border border-border p-4 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {getTypeBadge(action.type)}
                        <h4 className="font-semibold">{action.hospital}</h4>
                      </div>
                      <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                        {action.status}
                      </Badge>
                    </div>
                    <div className="grid gap-2 text-sm mb-4">
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Requested by:</span>
                        <span className="font-medium">{action.requestedBy}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Date:</span>
                        <span className="font-medium">{action.requestDate}</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="text-muted-foreground">Changes:</span>
                        <span className="font-medium">{action.changes}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="text-destructive border-destructive/20 hover:bg-destructive/10">
                        <XCircle className="h-4 w-4 mr-1" />
                        Reject
                      </Button>
                      <Button size="sm" className="bg-success hover:bg-success/90">
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Approve
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => {
                          setSelectedRequest(action);
                          setDetailsOpen(true);
                        }}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="deboarding" className="space-y-4">
            <Card className="shadow-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Deboarding Requests</CardTitle>
                    <CardDescription>Review hospital removal requests</CardDescription>
                  </div>
                  <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
                    {deboardingRequests.length} Pending
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {deboardingRequests.map((action) => (
                  <div
                    key={action.id}
                    className="rounded-lg border border-border p-4 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {getTypeBadge(action.type)}
                        <h4 className="font-semibold">{action.hospital}</h4>
                      </div>
                      <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                        {action.status}
                      </Badge>
                    </div>
                    <div className="grid gap-2 text-sm mb-4">
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Requested by:</span>
                        <span className="font-medium">{action.requestedBy}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Date:</span>
                        <span className="font-medium">{action.requestDate}</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="text-muted-foreground">Changes:</span>
                        <span className="font-medium">{action.changes}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="text-destructive border-destructive/20 hover:bg-destructive/10">
                        <XCircle className="h-4 w-4 mr-1" />
                        Reject
                      </Button>
                      <Button size="sm" className="bg-success hover:bg-success/90">
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Approve
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => {
                          setSelectedRequest(action);
                          setDetailsOpen(true);
                        }}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="details-edit" className="space-y-4">
            <Card className="shadow-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Details Edit Requests</CardTitle>
                    <CardDescription>Review hospital information updates</CardDescription>
                  </div>
                  <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                    {detailsEditRequests.length} Pending
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {detailsEditRequests.map((action) => (
                  <div
                    key={action.id}
                    className="rounded-lg border border-border p-4 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {getTypeBadge(action.type)}
                        <h4 className="font-semibold">{action.hospital}</h4>
                      </div>
                      <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                        {action.status}
                      </Badge>
                    </div>
                    <div className="grid gap-2 text-sm mb-4">
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Requested by:</span>
                        <span className="font-medium">{action.requestedBy}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Date:</span>
                        <span className="font-medium">{action.requestDate}</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="text-muted-foreground">Changes:</span>
                        <span className="font-medium">{action.changes}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="text-destructive border-destructive/20 hover:bg-destructive/10">
                        <XCircle className="h-4 w-4 mr-1" />
                        Reject
                      </Button>
                      <Button size="sm" className="bg-success hover:bg-success/90">
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Approve
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => {
                          setSelectedRequest(action);
                          setDetailsOpen(true);
                        }}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="audit" className="space-y-4">
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Change History</CardTitle>
                <CardDescription>Complete audit trail of all provider modifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {auditLog.map((log) => (
                  <div
                    key={log.id}
                    className="rounded-lg border border-border p-4"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-semibold">{log.hospital}</h4>
                        <p className="text-sm text-muted-foreground">{log.action}</p>
                      </div>
                      <Badge variant="outline" className={
                        log.changeType === "Manual" 
                          ? "bg-primary/10 text-primary border-primary/20"
                          : "bg-muted"
                      }>
                        {log.changeType}
                      </Badge>
                    </div>
                    <div className="grid gap-2 text-sm mb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Editor:</span>
                        <span className="font-medium">{log.editor}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Date/Time:</span>
                        <span className="font-medium">{log.date}</span>
                      </div>
                    </div>
                    <div className="rounded-md bg-muted/50 p-3 space-y-1 text-sm">
                      <div className="flex items-start gap-2">
                        <span className="text-destructive font-medium">Before:</span>
                        <span className="text-muted-foreground">{log.before}</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="text-success font-medium">After:</span>
                        <span className="text-foreground">{log.after}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedRequest?.hospital} - Review Details</DialogTitle>
            <DialogDescription>
              {selectedRequest?.type} request by {selectedRequest?.requestedBy} on {selectedRequest?.requestDate}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 mt-4">
            {selectedRequest?.type === "Onboarding" && (
              <div className="space-y-3">
                <h4 className="font-semibold text-sm">Hospital Information</h4>
                <div className="rounded-lg border border-border p-4 space-y-2 text-sm">
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Name:</span>
                    <span className="font-medium">{selectedRequest?.details?.hospitalName}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Address:</span>
                    <span className="font-medium">{selectedRequest?.details?.address}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Contact Person:</span>
                    <span className="font-medium">{selectedRequest?.details?.contactPerson}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Phone:</span>
                    <span className="font-medium">{selectedRequest?.details?.phone}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Email:</span>
                    <span className="font-medium">{selectedRequest?.details?.email}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Total Beds:</span>
                    <span className="font-medium">{selectedRequest?.details?.bedCount}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">ICU Beds:</span>
                    <span className="font-medium">{selectedRequest?.details?.icuBeds}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Emergency Services:</span>
                    <span className="font-medium">{selectedRequest?.details?.emergencyServices ? "Yes" : "No"}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Specialties:</span>
                    <span className="font-medium">{selectedRequest?.details?.specialties?.join(", ")}</span>
                  </div>
                </div>
              </div>
            )}

            {selectedRequest?.type === "Update" && (
              <div className="space-y-3">
                <h4 className="font-semibold text-sm">Changes Requested</h4>
                <div className="rounded-lg border border-border p-4 space-y-3 text-sm">
                  {Object.keys(selectedRequest?.details?.before || {}).map((key) => (
                    <div key={key} className="space-y-1">
                      <div className="font-medium capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</div>
                      <div className="flex items-start gap-2 pl-4">
                        <span className="text-destructive font-medium">Before:</span>
                        <span className="text-muted-foreground">
                          {Array.isArray(selectedRequest?.details?.before[key]) 
                            ? selectedRequest?.details?.before[key].join(", ")
                            : selectedRequest?.details?.before[key]}
                        </span>
                      </div>
                      <div className="flex items-start gap-2 pl-4">
                        <span className="text-success font-medium">After:</span>
                        <span className="text-foreground">
                          {Array.isArray(selectedRequest?.details?.after[key])
                            ? selectedRequest?.details?.after[key].join(", ")
                            : selectedRequest?.details?.after[key]}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {selectedRequest?.type === "Deboarding" && (
              <div className="space-y-3">
                <h4 className="font-semibold text-sm">Deboarding Information</h4>
                <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-4 space-y-2 text-sm">
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Reason:</span>
                    <span className="font-medium">{selectedRequest?.details?.reason}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Cases Reported:</span>
                    <span className="font-medium">{selectedRequest?.details?.casesReported}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Total Amount Involved:</span>
                    <span className="font-medium">{selectedRequest?.details?.totalAmountInvolved}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Investigation Status:</span>
                    <span className="font-medium">{selectedRequest?.details?.investigationStatus}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <span className="text-muted-foreground">Recommended Action:</span>
                    <span className="font-medium">{selectedRequest?.details?.recommendedAction}</span>
                  </div>
                </div>
              </div>
            )}

            <div className="flex gap-2 pt-4 border-t">
              <Button 
                variant="outline" 
                className="text-destructive border-destructive/20 hover:bg-destructive/10"
                onClick={() => setDetailsOpen(false)}
              >
                <XCircle className="h-4 w-4 mr-1" />
                Reject
              </Button>
              <Button 
                className="bg-success hover:bg-success/90"
                onClick={() => setDetailsOpen(false)}
              >
                <CheckCircle className="h-4 w-4 mr-1" />
                Approve
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
