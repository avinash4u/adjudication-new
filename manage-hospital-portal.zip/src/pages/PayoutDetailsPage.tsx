import { useParams, useNavigate } from "react-router-dom";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  ArrowLeft, 
  Building2, 
  CreditCard, 
  Calendar, 
  CheckCircle2, 
  AlertCircle,
  Clock,
  User,
  Phone,
  Mail,
  MapPin,
  Receipt
} from "lucide-react";

export default function PayoutDetailsPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  // Mock data - in real app this would be fetched based on ID
  const payoutDetails = {
    id: id || "1",
    hospital: "Apollo Hospitals",
    claimId: "CLM-2025-001235",
    amount: "₹2,50,000",
    priority: "High",
    dueDate: "22-Jan-2025",
    paymentMode: "RTGS",
    verified: true,
    status: "Pending",
    hospitalDetails: {
      address: "123 Medical Center Road, Indira Nagar, Bangalore - 560038",
      email: "finance@apollohospitals.com",
      phone: "+91 80 2525 2525",
      accountNumber: "XXXX XXXX 1234",
      ifscCode: "HDFC0001234",
      branch: "Indira Nagar, Bangalore"
    },
    claimDetails: {
      patientName: "Rajesh Kumar",
      patientId: "PAT-2025-5678",
      admissionDate: "15-Jan-2025",
      dischargeDate: "20-Jan-2025",
      treatmentType: "Cardiac Surgery",
      claimAmount: "₹2,50,000",
      approvedAmount: "₹2,50,000",
      submittedDate: "20-Jan-2025"
    },
    timeline: [
      {
        date: "20-Jan-2025",
        time: "10:30 AM",
        event: "Claim Submitted",
        description: "Hospital submitted claim for processing",
        icon: Receipt
      },
      {
        date: "20-Jan-2025",
        time: "02:15 PM",
        event: "Claim Verified",
        description: "Documents verified and approved by claims team",
        icon: CheckCircle2
      },
      {
        date: "21-Jan-2025",
        time: "11:00 AM",
        event: "Payout Approved",
        description: "Payment approved and queued for processing",
        icon: CheckCircle2
      }
    ]
  };

  const getPriorityBadge = (priority: string) => {
    const config: Record<string, string> = {
      High: "bg-destructive/10 text-destructive border-destructive/20",
      Medium: "bg-warning/10 text-warning border-warning/20",
      Low: "bg-muted text-muted-foreground border-border",
    };
    return (
      <Badge variant="outline" className={config[priority]}>
        {priority}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Payout Details"
        description={`Detailed information for ${payoutDetails.claimId}`}
        icon={CreditCard}
        actions={
          <Button variant="outline" onClick={() => navigate("/payouts")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Payouts
          </Button>
        }
      />

      <div className="container mx-auto px-6 py-8">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Payout Summary */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Payout Summary</CardTitle>
                <CardDescription>Overview of the pending payout</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Hospital</p>
                    <p className="font-semibold flex items-center gap-2 mt-1">
                      <Building2 className="h-4 w-4 text-primary" />
                      {payoutDetails.hospital}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Claim ID</p>
                    <p className="font-mono text-sm font-semibold mt-1">{payoutDetails.claimId}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Amount</p>
                    <p className="text-2xl font-bold mt-1">{payoutDetails.amount}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Due Date</p>
                    <p className="font-semibold flex items-center gap-2 mt-1">
                      <Calendar className="h-4 w-4 text-primary" />
                      {payoutDetails.dueDate}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Priority</p>
                    <div className="mt-1">{getPriorityBadge(payoutDetails.priority)}</div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <Badge variant="outline" className="bg-success/10 text-success border-success/20 mt-1">
                      <CheckCircle2 className="h-3 w-3 mr-1" />
                      {payoutDetails.verified ? "Verified" : "Pending Verification"}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Claim Details */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Claim Details</CardTitle>
                <CardDescription>Information about the insurance claim</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Patient Name</p>
                    <p className="font-semibold flex items-center gap-2 mt-1">
                      <User className="h-4 w-4 text-primary" />
                      {payoutDetails.claimDetails.patientName}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Patient ID</p>
                    <p className="font-mono text-sm font-semibold mt-1">{payoutDetails.claimDetails.patientId}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Admission Date</p>
                    <p className="font-semibold mt-1">{payoutDetails.claimDetails.admissionDate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Discharge Date</p>
                    <p className="font-semibold mt-1">{payoutDetails.claimDetails.dischargeDate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Treatment Type</p>
                    <p className="font-semibold mt-1">{payoutDetails.claimDetails.treatmentType}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Submitted Date</p>
                    <p className="font-semibold mt-1">{payoutDetails.claimDetails.submittedDate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Claim Amount</p>
                    <p className="font-semibold mt-1">{payoutDetails.claimDetails.claimAmount}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Approved Amount</p>
                    <p className="font-semibold text-success mt-1">{payoutDetails.claimDetails.approvedAmount}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Activity Timeline */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Activity Timeline</CardTitle>
                <CardDescription>History of actions taken on this payout</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {payoutDetails.timeline.map((item, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="rounded-full bg-primary/10 p-2">
                          <item.icon className="h-4 w-4 text-primary" />
                        </div>
                        {index < payoutDetails.timeline.length - 1 && (
                          <div className="w-px h-full bg-border mt-2" />
                        )}
                      </div>
                      <div className="flex-1 pb-8">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-semibold">{item.event}</p>
                          <Badge variant="outline" className="text-xs">
                            {item.date}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{item.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">{item.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Hospital Bank Details */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Bank Details</CardTitle>
                <CardDescription>Payment destination</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Account Number</p>
                  <p className="font-mono font-semibold mt-1">{payoutDetails.hospitalDetails.accountNumber}</p>
                </div>
                <Separator />
                <div>
                  <p className="text-sm text-muted-foreground">IFSC Code</p>
                  <p className="font-mono font-semibold mt-1">{payoutDetails.hospitalDetails.ifscCode}</p>
                </div>
                <Separator />
                <div>
                  <p className="text-sm text-muted-foreground">Branch</p>
                  <p className="font-semibold mt-1">{payoutDetails.hospitalDetails.branch}</p>
                </div>
                <Separator />
                <div>
                  <p className="text-sm text-muted-foreground">Payment Mode</p>
                  <Badge variant="outline" className="mt-1">{payoutDetails.paymentMode}</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Hospital Contact */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Hospital Contact</CardTitle>
                <CardDescription>Communication details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground flex items-center gap-2">
                    <MapPin className="h-4 w-4" />
                    Address
                  </p>
                  <p className="text-sm mt-1">{payoutDetails.hospitalDetails.address}</p>
                </div>
                <Separator />
                <div>
                  <p className="text-sm text-muted-foreground flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Email
                  </p>
                  <p className="text-sm font-semibold mt-1">{payoutDetails.hospitalDetails.email}</p>
                </div>
                <Separator />
                <div>
                  <p className="text-sm text-muted-foreground flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    Phone
                  </p>
                  <p className="text-sm font-semibold mt-1">{payoutDetails.hospitalDetails.phone}</p>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-card border-primary/20">
              <CardContent className="p-6">
                <div className="flex gap-3">
                  <AlertCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <div className="space-y-3">
                    <div>
                      <p className="font-semibold text-sm">Ready to Process?</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Once processed, payment will be initiated within 24-48 hours.
                      </p>
                    </div>
                    <Button className="w-full gap-2">
                      <CheckCircle2 className="h-4 w-4" />
                      Process This Payout
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
