import { useNavigate, useParams } from "react-router-dom";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  ArrowLeft,
  Building2,
  CreditCard,
  Calendar,
  FileText,
  User,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  Clock,
  AlertCircle,
} from "lucide-react";

export default function PayoutDetails() {
  const navigate = useNavigate();
  const { id } = useParams();

  // Mock data - in real app, fetch based on id
  const payoutDetails = {
    id: id,
    hospital: "Apollo Hospitals",
    claimId: "CLM-2025-001235",
    amount: "₹2,50,000",
    priority: "High",
    dueDate: "22-Jan-2025",
    paymentMode: "RTGS",
    verified: true,
    submittedDate: "15-Jan-2025",
    patientName: "Rajesh Kumar",
    patientId: "PAT-2025-5678",
    treatmentType: "Cardiac Surgery",
    admissionDate: "10-Jan-2025",
    dischargeDate: "14-Jan-2025",
    hospitalContact: {
      name: "Dr. Sharma",
      phone: "+91 98765 43210",
      email: "finance@apollohospitals.com",
    },
    bankDetails: {
      accountName: "Apollo Hospitals",
      accountNumber: "XXXX XXXX 5678",
      ifsc: "HDFC0001234",
      branch: "Mumbai Central",
    },
    claimBreakdown: [
      { item: "Surgery Charges", amount: "₹1,50,000" },
      { item: "ICU Charges", amount: "₹50,000" },
      { item: "Medication", amount: "₹30,000" },
      { item: "Consultation", amount: "₹15,000" },
      { item: "Diagnostic Tests", amount: "₹5,000" },
    ],
    timeline: [
      { date: "15-Jan-2025", event: "Claim Submitted", status: "completed" },
      { date: "16-Jan-2025", event: "Documents Verified", status: "completed" },
      { date: "18-Jan-2025", event: "Approval Pending", status: "completed" },
      { date: "20-Jan-2025", event: "Payment Approved", status: "completed" },
      { date: "Pending", event: "Payment Processing", status: "current" },
    ],
  };

  const getPriorityBadge = (priority: string) => {
    const config: Record<string, string> = {
      High: "bg-destructive/10 text-destructive border-destructive/20",
      Medium: "bg-warning/10 text-warning border-warning/20",
      Low: "bg-muted text-muted-foreground border-border",
    };
    return (
      <Badge variant="outline" className={config[priority]}>
        {priority}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Payout Details"
        description={`Claim ID: ${payoutDetails.claimId}`}
        icon={FileText}
        actions={
          <Button variant="outline" onClick={() => navigate("/payouts/processing")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Processing
          </Button>
        }
      />

      <div className="container mx-auto px-6 py-8">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Details - 2 columns */}
          <div className="lg:col-span-2 space-y-6">
            {/* Overview Card */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Payout Overview</CardTitle>
                <CardDescription>Key information about this payout</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Hospital</p>
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-muted-foreground" />
                        <p className="font-semibold">{payoutDetails.hospital}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Claim Amount</p>
                      <p className="text-2xl font-bold text-primary">{payoutDetails.amount}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Priority</p>
                      {getPriorityBadge(payoutDetails.priority)}
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Payment Mode</p>
                      <div className="flex items-center gap-2">
                        <CreditCard className="h-4 w-4 text-muted-foreground" />
                        <p className="font-semibold">{payoutDetails.paymentMode}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Due Date</p>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <p className="font-semibold">{payoutDetails.dueDate}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Verification Status</p>
                      {payoutDetails.verified ? (
                        <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Verified
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                          <Clock className="h-3 w-3 mr-1" />
                          Pending
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Patient Information */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Patient Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Patient Name</p>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <p className="font-semibold">{payoutDetails.patientName}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Patient ID</p>
                    <p className="font-mono text-sm">{payoutDetails.patientId}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Treatment Type</p>
                    <p className="font-semibold">{payoutDetails.treatmentType}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Treatment Duration</p>
                    <p className="text-sm">
                      {payoutDetails.admissionDate} to {payoutDetails.dischargeDate}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Claim Breakdown */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Claim Breakdown</CardTitle>
                <CardDescription>Itemized list of charges</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {payoutDetails.claimBreakdown.map((item, index) => (
                    <div key={index}>
                      <div className="flex justify-between items-center">
                        <p className="text-sm">{item.item}</p>
                        <p className="font-semibold">{item.amount}</p>
                      </div>
                      {index < payoutDetails.claimBreakdown.length - 1 && (
                        <Separator className="mt-3" />
                      )}
                    </div>
                  ))}
                  <Separator className="my-4" />
                  <div className="flex justify-between items-center">
                    <p className="font-semibold">Total Amount</p>
                    <p className="text-xl font-bold text-primary">{payoutDetails.amount}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - 1 column */}
          <div className="space-y-6">
            {/* Hospital Contact */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Hospital Contact</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Contact Person</p>
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <p className="font-semibold">{payoutDetails.hospitalContact.name}</p>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Phone</p>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <p className="text-sm">{payoutDetails.hospitalContact.phone}</p>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Email</p>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <p className="text-sm break-all">{payoutDetails.hospitalContact.email}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Bank Details */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Bank Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Account Name</p>
                  <p className="font-semibold">{payoutDetails.bankDetails.accountName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Account Number</p>
                  <p className="font-mono text-sm">{payoutDetails.bankDetails.accountNumber}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">IFSC Code</p>
                  <p className="font-mono text-sm">{payoutDetails.bankDetails.ifsc}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Branch</p>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <p className="text-sm">{payoutDetails.bankDetails.branch}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Timeline */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Processing Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {payoutDetails.timeline.map((event, index) => (
                    <div key={index} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        {event.status === "completed" ? (
                          <CheckCircle2 className="h-5 w-5 text-success" />
                        ) : event.status === "current" ? (
                          <Clock className="h-5 w-5 text-primary animate-pulse" />
                        ) : (
                          <AlertCircle className="h-5 w-5 text-muted-foreground" />
                        )}
                        {index < payoutDetails.timeline.length - 1 && (
                          <div className="w-0.5 h-8 bg-border my-1" />
                        )}
                      </div>
                      <div className="flex-1 pb-4">
                        <p className="font-semibold text-sm">{event.event}</p>
                        <p className="text-xs text-muted-foreground">{event.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
