import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Building2, 
  MapPin, 
  Phone, 
  Mail, 
  Calendar, 
  CreditCard, 
  Award, 
  Activity,
  ArrowLeft,
  UserCircle,
  Stethoscope,
  MapPinned,
  Clock,
  CheckCircle,
  UserPlus,
  X,
  Upload,
  Image as ImageIcon,
  TrendingUp,
  TrendingDown,
  BarChart3
} from "lucide-react";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Bar, BarChart, Line, LineChart, Pie, PieChart, Cell, XAxis, YAxis, CartesianGrid, Legend, ResponsiveContainer } from "recharts";

const hospitalsData = [
  {
    id: 1,
    name: "Apollo Hospitals",
    address: "Sahar Road, Andheri East",
    city: "Mumbai",
    state: "Maharashtra",
    pincode: "400001",
    latitude: "19.0760",
    longitude: "72.8777",
    phone: "+91 22 1234 5678",
    email: "contact@apollo.com",
    beds: 500,
    icuBeds: 50,
    otRooms: 12,
    emergencyUnit: true,
    opdSetup: true,
    category: "Tertiary Care Hospital",
    accreditation: "NABH",
    status: "Active",
    taggingStatus: "Network",
    tags: ["ACKO Internal", "Preferred Partner"],
    activeSince: "2020-03-15",
    rohiniCode: "ROH123456",
    prcNumber: "PRC987654",
    providerId: "PROV001",
    irdaCode: "IRDA12345",
    nhcxCompliant: true,
    serviceTaxNumber: "STX123456789",
    pan: "AABCA1234B",
    gstin: "27AABCA1234B1Z5",
    registrationNumber: "REG123456",
    rohiniExpiry: "2025-12-31",
    nabhExpiry: "2026-06-30",
    registrationExpiry: "2025-12-31",
    accreditationExpiry: "2026-06-30",
    specialties: ["Orthopaedics", "Cardiology", "Neurology", "Oncology"],
    bankAccountNumber: "1234567890",
    bankName: "HDFC Bank",
    ifscCode: "HDFC0001234",
    paymentCycle: "weekly",
    customPaymentDays: "",
    source: "ACKO",
    images: ["hospital1.jpg", "hospital1_interior.jpg"],
    branches: [
      { city: "Mumbai", address: "Sahar Road, Andheri East", pincode: "400001" },
      { city: "Delhi", address: "Jasola, New Delhi", pincode: "110025" },
      { city: "Chennai", address: "Greams Road", pincode: "600006" }
    ],
    doctors: [
      { name: "Dr. Rajesh Kumar", specialty: "Cardiology", experience: "15 years", qualification: "MD, DM (Cardiology)" },
      { name: "Dr. Priya Sharma", specialty: "Neurology", experience: "12 years", qualification: "MD, DM (Neurology)" },
      { name: "Dr. Amit Patel", specialty: "Orthopaedics", experience: "18 years", qualification: "MS (Ortho), MCh" },
      { name: "Dr. Sunita Reddy", specialty: "Oncology", experience: "10 years", qualification: "MD, DM (Medical Oncology)" }
    ],
    auditLog: [
      { date: "2024-01-15", action: "Hospital Onboarded", by: "Amit Sharma", details: "Initial hospital registration completed" },
      { date: "2024-01-18", action: "Documents Verified", by: "Priya Reddy", details: "All legal documents and certifications verified" },
      { date: "2024-01-20", action: "Approved", by: "Dr. Rajesh Kumar", details: "Hospital approved for network inclusion" },
      { date: "2024-02-05", action: "Tariff Updated", by: "Neha Patel", details: "Updated tariff rates for cardiology department" },
      { date: "2024-03-12", action: "Specialties Added", by: "Amit Sharma", details: "Added Oncology specialty" },
      { date: "2024-04-08", action: "Bank Details Updated", by: "Finance Team", details: "Updated bank account information" }
    ]
  },
  {
    id: 2,
    name: "Fortis Healthcare",
    address: "Sector 62, Phase VIII",
    city: "Delhi",
    state: "Delhi",
    pincode: "110001",
    latitude: "28.7041",
    longitude: "77.1025",
    phone: "+91 11 2345 6789",
    email: "info@fortis.com",
    beds: 350,
    icuBeds: 40,
    otRooms: 10,
    emergencyUnit: true,
    opdSetup: true,
    category: "Multi-specialty",
    accreditation: "NABH",
    status: "Active",
    taggingStatus: "Non-Network",
    tags: ["IHX"],
    activeSince: "2019-08-22",
    rohiniCode: "ROH234567",
    prcNumber: "PRC876543",
    providerId: "PROV002",
    irdaCode: "IRDA23456",
    nhcxCompliant: true,
    serviceTaxNumber: "STX234567890",
    pan: "AABCB2345C",
    gstin: "07AABCB2345C1Z5",
    registrationNumber: "REG234567",
    rohiniExpiry: "2025-10-31",
    nabhExpiry: "2026-04-30",
    registrationExpiry: "2025-10-31",
    accreditationExpiry: "2026-04-30",
    specialties: ["Gynaecology", "Paediatrics", "Orthopaedics"],
    bankAccountNumber: "2345678901",
    bankName: "ICICI Bank",
    ifscCode: "ICIC0002345",
    paymentCycle: "daily",
    customPaymentDays: "",
    source: "IHX",
    images: ["hospital2.jpg"],
    branches: [
      { city: "Delhi", address: "Sector 62, Phase VIII", pincode: "110001" },
      { city: "Bangalore", address: "Bannerghatta Road", pincode: "560076" }
    ],
    doctors: [
      { name: "Dr. Meera Singh", specialty: "Gynaecology", experience: "14 years", qualification: "MD, DNB (OBG)" },
      { name: "Dr. Anil Kumar", specialty: "Paediatrics", experience: "16 years", qualification: "MD (Paediatrics), DCH" },
      { name: "Dr. Vikram Malhotra", specialty: "Orthopaedics", experience: "20 years", qualification: "MS (Ortho)" }
    ],
    auditLog: [
      { date: "2024-02-01", action: "Hospital Onboarded", by: "Suresh Kumar", details: "Initial hospital registration completed" },
      { date: "2024-02-03", action: "Documents Verified", by: "Kavita Iyer", details: "All legal documents and certifications verified" },
      { date: "2024-02-05", action: "Approved", by: "Dr. Rajesh Kumar", details: "Hospital approved for network inclusion" },
      { date: "2024-03-20", action: "Branch Added", by: "Amit Sharma", details: "Added Bangalore branch location" }
    ]
  },
  {
    id: 3,
    name: "Max Healthcare",
    address: "Press Enclave Road",
    city: "Bangalore",
    state: "Karnataka",
    pincode: "560001",
    latitude: "12.9716",
    longitude: "77.5946",
    phone: "+91 80 3456 7890",
    email: "contact@maxhealthcare.com",
    beds: 400,
    icuBeds: 45,
    otRooms: 11,
    emergencyUnit: true,
    opdSetup: true,
    category: "Tertiary Care Hospital",
    accreditation: "NABH",
    status: "Active",
    taggingStatus: "Network",
    tags: ["Preferred Partner", "Early Discharge"],
    activeSince: "2018-05-10",
    rohiniCode: "ROH345678",
    prcNumber: "PRC765432",
    providerId: "PROV003",
    irdaCode: "IRDA34567",
    nhcxCompliant: true,
    serviceTaxNumber: "STX345678901",
    pan: "AABCC3456D",
    gstin: "29AABCC3456D1Z5",
    registrationNumber: "REG345678",
    rohiniExpiry: "2025-11-30",
    nabhExpiry: "2026-05-31",
    registrationExpiry: "2025-11-30",
    accreditationExpiry: "2026-05-31",
    specialties: ["Oncology", "Cardiology", "Nephrology", "Gastroenterology"],
    bankAccountNumber: "3456789012",
    bankName: "Axis Bank",
    ifscCode: "UTIB0003456",
    paymentCycle: "custom",
    customPaymentDays: "3",
    source: "TPA1",
    images: ["hospital3.jpg", "hospital3_ward.jpg"],
    branches: [
      { city: "Bangalore", address: "Press Enclave Road", pincode: "560001" },
      { city: "Mumbai", address: "Malad West", pincode: "400064" },
      { city: "Pune", address: "Viman Nagar", pincode: "411014" }
    ],
    doctors: [
      { name: "Dr. Ramesh Babu", specialty: "Oncology", experience: "22 years", qualification: "MD, DM (Medical Oncology)" },
      { name: "Dr. Kavita Nair", specialty: "Cardiology", experience: "18 years", qualification: "MD, DM (Cardiology)" },
      { name: "Dr. Sanjay Gupta", specialty: "Nephrology", experience: "15 years", qualification: "MD, DM (Nephrology)" },
      { name: "Dr. Deepa Iyer", specialty: "Gastroenterology", experience: "13 years", qualification: "MD, DM (Gastro)" }
    ],
    auditLog: [
      { date: "2024-01-10", action: "Hospital Onboarded", by: "Priya Reddy", details: "Initial hospital registration completed" },
      { date: "2024-01-12", action: "Documents Verified", by: "Neha Patel", details: "All legal documents and certifications verified" },
      { date: "2024-01-15", action: "Approved", by: "Dr. Rajesh Kumar", details: "Hospital approved for network inclusion" },
      { date: "2024-02-28", action: "Tariff Updated", by: "Finance Team", details: "Updated tariff rates for all departments" },
      { date: "2024-03-15", action: "Branch Added", by: "Amit Sharma", details: "Added Mumbai and Pune branch locations" },
      { date: "2024-04-10", action: "Accreditation Renewed", by: "Compliance Team", details: "NABH accreditation renewed" }
    ]
  }
];

export default function HospitalDetails() {
  const { id } = useParams();
  const { toast } = useToast();
  const hospital = hospitalsData.find(h => h.id === Number(id));
  
  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState(hospital);
  const [selectedSpecialties, setSelectedSpecialties] = useState<string[]>(hospital?.specialties || []);
  const [uploadedImages, setUploadedImages] = useState<string[]>(hospital?.images || []);
  const [imagePreview, setImagePreview] = useState<string[]>([]);

  const availableSpecialties = [
    "Cardiology", "Neurology", "Orthopaedics", "Oncology", 
    "Gynaecology", "Paediatrics", "Nephrology", "Gastroenterology",
    "Dermatology", "Psychiatry", "Ophthalmology", "ENT",
    "Pulmonology", "Rheumatology", "Endocrinology", "Urology"
  ];

  const handleEdit = () => {
    setIsEditing(true);
    setEditedData(hospital);
    setSelectedSpecialties(hospital?.specialties || []);
    setUploadedImages(hospital?.images || []);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditedData(hospital);
    setSelectedSpecialties(hospital?.specialties || []);
    setUploadedImages(hospital?.images || []);
    setImagePreview([]);
  };

  const handleSave = () => {
    // Update specialties and images in the edited data
    if (editedData) {
      editedData.specialties = selectedSpecialties;
      editedData.images = uploadedImages;
    }
    // Here you would typically save to backend/database
    setIsEditing(false);
    setImagePreview([]);
    toast({
      title: "Changes saved",
      description: "Hospital details have been updated successfully.",
    });
  };

  const handleInputChange = (field: string, value: any) => {
    setEditedData(prev => prev ? { ...prev, [field]: value } : prev);
  };

  const handleAddSpecialty = (specialty: string) => {
    if (!selectedSpecialties.includes(specialty)) {
      setSelectedSpecialties([...selectedSpecialties, specialty]);
    }
  };

  const handleRemoveSpecialty = (specialty: string) => {
    setSelectedSpecialties(selectedSpecialties.filter(s => s !== specialty));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result as string;
          setImagePreview(prev => [...prev, result]);
          setUploadedImages(prev => [...prev, file.name]);
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const handleRemoveImage = (index: number) => {
    setImagePreview(prev => prev.filter((_, i) => i !== index));
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  const currentData = isEditing ? editedData : hospital;

  if (!hospital || !currentData) {
    return (
      <div className="min-h-screen bg-background">
        <PageHeader
          title="Hospital Not Found"
          description="The hospital you're looking for doesn't exist"
          icon={Building2}
        />
        <div className="container mx-auto px-6 py-8">
          <Link to="/hospitals">
            <Button variant="outline" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Hospitals
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title={hospital.name}
        description={`${hospital.category} - ${hospital.city}, ${hospital.state}`}
        icon={Building2}
        actions={
          <div className="flex gap-2">
            <Link to="/hospitals">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
            </Link>
            {isEditing ? (
              <>
                <Button variant="outline" onClick={handleCancel}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  Save Changes
                </Button>
              </>
            ) : (
              <Button onClick={handleEdit}>Edit Hospital</Button>
            )}
          </div>
        }
      />

      <div className="container mx-auto px-6 py-8">
        {/* Main Tabs: Hospital Details and Analytics & Reports */}
        <Tabs defaultValue="hospital-details" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8 h-12">
            <TabsTrigger value="hospital-details" className="text-base">
              Hospital Details
            </TabsTrigger>
            <TabsTrigger value="analytics-reports" className="text-base">
              Analytics & Reports
            </TabsTrigger>
          </TabsList>

          {/* Hospital Details Tab Content */}
          <TabsContent value="hospital-details">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-6 mb-6">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="infrastructure">Infrastructure</TabsTrigger>
                <TabsTrigger value="locations">Locations</TabsTrigger>
                <TabsTrigger value="staff">Medical Staff</TabsTrigger>
                <TabsTrigger value="legal">Legal & Compliance</TabsTrigger>
                <TabsTrigger value="banking">Banking</TabsTrigger>
              </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Basic Details */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  Basic Details
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Name:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.name}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Address:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.address}
                        onChange={(e) => handleInputChange('address', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.address}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">City:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.city}
                        onChange={(e) => handleInputChange('city', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.city}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">State:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.state}
                        onChange={(e) => handleInputChange('state', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.state}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Pincode:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.pincode}
                        onChange={(e) => handleInputChange('pincode', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.pincode}</p>
                    )}
                  </div>
                  <div className="md:col-span-2">
                    <span className="text-muted-foreground">Status:</span>
                    <div className="flex items-center gap-2 flex-wrap mt-1">
                      <Badge 
                        variant="outline" 
                        className={
                          currentData.taggingStatus === "Network" 
                            ? "bg-success/10 text-success border-success/20"
                            : currentData.taggingStatus === "Non-Network"
                            ? "bg-warning/10 text-warning border-warning/20"
                            : "bg-destructive/10 text-destructive border-destructive/20"
                        }
                      >
                        {currentData.taggingStatus}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        (since {new Date(currentData.activeSince).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })})
                      </span>
                    </div>
                  </div>
                  {currentData.tags && currentData.tags.length > 0 && (
                    <div className="md:col-span-3">
                      <span className="text-muted-foreground">Tags:</span>
                      <div className="flex items-center gap-2 flex-wrap mt-1">
                        {currentData.tags.map((tag: string) => (
                          <Badge 
                            key={tag}
                            variant="secondary"
                            className={
                              tag === "Suspicious"
                                ? "bg-destructive/10 text-destructive border-destructive/20"
                                : tag === "ACKO Internal" || tag === "IHX"
                                ? "bg-primary/10 text-primary border-primary/20"
                                : tag === "Preferred Partner"
                                ? "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20"
                                : tag === "Early Discharge"
                                ? "bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20"
                                : "bg-muted text-muted-foreground"
                            }
                          >
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Phone className="h-5 w-5 text-primary" />
                  Contact Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Email:</span>
                    {isEditing ? (
                      <Input
                        type="email"
                        value={currentData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">
                        <a href={`mailto:${currentData.email}`} className="text-primary hover:underline">
                          {currentData.email}
                        </a>
                      </p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Phone Number:</span>
                    {isEditing ? (
                      <Input
                        type="tel"
                        value={currentData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">
                        <a href={`tel:${currentData.phone}`} className="text-primary hover:underline">
                          {currentData.phone}
                        </a>
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Category & Accreditations */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" />
                  Category & Accreditations
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Category:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.category}
                        onChange={(e) => handleInputChange('category', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.category}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Accreditation:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.accreditation}
                        onChange={(e) => handleInputChange('accreditation', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.accreditation}</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Data Source */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Data Source</h3>
                <div className="text-sm">
                  <span className="text-muted-foreground">Source:</span>
                  <p className="font-medium">{hospital.source}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Infrastructure Tab */}
          <TabsContent value="infrastructure" className="space-y-6">
            {/* Infrastructure Information */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Infrastructure Information
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">No. of Beds:</span>
                    {isEditing ? (
                      <Input
                        type="number"
                        value={currentData.beds}
                        onChange={(e) => handleInputChange('beds', Number(e.target.value))}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.beds}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">ICU Beds:</span>
                    {isEditing ? (
                      <Input
                        type="number"
                        value={currentData.icuBeds}
                        onChange={(e) => handleInputChange('icuBeds', Number(e.target.value))}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.icuBeds}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">OT Rooms:</span>
                    {isEditing ? (
                      <Input
                        type="number"
                        value={currentData.otRooms}
                        onChange={(e) => handleInputChange('otRooms', Number(e.target.value))}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.otRooms}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Emergency Unit:</span>
                    <p className="font-medium">{currentData.emergencyUnit ? "Yes" : "No"}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">OPD Setup:</span>
                    <p className="font-medium">{currentData.opdSetup ? "Yes" : "No"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Specialties */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Specialties</h3>
                {isEditing ? (
                  <div className="space-y-4">
                    <Select onValueChange={handleAddSpecialty}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Add specialty" />
                      </SelectTrigger>
                      <SelectContent className="bg-background z-50">
                        {availableSpecialties.map((specialty) => (
                          <SelectItem key={specialty} value={specialty}>
                            {specialty}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="flex gap-2 flex-wrap">
                      {selectedSpecialties.map((specialty, idx) => (
                        <Badge key={idx} variant="outline" className="gap-1 pr-1">
                          {specialty}
                          <button
                            onClick={() => handleRemoveSpecialty(specialty)}
                            className="ml-1 hover:bg-destructive/20 rounded-full p-0.5"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex gap-2 flex-wrap">
                    {(currentData?.specialties || selectedSpecialties).map((specialty, idx) => (
                      <Badge key={idx} variant="outline">{specialty}</Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Images */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <ImageIcon className="h-5 w-5 text-primary" />
                  Images
                </h3>
                {isEditing ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <label className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 cursor-pointer transition-colors">
                        <Upload className="h-4 w-4" />
                        Upload Images
                        <input
                          type="file"
                          multiple
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                        />
                      </label>
                      <span className="text-sm text-muted-foreground">
                        {uploadedImages.length} image(s)
                      </span>
                    </div>
                    
                    {/* Image Previews */}
                    {imagePreview.length > 0 && (
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {imagePreview.map((preview, idx) => (
                          <div key={idx} className="relative group">
                            <img
                              src={preview}
                              alt={`Preview ${idx + 1}`}
                              className="w-full h-32 object-cover rounded-lg border border-border"
                            />
                            <button
                              onClick={() => handleRemoveImage(idx)}
                              className="absolute top-2 right-2 p-1 bg-destructive text-destructive-foreground rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <X className="h-4 w-4" />
                            </button>
                            <p className="text-xs text-muted-foreground mt-1 truncate">
                              {uploadedImages[idx]}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                    
                    {/* Existing Images */}
                    {uploadedImages.length > 0 && imagePreview.length === 0 && (
                      <div className="flex gap-2 flex-wrap">
                        {uploadedImages.map((img, idx) => (
                          <Badge key={idx} variant="outline" className="gap-1 pr-1">
                            {img}
                            <button
                              onClick={() => handleRemoveImage(idx)}
                              className="ml-1 hover:bg-destructive/20 rounded-full p-0.5"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex gap-2 flex-wrap">
                    {currentData?.images.map((img, idx) => (
                      <Badge key={idx} variant="outline">{img}</Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Locations Tab */}
          <TabsContent value="locations" className="space-y-6">
            {/* Branch Locations */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <MapPinned className="h-5 w-5 text-primary" />
                  Branch Locations
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {hospital.branches.map((branch, idx) => (
                    <Link 
                      key={idx} 
                      to={`/hospitals?city=${encodeURIComponent(branch.city)}`}
                      className="p-4 rounded-lg border border-border bg-muted/30 hover:bg-muted/50 hover:border-primary/50 transition-all cursor-pointer"
                    >
                      <div className="flex items-start gap-2">
                        <MapPin className="h-4 w-4 text-primary mt-1" />
                        <div>
                          <p className="font-semibold text-primary hover:underline">{branch.city}</p>
                          <p className="text-sm text-muted-foreground">{branch.address}</p>
                          <p className="text-sm text-muted-foreground">PIN: {branch.pincode}</p>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Geo-coordinates */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  Geo-coordinates
                </h3>
                <div className="text-sm">
                  <p className="font-medium">
                    <a 
                      href={`https://www.google.com/maps?q=${hospital.latitude},${hospital.longitude}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                    >
                      Latitude: {hospital.latitude}, Longitude: {hospital.longitude}
                    </a>
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Medical Staff Tab */}
          <TabsContent value="staff" className="space-y-6">
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Stethoscope className="h-5 w-5 text-primary" />
                  Medical Staff
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {hospital.doctors.map((doctor, idx) => (
                    <div key={idx} className="p-4 rounded-lg border border-border bg-muted/30">
                      <div className="flex items-start gap-3">
                        <UserCircle className="h-10 w-10 text-primary" />
                        <div className="flex-1">
                          <p className="font-semibold">{doctor.name}</p>
                          <div className="mt-1 space-y-1">
                            <Badge variant="outline" className="text-xs">
                              {doctor.specialty}
                            </Badge>
                            <p className="text-xs text-muted-foreground">{doctor.qualification}</p>
                            <p className="text-xs text-muted-foreground">Experience: {doctor.experience}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Legal & Compliance Tab */}
          <TabsContent value="legal" className="space-y-6">
            {/* Unique Identifiers */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Unique Identifiers</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">ROHINI Code:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.rohiniCode}
                        onChange={(e) => handleInputChange('rohiniCode', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.rohiniCode}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">PRC Number:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.prcNumber}
                        onChange={(e) => handleInputChange('prcNumber', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.prcNumber}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Provider ID:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.providerId}
                        onChange={(e) => handleInputChange('providerId', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.providerId}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">IRDA Code:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.irdaCode}
                        onChange={(e) => handleInputChange('irdaCode', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.irdaCode}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">NHCX Compliant:</span>
                    <p className="font-medium">{currentData.nhcxCompliant ? "Yes" : "No"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Legal Identifiers */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                  Legal Identifiers
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Service Tax Number:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.serviceTaxNumber}
                        onChange={(e) => handleInputChange('serviceTaxNumber', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.serviceTaxNumber}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">PAN:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.pan}
                        onChange={(e) => handleInputChange('pan', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.pan}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">GSTIN:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.gstin}
                        onChange={(e) => handleInputChange('gstin', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.gstin}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Registration Number:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.registrationNumber}
                        onChange={(e) => handleInputChange('registrationNumber', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.registrationNumber}</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Expiry Dates */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  Expiry Dates
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">ROHINI Expiry:</span>
                    {isEditing ? (
                      <Input
                        type="date"
                        value={currentData.rohiniExpiry}
                        onChange={(e) => handleInputChange('rohiniExpiry', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.rohiniExpiry}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">NABH Expiry:</span>
                    {isEditing ? (
                      <Input
                        type="date"
                        value={currentData.nabhExpiry}
                        onChange={(e) => handleInputChange('nabhExpiry', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.nabhExpiry}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Registration Expiry:</span>
                    {isEditing ? (
                      <Input
                        type="date"
                        value={currentData.registrationExpiry}
                        onChange={(e) => handleInputChange('registrationExpiry', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.registrationExpiry}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Accreditation Expiry:</span>
                    {isEditing ? (
                      <Input
                        type="date"
                        value={currentData.accreditationExpiry}
                        onChange={(e) => handleInputChange('accreditationExpiry', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.accreditationExpiry}</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Banking Tab */}
          <TabsContent value="banking" className="space-y-6">
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                  Bank Account Details
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Account Number:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.bankAccountNumber}
                        onChange={(e) => handleInputChange('bankAccountNumber', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.bankAccountNumber}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Bank Name:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.bankName}
                        onChange={(e) => handleInputChange('bankName', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.bankName}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">IFSC Code:</span>
                    {isEditing ? (
                      <Input
                        value={currentData.ifscCode}
                        onChange={(e) => handleInputChange('ifscCode', e.target.value)}
                        className="mt-1"
                      />
                    ) : (
                      <p className="font-medium">{currentData.ifscCode}</p>
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Payment Cycle:</span>
                    {isEditing ? (
                      <Select
                        value={currentData.paymentCycle}
                        onValueChange={(value) => {
                          handleInputChange('paymentCycle', value);
                          if (value !== 'custom') {
                            handleInputChange('customPaymentDays', '');
                          }
                        }}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select payment cycle" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="custom">Custom</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="font-medium capitalize">
                        {currentData.paymentCycle === 'custom' 
                          ? `Custom (${currentData.customPaymentDays} days)`
                          : currentData.paymentCycle}
                      </p>
                    )}
                  </div>
                  {isEditing && currentData.paymentCycle === 'custom' && (
                    <div>
                      <span className="text-muted-foreground">Custom Payment Days:</span>
                      <Input
                        type="number"
                        min="1"
                        placeholder="e.g., 2, 3, 5"
                        value={currentData.customPaymentDays}
                        onChange={(e) => handleInputChange('customPaymentDays', e.target.value)}
                        className="mt-1"
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Enter number of days for custom payment cycle
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
            </TabsContent>
            </Tabs>
          </TabsContent>

          {/* Analytics & Reports Tab Content */}
          <TabsContent value="analytics-reports">
            <Tabs defaultValue="analytics" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="analytics">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Analytics
                </TabsTrigger>
                <TabsTrigger value="audit">
                  <Clock className="h-4 w-4 mr-2" />
                  Audit Log
                </TabsTrigger>
              </TabsList>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            {/* Key Metrics Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="shadow-card">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Avg Cashless Claim</p>
                      <p className="text-2xl font-bold mt-1">₹45,320</p>
                      <div className="flex items-center gap-1 mt-1">
                        <TrendingUp className="h-3 w-3 text-success" />
                        <span className="text-xs text-success">+12.5%</span>
                        <span className="text-xs text-muted-foreground">vs last month</span>
                      </div>
                    </div>
                    <BarChart3 className="h-8 w-8 text-primary/50" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="shadow-card">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Avg Reimbursement Claim</p>
                      <p className="text-2xl font-bold mt-1">₹32,180</p>
                      <div className="flex items-center gap-1 mt-1">
                        <TrendingDown className="h-3 w-3 text-destructive" />
                        <span className="text-xs text-destructive">-3.2%</span>
                        <span className="text-xs text-muted-foreground">vs last month</span>
                      </div>
                    </div>
                    <BarChart3 className="h-8 w-8 text-primary/50" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="shadow-card">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Claims (MTD)</p>
                      <p className="text-2xl font-bold mt-1">1,247</p>
                      <div className="flex items-center gap-1 mt-1">
                        <TrendingUp className="h-3 w-3 text-success" />
                        <span className="text-xs text-success">+8.4%</span>
                        <span className="text-xs text-muted-foreground">vs last month</span>
                      </div>
                    </div>
                    <Activity className="h-8 w-8 text-primary/50" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="shadow-card">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Claim Value</p>
                      <p className="text-2xl font-bold mt-1">₹5.2Cr</p>
                      <div className="flex items-center gap-1 mt-1">
                        <TrendingUp className="h-3 w-3 text-success" />
                        <span className="text-xs text-success">+15.7%</span>
                        <span className="text-xs text-muted-foreground">vs last month</span>
                      </div>
                    </div>
                    <CreditCard className="h-8 w-8 text-primary/50" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Claim Volume Trends */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="shadow-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Monthly Claim Volume</h3>
                  <ChartContainer 
                    config={{
                      cashless: { label: "Cashless", color: "hsl(var(--primary))" },
                      reimbursement: { label: "Reimbursement", color: "hsl(var(--chart-2))" }
                    }}
                    className="h-[300px]"
                  >
                    <LineChart
                      data={[
                        { month: "Jan", cashless: 320, reimbursement: 180 },
                        { month: "Feb", cashless: 385, reimbursement: 220 },
                        { month: "Mar", cashless: 410, reimbursement: 195 },
                        { month: "Apr", cashless: 450, reimbursement: 240 },
                        { month: "May", cashless: 520, reimbursement: 280 },
                        { month: "Jun", cashless: 485, reimbursement: 250 }
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Legend />
                      <Line type="monotone" dataKey="cashless" stroke="hsl(var(--primary))" strokeWidth={2} name="Cashless" />
                      <Line type="monotone" dataKey="reimbursement" stroke="hsl(var(--chart-2))" strokeWidth={2} name="Reimbursement" />
                    </LineChart>
                  </ChartContainer>
                </CardContent>
              </Card>

              <Card className="shadow-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Average Claim Size Trend</h3>
                  <ChartContainer 
                    config={{
                      cashless: { label: "Cashless", color: "hsl(var(--primary))" },
                      reimbursement: { label: "Reimbursement", color: "hsl(var(--chart-2))" }
                    }}
                    className="h-[300px]"
                  >
                    <LineChart
                      data={[
                        { month: "Jan", cashless: 42500, reimbursement: 31200 },
                        { month: "Feb", cashless: 43200, reimbursement: 32800 },
                        { month: "Mar", cashless: 44100, reimbursement: 33500 },
                        { month: "Apr", cashless: 44800, reimbursement: 32900 },
                        { month: "May", cashless: 45320, reimbursement: 32180 },
                        { month: "Jun", cashless: 46100, reimbursement: 33400 }
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Legend />
                      <Line type="monotone" dataKey="cashless" stroke="hsl(var(--primary))" strokeWidth={2} name="Cashless (₹)" />
                      <Line type="monotone" dataKey="reimbursement" stroke="hsl(var(--chart-2))" strokeWidth={2} name="Reimbursement (₹)" />
                    </LineChart>
                  </ChartContainer>
                </CardContent>
              </Card>
            </div>

            {/* Top Treatments & City Distribution */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="shadow-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Top Treatments & Procedures</h3>
                  <ChartContainer 
                    config={{
                      claims: { label: "Claims", color: "hsl(var(--primary))" }
                    }}
                    className="h-[300px]"
                  >
                    <BarChart
                      data={[
                        { treatment: "Cardiac Surgery", claims: 145, avgClaim: 125000 },
                        { treatment: "Ortho Surgery", claims: 230, avgClaim: 85000 },
                        { treatment: "Neurosurgery", claims: 95, avgClaim: 150000 },
                        { treatment: "Oncology Treatment", claims: 180, avgClaim: 95000 },
                        { treatment: "Gastro Procedures", claims: 165, avgClaim: 65000 },
                        { treatment: "Kidney Transplant", claims: 45, avgClaim: 280000 }
                      ]}
                      layout="vertical"
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="treatment" type="category" width={120} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="claims" fill="hsl(var(--primary))" name="Number of Claims" />
                    </BarChart>
                  </ChartContainer>
                </CardContent>
              </Card>

              <Card className="shadow-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Claim Value by Top Cities</h3>
                  <ChartContainer 
                    config={{
                      value: { label: "Claim Value", color: "hsl(var(--chart-3))" }
                    }}
                    className="h-[300px]"
                  >
                    <BarChart
                      data={[
                        { city: "Mumbai", value: 18500000 },
                        { city: "Delhi", value: 15200000 },
                        { city: "Bangalore", value: 12800000 },
                        { city: "Chennai", value: 9500000 },
                        { city: "Pune", value: 7800000 },
                        { city: "Hyderabad", value: 6200000 }
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="city" />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="value" fill="hsl(var(--chart-3))" name="Claim Value (₹)" />
                    </BarChart>
                  </ChartContainer>
                </CardContent>
              </Card>
            </div>

            {/* Policy Type & WoW/MoM Comparison */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="shadow-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Retail vs GMC Split</h3>
                  <ChartContainer 
                    config={{
                      retail: { label: "Retail", color: "hsl(var(--primary))" },
                      gmc: { label: "GMC", color: "hsl(var(--chart-4))" }
                    }}
                    className="h-[300px]"
                  >
                    <PieChart>
                      <Pie
                        data={[
                          { name: "Retail", value: 65, fill: "hsl(var(--primary))" },
                          { name: "GMC", value: 35, fill: "hsl(var(--chart-4))" }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={100}
                        dataKey="value"
                      />
                      <ChartTooltip content={<ChartTooltipContent />} />
                    </PieChart>
                  </ChartContainer>
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground">Retail Claims</p>
                      <p className="text-xl font-bold">810</p>
                      <p className="text-xs text-muted-foreground">Avg: ₹42,500</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground">GMC Claims</p>
                      <p className="text-xl font-bold">437</p>
                      <p className="text-xs text-muted-foreground">Avg: ₹38,200</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Week-over-Week & Month-over-Month Trends</h3>
                  <div className="space-y-4">
                    <div className="p-4 rounded-lg border border-border bg-muted/30">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-sm font-medium">Claim Volume (WoW)</p>
                        <div className="flex items-center gap-1">
                          <TrendingUp className="h-4 w-4 text-success" />
                          <span className="text-sm font-semibold text-success">+8.4%</span>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Current week: 312 claims | Previous week: 288 claims
                      </p>
                    </div>

                    <div className="p-4 rounded-lg border border-border bg-muted/30">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-sm font-medium">Avg Claim Size (WoW)</p>
                        <div className="flex items-center gap-1">
                          <TrendingUp className="h-4 w-4 text-success" />
                          <span className="text-sm font-semibold text-success">+2.1%</span>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Current: ₹41,250 | Previous: ₹40,400
                      </p>
                    </div>

                    <div className="p-4 rounded-lg border border-border bg-muted/30">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-sm font-medium">Claim Volume (MoM)</p>
                        <div className="flex items-center gap-1">
                          <TrendingUp className="h-4 w-4 text-success" />
                          <span className="text-sm font-semibold text-success">+12.5%</span>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Current month: 1,247 claims | Previous month: 1,109 claims
                      </p>
                    </div>

                    <div className="p-4 rounded-lg border border-border bg-muted/30">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-sm font-medium">Avg Claim Size (MoM)</p>
                        <div className="flex items-center gap-1">
                          <TrendingUp className="h-4 w-4 text-success" />
                          <span className="text-sm font-semibold text-success">+5.8%</span>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Current: ₹45,320 | Previous: ₹42,840
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Additional Analytics */}
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Claim Processing Efficiency</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg border border-border bg-muted/30 text-center">
                    <p className="text-sm text-muted-foreground mb-1">Average length of stay</p>
                    <p className="text-2xl font-bold">2.3 days</p>
                    <Badge variant="outline" className="mt-2 bg-success/10 text-success border-success/20">
                      Fast Processing
                    </Badge>
                  </div>
                  <div className="p-4 rounded-lg border border-border bg-muted/30 text-center">
                    <p className="text-sm text-muted-foreground mb-1">Approval Rate</p>
                    <p className="text-2xl font-bold">94.2%</p>
                    <Badge variant="outline" className="mt-2 bg-success/10 text-success border-success/20">
                      Excellent
                    </Badge>
                  </div>
                  <div className="p-4 rounded-lg border border-border bg-muted/30 text-center">
                    <p className="text-sm text-muted-foreground mb-1">Query Rate</p>
                    <p className="text-2xl font-bold">8.5%</p>
                    <Badge variant="outline" className="mt-2 bg-warning/10 text-warning border-warning/20">
                      Good
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Audit Log Tab */}
          <TabsContent value="audit" className="space-y-6">
            <Card className="shadow-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  Audit Trail & Timeline
                </h3>
                <div className="space-y-4">
                  {hospital.auditLog.slice().reverse().map((log, idx) => (
                    <div key={idx} className="flex gap-4 p-4 rounded-lg border border-border bg-muted/30">
                      <div className="flex-shrink-0">
                        {log.action === "Approved" ? (
                          <CheckCircle className="h-8 w-8 text-success" />
                        ) : log.action === "Hospital Onboarded" ? (
                          <UserPlus className="h-8 w-8 text-primary" />
                        ) : (
                          <Clock className="h-8 w-8 text-muted-foreground" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="font-semibold">{log.action}</p>
                            <p className="text-sm text-muted-foreground mt-1">{log.details}</p>
                          </div>
                          <Badge variant="outline" className="text-xs whitespace-nowrap">
                            {log.date}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          By: <span className="font-medium">{log.by}</span>
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            </TabsContent>
            </Tabs>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
