import { useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CreditCard, AlertCircle, CheckCircle2, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function ProcessingPayouts() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [selectedPayouts, setSelectedPayouts] = useState<number[]>([]);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);

  const pendingPayouts = [
    {
      id: 1,
      hospital: "Apollo Hospitals",
      claimId: "CLM-2025-001235",
      amount: "₹2,50,000",
      priority: "High",
      dueDate: "22-Jan-2025",
      paymentMode: "RTGS",
      verified: true,
    },
    {
      id: 2,
      hospital: "Fortis Healthcare",
      claimId: "CLM-2025-001240",
      amount: "₹1,75,000",
      priority: "Medium",
      dueDate: "23-Jan-2025",
      paymentMode: "NEFT",
      verified: true,
    },
    {
      id: 3,
      hospital: "Max Healthcare",
      claimId: "CLM-2025-001241",
      amount: "₹95,000",
      priority: "Low",
      dueDate: "25-Jan-2025",
      paymentMode: "IMPS",
      verified: false,
    },
    {
      id: 4,
      hospital: "Narayana Health",
      claimId: "CLM-2025-001242",
      amount: "₹3,20,000",
      priority: "High",
      dueDate: "22-Jan-2025",
      paymentMode: "RTGS",
      verified: true,
    },
    {
      id: 5,
      hospital: "Manipal Hospitals",
      claimId: "CLM-2025-001243",
      amount: "₹1,45,000",
      priority: "Medium",
      dueDate: "24-Jan-2025",
      paymentMode: "NEFT",
      verified: true,
    },
  ];

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedPayouts(pendingPayouts.map((p) => p.id));
    } else {
      setSelectedPayouts([]);
    }
  };

  const handleSelectPayout = (id: number, checked: boolean) => {
    if (checked) {
      setSelectedPayouts([...selectedPayouts, id]);
    } else {
      setSelectedPayouts(selectedPayouts.filter((payoutId) => payoutId !== id));
    }
  };

  const handleProcessPayouts = () => {
    if (selectedPayouts.length === 0) {
      toast({
        title: "No payouts selected",
        description: "Please select at least one payout to process.",
        variant: "destructive",
      });
      return;
    }
    setShowConfirmDialog(true);
  };

  const confirmProcessPayouts = () => {
    // In a real app, this would make an API call to process the payouts
    toast({
      title: "Payouts Processed",
      description: `Successfully initiated ${selectedPayouts.length} payout(s). They will be completed within 24-48 hours.`,
    });
    setSelectedPayouts([]);
    setShowConfirmDialog(false);
  };

  const getPriorityBadge = (priority: string) => {
    const config: Record<string, string> = {
      High: "bg-destructive/10 text-destructive border-destructive/20",
      Medium: "bg-warning/10 text-warning border-warning/20",
      Low: "bg-muted text-muted-foreground border-border",
    };
    return (
      <Badge variant="outline" className={config[priority]}>
        {priority}
      </Badge>
    );
  };

  const totalAmount = pendingPayouts
    .filter((p) => selectedPayouts.includes(p.id))
    .reduce((sum, p) => {
      const amount = parseFloat(p.amount.replace(/[₹,]/g, ""));
      return sum + amount;
    }, 0);

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Process Pending Payouts"
        description="Review and approve pending hospital payments"
        icon={CreditCard}
        actions={
          <Button variant="outline" onClick={() => navigate("/payouts")}>
            Back to Payout Tracking
          </Button>
        }
      />

      <div className="container mx-auto px-6 py-8">
        {/* Summary Card */}
        <Card className="mb-8 shadow-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Selected Payouts</p>
                <p className="text-3xl font-bold">
                  {selectedPayouts.length} / {pendingPayouts.length}
                </p>
                {selectedPayouts.length > 0 && (
                  <p className="text-sm text-muted-foreground">
                    Total Amount: ₹{totalAmount.toLocaleString("en-IN")}
                  </p>
                )}
              </div>
              <Button
                size="lg"
                onClick={handleProcessPayouts}
                disabled={selectedPayouts.length === 0}
                className="gap-2"
              >
                <CheckCircle2 className="h-5 w-5" />
                Process Selected Payouts
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Pending Payouts Table */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Pending Payouts Queue</CardTitle>
            <CardDescription>
              Select payouts to process and initiate payment transfer
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedPayouts.length === pendingPayouts.length}
                      onCheckedChange={handleSelectAll}
                    />
                  </TableHead>
                  <TableHead>Hospital</TableHead>
                  <TableHead>Claim ID</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Payment Mode</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingPayouts.map((payout) => (
                  <TableRow key={payout.id}>
                    <TableCell>
                      <Checkbox
                        checked={selectedPayouts.includes(payout.id)}
                        onCheckedChange={(checked) =>
                          handleSelectPayout(payout.id, checked as boolean)
                        }
                      />
                    </TableCell>
                    <TableCell className="font-medium">{payout.hospital}</TableCell>
                    <TableCell className="font-mono text-sm">{payout.claimId}</TableCell>
                    <TableCell className="font-semibold">{payout.amount}</TableCell>
                    <TableCell>{payout.paymentMode}</TableCell>
                    <TableCell>{getPriorityBadge(payout.priority)}</TableCell>
                    <TableCell>{payout.dueDate}</TableCell>
                    <TableCell>
                      {payout.verified ? (
                        <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Verified
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                          <Clock className="h-3 w-3 mr-1" />
                          Pending Verification
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => navigate(`/payouts/processing/${payout.id}`)}
                      >
                        View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Info Card */}
        <Card className="mt-6 shadow-card border-primary/20">
          <CardContent className="p-6">
            <div className="flex gap-4">
              <AlertCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold text-foreground">Processing Information</p>
                <p className="text-sm text-muted-foreground">
                  Once you process the selected payouts, the payment will be initiated immediately
                  and should reach the hospital accounts within 24-48 hours depending on the
                  payment mode selected. All transactions are logged and auditable.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Payout Processing</AlertDialogTitle>
            <AlertDialogDescription>
              You are about to process {selectedPayouts.length} payout(s) with a total amount of
              ₹{totalAmount.toLocaleString("en-IN")}. This action will initiate the payment
              transfer and cannot be undone. Are you sure you want to continue?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmProcessPayouts}>
              Confirm & Process
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
