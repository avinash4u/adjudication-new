import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, Search, ArrowLeft, Building2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { AddTariffDialog } from "@/components/tariff/AddTariffDialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import apolloHospitalImg from "@/assets/hospitals/apollo-hospital.jpg";
import fortisHospitalImg from "@/assets/hospitals/fortis-hospital.jpg";
import maxHospitalImg from "@/assets/hospitals/max-hospital.jpg";
import lilavatiHospitalImg from "@/assets/hospitals/lilavati-hospital.jpg";
import manipalHospitalImg from "@/assets/hospitals/manipal-hospital.jpg";
import medantaHospitalImg from "@/assets/hospitals/medanta-hospital.jpg";
import cloudnineHospitalImg from "@/assets/hospitals/cloudnine-hospital.jpg";
import kokilabenHospitalImg from "@/assets/hospitals/kokilaben-hospital.jpg";

export default function TariffManagement() {
  const { hospitalId } = useParams();
  const navigate = useNavigate();
  const [selectedHospitalId, setSelectedHospitalId] = useState<number | null>(
    hospitalId ? Number(hospitalId) : null
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [packageSearchTerm, setPackageSearchTerm] = useState("");

  useEffect(() => {
    if (hospitalId) {
      setSelectedHospitalId(Number(hospitalId));
    } else {
      setSelectedHospitalId(null);
    }
  }, [hospitalId]);

  const hospitals = [
    { id: 1, name: "Apollo Hospitals", image: apolloHospitalImg, location: "Multiple locations across India" },
    { id: 2, name: "Fortis Healthcare", image: fortisHospitalImg, location: "Multiple locations across India" },
    { id: 3, name: "Max Healthcare", image: maxHospitalImg, location: "Delhi NCR" },
    { id: 4, name: "Lilavati Hospital", image: lilavatiHospitalImg, location: "Mumbai" },
    { id: 5, name: "Manipal Hospitals", image: manipalHospitalImg, location: "Bangalore" },
    { id: 6, name: "Medanta - The Medicity", image: medantaHospitalImg, location: "Gurugram" },
    { id: 7, name: "Cloudnine Hospitals", image: cloudnineHospitalImg, location: "Multiple locations" },
    { id: 8, name: "Kokilaben Hospital", image: kokilabenHospitalImg, location: "Mumbai" },
  ];

  const tariffData = [
    {
      hospitalId: 1,
      hospitalName: "Apollo Hospitals",
      effectiveDate: "01-Apr-2025",
      expiryDate: "01-Apr-2026",
      packages: [
        {
          packageCode: "PKG000396",
          packageName: "BALLOON ATRIAL SEPTOSTOMY (EM) PKG",
          opd: "40300",
          executiveOpd: "",
          general: "45500",
          twinSharing: "47200",
          semiPrivate: "49600",
          private: "63100",
          deluxe: "79600",
          superDeluxe: "88500",
          suite: "99300",
          presidentialSuite: "125000",
          vipRoom: "112000",
          vvipRoom: "138000",
          dayCare: "38000",
          ipdDiscount: "10%",
          opdDiscount: "8%",
        },
        {
          packageCode: "PKG000401",
          packageName: "ANGIOGRAPHY DAY CARE PACKAGE",
          opd: "16800",
          executiveOpd: "16800",
          general: "17000",
          twinSharing: "21000",
          semiPrivate: "25900",
          private: "32900",
          deluxe: "35900",
          superDeluxe: "39500",
          suite: "43900",
          presidentialSuite: "55000",
          vipRoom: "49500",
          vvipRoom: "62000",
          dayCare: "15500",
          ipdDiscount: "15%",
          opdDiscount: "12%",
        },
        {
          packageCode: "PKG000402",
          packageName: "ENDOMYOCARDIAL BIOPSY PKG",
          opd: "23800",
          executiveOpd: "23800",
          general: "24800",
          twinSharing: "26300",
          semiPrivate: "28100",
          private: "39900",
          deluxe: "42100",
          superDeluxe: "47200",
          suite: "53200",
          presidentialSuite: "66500",
          vipRoom: "59800",
          vvipRoom: "74000",
          dayCare: "22500",
          discount: "5%",
        },
        {
          packageCode: "PKG000403",
          packageName: "PARAVALVULAR LEAK DEVICE CLOSER (EM) PKG",
          opd: "96700",
          executiveOpd: "",
          general: "103400",
          twinSharing: "115000",
          semiPrivate: "129400",
          private: "160000",
          deluxe: "178000",
          superDeluxe: "198000",
          suite: "219500",
          presidentialSuite: "275000",
          vipRoom: "247000",
          vvipRoom: "305000",
          dayCare: "92000",
          discount: "12%",
        },
        {
          packageCode: "PKG000404",
          packageName: "ELECTROPHYSIOLOGY STUDY WITH RADIO FREQUENCY ABLATION (EM) PKG",
          opd: "84500",
          executiveOpd: "84500",
          general: "92800",
          twinSharing: "101000",
          semiPrivate: "110500",
          private: "145800",
          deluxe: "188500",
          superDeluxe: "232000",
          suite: "277900",
          presidentialSuite: "348000",
          vipRoom: "312000",
          vvipRoom: "385000",
          dayCare: "81000",
          discount: "8%",
        },
        {
          packageCode: "PKG000405",
          packageName: "CORONARY ARTERY BYPASS GRAFTING (CABG) PKG",
          opd: "285000",
          executiveOpd: "285000",
          general: "295000",
          twinSharing: "310000",
          semiPrivate: "325000",
          private: "385000",
          deluxe: "425000",
          superDeluxe: "460000",
          suite: "495000",
          presidentialSuite: "620000",
          vipRoom: "557000",
          vvipRoom: "688000",
          dayCare: "272000",
          discount: "10%",
        },
        {
          packageCode: "PKG000406",
          packageName: "PACEMAKER IMPLANTATION (SINGLE CHAMBER) PKG",
          opd: "125000",
          executiveOpd: "125000",
          general: "135000",
          twinSharing: "145000",
          semiPrivate: "155000",
          private: "185000",
          deluxe: "215000",
          superDeluxe: "235000",
          suite: "255000",
          presidentialSuite: "320000",
          vipRoom: "287000",
          vvipRoom: "355000",
          dayCare: "120000",
          discount: "8%",
        },
        {
          packageCode: "PKG000407",
          packageName: "CARDIAC CATHETERIZATION PKG",
          opd: "35000",
          executiveOpd: "35000",
          general: "38000",
          twinSharing: "41500",
          semiPrivate: "45000",
          private: "55000",
          deluxe: "65000",
          superDeluxe: "71500",
          suite: "78000",
          presidentialSuite: "98000",
          vipRoom: "88000",
          vvipRoom: "108000",
          dayCare: "33500",
          discount: "12%",
        },
        {
          packageCode: "PKG000411",
          packageName: "MITRAL VALVE REPLACEMENT PKG",
          opd: "325000",
          executiveOpd: "325000",
          general: "345000",
          twinSharing: "365000",
          semiPrivate: "385000",
          private: "445000",
          deluxe: "495000",
          superDeluxe: "530000",
          suite: "565000",
          presidentialSuite: "708000",
          vipRoom: "636000",
          vvipRoom: "785000",
          dayCare: "310000",
          discount: "10%",
        },
        {
          packageCode: "PKG000412",
          packageName: "AORTIC VALVE REPLACEMENT PKG",
          opd: "335000",
          executiveOpd: "335000",
          general: "355000",
          twinSharing: "375000",
          semiPrivate: "395000",
          private: "455000",
          deluxe: "505000",
          superDeluxe: "540000",
          suite: "575000",
          presidentialSuite: "720000",
          vipRoom: "647000",
          vvipRoom: "799000",
          dayCare: "320000",
          discount: "10%",
        },
        {
          packageCode: "PKG000414",
          packageName: "TOTAL KNEE REPLACEMENT (UNILATERAL) PKG",
          opd: "185000",
          executiveOpd: "185000",
          general: "195000",
          twinSharing: "210000",
          semiPrivate: "225000",
          private: "265000",
          deluxe: "305000",
          superDeluxe: "330000",
          suite: "355000",
          presidentialSuite: "445000",
          vipRoom: "400000",
          vvipRoom: "494000",
          dayCare: "177000",
          discount: "15%",
        },
        {
          packageCode: "PKG000415",
          packageName: "TOTAL HIP REPLACEMENT (UNILATERAL) PKG",
          opd: "195000",
          executiveOpd: "195000",
          general: "205000",
          twinSharing: "220000",
          semiPrivate: "235000",
          private: "275000",
          deluxe: "315000",
          superDeluxe: "340000",
          suite: "365000",
          presidentialSuite: "457000",
          vipRoom: "411000",
          vvipRoom: "507000",
          dayCare: "186000",
          discount: "15%",
        },
        {
          packageCode: "PKG000417",
          packageName: "LAPAROSCOPIC CHOLECYSTECTOMY PKG",
          opd: "75000",
          executiveOpd: "75000",
          general: "82000",
          twinSharing: "88500",
          semiPrivate: "95000",
          private: "115000",
          deluxe: "135000",
          superDeluxe: "150000",
          suite: "165000",
          presidentialSuite: "207000",
          vipRoom: "186000",
          vvipRoom: "230000",
          dayCare: "72000",
          discount: "12%",
        },
        {
          packageCode: "PKG000418",
          packageName: "APPENDECTOMY (LAPAROSCOPIC) PKG",
          opd: "65000",
          executiveOpd: "65000",
          general: "72000",
          twinSharing: "78500",
          semiPrivate: "85000",
          private: "105000",
          deluxe: "125000",
          superDeluxe: "140000",
          suite: "155000",
          presidentialSuite: "194000",
          vipRoom: "174000",
          vvipRoom: "215000",
          dayCare: "62000",
          discount: "10%",
        },
        {
          packageCode: "PKG000419",
          packageName: "HERNIA REPAIR (LAPAROSCOPIC) PKG",
          opd: "68000",
          executiveOpd: "68000",
          general: "75000",
          twinSharing: "81500",
          semiPrivate: "88000",
          private: "108000",
          deluxe: "128000",
          superDeluxe: "143000",
          suite: "158000",
          presidentialSuite: "198000",
          vipRoom: "178000",
          vvipRoom: "220000",
          dayCare: "65000",
          discount: "12%",
        },
        {
          packageCode: "PKG000421",
          packageName: "CRANIOTOMY FOR BRAIN TUMOR PKG",
          opd: "385000",
          executiveOpd: "385000",
          general: "405000",
          twinSharing: "430000",
          semiPrivate: "455000",
          private: "525000",
          deluxe: "585000",
          superDeluxe: "625000",
          suite: "665000",
          presidentialSuite: "832000",
          vipRoom: "748000",
          vvipRoom: "924000",
          dayCare: "368000",
          discount: "8%",
        },
        {
          packageCode: "PKG000422",
          packageName: "SPINAL FUSION SURGERY PKG",
          opd: "285000",
          executiveOpd: "285000",
          general: "305000",
          twinSharing: "325000",
          semiPrivate: "345000",
          private: "405000",
          deluxe: "455000",
          superDeluxe: "490000",
          suite: "525000",
          presidentialSuite: "657000",
          vipRoom: "591000",
          vvipRoom: "729000",
          dayCare: "272000",
          discount: "10%",
        },
        {
          packageCode: "PKG000423",
          packageName: "KIDNEY TRANSPLANTATION PKG",
          opd: "485000",
          executiveOpd: "485000",
          general: "515000",
          twinSharing: "545000",
          semiPrivate: "575000",
          private: "655000",
          deluxe: "725000",
          superDeluxe: "775000",
          suite: "825000",
          presidentialSuite: "1033000",
          vipRoom: "928000",
          vvipRoom: "1146000",
          dayCare: "463000",
          discount: "5%",
        },
        {
          packageCode: "PKG000424",
          packageName: "LIVER TRANSPLANTATION PKG",
          opd: "985000",
          executiveOpd: "985000",
          general: "1050000",
          twinSharing: "1118000",
          semiPrivate: "1185000",
          private: "1365000",
          deluxe: "1525000",
          superDeluxe: "1640000",
          suite: "1755000",
          presidentialSuite: "2197000",
          vipRoom: "1975000",
          vvipRoom: "2439000",
          dayCare: "940000",
          discount: "5%",
        },
        {
          packageCode: "PKG000425",
          packageName: "CATARACT SURGERY (PHACOEMULSIFICATION) PKG",
          opd: "35000",
          executiveOpd: "35000",
          general: "38000",
          twinSharing: "41500",
          semiPrivate: "45000",
          private: "55000",
          deluxe: "65000",
          superDeluxe: "71500",
          suite: "78000",
          presidentialSuite: "98000",
          vipRoom: "88000",
          vvipRoom: "108000",
          dayCare: "33500",
          discount: "15%",
        },
      ],
    },
    {
      hospitalId: 2,
      hospitalName: "Fortis Healthcare",
      effectiveDate: "01-Jan-2025",
      expiryDate: "31-Dec-2025",
      packages: [
        {
          packageCode: "PKG000408",
          packageName: "ANGIOGRAM (EM) PKG",
          opd: "17600",
          executiveOpd: "17600",
          general: "17600",
          twinSharing: "22000",
          semiPrivate: "26900",
          private: "31900",
          deluxe: "34900",
          superDeluxe: "39500",
          suite: "44900",
          presidentialSuite: "56000",
          vipRoom: "50500",
          vvipRoom: "62000",
          dayCare: "16800",
          discount: "10%",
        },
        {
          packageCode: "PKG000409",
          packageName: "PERIPHERAL ANGIOGRAM (EM) PKG",
          opd: "18100",
          executiveOpd: "18100",
          general: "17100",
          twinSharing: "18500",
          semiPrivate: "20400",
          private: "28900",
          deluxe: "33000",
          superDeluxe: "36200",
          suite: "39500",
          presidentialSuite: "49500",
          vipRoom: "44500",
          vvipRoom: "55000",
          dayCare: "17300",
          discount: "15%",
        },
        {
          packageCode: "PKG000410",
          packageName: "AORTAGRAM (EM) PKG",
          opd: "18300",
          executiveOpd: "18300",
          general: "20300",
          twinSharing: "22100",
          semiPrivate: "23900",
          private: "34300",
          deluxe: "37400",
          superDeluxe: "43000",
          suite: "48900",
          presidentialSuite: "61000",
          vipRoom: "55000",
          vvipRoom: "68000",
          dayCare: "17500",
          discount: "12%",
        },
        {
          packageCode: "PKG000426",
          packageName: "PERCUTANEOUS CORONARY INTERVENTION (PCI) PKG",
          opd: "195000",
          executiveOpd: "195000",
          general: "205000",
          twinSharing: "225000",
          semiPrivate: "245000",
          private: "295000",
          deluxe: "345000",
          superDeluxe: "375000",
          suite: "405000",
          presidentialSuite: "507000",
          vipRoom: "456000",
          vvipRoom: "563000",
          dayCare: "186000",
          discount: "12%",
        },
        {
          packageCode: "PKG000427",
          packageName: "ECHOCARDIOGRAPHY PKG",
          opd: "3500",
          executiveOpd: "3500",
          general: "3800",
          twinSharing: "4150",
          semiPrivate: "4500",
          private: "5500",
          deluxe: "6500",
          superDeluxe: "7150",
          suite: "7800",
          presidentialSuite: "9750",
          vipRoom: "8775",
          vvipRoom: "10800",
          dayCare: "3350",
          discount: "8%",
        },
        {
          packageCode: "PKG000428",
          packageName: "STRESS TEST (TMT) PKG",
          opd: "4500",
          executiveOpd: "4500",
          general: "4800",
          twinSharing: "5150",
          semiPrivate: "5500",
          private: "6500",
          deluxe: "7500",
          superDeluxe: "8150",
          suite: "8800",
          presidentialSuite: "11000",
          vipRoom: "9900",
          vvipRoom: "12200",
          dayCare: "4300",
          discount: "10%",
        },
        {
          packageCode: "PKG000429",
          packageName: "HOLTER MONITORING (24 HOURS) PKG",
          opd: "5500",
          executiveOpd: "5500",
          general: "5800",
          twinSharing: "6300",
          semiPrivate: "6800",
          private: "8000",
          deluxe: "9500",
          superDeluxe: "10250",
          suite: "11000",
          presidentialSuite: "13750",
          vipRoom: "12375",
          vvipRoom: "15250",
          dayCare: "5250",
          discount: "8%",
        },
        {
          packageCode: "PKG000430",
          packageName: "CAROTID DOPPLER STUDY PKG",
          opd: "6500",
          executiveOpd: "6500",
          general: "6800",
          twinSharing: "7300",
          semiPrivate: "7800",
          private: "9000",
          deluxe: "10500",
          superDeluxe: "11500",
          suite: "12500",
          presidentialSuite: "15625",
          vipRoom: "14063",
          vvipRoom: "17350",
          dayCare: "6200",
          discount: "10%",
        },
        {
          packageCode: "PKG000431",
          packageName: "RENAL DOPPLER STUDY PKG",
          opd: "6800",
          executiveOpd: "6800",
          general: "7200",
          twinSharing: "7700",
          semiPrivate: "8200",
          private: "9500",
          deluxe: "11000",
          superDeluxe: "12000",
          suite: "13000",
          presidentialSuite: "16250",
          vipRoom: "14625",
          vvipRoom: "18050",
          dayCare: "6500",
          discount: "10%",
        },
        {
          packageCode: "PKG000432",
          packageName: "HYSTERECTOMY (LAPAROSCOPIC) PKG",
          opd: "95000",
          executiveOpd: "95000",
          general: "105000",
          twinSharing: "115000",
          semiPrivate: "125000",
          private: "155000",
          deluxe: "185000",
          superDeluxe: "205000",
          suite: "225000",
          presidentialSuite: "282000",
          vipRoom: "253500",
          vvipRoom: "313000",
          dayCare: "91000",
          discount: "12%",
        },
        {
          packageCode: "PKG000433",
          packageName: "CESAREAN SECTION PKG",
          opd: "75000",
          executiveOpd: "75000",
          general: "85000",
          twinSharing: "95000",
          semiPrivate: "105000",
          private: "135000",
          deluxe: "165000",
          superDeluxe: "185000",
          suite: "205000",
          presidentialSuite: "257000",
          vipRoom: "231000",
          vvipRoom: "285000",
          dayCare: "72000",
          discount: "10%",
        },
        {
          packageCode: "PKG000434",
          packageName: "NORMAL DELIVERY PKG",
          opd: "45000",
          executiveOpd: "45000",
          general: "52000",
          twinSharing: "58500",
          semiPrivate: "65000",
          private: "85000",
          deluxe: "105000",
          superDeluxe: "120000",
          suite: "135000",
          presidentialSuite: "169000",
          vipRoom: "152000",
          vvipRoom: "188000",
          dayCare: "43000",
          discount: "12%",
        },
        {
          packageCode: "PKG000435",
          packageName: "PROSTATECTOMY (TURP) PKG",
          opd: "85000",
          executiveOpd: "85000",
          general: "95000",
          twinSharing: "105000",
          semiPrivate: "115000",
          private: "145000",
          deluxe: "175000",
          superDeluxe: "195000",
          suite: "215000",
          presidentialSuite: "269000",
          vipRoom: "242000",
          vvipRoom: "299000",
          dayCare: "81500",
          discount: "10%",
        },
        {
          packageCode: "PKG000436",
          packageName: "NEPHRECTOMY (LAPAROSCOPIC) PKG",
          opd: "165000",
          executiveOpd: "165000",
          general: "178000",
          twinSharing: "193000",
          semiPrivate: "208000",
          private: "255000",
          deluxe: "305000",
          superDeluxe: "335000",
          suite: "365000",
          presidentialSuite: "457000",
          vipRoom: "411000",
          vvipRoom: "507000",
          dayCare: "158000",
          discount: "12%",
        },
        {
          packageCode: "PKG000437",
          packageName: "THYROIDECTOMY PKG",
          opd: "75000",
          executiveOpd: "75000",
          general: "85000",
          twinSharing: "95000",
          semiPrivate: "105000",
          private: "135000",
          deluxe: "165000",
          superDeluxe: "185000",
          suite: "205000",
          presidentialSuite: "257000",
          vipRoom: "231000",
          vvipRoom: "285000",
          dayCare: "72000",
          discount: "10%",
        },
        {
          packageCode: "PKG000438",
          packageName: "MASTECTOMY PKG",
          opd: "95000",
          executiveOpd: "95000",
          general: "108000",
          twinSharing: "121500",
          semiPrivate: "135000",
          private: "175000",
          deluxe: "215000",
          superDeluxe: "240000",
          suite: "265000",
          presidentialSuite: "332000",
          vipRoom: "298000",
          vvipRoom: "368000",
          dayCare: "91000",
          discount: "8%",
        },
        {
          packageCode: "PKG000439",
          packageName: "COLONOSCOPY PKG",
          opd: "15000",
          executiveOpd: "15000",
          general: "16500",
          twinSharing: "18000",
          semiPrivate: "19500",
          private: "24000",
          deluxe: "28500",
          superDeluxe: "31500",
          suite: "34500",
          presidentialSuite: "43200",
          vipRoom: "38850",
          vvipRoom: "47900",
          dayCare: "14300",
          discount: "12%",
        },
        {
          packageCode: "PKG000440",
          packageName: "UPPER GI ENDOSCOPY PKG",
          opd: "12000",
          executiveOpd: "12000",
          general: "13500",
          twinSharing: "14750",
          semiPrivate: "16000",
          private: "20000",
          deluxe: "24000",
          superDeluxe: "26500",
          suite: "29000",
          presidentialSuite: "36300",
          vipRoom: "32650",
          vvipRoom: "40300",
          dayCare: "11500",
          discount: "10%",
        },
      ],
    },
    {
      hospitalId: 3,
      hospitalName: "Max Healthcare",
      effectiveDate: "15-Feb-2025",
      expiryDate: "15-Feb-2026",
      packages: [
        {
          packageCode: "PKG000413",
          packageName: "CORONARY ANGIOGRAM, PERIPHERAL ANGIOGRAM (SAME SITTING) (EM) PKG",
          opd: "26800",
          executiveOpd: "",
          general: "28800",
          semiPrivate: "38900",
          private: "51900",
          deluxe: "57900",
          suite: "64900",
          discount: "18%",
        },
        {
          packageCode: "PKG000416",
          packageName: "ANGIOPLASTY (EM) PKG",
          opd: "198500",
          executiveOpd: "198500",
          general: "205000",
          semiPrivate: "278500",
          private: "341000",
          deluxe: "361500",
          suite: "456000",
          discount: "20%",
        },
        {
          packageCode: "PKG000420",
          packageName: "AORTIC STENT GRAFTING (EM) PKG",
          opd: "171100",
          executiveOpd: "171100",
          general: "196800",
          semiPrivate: "216300",
          private: "325000",
          deluxe: "356200",
          suite: "449900",
          discount: "10%",
        },
        {
          packageCode: "PKG000441",
          packageName: "ROBOTIC PROSTATECTOMY PKG",
          opd: "285000",
          executiveOpd: "285000",
          general: "305000",
          semiPrivate: "355000",
          private: "425000",
          deluxe: "485000",
          suite: "565000",
          discount: "8%",
        },
        {
          packageCode: "PKG000442",
          packageName: "ROBOTIC HYSTERECTOMY PKG",
          opd: "265000",
          executiveOpd: "265000",
          general: "285000",
          semiPrivate: "335000",
          private: "405000",
          deluxe: "465000",
          suite: "545000",
          discount: "8%",
        },
        {
          packageCode: "PKG000443",
          packageName: "ROTABLATOR ANGIOPLASTY PKG",
          opd: "225000",
          executiveOpd: "225000",
          general: "245000",
          semiPrivate: "295000",
          private: "365000",
          deluxe: "425000",
          suite: "505000",
          discount: "12%",
        },
        {
          packageCode: "PKG000444",
          packageName: "INTRAVASCULAR ULTRASOUND (IVUS) PKG",
          opd: "85000",
          executiveOpd: "85000",
          general: "95000",
          semiPrivate: "115000",
          private: "145000",
          deluxe: "175000",
          suite: "215000",
          discount: "10%",
        },
        {
          packageCode: "PKG000445",
          packageName: "OPTICAL COHERENCE TOMOGRAPHY (OCT) PKG",
          opd: "95000",
          executiveOpd: "95000",
          general: "105000",
          semiPrivate: "125000",
          private: "155000",
          deluxe: "185000",
          suite: "225000",
          discount: "10%",
        },
        {
          packageCode: "PKG000446",
          packageName: "FRACTIONAL FLOW RESERVE (FFR) PKG",
          opd: "75000",
          executiveOpd: "75000",
          general: "85000",
          semiPrivate: "105000",
          private: "135000",
          deluxe: "165000",
          suite: "205000",
          discount: "12%",
        },
        {
          packageCode: "PKG000447",
          packageName: "BONE MARROW TRANSPLANTATION PKG",
          opd: "885000",
          executiveOpd: "885000",
          general: "935000",
          semiPrivate: "1055000",
          private: "1225000",
          deluxe: "1385000",
          suite: "1605000",
          discount: "5%",
        },
        {
          packageCode: "PKG000448",
          packageName: "STEM CELL TRANSPLANTATION PKG",
          opd: "785000",
          executiveOpd: "785000",
          general: "835000",
          semiPrivate: "955000",
          private: "1125000",
          deluxe: "1285000",
          suite: "1505000",
          discount: "5%",
        },
        {
          packageCode: "PKG000449",
          packageName: "CHEMOTHERAPY (PER CYCLE) PKG",
          opd: "55000",
          executiveOpd: "55000",
          general: "62000",
          semiPrivate: "75000",
          private: "95000",
          deluxe: "115000",
          suite: "145000",
          discount: "8%",
        },
        {
          packageCode: "PKG000450",
          packageName: "RADIOTHERAPY (PER SESSION) PKG",
          opd: "15000",
          executiveOpd: "15000",
          general: "17000",
          semiPrivate: "21000",
          private: "27000",
          deluxe: "33000",
          suite: "41000",
          discount: "10%",
        },
        {
          packageCode: "PKG000451",
          packageName: "STEREOTACTIC RADIOSURGERY (GAMMA KNIFE) PKG",
          opd: "285000",
          executiveOpd: "285000",
          general: "305000",
          semiPrivate: "355000",
          private: "425000",
          deluxe: "485000",
          suite: "565000",
          discount: "8%",
        },
        {
          packageCode: "PKG000452",
          packageName: "BARIATRIC SURGERY (GASTRIC BYPASS) PKG",
          opd: "285000",
          executiveOpd: "285000",
          general: "305000",
          semiPrivate: "355000",
          private: "425000",
          deluxe: "485000",
          suite: "565000",
          discount: "12%",
        },
        {
          packageCode: "PKG000453",
          packageName: "SLEEVE GASTRECTOMY PKG",
          opd: "265000",
          executiveOpd: "265000",
          general: "285000",
          semiPrivate: "335000",
          private: "405000",
          deluxe: "465000",
          suite: "545000",
          discount: "12%",
        },
        {
          packageCode: "PKG000454",
          packageName: "COCHLEAR IMPLANT PKG",
          opd: "485000",
          executiveOpd: "485000",
          general: "515000",
          semiPrivate: "575000",
          private: "655000",
          deluxe: "725000",
          suite: "825000",
          discount: "8%",
        },
        {
          packageCode: "PKG000455",
          packageName: "LASIK EYE SURGERY (BOTH EYES) PKG",
          opd: "85000",
          executiveOpd: "85000",
          general: "92000",
          semiPrivate: "105000",
          private: "125000",
          deluxe: "145000",
          suite: "175000",
          discount: "15%",
        },
      ],
    },
    {
      hospitalId: 4,
      hospitalName: "Lilavati Hospital",
      effectiveDate: "01-Mar-2025",
      expiryDate: "28-Feb-2026",
      packages: [
        {
          packageCode: "PKG000456",
          packageName: "CORONARY ANGIOGRAPHY PKG",
          opd: "18500",
          executiveOpd: "18500",
          general: "19500",
          semiPrivate: "24500",
          private: "31500",
          deluxe: "38500",
          suite: "47500",
          discount: "10%",
        },
        {
          packageCode: "PKG000457",
          packageName: "ANGIOPLASTY WITH STENT PKG",
          opd: "205000",
          executiveOpd: "205000",
          general: "218000",
          semiPrivate: "265000",
          private: "328000",
          deluxe: "385000",
          suite: "458000",
          discount: "12%",
        },
        {
          packageCode: "PKG000458",
          packageName: "TOTAL KNEE REPLACEMENT PKG",
          opd: "195000",
          executiveOpd: "195000",
          general: "208000",
          semiPrivate: "248000",
          private: "298000",
          deluxe: "348000",
          suite: "408000",
          discount: "15%",
        },
      ],
    },
    {
      hospitalId: 5,
      hospitalName: "Manipal Hospitals",
      effectiveDate: "15-Jan-2025",
      expiryDate: "14-Jan-2026",
      packages: [
        {
          packageCode: "PKG000459",
          packageName: "CARDIAC BYPASS SURGERY PKG",
          opd: "295000",
          executiveOpd: "295000",
          general: "315000",
          semiPrivate: "365000",
          private: "435000",
          deluxe: "495000",
          suite: "575000",
          discount: "10%",
        },
        {
          packageCode: "PKG000460",
          packageName: "LIVER RESECTION PKG",
          opd: "385000",
          executiveOpd: "385000",
          general: "415000",
          semiPrivate: "475000",
          private: "555000",
          deluxe: "625000",
          suite: "715000",
          discount: "8%",
        },
        {
          packageCode: "PKG000461",
          packageName: "BRAIN TUMOR SURGERY PKG",
          opd: "395000",
          executiveOpd: "395000",
          general: "425000",
          semiPrivate: "485000",
          private: "565000",
          deluxe: "635000",
          suite: "725000",
          discount: "8%",
        },
      ],
    },
    {
      hospitalId: 6,
      hospitalName: "Medanta - The Medicity",
      effectiveDate: "01-Apr-2025",
      expiryDate: "31-Mar-2026",
      packages: [
        {
          packageCode: "PKG000462",
          packageName: "HEART TRANSPLANTATION PKG",
          opd: "1285000",
          executiveOpd: "1285000",
          general: "1355000",
          semiPrivate: "1525000",
          private: "1755000",
          deluxe: "1955000",
          suite: "2255000",
          discount: "5%",
        },
        {
          packageCode: "PKG000463",
          packageName: "LUNG TRANSPLANTATION PKG",
          opd: "1185000",
          executiveOpd: "1185000",
          general: "1255000",
          semiPrivate: "1425000",
          private: "1655000",
          deluxe: "1855000",
          suite: "2155000",
          discount: "5%",
        },
        {
          packageCode: "PKG000464",
          packageName: "ROBOTIC CARDIAC SURGERY PKG",
          opd: "485000",
          executiveOpd: "485000",
          general: "515000",
          semiPrivate: "585000",
          private: "675000",
          deluxe: "755000",
          suite: "865000",
          discount: "8%",
        },
      ],
    },
    {
      hospitalId: 7,
      hospitalName: "Cloudnine Hospitals",
      effectiveDate: "01-Feb-2025",
      expiryDate: "31-Jan-2026",
      packages: [
        {
          packageCode: "PKG000465",
          packageName: "NORMAL DELIVERY PKG",
          opd: "48000",
          executiveOpd: "48000",
          general: "55000",
          semiPrivate: "68000",
          private: "88000",
          deluxe: "108000",
          suite: "138000",
          discount: "12%",
        },
        {
          packageCode: "PKG000466",
          packageName: "CESAREAN SECTION PKG",
          opd: "78000",
          executiveOpd: "78000",
          general: "88000",
          semiPrivate: "108000",
          private: "138000",
          deluxe: "168000",
          suite: "208000",
          discount: "10%",
        },
        {
          packageCode: "PKG000467",
          packageName: "HIGH RISK PREGNANCY CARE PKG",
          opd: "125000",
          executiveOpd: "125000",
          general: "138000",
          semiPrivate: "165000",
          private: "205000",
          deluxe: "245000",
          suite: "295000",
          discount: "8%",
        },
      ],
    },
    {
      hospitalId: 8,
      hospitalName: "Kokilaben Hospital",
      effectiveDate: "01-May-2025",
      expiryDate: "30-Apr-2026",
      packages: [
        {
          packageCode: "PKG000468",
          packageName: "NEUROSURGERY (COMPLEX) PKG",
          opd: "425000",
          executiveOpd: "425000",
          general: "455000",
          semiPrivate: "525000",
          private: "615000",
          deluxe: "695000",
          suite: "795000",
          discount: "8%",
        },
        {
          packageCode: "PKG000469",
          packageName: "SPINE SURGERY (COMPLEX) PKG",
          opd: "325000",
          executiveOpd: "325000",
          general: "355000",
          semiPrivate: "415000",
          private: "495000",
          deluxe: "565000",
          suite: "655000",
          discount: "10%",
        },
        {
          packageCode: "PKG000470",
          packageName: "ONCOLOGY SURGERY PKG",
          opd: "285000",
          executiveOpd: "285000",
          general: "315000",
          semiPrivate: "375000",
          private: "455000",
          deluxe: "525000",
          suite: "615000",
          discount: "8%",
        },
      ],
    },
  ];

  const filteredHospitals = hospitals.filter((hospital) =>
    searchTerm === "" ||
    hospital.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    hospital.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedHospital = selectedHospitalId 
    ? hospitals.find(h => h.id === selectedHospitalId)
    : null;

  const selectedTariffData = selectedHospitalId
    ? tariffData.find(t => t.hospitalId === selectedHospitalId)
    : null;

  const filteredPackages = selectedTariffData?.packages.filter((pkg) =>
    packageSearchTerm === "" ||
    pkg.packageCode.toLowerCase().includes(packageSearchTerm.toLowerCase()) ||
    pkg.packageName.toLowerCase().includes(packageSearchTerm.toLowerCase())
  ) || [];

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Tariff Management"
        description={selectedHospital ? `Tariff details for ${selectedHospital.name}` : "Select a hospital to view tariff details"}
        icon={DollarSign}
        actions={
          selectedHospital ? (
            <Button variant="outline" className="gap-2" onClick={() => navigate('/tariffs')}>
              <ArrowLeft className="h-4 w-4" />
              Back to Hospitals
            </Button>
          ) : (
            <AddTariffDialog />
          )
        }
      />

      <div className="container mx-auto px-6 py-8">
        {!selectedHospital ? (
          <>
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search hospitals by name or location..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredHospitals.map((hospital) => (
                <Card 
                  key={hospital.id} 
                  className="shadow-card hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => navigate(`/tariffs/${hospital.id}`)}
                >
                  <CardContent className="p-6">
                    <div className="flex gap-4">
                      <img
                        src={hospital.image}
                        alt={hospital.name}
                        className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-lg mb-1 truncate">{hospital.name}</h3>
                        <p className="text-sm text-muted-foreground mb-3">{hospital.location}</p>
                        <Button variant="outline" size="sm" className="gap-2">
                          <DollarSign className="h-4 w-4" />
                          View Tariffs
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredHospitals.length === 0 && (
              <Card className="shadow-card">
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Building2 className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No hospitals found</h3>
                  <p className="text-sm text-muted-foreground">
                    Try adjusting your search
                  </p>
                </CardContent>
              </Card>
            )}
          </>
        ) : selectedTariffData ? (
          <Card className="shadow-card">
            <CardHeader>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <CardTitle className="text-xl">{selectedTariffData.hospitalName}</CardTitle>
                  <CardDescription className="mt-1">
                    <span className="text-muted-foreground">Effective:</span>
                    <span className="ml-2 font-medium">
                      {selectedTariffData.effectiveDate} - {selectedTariffData.expiryDate}
                    </span>
                  </CardDescription>
                </div>
              </div>
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by service code or package name..."
                  value={packageSearchTerm}
                  onChange={(e) => setPackageSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[600px]">
                <div className="min-w-[2400px] p-6">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-primary/5">
                        <TableHead className="font-semibold w-[140px]">Service Code / Package Code</TableHead>
                        <TableHead className="font-semibold min-w-[280px]">Service Name / Package Name</TableHead>
                        <TableHead className="font-semibold text-center">OPD</TableHead>
                        <TableHead className="font-semibold text-center">Executive OPD</TableHead>
                        <TableHead className="font-semibold text-center">General</TableHead>
                        <TableHead className="font-semibold text-center">Twin Sharing</TableHead>
                        <TableHead className="font-semibold text-center">Semi Private</TableHead>
                        <TableHead className="font-semibold text-center">Private</TableHead>
                        <TableHead className="font-semibold text-center">Deluxe</TableHead>
                        <TableHead className="font-semibold text-center">Super Deluxe</TableHead>
                        <TableHead className="font-semibold text-center">Suite</TableHead>
                        <TableHead className="font-semibold text-center">Presidential Suite</TableHead>
                        <TableHead className="font-semibold text-center">VIP Room</TableHead>
                        <TableHead className="font-semibold text-center">VVIP Room</TableHead>
                        <TableHead className="font-semibold text-center">Day Care</TableHead>
                        <TableHead className="font-semibold text-center">IPD Discount</TableHead>
                        <TableHead className="font-semibold text-center">OPD Discount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPackages.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={17} className="text-center py-8 text-muted-foreground">
                            No packages found matching "{packageSearchTerm}"
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredPackages.map((pkg, idx) => (
                          <TableRow key={idx} className="hover:bg-muted/30">
                            <TableCell className="font-medium text-xs">{pkg.packageCode}</TableCell>
                            <TableCell className="text-sm">{pkg.packageName}</TableCell>
                            <TableCell className="text-center text-sm">{pkg.opd || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{pkg.executiveOpd || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{pkg.general || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{(pkg as any).twinSharing || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{pkg.semiPrivate || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{pkg.private || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{pkg.deluxe || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{(pkg as any).superDeluxe || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{pkg.suite || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{(pkg as any).presidentialSuite || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{(pkg as any).vipRoom || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{(pkg as any).vvipRoom || "-"}</TableCell>
                            <TableCell className="text-center text-sm">{(pkg as any).dayCare || "-"}</TableCell>
                            <TableCell className="text-center">
                              <Badge variant="outline" className="bg-success/10 text-success border-success/20 text-xs">
                                {(pkg as any).ipdDiscount || pkg.discount}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-center">
                              <Badge variant="outline" className="bg-success/10 text-success border-success/20 text-xs">
                                {(pkg as any).opdDiscount || pkg.discount}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
                <ScrollBar orientation="horizontal" />
              </ScrollArea>
              <div className="p-6 pt-4 flex justify-end gap-2 border-t">
                <Button variant="outline" size="sm">
                  Edit Tariff
                </Button>
                <Button variant="outline" size="sm">
                  Download
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="shadow-card">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <DollarSign className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No tariff data available</h3>
              <p className="text-sm text-muted-foreground">
                Tariff information not yet added for this hospital
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
