import { PageHeader } from "@/components/layout/PageHeader";
import { Palette, CheckCircle, Bell, Building2, UserPlus, UserMinus } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

export default function DesignVariations() {
  const { toast } = useToast();

  const showApprovalToast = () => {
    toast({
      title: "Approval Request Sent",
      description: "The approval request for the updates have been sent to the concerned team.",
      duration: 5000,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Design Variations"
        description="Explore different card design variations"
        icon={Palette}
      />

      <div className="container mx-auto px-6 py-8 space-y-6">
        <Card className="max-w-2xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-primary" />
              Approval Request Toast <span className="text-xs font-normal text-muted-foreground">(for makers)</span>
            </CardTitle>
            <CardDescription>
              Click the button below to see the approval request toast message
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={showApprovalToast}>
              Send Approval Request
            </Button>
          </CardContent>
        </Card>

        <Card className="max-w-2xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-primary" />
              Notification Messages <span className="text-xs font-normal text-muted-foreground">(for makers)</span>
              <Badge variant="secondary" className="ml-2">3</Badge>
            </CardTitle>
            <CardDescription>
              Approved update requests notifications
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3 p-3 rounded-lg border border-green-200 bg-green-50 dark:border-green-900 dark:bg-green-950/20">
              <Building2 className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-sm text-green-900 dark:text-green-100">
                  Hospital Details Update Approved
                </p>
                <p className="text-xs text-green-700 dark:text-green-300 mt-1">
                  Apollo Hospital details have been successfully updated.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-lg border border-green-200 bg-green-50 dark:border-green-900 dark:bg-green-950/20">
              <UserPlus className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-sm text-green-900 dark:text-green-100">
                  Hospital Onboarding Approved
                </p>
                <p className="text-xs text-green-700 dark:text-green-300 mt-1">
                  Fortis Hospital has been successfully onboarded to the network.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-lg border border-green-200 bg-green-50 dark:border-green-900 dark:bg-green-950/20">
              <UserMinus className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-sm text-green-900 dark:text-green-100">
                  Hospital Deboarding Approved
                </p>
                <p className="text-xs text-green-700 dark:text-green-300 mt-1">
                  Max Hospital has been removed from the network as requested.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
