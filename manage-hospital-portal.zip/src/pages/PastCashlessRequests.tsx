import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { History, Download, Search, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { CashlessRequestDetailsDialog } from "@/components/cashless/CashlessRequestDetailsDialog";

export default function PastCashlessRequests() {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateRange, setDateRange] = useState("all");
  const [selectedRequest, setSelectedRequest] = useState<typeof pastRequests[0] | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  // Apply filter from navigation state
  useEffect(() => {
    const state = location.state as { filterStatus?: string; dateRange?: string };
    if (state?.filterStatus) {
      setStatusFilter(state.filterStatus);
    }
    if (state?.dateRange) {
      setDateRange(state.dateRange);
    }
    // Clear the state to prevent reapplying on refresh
    if (state?.filterStatus || state?.dateRange) {
      window.history.replaceState({}, document.title);
    }
  }, [location]);

  const pastRequests = [
    // 50 Approved - Onboarding
    ...Array.from({ length: 50 }, (_, i) => ({
      id: i + 1,
      hospital: `${["City Care", "Metro Health", "Wellness", "Green Valley", "Sunrise Medical", "Apollo Care", "Fortis Clinic", "Max Healthcare", "Lilavati", "Kokilaben", "Manipal", "Medanta", "Continental", "Rainbow", "Narayana", "KIMS", "Global", "Columbia Asia", "Sakra", "Cloudnine"][i % 20]} Hospital`,
      requestDate: `${String(Math.floor(Math.random() * 30) + 1).padStart(2, '0')}-${["Jan", "Feb", "Mar", "Apr", "May", "Jun"][Math.floor(Math.random() * 6)]}-2025`,
      completedDate: `${String(Math.floor(Math.random() * 30) + 1).padStart(2, '0')}-${["Jan", "Feb", "Mar", "Apr", "May", "Jun"][Math.floor(Math.random() * 6)]}-2025`,
      claimId: `CLM-2025-AO-${String(i + 1).padStart(3, '0')}`,
      patientName: `Patient ${i + 1}`,
      finalAmount: `₹${(Math.floor(Math.random() * 150) + 50) * 1000}`,
      status: "Approved - Onboarding",
      outcome: "Hospital Onboarded",
      documents: ["All Documents Verified"],
    })),
    // 48 Approved - Single Claim
    ...Array.from({ length: 48 }, (_, i) => ({
      id: i + 51,
      hospital: `${["Urban Care", "Park Hospital", "Apex Clinic", "Elite Medical", "Prime Healthcare", "Zenith Hospital", "Summit Care", "Horizon Medical", "Vista Health", "Stellar Hospital", "Nova Care", "Aurora Medical", "Phoenix Hospital", "Meridian Health", "Pinnacle Care"][i % 15]} Center`,
      requestDate: `${String(Math.floor(Math.random() * 30) + 1).padStart(2, '0')}-${["Jan", "Feb", "Mar", "Apr", "May"][Math.floor(Math.random() * 5)]}-2025`,
      completedDate: `${String(Math.floor(Math.random() * 30) + 1).padStart(2, '0')}-${["Jan", "Feb", "Mar", "Apr", "May"][Math.floor(Math.random() * 5)]}-2025`,
      claimId: `CLM-2025-SC-${String(i + 1).padStart(3, '0')}`,
      patientName: `Patient ${i + 51}`,
      finalAmount: `₹${(Math.floor(Math.random() * 100) + 30) * 1000}`,
      status: "Approved - Single Claim",
      outcome: "Claim Paid",
      documents: ["Medical Report", "Patient ID Proof"],
    })),
    // 35 Rejected
    ...Array.from({ length: 35 }, (_, i) => ({
      id: i + 99,
      hospital: `${["Care Plus", "Health First", "Remedy Hospital", "Cure Clinic", "Wellness Plus", "MediCenter", "HealthHub", "CarePoint", "Healing Touch", "LifeCare"][i % 10]} Hospital`,
      requestDate: `${String(Math.floor(Math.random() * 30) + 1).padStart(2, '0')}-${["Jan", "Feb", "Mar", "Apr"][Math.floor(Math.random() * 4)]}-2025`,
      completedDate: `${String(Math.floor(Math.random() * 30) + 1).padStart(2, '0')}-${["Jan", "Feb", "Mar", "Apr"][Math.floor(Math.random() * 4)]}-2025`,
      claimId: `CLM-2025-RJ-${String(i + 1).padStart(3, '0')}`,
      patientName: `Patient ${i + 99}`,
      finalAmount: "₹0",
      status: "Rejected",
      outcome: i % 2 === 0 ? "Documentation Incomplete" : "Policy Exclusion",
      documents: ["Incomplete"],
    })),
  ];

  const getStatusBadge = (status: string) => {
    const config: Record<string, string> = {
      "Completed": "bg-success/10 text-success border-success/20",
      "Rejected": "bg-destructive/10 text-destructive border-destructive/20",
    };
    return (
      <Badge variant="outline" className={config[status] || ""}>
        {status}
      </Badge>
    );
  };

  const getOutcomeBadge = (outcome: string) => {
    const config: Record<string, string> = {
      "Claim Paid": "bg-primary/10 text-primary border-primary/20",
      "Hospital Onboarded": "bg-accent/10 text-accent border-accent/20",
      "Documentation Incomplete": "bg-warning/10 text-warning border-warning/20",
      "Policy Exclusion": "bg-destructive/10 text-destructive border-destructive/20",
    };
    return (
      <Badge variant="outline" className={config[outcome] || ""}>
        {outcome}
      </Badge>
    );
  };

  const filteredRequests = pastRequests.filter((request) => {
    const matchesSearch = 
      request.hospital.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.claimId.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Handle "Approved" filter to show both onboarding and single claim
    const matchesStatus = 
      statusFilter === "all" || 
      request.status === statusFilter ||
      (statusFilter === "Approved" && (request.status === "Approved - Onboarding" || request.status === "Approved - Single Claim"));
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Closed Cashless Anywhere Requests"
        description="View and analyze closed cashless treatment requests"
        icon={History}
        actions={
          <>
            <Button variant="outline" className="gap-2" onClick={() => navigate("/cashless")}>
              <ArrowLeft className="h-4 w-4" />
              Back to Cashless Anywhere
            </Button>
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Export Report
            </Button>
          </>
        }
      />

      <div className="container mx-auto px-6 py-8">
        {/* Filters */}
        <Card className="mb-6 shadow-card">
          <CardHeader>
            <CardTitle>Search & Filter</CardTitle>
            <CardDescription>Find specific requests by hospital, patient, or claim ID</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="search">Search</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="search"
                    placeholder="Hospital, patient, or claim ID..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger id="status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="Approved">Approved</SelectItem>
                    <SelectItem value="Rejected">Rejected</SelectItem>
                    <SelectItem value="Approved - Onboarding">Approved - Onboarding</SelectItem>
                    <SelectItem value="Approved - Single Claim">Approved - Single Claim</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="dateRange">Date Range</Label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger id="dateRange">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Time</SelectItem>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="week">Last 7 Days</SelectItem>
                    <SelectItem value="month">Last 30 Days</SelectItem>
                    <SelectItem value="quarter">Last Quarter</SelectItem>
                    <SelectItem value="year">Last Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Summary */}
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Showing {filteredRequests.length} of {pastRequests.length} requests
          </p>
        </div>

        {/* Requests List */}
        <div className="grid gap-4">
          {filteredRequests.map((request) => (
            <Card key={request.id} className="shadow-card">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{request.hospital}</CardTitle>
                    <CardDescription className="mt-1">
                      Patient: {request.patientName} • Claim ID: {request.claimId}
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    {getStatusBadge(request.status)}
                    {getOutcomeBadge(request.outcome)}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-4 mb-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Request Date</p>
                    <p className="font-medium">{request.requestDate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Completed Date</p>
                    <p className="font-medium">{request.completedDate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Final Amount</p>
                    <p className="font-semibold text-lg">{request.finalAmount}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Outcome</p>
                    <p className="font-medium">{request.outcome}</p>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setSelectedRequest(request);
                      setDetailsOpen(true);
                    }}
                  >
                    View Details
                  </Button>
                  <Button variant="outline" size="sm" className="gap-2">
                    <Download className="h-3 w-3" />
                    Download Report
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <CashlessRequestDetailsDialog
          open={detailsOpen}
          onOpenChange={setDetailsOpen}
          request={selectedRequest}
        />
      </div>
    </div>
  );
}
