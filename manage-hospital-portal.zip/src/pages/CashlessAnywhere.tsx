import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Send, CheckCircle, XCircle, Clock, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { NewCashlessRequestDialog } from "@/components/cashless/NewCashlessRequestDialog";
import { CashlessRequestDetailsDialog } from "@/components/cashless/CashlessRequestDetailsDialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from "react-router-dom";
import { useState, useRef } from "react";

export default function CashlessAnywhere() {
  const navigate = useNavigate();
  const [selectedRequest, setSelectedRequest] = useState<typeof requests[0] | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const pendingRequestsRef = useRef<HTMLDivElement>(null);
  
  const requests = Array.from({ length: 23 }, (_, i) => ({
    id: i + 1,
    hospital: `${["City Care", "Metro Health", "Wellness", "Urban Care", "Green Valley", "Sunrise Medical", "Apollo Care", "Fortis Clinic", "Max Healthcare", "Lilavati", "Kokilaben", "Manipal", "Medanta", "Continental", "Rainbow", "Narayana", "KIMS", "Global", "Columbia Asia", "Sakra", "Cloudnine", "Motherhood", "Aster"][i % 23]} Hospital`,
    requestDate: "07-Nov-2025",
    claimId: `CLM-2025-CA-${String(i + 1).padStart(3, '0')}`,
    patientName: `${["Rajesh Kumar", "Priya Sharma", "Amit Patel", "Sneha Reddy", "Vikram Singh", "Anita Desai", "Rohit Verma", "Kavita Nair", "Suresh Iyer", "Meera Joshi", "Arjun Rao", "Divya Menon", "Karthik Bhat", "Lakshmi Pillai", "Ravi Krishnan", "Shalini Agarwal", "Manoj Gupta", "Pooja Malhotra", "Sanjay Chopra", "Neha Kapoor", "Anil Mehta", "Swati Bansal", "Deepak Saxena"][i % 23]}`,
    estimatedAmount: `₹${(Math.floor(Math.random() * 150) + 30) * 1000}`,
    status: "Pending Review",
    requestType: i < 12 ? "Hospital Initiated" : "ACKO Initiated",
    documents: i % 3 === 0 ? ["ID Proof", "Medical Records", "Estimate"] : i % 3 === 1 ? ["ID Proof", "Medical Records"] : ["ID Proof"],
  }));

  const hospitalRequests = requests.filter(req => req.requestType === "Hospital Initiated");
  const ackoRequests = requests.filter(req => req.requestType === "ACKO Initiated");

  const stats = [
    { label: "Total Requests", value: "156", icon: Send, color: "text-primary" },
    { label: "Pending Review", value: "23", icon: Clock, color: "text-warning" },
    { 
      label: "Approved", 
      value: "98", 
      icon: CheckCircle, 
      color: "text-success"
    },
    { label: "Rejected", value: "35", icon: XCircle, color: "text-destructive" },
  ];

  const getStatusBadge = (status: string) => {
    const config: Record<string, string> = {
      "Pending Review": "bg-warning/10 text-warning border-warning/20",
      "Approved - Onboarding": "bg-success/10 text-success border-success/20",
      "Approved - Single Claim": "bg-accent/10 text-accent border-accent/20",
      Rejected: "bg-destructive/10 text-destructive border-destructive/20",
    };
    return (
      <Badge variant="outline" className={config[status] || ""}>
        {status}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Cashless Anywhere"
        description="Manage cashless treatment requests from non-network hospitals"
        icon={Send}
        actions={
          <>
            <Button variant="outline" className="gap-2" onClick={() => navigate("/cashless/past")}>
              <History className="h-4 w-4" />
              Closed Requests
            </Button>
            <NewCashlessRequestDialog />
          </>
        }
      />

      <div className="container mx-auto px-6 py-8">
        <div className="mb-6">
          <h2 className="text-2xl font-semibold mb-4">Today's snapshot</h2>
        </div>

        <div className="grid gap-4 md:grid-cols-4 mb-8">
          {/* Total Requests - Non-clickable */}
          <Card className="shadow-card border-2 border-primary/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Send className="h-6 w-6 text-primary" />
                <div>
                  <p className="text-xs font-medium text-muted-foreground">Total Requests</p>
                  <p className="text-2xl font-bold">156</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Clickable breakdown stats */}
          {stats.slice(1).map((stat) => (
            <Card 
              key={stat.label} 
              className="shadow-card cursor-pointer transition-all hover:shadow-lg hover:scale-105"
              onClick={() => {
                if (stat.label === "Pending Review") {
                  // Scroll to pending requests section
                  pendingRequestsRef.current?.scrollIntoView({ 
                    behavior: "smooth", 
                    block: "start" 
                  });
                } else if (stat.label === "Approved") {
                  // Navigate to closed requests with Approved filter
                  navigate("/cashless/past", { 
                    state: { filterStatus: "Approved", dateRange: "today" } 
                  });
                } else if (stat.label === "Rejected") {
                  // Navigate to closed requests with Rejected filter
                  navigate("/cashless/past", { 
                    state: { filterStatus: "Rejected", dateRange: "today" } 
                  });
                }
              }}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">{stat.label}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div ref={pendingRequestsRef} className="mb-6 scroll-mt-24">
          <h2 className="text-2xl font-semibold mb-4">Pending Requests</h2>
        </div>

        <Tabs defaultValue="hospital" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="hospital">
              Hospital Initiated ({hospitalRequests.length})
            </TabsTrigger>
            <TabsTrigger value="acko">
              ACKO Initiated ({ackoRequests.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="hospital">
            <div className="grid gap-4">
              {hospitalRequests.map((request) => (
                <Card key={request.id} className="shadow-card">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{request.hospital}</CardTitle>
                        <CardDescription className="mt-1">
                          Patient: {request.patientName} • Claim ID: {request.claimId}
                        </CardDescription>
                      </div>
                      {getStatusBadge(request.status)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-3 mb-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Request Date</p>
                        <p className="font-medium">{request.requestDate}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Estimated Amount</p>
                        <p className="font-semibold text-lg">{request.estimatedAmount}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Documents</p>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {request.documents.map((doc, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {doc}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setSelectedRequest(request);
                          setDialogOpen(true);
                        }}
                      >
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="acko">
            <div className="grid gap-4">
              {ackoRequests.map((request) => (
                <Card key={request.id} className="shadow-card">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{request.hospital}</CardTitle>
                        <CardDescription className="mt-1">
                          Patient: {request.patientName} • Claim ID: {request.claimId}
                        </CardDescription>
                      </div>
                      {getStatusBadge(request.status)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-3 mb-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Request Date</p>
                        <p className="font-medium">{request.requestDate}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Estimated Amount</p>
                        <p className="font-semibold text-lg">{request.estimatedAmount}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Documents</p>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {request.documents.map((doc, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {doc}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setSelectedRequest(request);
                          setDialogOpen(true);
                        }}
                      >
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <CashlessRequestDetailsDialog 
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        request={selectedRequest}
      />
    </div>
  );
}
