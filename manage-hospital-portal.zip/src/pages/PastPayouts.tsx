import { useState, useMemo } from "react";
import { parse } from "date-fns";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { History, Calendar, Building2, TrendingDown, TrendingUp, DollarSign, MoreVertical, ArrowUpDown, Filter, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useNavigate } from "react-router-dom";
import { Separator } from "@/components/ui/separator";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, LineChart, Line } from "recharts";

type SortConfig = {
  key: string;
  direction: "asc" | "desc" | null;
};

type FilterConfig = {
  [key: string]: string;
};

export default function PastPayouts() {
  const navigate = useNavigate();
  const [timeRange, setTimeRange] = useState("last-30-days");
  const [selectedHospital, setSelectedHospital] = useState("all");
  const [selectedPayout, setSelectedPayout] = useState<any>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: "", direction: null });
  const [filters, setFilters] = useState<FilterConfig>({});

  const hospitals = [
    { id: "all", name: "All Hospitals" },
    { id: "1", name: "Apollo Hospitals" },
    { id: "2", name: "Fortis Healthcare" },
    { id: "3", name: "Max Healthcare" },
    { id: "4", name: "Narayana Health" },
    { id: "5", name: "Manipal Hospitals" },
  ];

  // Analytics are computed dynamically from filters

  const monthlyData = [
    { month: "Oct", amount: 65000000 },
    { month: "Nov", amount: 72000000 },
    { month: "Dec", amount: 68000000 },
    { month: "Jan", amount: 85000000 },
  ];

  const paymentModeData = [
    { mode: "NEFT", count: 1200, amount: 42000000 },
    { mode: "RTGS", count: 950, amount: 28000000 },
    { mode: "IMPS", count: 697, amount: 15000000 },
  ];

  const pastPayouts = [
    {
      id: 1,
      hospital: "Apollo Hospitals",
      claimId: "CLM-2025-009234",
      amount: "₹1,25,000",
      date: "05-Nov-2025",
      paymentMode: "NEFT",
      status: "Success",
      utrNumber: "UTR202501234567",
      patientName: "Rajesh Kumar",
      policyNumber: "POL-2025-5678",
      treatmentType: "Cardiac Surgery",
      admissionDate: "01-Nov-2025",
      dischargeDate: "04-Nov-2025",
      claimAmount: "₹1,50,000",
      approvedAmount: "₹1,25,000",
      processedBy: "Amit Sharma",
      processedDate: "05-Nov-2025",
    },
    {
      id: 2,
      hospital: "Fortis Healthcare",
      claimId: "CLM-2025-009235",
      amount: "₹2,50,000",
      date: "03-Nov-2025",
      paymentMode: "RTGS",
      status: "Success",
      utrNumber: "UTR202501234568",
      patientName: "Priya Singh",
      policyNumber: "POL-2025-5679",
      treatmentType: "Orthopedic Surgery",
      admissionDate: "28-Oct-2025",
      dischargeDate: "02-Nov-2025",
      claimAmount: "₹2,80,000",
      approvedAmount: "₹2,50,000",
      processedBy: "Sneha Patel",
      processedDate: "03-Nov-2025",
    },
    {
      id: 3,
      hospital: "Max Healthcare",
      claimId: "CLM-2025-009236",
      amount: "₹75,000",
      date: "01-Nov-2025",
      paymentMode: "NEFT",
      status: "Failed",
      utrNumber: "",
      patientName: "Vikram Reddy",
      policyNumber: "POL-2025-5680",
      treatmentType: "General Medicine",
      admissionDate: "30-Oct-2025",
      dischargeDate: "31-Oct-2025",
      claimAmount: "₹75,000",
      approvedAmount: "₹75,000",
      processedBy: "Rahul Verma",
      processedDate: "01-Nov-2025",
      failureReason: "Invalid bank account details",
    },
    {
      id: 4,
      hospital: "Narayana Health",
      claimId: "CLM-2025-009237",
      amount: "₹1,85,000",
      date: "30-Oct-2025",
      paymentMode: "IMPS",
      status: "Success",
      utrNumber: "UTR202501234890",
      patientName: "Meera Iyer",
      policyNumber: "POL-2025-5681",
      treatmentType: "Neurosurgery",
      admissionDate: "24-Oct-2025",
      dischargeDate: "29-Oct-2025",
      claimAmount: "₹2,00,000",
      approvedAmount: "₹1,85,000",
      processedBy: "Karan Mehta",
      processedDate: "30-Oct-2025",
    },
    {
      id: 5,
      hospital: "Manipal Hospitals",
      claimId: "CLM-2025-009238",
      amount: "₹3,20,000",
      date: "28-Oct-2025",
      paymentMode: "RTGS",
      status: "Failed",
      utrNumber: "",
      patientName: "Anil Gupta",
      policyNumber: "POL-2025-5682",
      treatmentType: "Cancer Treatment",
      admissionDate: "18-Oct-2025",
      dischargeDate: "27-Oct-2025",
      claimAmount: "₹3,50,000",
      approvedAmount: "₹3,20,000",
      processedBy: "Divya Nair",
      processedDate: "28-Oct-2025",
      failureReason: "Payment gateway timeout",
    },
    {
      id: 6,
      hospital: "Cloudnine Hospital",
      claimId: "CLM-2025-009239",
      amount: "₹1,50,000",
      date: "25-Oct-2025",
      paymentMode: "NEFT",
      status: "Success",
      utrNumber: "UTR202501235123",
      patientName: "Sunita Rao",
      policyNumber: "POL-2025-5683",
      treatmentType: "Maternity",
      admissionDate: "24-Oct-2025",
      dischargeDate: "25-Oct-2025",
      claimAmount: "₹1,50,000",
      approvedAmount: "₹1,50,000",
      processedBy: "Ankit Joshi",
      processedDate: "25-Oct-2025",
    },
    {
      id: 7,
      hospital: "Apollo Hospitals",
      claimId: "CLM-2025-009240",
      amount: "₹95,000",
      date: "22-Oct-2025",
      paymentMode: "NEFT",
      status: "Success",
      utrNumber: "UTR202501235124",
      patientName: "Karan Singh",
      policyNumber: "POL-2025-5684",
      treatmentType: "Gastroenterology",
      admissionDate: "20-Oct-2025",
      dischargeDate: "21-Oct-2025",
      claimAmount: "₹95,000",
      approvedAmount: "₹95,000",
      processedBy: "Amit Sharma",
      processedDate: "22-Oct-2025",
    },
    {
      id: 8,
      hospital: "Max Healthcare",
      claimId: "CLM-2025-009241",
      amount: "₹2,10,000",
      date: "20-Oct-2025",
      paymentMode: "RTGS",
      status: "Success",
      utrNumber: "UTR202501235125",
      patientName: "Anjali Desai",
      policyNumber: "POL-2025-5685",
      treatmentType: "Oncology",
      admissionDate: "12-Oct-2025",
      dischargeDate: "19-Oct-2025",
      claimAmount: "₹2,40,000",
      approvedAmount: "₹2,10,000",
      processedBy: "Rahul Verma",
      processedDate: "20-Oct-2025",
    },
    {
      id: 9,
      hospital: "Fortis Healthcare",
      claimId: "CLM-2025-009242",
      amount: "₹1,40,000",
      date: "18-Oct-2025",
      paymentMode: "IMPS",
      status: "Failed",
      utrNumber: "",
      patientName: "Ravi Patel",
      policyNumber: "POL-2025-5686",
      treatmentType: "Urology",
      admissionDate: "15-Oct-2025",
      dischargeDate: "17-Oct-2025",
      claimAmount: "₹1,40,000",
      approvedAmount: "₹1,40,000",
      processedBy: "Sneha Patel",
      processedDate: "18-Oct-2025",
      failureReason: "Bank server downtime",
    },
    {
      id: 10,
      hospital: "Narayana Health",
      claimId: "CLM-2025-009243",
      amount: "₹3,85,000",
      date: "15-Oct-2025",
      paymentMode: "RTGS",
      status: "Success",
      utrNumber: "UTR202501235126",
      patientName: "Lakshmi Iyer",
      policyNumber: "POL-2025-5687",
      treatmentType: "Cardiothoracic Surgery",
      admissionDate: "08-Oct-2025",
      dischargeDate: "14-Oct-2025",
      claimAmount: "₹4,00,000",
      approvedAmount: "₹3,85,000",
      processedBy: "Karan Mehta",
      processedDate: "15-Oct-2025",
    },
  ];

  // Helper: parse currency string like "₹1,25,000" to number (125000)
  const parseAmount = (value: string) => {
    const n = Number(value.replace(/[^\d]/g, ""));
    return isNaN(n) ? 0 : n;
  };

  const inr = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 });

  const getFromDateForRange = (range: string): Date | null => {
    const now = new Date();
    switch (range) {
      case 'last-7-days': {
        const d = new Date(now);
        d.setDate(d.getDate() - 7);
        return d;
      }
      case 'last-30-days': {
        const d = new Date(now);
        d.setDate(d.getDate() - 30);
        return d;
      }
      case 'last-3-months': {
        const d = new Date(now);
        d.setMonth(d.getMonth() - 3);
        return d;
      }
      case 'last-6-months': {
        const d = new Date(now);
        d.setMonth(d.getMonth() - 6);
        return d;
      }
      case 'last-year': {
        const d = new Date(now);
        d.setFullYear(d.getFullYear() - 1);
        return d;
      }
      default:
        return null; // 'custom' or unknown -> no time filter
    }
  };

  // Apply top filters (time range + hospital)
  const baseFiltered = useMemo(() => {
    const fromDate = getFromDateForRange(timeRange);
    const hospitalName = selectedHospital === 'all' ? null : hospitals.find(h => h.id === selectedHospital)?.name;
    return pastPayouts.filter((p) => {
      const paymentDate = parse(p.date, 'dd-MMM-yyyy', new Date());
      const inRange = !fromDate || paymentDate >= fromDate;
      const hospitalOk = !hospitalName || p.hospital === hospitalName;
      return inRange && hospitalOk;
    });
  }, [timeRange, selectedHospital]);

  // Metrics derived from top filters only
  const metrics = useMemo(() => {
    const successAmount = baseFiltered.filter(p => p.status === 'Success').reduce((sum, p) => sum + parseAmount(p.amount), 0);
    const failedAmount = baseFiltered.filter(p => p.status === 'Failed').reduce((sum, p) => sum + parseAmount(p.amount), 0);
    const successCount = baseFiltered.filter(p => p.status === 'Success').length;
    const failedCount = baseFiltered.filter(p => p.status === 'Failed').length;

    return {
      totalAmount: successAmount + failedAmount,
      successAmount,
      failedAmount,
      totalCount: baseFiltered.length,
      successCount,
      failedCount,
    };
  }, [baseFiltered]);

  const getStatusBadge = (status: string) => {
    const config: Record<string, string> = {
      Success: "bg-success/10 text-success border-success/20",
      Failed: "bg-destructive/10 text-destructive border-destructive/20",
    };
    return (
      <Badge variant="outline" className={config[status]}>
        {status}
      </Badge>
    );
  };

  const handleViewDetails = (payout: any) => {
    setSelectedPayout(payout);
    setDetailsOpen(true);
  };

  const handleSort = (key: string) => {
    let direction: "asc" | "desc" | null = "asc";
    if (sortConfig.key === key) {
      if (sortConfig.direction === "asc") {
        direction = "desc";
      } else if (sortConfig.direction === "desc") {
        direction = null;
      }
    }
    setSortConfig({ key, direction });
  };

  const handleFilter = (key: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const filteredAndSortedPayouts = useMemo(() => {
    let result = [...baseFiltered];

    // Apply column filters
    Object.keys(filters).forEach((key) => {
      const val = filters[key];
      if (val) {
        result = result.filter((payout: any) =>
          String(payout[key]).toLowerCase().includes(val.toLowerCase())
        );
      }
    });

    // Apply sorting
    if (sortConfig.key && sortConfig.direction) {
      result.sort((a: any, b: any) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];

        // Special handling for amount and date
        if (sortConfig.key === 'amount') {
          const an = parseAmount(aValue);
          const bn = parseAmount(bValue);
          return sortConfig.direction === 'asc' ? an - bn : bn - an;
        }
        if (sortConfig.key === 'date') {
          const ad = parse(aValue, 'dd-MMM-yyyy', new Date()).getTime();
          const bd = parse(bValue, 'dd-MMM-yyyy', new Date()).getTime();
          return sortConfig.direction === 'asc' ? ad - bd : bd - ad;
        }

        if (aValue < bValue) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }

    return result;
  }, [baseFiltered, filters, sortConfig]);

  const handleExport = () => {
    const headers = ["Hospital", "Claim ID", "Amount", "Payment Mode", "Date", "Status", "UTR Number"];
    const csvData = filteredAndSortedPayouts.map((payout) => [
      payout.hospital,
      payout.claimId,
      payout.amount,
      payout.paymentMode,
      payout.date,
      payout.status,
      payout.utrNumber || "-",
    ]);

    const csvContent = [
      headers.join(","),
      ...csvData.map((row) => row.join(",")),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `payouts_export_${new Date().toISOString().split("T")[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const chartConfig = {
    amount: {
      label: "Amount",
      color: "hsl(var(--primary))",
    },
  };

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Past Payouts"
        description="Historical payout records and analytics"
        icon={History}
        actions={
          <Button variant="outline" onClick={() => navigate("/payouts")}>
            Back to Current Payouts
          </Button>
        }
      />

      <div className="container mx-auto px-6 py-8">
        {/* Filters */}
        <Card className="mb-8 shadow-card">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
            <CardDescription>Customize your payout report</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="timeRange">
                  <Calendar className="h-4 w-4 inline mr-2" />
                  Time Range
                </Label>
                <Select value={timeRange} onValueChange={setTimeRange}>
                  <SelectTrigger id="timeRange">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="last-7-days">Last 7 Days</SelectItem>
                    <SelectItem value="last-30-days">Last 30 Days</SelectItem>
                    <SelectItem value="last-3-months">Last 3 Months</SelectItem>
                    <SelectItem value="last-6-months">Last 6 Months</SelectItem>
                    <SelectItem value="last-year">Last Year</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="hospital">
                  <Building2 className="h-4 w-4 inline mr-2" />
                  Hospital
                </Label>
                <Select value={selectedHospital} onValueChange={setSelectedHospital}>
                  <SelectTrigger id="hospital">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {hospitals.map((hospital) => (
                      <SelectItem key={hospital.id} value={hospital.id}>
                        {hospital.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Analytics Summary */}
        <div className="grid gap-6 md:grid-cols-2 mb-8">
          <Card className="shadow-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Payouts</p>
                  <p className="text-2xl font-bold mt-1">{inr.format(metrics.totalAmount)}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Success: {inr.format(metrics.successAmount)} • Failed: {inr.format(metrics.failedAmount)}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-success" />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Transactions</p>
                  <p className="text-2xl font-bold mt-1">{metrics.totalCount.toLocaleString('en-IN')}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Success: {metrics.successCount.toLocaleString('en-IN')} • Failed: {metrics.failedCount.toLocaleString('en-IN')}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payout History Table */}
        <Card className="shadow-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Payout History</CardTitle>
                <CardDescription>Detailed transaction records</CardDescription>
              </div>
              <Button onClick={handleExport} variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Export List
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <span>Hospital</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <DropdownMenuItem onClick={() => handleSort("hospital")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by ASC
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleSort("hospital")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by DESC
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <div className="p-2">
                            <Input
                              placeholder="Filter..."
                              value={filters.hospital || ""}
                              onChange={(e) => handleFilter("hospital", e.target.value)}
                              className="h-8"
                            />
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <span>Claim ID</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <DropdownMenuItem onClick={() => handleSort("claimId")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by ASC
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleSort("claimId")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by DESC
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <div className="p-2">
                            <Input
                              placeholder="Filter..."
                              value={filters.claimId || ""}
                              onChange={(e) => handleFilter("claimId", e.target.value)}
                              className="h-8"
                            />
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <span>Amount</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <DropdownMenuItem onClick={() => handleSort("amount")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by ASC
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleSort("amount")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by DESC
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <div className="p-2">
                            <Input
                              placeholder="Filter..."
                              value={filters.amount || ""}
                              onChange={(e) => handleFilter("amount", e.target.value)}
                              className="h-8"
                            />
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <span>Payment Mode</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <DropdownMenuItem onClick={() => handleSort("paymentMode")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by ASC
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleSort("paymentMode")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by DESC
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <div className="p-2">
                            <Input
                              placeholder="Filter..."
                              value={filters.paymentMode || ""}
                              onChange={(e) => handleFilter("paymentMode", e.target.value)}
                              className="h-8"
                            />
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <span>Date</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <DropdownMenuItem onClick={() => handleSort("date")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by ASC
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleSort("date")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by DESC
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <div className="p-2">
                            <Input
                              placeholder="Filter..."
                              value={filters.date || ""}
                              onChange={(e) => handleFilter("date", e.target.value)}
                              className="h-8"
                            />
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <span>Status</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <DropdownMenuItem onClick={() => handleSort("status")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by ASC
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleSort("status")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by DESC
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <div className="p-2">
                            <Input
                              placeholder="Filter..."
                              value={filters.status || ""}
                              onChange={(e) => handleFilter("status", e.target.value)}
                              className="h-8"
                            />
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <span>UTR Number</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <DropdownMenuItem onClick={() => handleSort("utrNumber")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by ASC
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleSort("utrNumber")}>
                            <ArrowUpDown className="mr-2 h-4 w-4" />
                            Sort by DESC
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <div className="p-2">
                            <Input
                              placeholder="Filter..."
                              value={filters.utrNumber || ""}
                              onChange={(e) => handleFilter("utrNumber", e.target.value)}
                              className="h-8"
                            />
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAndSortedPayouts.map((payout) => (
                  <TableRow key={payout.id}>
                    <TableCell className="font-medium">{payout.hospital}</TableCell>
                    <TableCell className="font-mono text-sm">{payout.claimId}</TableCell>
                    <TableCell className="font-semibold">{payout.amount}</TableCell>
                    <TableCell>{payout.paymentMode}</TableCell>
                    <TableCell>{payout.date}</TableCell>
                    <TableCell>{getStatusBadge(payout.status)}</TableCell>
                    <TableCell className="font-mono text-sm">
                      {payout.utrNumber || "-"}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" onClick={() => handleViewDetails(payout)}>
                        View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* View Details Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Payout Details</DialogTitle>
            <DialogDescription>Complete information about the payment and claim</DialogDescription>
          </DialogHeader>

          {selectedPayout && (
            <div className="space-y-6">
              {/* Payment Information */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Payment Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Claim ID</p>
                    <p className="font-mono font-medium">{selectedPayout.claimId}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <div className="mt-1">{getStatusBadge(selectedPayout.status)}</div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Amount</p>
                    <p className="font-semibold text-lg">{selectedPayout.amount}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Payment Mode</p>
                    <p className="font-medium">{selectedPayout.paymentMode}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Payment Date</p>
                    <p className="font-medium">{selectedPayout.date}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">UTR Number</p>
                    <p className="font-mono font-medium">{selectedPayout.utrNumber || "-"}</p>
                  </div>
                  {selectedPayout.status === "Failed" && selectedPayout.failureReason && (
                    <div className="col-span-2">
                      <p className="text-sm text-muted-foreground">Failure Reason</p>
                      <p className="font-medium text-destructive">{selectedPayout.failureReason}</p>
                    </div>
                  )}
                </div>
              </div>

              <Separator />

              {/* Hospital Information */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Hospital Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <p className="text-sm text-muted-foreground">Hospital Name</p>
                    <p className="font-medium">{selectedPayout.hospital}</p>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Claim Information */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Claim Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Patient Name</p>
                    <p className="font-medium">{selectedPayout.patientName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Policy Number</p>
                    <p className="font-mono font-medium">{selectedPayout.policyNumber}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Treatment Type</p>
                    <p className="font-medium">{selectedPayout.treatmentType}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Admission Date</p>
                    <p className="font-medium">{selectedPayout.admissionDate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Discharge Date</p>
                    <p className="font-medium">{selectedPayout.dischargeDate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Claim Amount</p>
                    <p className="font-semibold">{selectedPayout.claimAmount}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Approved Amount</p>
                    <p className="font-semibold text-success">{selectedPayout.approvedAmount}</p>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Processing Information */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Processing Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Processed By</p>
                    <p className="font-medium">{selectedPayout.processedBy}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Processed Date</p>
                    <p className="font-medium">{selectedPayout.processedDate}</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
