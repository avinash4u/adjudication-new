import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { PageHeader } from "@/components/layout/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Building2, ArrowLeft, Upload, X, MapPin, UserCircle, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { SpecialtySelector } from "@/components/hospital/SpecialtySelector";

export default function AddHospital() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [providerType, setProviderType] = useState<string>("");
  const [formData, setFormData] = useState({
    // Basic Information
    name: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    latitude: "",
    longitude: "",
    phone: "",
    email: "",
    
    // Facility Information (Hospital only)
    beds: "",
    icuBeds: "",
    otRooms: "",
    emergencyUnit: false,
    opdSetup: false,
    category: "",
    accreditation: "",
    status: "Active",
    activeSince: "",
    
    // Identification & Compliance
    rohiniCode: "",
    prcNumber: "",
    providerId: "",
    irdaCode: "",
    nhcxCompliant: false,
    serviceTaxNumber: "",
    pan: "",
    gstin: "",
    registrationNumber: "",
    
    // Expiry Dates
    rohiniExpiry: "",
    nabhExpiry: "",
    registrationExpiry: "",
    accreditationExpiry: "",
    
    // Specialties & Tags
    specialties: [] as string[],
    taggingStatus: "Network",
    tags: "",
    source: "",
    images: [] as string[],
    
    // Locations (Hospital only)
    branches: [] as Array<{ city: string; address: string; pincode: string }>,
    
    // Medical Staff (Hospital only)
    doctors: [] as Array<{ name: string; specialty: string; experience: string; qualification: string }>,
    
    // Banking Details
    bankAccountNumber: "",
    bankName: "",
    ifscCode: "",
    paymentCycle: "",
    customPaymentDays: "",
  });

  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [imagePreview, setImagePreview] = useState<string[]>([]);
  
  // Branch management
  const [newBranch, setNewBranch] = useState({ city: "", address: "", pincode: "" });
  
  // Doctor management
  const [newDoctor, setNewDoctor] = useState({ name: "", specialty: "", experience: "", qualification: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Convert tags from comma-separated string to array
    const providerData = {
      ...formData,
      providerType,
      beds: providerType === "Hospital" ? (parseInt(formData.beds) || 0) : undefined,
      icuBeds: providerType === "Hospital" ? (parseInt(formData.icuBeds) || 0) : undefined,
      otRooms: providerType === "Hospital" ? (parseInt(formData.otRooms) || 0) : undefined,
      tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean),
      images: uploadedImages,
    };

    console.log("New provider data:", providerData);
    
    toast({
      title: `${providerType} Added Successfully`,
      description: `${formData.name} has been added to the provider master.`,
    });
    
    navigate("/hospitals");
  };
  
  const showFacilityDetails = providerType === "Hospital";
  const showFullCompliance = providerType === "Hospital";

  // If provider type not selected, show selection screen
  if (!providerType) {
    return (
      <div className="min-h-screen bg-background">
        <PageHeader
          title="Add New Provider"
          description="Select the type of provider you want to add"
          icon={Building2}
          actions={
            <Button variant="outline" onClick={() => navigate("/hospitals")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Providers
            </Button>
          }
        />

        <div className="container mx-auto px-6 py-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-semibold mb-6">Choose Provider Type</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card 
                className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-primary"
                onClick={() => setProviderType("Hospital")}
              >
                <CardContent className="p-8 text-center">
                  <Building2 className="h-16 w-16 mx-auto mb-4 text-primary" />
                  <h3 className="text-xl font-semibold mb-2">Hospital</h3>
                  <p className="text-muted-foreground">
                    Multi-specialty hospitals with in-patient facilities, ICU, OT rooms, and comprehensive medical services
                  </p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-primary"
                onClick={() => setProviderType("Clinic")}
              >
                <CardContent className="p-8 text-center">
                  <Building2 className="h-16 w-16 mx-auto mb-4 text-primary" />
                  <h3 className="text-xl font-semibold mb-2">Clinic</h3>
                  <p className="text-muted-foreground">
                    Out-patient clinics providing consultation and treatment services
                  </p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-primary"
                onClick={() => setProviderType("Diagnostic Centre/Lab")}
              >
                <CardContent className="p-8 text-center">
                  <Building2 className="h-16 w-16 mx-auto mb-4 text-primary" />
                  <h3 className="text-xl font-semibold mb-2">Diagnostic Centre/Lab</h3>
                  <p className="text-muted-foreground">
                    Diagnostic and pathology laboratories providing testing services
                  </p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-primary"
                onClick={() => setProviderType("Online Healthcare Platform")}
              >
                <CardContent className="p-8 text-center">
                  <Building2 className="h-16 w-16 mx-auto mb-4 text-primary" />
                  <h3 className="text-xl font-semibold mb-2">Online Healthcare Platform</h3>
                  <p className="text-muted-foreground">
                    Digital health platforms providing telemedicine and online consultation services
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result as string;
          setImagePreview(prev => [...prev, result]);
          setUploadedImages(prev => [...prev, file.name]);
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const handleRemoveImage = (index: number) => {
    setImagePreview(prev => prev.filter((_, i) => i !== index));
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleAddBranch = () => {
    if (newBranch.city && newBranch.address && newBranch.pincode) {
      setFormData(prev => ({
        ...prev,
        branches: [...prev.branches, newBranch]
      }));
      setNewBranch({ city: "", address: "", pincode: "" });
    }
  };

  const handleRemoveBranch = (index: number) => {
    setFormData(prev => ({
      ...prev,
      branches: prev.branches.filter((_, i) => i !== index)
    }));
  };

  const handleAddDoctor = () => {
    if (newDoctor.name && newDoctor.specialty && newDoctor.experience && newDoctor.qualification) {
      setFormData(prev => ({
        ...prev,
        doctors: [...prev.doctors, newDoctor]
      }));
      setNewDoctor({ name: "", specialty: "", experience: "", qualification: "" });
    }
  };

  const handleRemoveDoctor = (index: number) => {
    setFormData(prev => ({
      ...prev,
      doctors: prev.doctors.filter((_, i) => i !== index)
    }));
  };

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title={`Add New ${providerType}`}
        description={`Enter ${providerType.toLowerCase()} information to add to the master database`}
        icon={Building2}
        actions={
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setProviderType("")}>
              Change Type
            </Button>
            <Button variant="outline" onClick={() => navigate("/hospitals")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Providers
            </Button>
          </div>
        }
      />

      <div className="container mx-auto px-6 py-8">
        <Card className="shadow-card">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit}>
              <Tabs defaultValue="basic" className="w-full">
                <TabsList className={`grid w-full ${showFacilityDetails ? 'grid-cols-8' : 'grid-cols-3'}`}>
                  <TabsTrigger value="basic">Basic</TabsTrigger>
                  {showFacilityDetails && <TabsTrigger value="facility">Facility</TabsTrigger>}
                  {showFacilityDetails && <TabsTrigger value="infrastructure">Infrastructure</TabsTrigger>}
                  {showFacilityDetails && <TabsTrigger value="locations">Locations</TabsTrigger>}
                  {showFacilityDetails && <TabsTrigger value="staff">Medical Staff</TabsTrigger>}
                  <TabsTrigger value="compliance">Compliance</TabsTrigger>
                  <TabsTrigger value="specialties">Specialties</TabsTrigger>
                  {showFacilityDetails && <TabsTrigger value="banking">Banking</TabsTrigger>}
                </TabsList>

                {/* Basic Information Tab */}
                <TabsContent value="basic" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">{providerType} Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Address *</Label>
                    <Textarea
                      id="address"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      required
                    />
                  </div>

                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2">
                      <Label htmlFor="city">City *</Label>
                      <Input
                        id="city"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="state">State *</Label>
                      <Input
                        id="state"
                        value={formData.state}
                        onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="pincode">Pincode *</Label>
                      <Input
                        id="pincode"
                        value={formData.pincode}
                        onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="latitude">Latitude</Label>
                      <Input
                        id="latitude"
                        value={formData.latitude}
                        onChange={(e) => setFormData({ ...formData, latitude: e.target.value })}
                        placeholder="e.g., 19.0760"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="longitude">Longitude</Label>
                      <Input
                        id="longitude"
                        value={formData.longitude}
                        onChange={(e) => setFormData({ ...formData, longitude: e.target.value })}
                        placeholder="e.g., 72.8777"
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="status">Status *</Label>
                      <Select
                        value={formData.status}
                        onValueChange={(value) => setFormData({ ...formData, status: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Active">Active</SelectItem>
                          <SelectItem value="Inactive">Inactive</SelectItem>
                          <SelectItem value="Pending">Pending</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="activeSince">Active Since</Label>
                      <Input
                        id="activeSince"
                        type="date"
                        value={formData.activeSince}
                        onChange={(e) => setFormData({ ...formData, activeSince: e.target.value })}
                      />
                    </div>
                  </div>
                </TabsContent>

                {/* Facility Information Tab - Only for Hospitals */}
                {showFacilityDetails && (
                <TabsContent value="facility" className="space-y-4 mt-4">
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2">
                      <Label htmlFor="beds">Total Beds *</Label>
                      <Input
                        id="beds"
                        type="number"
                        value={formData.beds}
                        onChange={(e) => setFormData({ ...formData, beds: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="icuBeds">ICU Beds *</Label>
                      <Input
                        id="icuBeds"
                        type="number"
                        value={formData.icuBeds}
                        onChange={(e) => setFormData({ ...formData, icuBeds: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="otRooms">OT Rooms *</Label>
                      <Input
                        id="otRooms"
                        type="number"
                        value={formData.otRooms}
                        onChange={(e) => setFormData({ ...formData, otRooms: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="category">Category *</Label>
                      <Select
                        value={formData.category}
                        onValueChange={(value) => setFormData({ ...formData, category: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Super Specialty Hospital">Super Specialty Hospital</SelectItem>
                          <SelectItem value="Tertiary Care Hospital">Tertiary Care Hospital</SelectItem>
                          <SelectItem value="Multi-specialty">Multi-specialty</SelectItem>
                          <SelectItem value="Women and Child Specialty">Women and Child Specialty</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="accreditation">Accreditation *</Label>
                      <Select
                        value={formData.accreditation}
                        onValueChange={(value) => setFormData({ ...formData, accreditation: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select accreditation" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="NABH">NABH</SelectItem>
                          <SelectItem value="NABL">NABL</SelectItem>
                          <SelectItem value="JCI">JCI</SelectItem>
                          <SelectItem value="None">None</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="emergencyUnit"
                        checked={formData.emergencyUnit}
                        onCheckedChange={(checked) => 
                          setFormData({ ...formData, emergencyUnit: checked as boolean })
                        }
                      />
                      <Label htmlFor="emergencyUnit" className="cursor-pointer">
                        Has Emergency Unit
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="opdSetup"
                        checked={formData.opdSetup}
                        onCheckedChange={(checked) => 
                          setFormData({ ...formData, opdSetup: checked as boolean })
                        }
                      />
                      <Label htmlFor="opdSetup" className="cursor-pointer">
                        Has OPD Setup
                      </Label>
                    </div>
                  </div>
                </TabsContent>
                )}

                {/* Infrastructure Tab - Only for Hospitals */}
                {showFacilityDetails && (
                <TabsContent value="infrastructure" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label>Hospital Images</Label>
                    <div className="space-y-4">
                      <div className="flex items-center gap-4">
                        <label className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 cursor-pointer transition-colors">
                          <Upload className="h-4 w-4" />
                          Upload Images
                          <input
                            type="file"
                            multiple
                            accept="image/*"
                            onChange={handleImageUpload}
                            className="hidden"
                          />
                        </label>
                        <span className="text-sm text-muted-foreground">
                          {uploadedImages.length} image(s) uploaded
                        </span>
                      </div>
                      
                      {/* Image Previews */}
                      {imagePreview.length > 0 && (
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          {imagePreview.map((preview, idx) => (
                            <div key={idx} className="relative group">
                              <img
                                src={preview}
                                alt={`Preview ${idx + 1}`}
                                className="w-full h-32 object-cover rounded-lg border border-border"
                              />
                              <button
                                type="button"
                                onClick={() => handleRemoveImage(idx)}
                                className="absolute top-2 right-2 p-1 bg-destructive text-destructive-foreground rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <X className="h-4 w-4" />
                              </button>
                              <p className="text-xs text-muted-foreground mt-1 truncate">
                                {uploadedImages[idx]}
                              </p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Upload images of the hospital facility, infrastructure, and departments
                    </p>
                  </div>
                </TabsContent>
                )}

                {/* Locations Tab - Only for Hospitals */}
                {showFacilityDetails && (
                <TabsContent value="locations" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label>Branch Locations</Label>
                    
                    {/* Add Branch Form */}
                    <div className="space-y-3 p-4 border border-border rounded-lg bg-muted/30">
                      <h4 className="text-sm font-semibold">Add New Branch</h4>
                      <div className="grid gap-3 md:grid-cols-3">
                        <Input
                          placeholder="City"
                          value={newBranch.city}
                          onChange={(e) => setNewBranch({ ...newBranch, city: e.target.value })}
                        />
                        <Input
                          placeholder="Address"
                          value={newBranch.address}
                          onChange={(e) => setNewBranch({ ...newBranch, address: e.target.value })}
                        />
                        <Input
                          placeholder="Pincode"
                          value={newBranch.pincode}
                          onChange={(e) => setNewBranch({ ...newBranch, pincode: e.target.value })}
                        />
                      </div>
                      <Button
                        type="button"
                        onClick={handleAddBranch}
                        variant="outline"
                        size="sm"
                        className="gap-2"
                      >
                        <Plus className="h-4 w-4" />
                        Add Branch
                      </Button>
                    </div>

                    {/* Existing Branches */}
                    {formData.branches.length > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                        {formData.branches.map((branch, idx) => (
                          <div key={idx} className="p-4 rounded-lg border border-border bg-muted/30 relative group">
                            <button
                              type="button"
                              onClick={() => handleRemoveBranch(idx)}
                              className="absolute top-2 right-2 p-1 bg-destructive text-destructive-foreground rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <X className="h-3 w-3" />
                            </button>
                            <div className="flex items-start gap-2">
                              <MapPin className="h-4 w-4 text-primary mt-1" />
                              <div>
                                <p className="font-semibold">{branch.city}</p>
                                <p className="text-sm text-muted-foreground">{branch.address}</p>
                                <p className="text-sm text-muted-foreground">PIN: {branch.pincode}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </TabsContent>
                )}

                {/* Medical Staff Tab - Only for Hospitals */}
                {showFacilityDetails && (
                <TabsContent value="staff" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label>Medical Staff</Label>
                    
                    {/* Add Doctor Form */}
                    <div className="space-y-3 p-4 border border-border rounded-lg bg-muted/30">
                      <h4 className="text-sm font-semibold">Add Medical Staff</h4>
                      <div className="grid gap-3 md:grid-cols-2">
                        <Input
                          placeholder="Doctor Name"
                          value={newDoctor.name}
                          onChange={(e) => setNewDoctor({ ...newDoctor, name: e.target.value })}
                        />
                        <Input
                          placeholder="Specialty"
                          value={newDoctor.specialty}
                          onChange={(e) => setNewDoctor({ ...newDoctor, specialty: e.target.value })}
                        />
                        <Input
                          placeholder="Experience (e.g., 15 years)"
                          value={newDoctor.experience}
                          onChange={(e) => setNewDoctor({ ...newDoctor, experience: e.target.value })}
                        />
                        <Input
                          placeholder="Qualification"
                          value={newDoctor.qualification}
                          onChange={(e) => setNewDoctor({ ...newDoctor, qualification: e.target.value })}
                        />
                      </div>
                      <Button
                        type="button"
                        onClick={handleAddDoctor}
                        variant="outline"
                        size="sm"
                        className="gap-2"
                      >
                        <Plus className="h-4 w-4" />
                        Add Staff
                      </Button>
                    </div>

                    {/* Existing Doctors */}
                    {formData.doctors.length > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        {formData.doctors.map((doctor, idx) => (
                          <div key={idx} className="p-4 rounded-lg border border-border bg-muted/30 relative group">
                            <button
                              type="button"
                              onClick={() => handleRemoveDoctor(idx)}
                              className="absolute top-2 right-2 p-1 bg-destructive text-destructive-foreground rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <X className="h-3 w-3" />
                            </button>
                            <div className="flex items-start gap-3">
                              <UserCircle className="h-10 w-10 text-primary" />
                              <div className="flex-1">
                                <p className="font-semibold">{doctor.name}</p>
                                <div className="mt-1 space-y-1">
                                  <Badge variant="outline" className="text-xs">
                                    {doctor.specialty}
                                  </Badge>
                                  <p className="text-xs text-muted-foreground">{doctor.qualification}</p>
                                  <p className="text-xs text-muted-foreground">Experience: {doctor.experience}</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </TabsContent>
                )}

                {/* Compliance Tab */}
                <TabsContent value="compliance" className="space-y-4 mt-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="rohiniCode">Rohini Code</Label>
                      <Input
                        id="rohiniCode"
                        value={formData.rohiniCode}
                        onChange={(e) => setFormData({ ...formData, rohiniCode: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="rohiniExpiry">Rohini Expiry</Label>
                      <Input
                        id="rohiniExpiry"
                        type="date"
                        value={formData.rohiniExpiry}
                        onChange={(e) => setFormData({ ...formData, rohiniExpiry: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="prcNumber">PRC Number</Label>
                      <Input
                        id="prcNumber"
                        value={formData.prcNumber}
                        onChange={(e) => setFormData({ ...formData, prcNumber: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="providerId">Provider ID</Label>
                      <Input
                        id="providerId"
                        value={formData.providerId}
                        onChange={(e) => setFormData({ ...formData, providerId: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="irdaCode">IRDA Code</Label>
                      <Input
                        id="irdaCode"
                        value={formData.irdaCode}
                        onChange={(e) => setFormData({ ...formData, irdaCode: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="registrationNumber">Registration Number</Label>
                      <Input
                        id="registrationNumber"
                        value={formData.registrationNumber}
                        onChange={(e) => setFormData({ ...formData, registrationNumber: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="pan">PAN *</Label>
                      <Input
                        id="pan"
                        value={formData.pan}
                        onChange={(e) => setFormData({ ...formData, pan: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="gstin">GSTIN *</Label>
                      <Input
                        id="gstin"
                        value={formData.gstin}
                        onChange={(e) => setFormData({ ...formData, gstin: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  {showFullCompliance && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="serviceTaxNumber">Service Tax Number</Label>
                        <Input
                          id="serviceTaxNumber"
                          value={formData.serviceTaxNumber}
                          onChange={(e) => setFormData({ ...formData, serviceTaxNumber: e.target.value })}
                        />
                      </div>

                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="rohiniExpiry">ROHINI Expiry</Label>
                          <Input
                            id="rohiniExpiry"
                            type="date"
                            value={formData.rohiniExpiry}
                            onChange={(e) => setFormData({ ...formData, rohiniExpiry: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="nabhExpiry">NABH Expiry</Label>
                          <Input
                            id="nabhExpiry"
                            type="date"
                            value={formData.nabhExpiry}
                            onChange={(e) => setFormData({ ...formData, nabhExpiry: e.target.value })}
                          />
                        </div>
                      </div>
                      
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="registrationExpiry">Registration Expiry</Label>
                          <Input
                            id="registrationExpiry"
                            type="date"
                            value={formData.registrationExpiry}
                            onChange={(e) => setFormData({ ...formData, registrationExpiry: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="accreditationExpiry">Accreditation Expiry</Label>
                          <Input
                            id="accreditationExpiry"
                            type="date"
                            value={formData.accreditationExpiry}
                            onChange={(e) => setFormData({ ...formData, accreditationExpiry: e.target.value })}
                          />
                        </div>
                      </div>
                    </>
                  )}

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="nhcxCompliant"
                      checked={formData.nhcxCompliant}
                      onCheckedChange={(checked) => 
                        setFormData({ ...formData, nhcxCompliant: checked as boolean })
                      }
                    />
                    <Label htmlFor="nhcxCompliant" className="cursor-pointer">
                      NHCX Compliant
                    </Label>
                  </div>
                </TabsContent>

                {/* Specialties & Tags Tab */}
                <TabsContent value="specialties" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="specialties">Specialties *</Label>
                    <SpecialtySelector
                      selectedSpecialties={formData.specialties}
                      onSpecialtiesChange={(specialties) => setFormData({ ...formData, specialties })}
                    />
                    <p className="text-xs text-muted-foreground">
                      Search and select multiple specialties
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="taggingStatus">Tagging Status *</Label>
                    <Select
                      value={formData.taggingStatus}
                      onValueChange={(value) => setFormData({ ...formData, taggingStatus: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Network">Network</SelectItem>
                        <SelectItem value="Non-Network">Non-Network</SelectItem>
                        <SelectItem value="Excluded">Excluded</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tags">Tags</Label>
                    <Input
                      id="tags"
                      value={formData.tags}
                      onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                      placeholder="e.g., ACKO Internal, Preferred Partner"
                    />
                    <p className="text-xs text-muted-foreground">
                      Enter multiple tags separated by commas
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="source">Source</Label>
                    <Select
                      value={formData.source}
                      onValueChange={(value) => setFormData({ ...formData, source: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select source" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ACKO">ACKO</SelectItem>
                        <SelectItem value="IHX">IHX</SelectItem>
                        <SelectItem value="TPA1">TPA1</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </TabsContent>

                {/* Banking Details Tab - Only for Hospitals */}
                {showFacilityDetails && (
                <TabsContent value="banking" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="bankName">Bank Name</Label>
                    <Input
                      id="bankName"
                      value={formData.bankName}
                      onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bankAccountNumber">Bank Account Number</Label>
                    <Input
                      id="bankAccountNumber"
                      value={formData.bankAccountNumber}
                      onChange={(e) => setFormData({ ...formData, bankAccountNumber: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ifscCode">IFSC Code</Label>
                    <Input
                      id="ifscCode"
                      value={formData.ifscCode}
                      onChange={(e) => setFormData({ ...formData, ifscCode: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="paymentCycle">Payment Cycle</Label>
                    <Select
                      value={formData.paymentCycle}
                      onValueChange={(value) => setFormData({ ...formData, paymentCycle: value, customPaymentDays: value !== "custom" ? "" : formData.customPaymentDays })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select payment cycle" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="custom">Custom</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {formData.paymentCycle === "custom" && (
                    <div className="space-y-2">
                      <Label htmlFor="customPaymentDays">Custom Payment Days</Label>
                      <Input
                        id="customPaymentDays"
                        type="number"
                        min="1"
                        placeholder="e.g., 2, 3, 5"
                        value={formData.customPaymentDays}
                        onChange={(e) => setFormData({ ...formData, customPaymentDays: e.target.value })}
                      />
                      <p className="text-sm text-muted-foreground">
                        Enter number of days for custom payment cycle
                      </p>
                    </div>
                  )}
                </TabsContent>
                )}
              </Tabs>

              <div className="flex justify-end gap-2 mt-6">
                <Button type="button" variant="outline" onClick={() => navigate("/hospitals")}>
                  Cancel
                </Button>
                <Button type="submit">Add {providerType}</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
