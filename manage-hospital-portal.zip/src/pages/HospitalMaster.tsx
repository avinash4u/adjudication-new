import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { PageHeader } from "@/components/layout/PageHeader";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Building2, Plus, Search, MapPin, Phone, Mail, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import HospitalFilters, { HospitalFilterOptions } from "@/components/hospital/HospitalFilters";
import apolloHospitalImg from "@/assets/hospitals/apollo-hospital.jpg";
import fortisHospitalImg from "@/assets/hospitals/fortis-hospital.jpg";
import maxHospitalImg from "@/assets/hospitals/max-hospital.jpg";
import lilavatiHospitalImg from "@/assets/hospitals/lilavati-hospital.jpg";
import manipalHospitalImg from "@/assets/hospitals/manipal-hospital.jpg";
import medantaHospitalImg from "@/assets/hospitals/medanta-hospital.jpg";
import cloudnineHospitalImg from "@/assets/hospitals/cloudnine-hospital.jpg";
import kokilabenHospitalImg from "@/assets/hospitals/kokilaben-hospital.jpg";

export default function HospitalMaster() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showIncompleteOnly, setShowIncompleteOnly] = useState(false);
  const [filters, setFilters] = useState<HospitalFilterOptions>({
    cities: [],
    states: [],
    pincodes: [],
    taggingStatuses: [],
    specialties: [],
    otherTags: [],
  });

  const hospitals = [
    {
      id: 1,
      providerType: "Hospital",
      name: "Apollo Hospitals",
      address: "Sahar Road, Andheri East",
      city: "Mumbai",
      state: "Maharashtra",
      pincode: "400001",
      latitude: "19.0760",
      longitude: "72.8777",
      phone: "+91 22 1234 5678",
      email: "contact@apollo.com",
      beds: 500,
      icuBeds: 50,
      otRooms: 12,
      emergencyUnit: true,
      opdSetup: true,
      category: "Tertiary Care Hospital",
      accreditation: "NABH",
      status: "Active",
      rohiniCode: "ROH123456",
      prcNumber: "PRC987654",
      providerId: "PROV001",
      irdaCode: "IRDA12345",
      nhcxCompliant: true,
      serviceTaxNumber: "STX123456789",
      pan: "AABCA1234B",
      gstin: "27AABCA1234B1Z5",
      registrationNumber: "REG123456",
      rohiniExpiry: "2025-12-31",
      nabhExpiry: "2026-06-30",
      registrationExpiry: "2025-12-31",
      accreditationExpiry: "2026-06-30",
      specialties: ["Orthopaedics", "Cardiology", "Neurology", "Oncology"],
      bankAccountNumber: "1234567890",
      bankName: "HDFC Bank",
      ifscCode: "HDFC0001234",
      source: "ACKO",
      images: ["hospital1.jpg", "hospital1_interior.jpg"],
      taggingStatus: "Network",
      tags: ["ACKO Internal", "Preferred Partner"],
      image: apolloHospitalImg,
    },
    {
      id: 2,
      providerType: "Hospital",
      name: "Fortis Healthcare",
      address: "Sector 62, Phase VIII",
      city: "Delhi",
      state: "Delhi",
      pincode: "110001",
      latitude: "28.7041",
      longitude: "77.1025",
      phone: "",
      email: "",
      beds: 350,
      icuBeds: 40,
      otRooms: 10,
      emergencyUnit: true,
      opdSetup: true,
      category: "Multi-specialty",
      accreditation: "NABH",
      status: "Active",
      rohiniCode: "",
      prcNumber: "PRC876543",
      providerId: "",
      irdaCode: "IRDA23456",
      nhcxCompliant: true,
      serviceTaxNumber: "STX234567890",
      pan: "",
      gstin: "",
      registrationNumber: "",
      rohiniExpiry: "2025-10-31",
      nabhExpiry: "2026-04-30",
      registrationExpiry: "2025-10-31",
      accreditationExpiry: "2026-04-30",
      specialties: ["Gynaecology", "Paediatrics", "Orthopaedics"],
      bankAccountNumber: "2345678901",
      bankName: "ICICI Bank",
      ifscCode: "ICIC0002345",
      source: "IHX",
      images: ["hospital2.jpg"],
      taggingStatus: "Non-Network",
      tags: ["IHX"],
      image: fortisHospitalImg,
    },
    {
      id: 3,
      providerType: "Hospital",
      name: "Max Healthcare",
      address: "",
      city: "Bangalore",
      state: "Karnataka",
      pincode: "560001",
      latitude: "12.9716",
      longitude: "77.5946",
      phone: "+91 80 3456 7890",
      email: "contact@maxhealthcare.com",
      beds: 400,
      icuBeds: 45,
      otRooms: 11,
      emergencyUnit: true,
      opdSetup: true,
      category: "",
      accreditation: "NABH",
      status: "Active",
      rohiniCode: "ROH345678",
      prcNumber: "PRC765432",
      providerId: "",
      irdaCode: "IRDA34567",
      nhcxCompliant: true,
      serviceTaxNumber: "STX345678901",
      pan: "",
      gstin: "29AABCC3456D1Z5",
      registrationNumber: "REG345678",
      rohiniExpiry: "2025-11-30",
      nabhExpiry: "2026-05-31",
      registrationExpiry: "2025-11-30",
      accreditationExpiry: "2026-05-31",
      specialties: [],
      bankAccountNumber: "3456789012",
      bankName: "Axis Bank",
      ifscCode: "UTIB0003456",
      source: "TPA1",
      images: ["hospital3.jpg", "hospital3_ward.jpg"],
      taggingStatus: "Network",
      tags: ["Preferred Partner", "Early Discharge"],
      image: maxHospitalImg,
    },
    {
      id: 4,
      providerType: "Clinic",
      name: "Lilavati Hospital",
      address: "A-791, Bandra Reclamation",
      city: "Mumbai",
      state: "Maharashtra",
      pincode: "",
      latitude: "19.0522",
      longitude: "72.8232",
      phone: "+91 22 2640 8888",
      email: "",
      beds: 320,
      icuBeds: 35,
      otRooms: 9,
      emergencyUnit: true,
      opdSetup: true,
      category: "Multi-specialty",
      accreditation: "NABH",
      status: "Active",
      rohiniCode: "",
      prcNumber: "PRC654321",
      providerId: "PROV004",
      irdaCode: "IRDA45678",
      nhcxCompliant: true,
      serviceTaxNumber: "STX456789012",
      pan: "AABCD4567E",
      gstin: "",
      registrationNumber: "REG456789",
      rohiniExpiry: "2025-09-30",
      nabhExpiry: "2026-03-31",
      registrationExpiry: "2025-09-30",
      accreditationExpiry: "2026-03-31",
      specialties: ["Cardiology", "Neurosurgery", "Orthopaedics", "General Surgery"],
      bankAccountNumber: "4567890123",
      bankName: "SBI",
      ifscCode: "SBIN0004567",
      source: "ACKO",
      images: ["hospital4.jpg"],
      taggingStatus: "Network",
      tags: ["ACKO Internal"],
      image: lilavatiHospitalImg,
    },
    {
      id: 5,
      providerType: "Hospital",
      name: "Manipal Hospital",
      address: "Old Airport Road",
      city: "Bangalore",
      state: "Karnataka",
      pincode: "560017",
      latitude: "12.9611",
      longitude: "77.6387",
      phone: "",
      email: "",
      beds: 450,
      icuBeds: 48,
      otRooms: 13,
      emergencyUnit: true,
      opdSetup: true,
      category: "",
      accreditation: "NABH",
      status: "Active",
      rohiniCode: "ROH567890",
      prcNumber: "PRC543210",
      providerId: "PROV005",
      irdaCode: "IRDA56789",
      nhcxCompliant: true,
      serviceTaxNumber: "STX567890123",
      pan: "",
      gstin: "",
      registrationNumber: "",
      rohiniExpiry: "2026-01-31",
      nabhExpiry: "2026-07-31",
      registrationExpiry: "2026-01-31",
      accreditationExpiry: "2026-07-31",
      specialties: [],
      bankAccountNumber: "5678901234",
      bankName: "HDFC Bank",
      ifscCode: "HDFC0005678",
      source: "IHX",
      images: ["hospital5.jpg"],
      taggingStatus: "Network",
      tags: ["Preferred Partner"],
      image: manipalHospitalImg,
    },
    {
      id: 6,
      providerType: "Hospital",
      name: "Medanta - The Medicity",
      address: "CH Baktawar Singh Road, Sector 38",
      city: "Gurugram",
      state: "",
      pincode: "122001",
      latitude: "28.4355",
      longitude: "77.0568",
      phone: "+91 124 4141 414",
      email: "info@medanta.org",
      beds: 1250,
      icuBeds: 120,
      otRooms: 45,
      emergencyUnit: true,
      opdSetup: true,
      category: "Super Specialty Hospital",
      accreditation: "NABH",
      status: "",
      rohiniCode: "",
      prcNumber: "PRC432109",
      providerId: "",
      irdaCode: "IRDA67890",
      nhcxCompliant: true,
      serviceTaxNumber: "STX678901234",
      pan: "",
      gstin: "06AABCF6789G1Z5",
      registrationNumber: "REG678901",
      rohiniExpiry: "2026-02-28",
      nabhExpiry: "2026-08-31",
      registrationExpiry: "2026-02-28",
      accreditationExpiry: "2026-08-31",
      specialties: ["Cardiology", "Oncology", "Neurosciences", "Orthopaedics", "Gastroenterology", "Nephrology"],
      bankAccountNumber: "6789012345",
      bankName: "ICICI Bank",
      ifscCode: "ICIC0006789",
      source: "TPA1",
      images: ["hospital6.jpg"],
      taggingStatus: "Network",
      tags: ["Early Discharge"],
      image: medantaHospitalImg,
    },
    {
      id: 7,
      providerType: "Diagnostic Centre/Lab",
      name: "Cloudnine Hospital",
      address: "",
      city: "Bangalore",
      state: "Karnataka",
      pincode: "560011",
      latitude: "12.9279",
      longitude: "77.5937",
      phone: "",
      email: "enquiry@cloudninehospitals.com",
      beds: 180,
      icuBeds: 20,
      otRooms: 7,
      emergencyUnit: true,
      opdSetup: true,
      category: "Women and Child Specialty",
      accreditation: "NABH",
      status: "Active",
      rohiniCode: "ROH789012",
      prcNumber: "PRC321098",
      providerId: "",
      irdaCode: "IRDA78901",
      nhcxCompliant: true,
      serviceTaxNumber: "STX789012345",
      pan: "",
      gstin: "",
      registrationNumber: "",
      rohiniExpiry: "2025-08-31",
      nabhExpiry: "2026-02-28",
      registrationExpiry: "2025-08-31",
      accreditationExpiry: "2026-02-28",
      specialties: ["Gynaecology", "Obstetrics", "Paediatrics", "Neonatology"],
      bankAccountNumber: "7890123456",
      bankName: "Axis Bank",
      ifscCode: "UTIB0007890",
      source: "ACKO",
      images: ["hospital7.jpg"],
      taggingStatus: "Excluded",
      tags: ["Suspicious"],
      image: cloudnineHospitalImg,
    },
    {
      id: 8,
      providerType: "Online Healthcare Platform",
      name: "Kokilaben Dhirubhai Ambani Hospital",
      address: "Achutrao Patwardhan Marg, Four Bungalows",
      city: "Mumbai",
      state: "Maharashtra",
      pincode: "400053",
      latitude: "19.1286",
      longitude: "72.8343",
      phone: "+91 22 4296 9999",
      email: "info@relianceada.com",
      beds: 750,
      icuBeds: 85,
      otRooms: 28,
      emergencyUnit: true,
      opdSetup: true,
      category: "Super Specialty Hospital",
      accreditation: "NABH",
      status: "Active",
      rohiniCode: "ROH890123",
      prcNumber: "PRC210987",
      providerId: "PROV008",
      irdaCode: "IRDA89012",
      nhcxCompliant: true,
      serviceTaxNumber: "STX890123456",
      pan: "AABCH8901I",
      gstin: "27AABCH8901I1Z5",
      registrationNumber: "REG890123",
      rohiniExpiry: "2026-03-31",
      nabhExpiry: "2026-09-30",
      registrationExpiry: "2026-03-31",
      accreditationExpiry: "2026-09-30",
      specialties: ["Cardiology", "Oncology", "Neurosciences", "Orthopaedics", "Transplant Surgery", "Critical Care"],
      bankAccountNumber: "8901234567",
      bankName: "HDFC Bank",
      ifscCode: "HDFC0008901",
      source: "IHX",
      images: ["hospital8.jpg"],
      taggingStatus: "Network",
      tags: ["ACKO Internal", "Preferred Partner", "Early Discharge"],
      image: kokilabenHospitalImg,
    },
  ];

  // Extract unique values for filter options
  const availableCities = useMemo(
    () => [...new Set(hospitals.map((h) => h.city))],
    []
  );
  const availableStates = useMemo(
    () => [...new Set(hospitals.map((h) => h.state))],
    []
  );
  const availablePincodes = useMemo(
    () => [...new Set(hospitals.map((h) => h.pincode))],
    []
  );
  const availableSpecialties = useMemo(
    () => [...new Set(hospitals.flatMap((h) => h.specialties))],
    []
  );
  const availableOtherTags = useMemo(
    () => [...new Set(hospitals.flatMap((h) => h.tags))],
    []
  );

  // Calculate data completeness percentage for a hospital
  const calculateCompleteness = (hospital: typeof hospitals[0]) => {
    const mandatoryFields = [
      'name',
      'address',
      'city',
      'state',
      'pincode',
      'phone',
      'email',
      'providerType',
      'category',
      'status',
      'registrationNumber',
      'rohiniCode',
      'providerId',
      'pan',
      'gstin',
    ];
    
    // Add specialty requirement (at least one)
    const hasSpecialties = hospital.specialties && hospital.specialties.length > 0;
    
    let filledCount = 0;
    mandatoryFields.forEach(field => {
      const value = hospital[field as keyof typeof hospital];
      if (value && value !== '') {
        filledCount++;
      }
    });
    
    if (hasSpecialties) filledCount++;
    
    const totalFields = mandatoryFields.length + 1; // +1 for specialties
    return Math.round((filledCount / totalFields) * 100);
  };

  // Calculate overall completeness
  const overallCompleteness = useMemo(() => {
    if (hospitals.length === 0) return 0;
    const total = hospitals.reduce((sum, hospital) => sum + calculateCompleteness(hospital), 0);
    return Math.round(total / hospitals.length);
  }, [hospitals]);

  const incompleteHospitalsCount = useMemo(() => {
    return hospitals.filter(h => calculateCompleteness(h) < 100).length;
  }, [hospitals]);

  // Apply search and filters
  const filteredHospitals = useMemo(() => {
    return hospitals.filter((hospital) => {
      // Search filter
      const matchesSearch =
        searchTerm === "" ||
        hospital.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        hospital.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
        hospital.state.toLowerCase().includes(searchTerm.toLowerCase()) ||
        hospital.id.toString().includes(searchTerm);

      // Completeness filter
      const matchesCompleteness = 
        !showIncompleteOnly || calculateCompleteness(hospital) < 100;

      // City filter
      const matchesCity =
        filters.cities.length === 0 || filters.cities.includes(hospital.city);

      // State filter
      const matchesState =
        filters.states.length === 0 || filters.states.includes(hospital.state);

      // Pincode filter
      const matchesPincode =
        filters.pincodes.length === 0 || filters.pincodes.includes(hospital.pincode);

      // Tagging status filter
      const matchesTaggingStatus =
        filters.taggingStatuses.length === 0 ||
        filters.taggingStatuses.includes(hospital.taggingStatus);

      // Specialty filter
      const matchesSpecialty =
        filters.specialties.length === 0 ||
        hospital.specialties.some((s) => filters.specialties.includes(s));

      // Other tags filter
      const matchesOtherTags =
        filters.otherTags.length === 0 ||
        hospital.tags.some((t) => filters.otherTags.includes(t));

      return (
        matchesSearch &&
        matchesCompleteness &&
        matchesCity &&
        matchesState &&
        matchesPincode &&
        matchesTaggingStatus &&
        matchesSpecialty &&
        matchesOtherTags
      );
    });
  }, [searchTerm, showIncompleteOnly, filters]);

  return (
    <div className="min-h-screen bg-background">
      <PageHeader
        title="Provider Master"
        description="Manage provider information and metadata"
        icon={Building2}
        actions={
          <Link to="/hospitals/add">
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Add Provider
            </Button>
          </Link>
        }
      />

      <div className="container mx-auto px-6 py-8">
        <div className="mb-6 flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search providers by name, city, or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <HospitalFilters
            filters={filters}
            onApplyFilters={setFilters}
            availableCities={availableCities}
            availableStates={availableStates}
            availablePincodes={availablePincodes}
            availableSpecialties={availableSpecialties}
            availableOtherTags={availableOtherTags}
          />
        </div>

        {/* Overall Completeness Card */}
        <Card 
          className={`mb-6 cursor-pointer transition-all hover:shadow-lg ${
            overallCompleteness >= 90
              ? "bg-green-500/5 border-green-500/20"
              : overallCompleteness >= 70
              ? "bg-yellow-500/5 border-yellow-500/20"
              : "bg-red-500/5 border-red-500/20"
          } ${showIncompleteOnly ? 'ring-2 ring-primary' : ''}`}
          onClick={() => incompleteHospitalsCount > 0 && setShowIncompleteOnly(!showIncompleteOnly)}
        >
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CheckCircle2 className={`h-8 w-8 ${
                  overallCompleteness >= 90
                    ? "text-green-600 dark:text-green-400"
                    : overallCompleteness >= 70
                    ? "text-yellow-600 dark:text-yellow-400"
                    : "text-red-600 dark:text-red-400"
                }`} />
                <div>
                  <h3 className="text-2xl font-bold">{overallCompleteness}%</h3>
                  <p className="text-sm text-muted-foreground">
                    Overall Data Completeness
                    {showIncompleteOnly && <span className="ml-2 text-primary font-medium">(Showing incomplete only)</span>}
                  </p>
                </div>
              </div>
              {incompleteHospitalsCount > 0 && (
                <div className="text-right">
                  <p className="text-lg font-semibold text-muted-foreground">
                    {incompleteHospitalsCount}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {incompleteHospitalsCount === 1 ? "provider needs" : "providers need"} attention
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4">
          {filteredHospitals.length === 0 ? (
            <Card className="shadow-card">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Building2 className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No providers found</h3>
                <p className="text-sm text-muted-foreground">
                  Try adjusting your search or filters
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredHospitals.map((hospital) => (
            <Card key={hospital.id} className="shadow-card hover:shadow-card-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-4 flex-1">
                    <img 
                      src={hospital.image} 
                      alt={hospital.name}
                      className="w-24 h-24 object-cover rounded-lg flex-shrink-0"
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className="text-xl font-semibold">{hospital.name}</h3>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-muted-foreground px-2 py-0.5 bg-muted/50 rounded">
                            {hospital.providerType}
                          </span>
                          <Badge 
                            variant="secondary"
                            className={`gap-1 ${
                              calculateCompleteness(hospital) >= 90
                                ? "bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20"
                                : calculateCompleteness(hospital) >= 70
                                ? "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20"
                                : "bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20"
                            }`}
                          >
                            <CheckCircle2 className="h-3 w-3" />
                            {calculateCompleteness(hospital)}% Complete
                          </Badge>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 mb-3">
                        <span className={`text-sm font-medium ${
                          hospital.taggingStatus === "Network" 
                            ? "text-success"
                            : hospital.taggingStatus === "Non-Network"
                            ? "text-warning"
                            : "text-destructive"
                        }`}>
                          {hospital.taggingStatus}
                        </span>
                        {hospital.tags && hospital.tags.length > 0 && (
                          <>
                            <span className="text-muted-foreground">•</span>
                            <div className="flex items-center gap-2 flex-wrap">
                              {hospital.tags.map((tag) => (
                                <Badge 
                                  key={tag}
                                  variant="secondary"
                                  className={
                                    tag === "Suspicious"
                                      ? "bg-destructive/10 text-destructive border-destructive/20"
                                      : tag === "ACKO Internal" || tag === "IHX"
                                      ? "bg-primary/10 text-primary border-primary/20"
                                      : tag === "Preferred Partner"
                                      ? "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20"
                                      : tag === "Early Discharge"
                                      ? "bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20"
                                      : "bg-muted text-muted-foreground"
                                  }
                                >
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </>
                        )}
                      </div>
                      <div className="grid gap-2 md:grid-cols-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="h-4 w-4" />
                          {hospital.city}, {hospital.state} - {hospital.pincode}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Phone className="h-4 w-4" />
                          {hospital.phone}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Mail className="h-4 w-4" />
                          {hospital.email}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Link to={`/hospitals/${hospital.id}`}>
                      <Button variant="outline" size="sm">
                        View & Edit
                      </Button>
                    </Link>
                    <Link to={`/tariffs/${hospital.id}`}>
                      <Button variant="outline" size="sm">
                        Tariffs
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
