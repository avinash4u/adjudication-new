import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { TopNav } from "@/components/TopNav";
import { ThemeProvider } from "@/components/ThemeProvider";
import Index from "./pages/Index";
import CommonTaskPool from "./pages/CommonTaskPool";
import AgentManagement from "./pages/AgentManagement";
import AgentProfile from "./pages/AgentProfile";
import AgentEditDetails from "./pages/AgentEditDetails";
import AgentPerformance from "./pages/AgentPerformance";
import RosterManagement from "./pages/RosterManagement";
import Performance from "./pages/Performance";
import CaseSearch from "./pages/CaseSearch";
import ClaimDetails from "./pages/ClaimDetails";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <SidebarProvider defaultOpen={true}>
            <div className="flex min-h-screen w-full">
              <AppSidebar />
              <div className="flex-1 flex flex-col">
                <TopNav />
                <Routes>
                  <Route path="/" element={<Index />} />
                  <Route path="/proposals" element={<CommonTaskPool />} />
                  <Route path="/agents" element={<AgentManagement />} />
                  <Route path="/agents/:agentId/profile" element={<AgentProfile />} />
                  <Route path="/agents/:agentId/edit" element={<AgentEditDetails />} />
                  <Route path="/agents/:agentId/performance" element={<AgentPerformance />} />
                  <Route path="/roster" element={<RosterManagement />} />
                  <Route path="/performance" element={<Performance />} />
                  <Route path="/search" element={<CaseSearch />} />
                  <Route path="/claim/:claimId" element={<ClaimDetails />} />
                  {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </div>
            </div>
          </SidebarProvider>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
