import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Info, Zap, CheckCircle, Clock, FileText, User, ArrowUpDown, ArrowUp, ArrowDown, Search, Filter, SlidersHorizontal, ExternalLink, MoreVertical, X, Plus, RefreshCw } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";
import { format } from "date-fns";

interface FilterCondition {
  id: string;
  column: string;
  operator: string;
  value: string;
}

interface Task {
  id: string;
  taskStatus: "Assigned" | "Pending assignment" | "Needs Review";
  priority?: number;
  slaBreachStatus: "On track" | "Near Breach" | "Breached";
  escalation: "Not escalated" | "Escalated";
  admissionType: "Emergency" | "Planned";
  claimType: "Cashless" | "Reimbursement";
  lobType: "Retail" | "GMC";
  claimSubType: "IPD" | "OPD";
  customerCohort: "Privileged" | "General";
  trustScore: "0-40" | "40-70" | ">80";
  cashlessRequestType: "Initial" | "Enhancement" | "Final";
  ageing: number;
  assignedTo?: string;
  skipQueue?: boolean;
  phone?: string;
  email?: string;
  patientUHID?: string;
  patientName?: string;
  customerName?: string;
}

const mockTasks: Task[] = [
  {
    id: "T-001",
    taskStatus: "Pending assignment",
    slaBreachStatus: "On track",
    escalation: "Not escalated",
    admissionType: "Planned",
    claimType: "Cashless",
    lobType: "Retail",
    claimSubType: "IPD",
    customerCohort: "General",
    trustScore: "40-70",
    cashlessRequestType: "Initial",
    ageing: 1,
    phone: "9876543210",
    email: "rajesh.kumar@example.com",
    patientUHID: "UHID001",
    patientName: "Rajesh Kumar",
    customerName: "Rajesh Kumar",
  },
  {
    id: "T-002",
    taskStatus: "Assigned",
    slaBreachStatus: "On track",
    escalation: "Not escalated",
    admissionType: "Planned",
    claimType: "Reimbursement",
    lobType: "GMC",
    claimSubType: "OPD",
    customerCohort: "General",
    trustScore: ">80",
    cashlessRequestType: "Enhancement",
    ageing: 2,
    assignedTo: "David Lee",
    phone: "9123456789",
    email: "priya.sharma@example.com",
    patientUHID: "UHID002",
    patientName: "Priya Sharma",
    customerName: "Priya Sharma",
  },
  {
    id: "T-003",
    taskStatus: "Pending assignment",
    slaBreachStatus: "Near Breach",
    escalation: "Not escalated",
    admissionType: "Emergency",
    claimType: "Cashless",
    lobType: "Retail",
    claimSubType: "IPD",
    customerCohort: "Privileged",
    trustScore: "40-70",
    cashlessRequestType: "Initial",
    ageing: 5,
    phone: "9988776655",
    email: "amit.patel@example.com",
    patientUHID: "UHID003",
    patientName: "Amit Patel",
    customerName: "Amit Patel",
  },
  {
    id: "T001",
    taskStatus: "Pending assignment",
    priority: 1,
    slaBreachStatus: "Near Breach",
    escalation: "Not escalated",
    admissionType: "Emergency",
    claimType: "Cashless",
    lobType: "Retail",
    claimSubType: "IPD",
    customerCohort: "Privileged",
    trustScore: ">80",
    cashlessRequestType: "Initial",
    ageing: 8,
  },
  {
    id: "T002",
    taskStatus: "Assigned",
    priority: 2,
    slaBreachStatus: "On track",
    escalation: "Not escalated",
    admissionType: "Planned",
    claimType: "Reimbursement",
    lobType: "GMC",
    claimSubType: "OPD",
    customerCohort: "General",
    trustScore: "40-70",
    cashlessRequestType: "Enhancement",
    ageing: 3,
    assignedTo: "John Doe",
  },
  {
    id: "T003",
    taskStatus: "Needs Review",
    priority: 3,
    slaBreachStatus: "Breached",
    escalation: "Escalated",
    admissionType: "Emergency",
    claimType: "Cashless",
    lobType: "Retail",
    claimSubType: "IPD",
    customerCohort: "Privileged",
    trustScore: "0-40",
    cashlessRequestType: "Final",
    ageing: 10,
    assignedTo: "Jane Smith",
  },
  {
    id: "T004",
    taskStatus: "Assigned",
    priority: 4,
    slaBreachStatus: "On track",
    escalation: "Not escalated",
    admissionType: "Planned",
    claimType: "Cashless",
    lobType: "GMC",
    claimSubType: "IPD",
    customerCohort: "General",
    trustScore: "40-70",
    cashlessRequestType: "Initial",
    ageing: 2,
    assignedTo: "Mike Johnson",
  },
  {
    id: "T005",
    taskStatus: "Pending assignment",
    priority: 5,
    slaBreachStatus: "Near Breach",
    escalation: "Not escalated",
    admissionType: "Emergency",
    claimType: "Reimbursement",
    lobType: "Retail",
    claimSubType: "OPD",
    customerCohort: "Privileged",
    trustScore: ">80",
    cashlessRequestType: "Enhancement",
    ageing: 7,
  },
  {
    id: "T006",
    taskStatus: "Assigned",
    priority: 6,
    slaBreachStatus: "On track",
    escalation: "Not escalated",
    admissionType: "Planned",
    claimType: "Cashless",
    lobType: "GMC",
    claimSubType: "OPD",
    customerCohort: "General",
    trustScore: "40-70",
    cashlessRequestType: "Initial",
    ageing: 4,
    assignedTo: "Sarah Williams",
  },
  {
    id: "T007",
    taskStatus: "Pending assignment",
    priority: 7,
    slaBreachStatus: "Breached",
    escalation: "Not escalated",
    admissionType: "Emergency",
    claimType: "Reimbursement",
    lobType: "Retail",
    claimSubType: "IPD",
    customerCohort: "Privileged",
    trustScore: ">80",
    cashlessRequestType: "Enhancement",
    ageing: 12,
  },
  {
    id: "T008",
    taskStatus: "Assigned",
    priority: 8,
    slaBreachStatus: "Near Breach",
    escalation: "Not escalated",
    admissionType: "Planned",
    claimType: "Cashless",
    lobType: "GMC",
    claimSubType: "IPD",
    customerCohort: "General",
    trustScore: "0-40",
    cashlessRequestType: "Final",
    ageing: 6,
    assignedTo: "Raj Patel",
  },
  {
    id: "T009",
    taskStatus: "Needs Review",
    priority: 9,
    slaBreachStatus: "On track",
    escalation: "Escalated",
    admissionType: "Emergency",
    claimType: "Reimbursement",
    lobType: "Retail",
    claimSubType: "OPD",
    customerCohort: "Privileged",
    trustScore: "40-70",
    cashlessRequestType: "Initial",
    ageing: 5,
    assignedTo: "Priya Singh",
  },
  {
    id: "T010",
    taskStatus: "Assigned",
    priority: 10,
    slaBreachStatus: "On track",
    escalation: "Not escalated",
    admissionType: "Planned",
    claimType: "Cashless",
    lobType: "GMC",
    claimSubType: "IPD",
    customerCohort: "General",
    trustScore: ">80",
    cashlessRequestType: "Enhancement",
    ageing: 1,
    assignedTo: "Anita Kumar",
  },
  {
    id: "T011",
    taskStatus: "Pending assignment",
    priority: 11,
    slaBreachStatus: "Near Breach",
    escalation: "Not escalated",
    admissionType: "Emergency",
    claimType: "Reimbursement",
    lobType: "Retail",
    claimSubType: "OPD",
    customerCohort: "Privileged",
    trustScore: "40-70",
    cashlessRequestType: "Final",
    ageing: 9,
  },
  {
    id: "T012",
    taskStatus: "Assigned",
    priority: 12,
    slaBreachStatus: "On track",
    escalation: "Not escalated",
    admissionType: "Planned",
    claimType: "Cashless",
    lobType: "GMC",
    claimSubType: "IPD",
    customerCohort: "General",
    trustScore: "0-40",
    cashlessRequestType: "Initial",
    ageing: 3,
    assignedTo: "Vikram Shah",
  },
];

interface CompletedTask {
  id: string;
  completedDate: string;
  completionTime: string;
  slaStatus: "Met" | "Breached";
  admissionType: "Emergency" | "Planned";
  claimType: "Cashless" | "Reimbursement";
  lobType: "Retail" | "GMC";
  claimSubType: "IPD" | "OPD";
  customerCohort: "Privileged" | "General";
  trustScore: "0-40" | "40-70" | ">80";
  cashlessRequestType: "Initial" | "Enhancement" | "Final";
  escalation: "Not escalated" | "Escalated";
  completedBy: string;
  totalTime: string;
  phone?: string;
  email?: string;
  patientUHID?: string;
  patientName?: string;
  customerName?: string;
}

const mockCompletedTasks: CompletedTask[] = [
  {
    id: "T-101",
    completedDate: "2025-10-20",
    completionTime: "14:30",
    slaStatus: "Met",
    admissionType: "Planned",
    claimType: "Cashless",
    lobType: "Retail",
    claimSubType: "IPD",
    customerCohort: "General",
    trustScore: "40-70",
    cashlessRequestType: "Initial",
    escalation: "Not escalated",
    completedBy: "John Doe",
    totalTime: "2h 15m",
  },
  {
    id: "T-102",
    completedDate: "2025-10-20",
    completionTime: "13:45",
    slaStatus: "Met",
    admissionType: "Emergency",
    claimType: "Reimbursement",
    lobType: "GMC",
    claimSubType: "OPD",
    customerCohort: "Privileged",
    trustScore: ">80",
    cashlessRequestType: "Enhancement",
    escalation: "Not escalated",
    completedBy: "Jane Smith",
    totalTime: "1h 30m",
  },
  {
    id: "T-103",
    completedDate: "2025-10-20",
    completionTime: "12:20",
    slaStatus: "Breached",
    admissionType: "Emergency",
    claimType: "Cashless",
    lobType: "Retail",
    claimSubType: "IPD",
    customerCohort: "General",
    trustScore: "0-40",
    cashlessRequestType: "Final",
    escalation: "Escalated",
    completedBy: "Mike Johnson",
    totalTime: "3h 45m",
  },
  {
    id: "T-104",
    completedDate: "2025-10-20",
    completionTime: "11:10",
    slaStatus: "Met",
    admissionType: "Planned",
    claimType: "Reimbursement",
    lobType: "GMC",
    claimSubType: "IPD",
    customerCohort: "Privileged",
    trustScore: "40-70",
    cashlessRequestType: "Initial",
    escalation: "Not escalated",
    completedBy: "Sarah Williams",
    totalTime: "2h 00m",
  },
  {
    id: "T-105",
    completedDate: "2025-10-19",
    completionTime: "16:55",
    slaStatus: "Met",
    admissionType: "Emergency",
    claimType: "Cashless",
    lobType: "Retail",
    claimSubType: "OPD",
    customerCohort: "General",
    trustScore: ">80",
    cashlessRequestType: "Enhancement",
    escalation: "Not escalated",
    completedBy: "Raj Patel",
    totalTime: "1h 20m",
  },
  {
    id: "T-106",
    completedDate: "2025-10-19",
    completionTime: "15:30",
    slaStatus: "Breached",
    admissionType: "Planned",
    claimType: "Reimbursement",
    lobType: "GMC",
    claimSubType: "IPD",
    customerCohort: "Privileged",
    trustScore: "40-70",
    cashlessRequestType: "Initial",
    escalation: "Escalated",
    completedBy: "Priya Singh",
    totalTime: "4h 10m",
  },
  {
    id: "T-107",
    completedDate: "2025-10-19",
    completionTime: "14:15",
    slaStatus: "Met",
    admissionType: "Emergency",
    claimType: "Cashless",
    lobType: "Retail",
    claimSubType: "IPD",
    customerCohort: "General",
    trustScore: "0-40",
    cashlessRequestType: "Final",
    escalation: "Not escalated",
    completedBy: "Anita Kumar",
    totalTime: "2h 30m",
  },
  {
    id: "T-108",
    completedDate: "2025-10-19",
    completionTime: "13:00",
    slaStatus: "Met",
    admissionType: "Planned",
    claimType: "Cashless",
    lobType: "GMC",
    claimSubType: "OPD",
    customerCohort: "Privileged",
    trustScore: ">80",
    cashlessRequestType: "Enhancement",
    escalation: "Not escalated",
    completedBy: "Vikram Shah",
    totalTime: "1h 45m",
  },
];

const CommonTaskPool = () => {
  const [lastRefreshed, setLastRefreshed] = useState(new Date());
  const [key, setKey] = useState(0);
  const [tasks, setTasks] = useState<Task[]>(mockTasks);
  const [completedTasks] = useState<CompletedTask[]>(mockCompletedTasks);
  const [filterConditions, setFilterConditions] = useState<FilterCondition[]>([]);
  const [taskStatusFilter, setTaskStatusFilter] = useState<string>("all");
  const [slaFilter, setSlaFilter] = useState<string>("all");
  const [escalationFilter, setEscalationFilter] = useState<string>("all");
  const [lobFilter, setLobFilter] = useState<string>("all");
  const [claimTypeFilter, setClaimTypeFilter] = useState<string>("all");
  const [claimSubTypeFilter, setClaimSubTypeFilter] = useState<string>("all");
  const [requestTypeFilter, setRequestTypeFilter] = useState<string>("all");
  const [cohortFilter, setCohortFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("default");
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [completedSlaFilter, setCompletedSlaFilter] = useState<string>("all");
  const [completedClaimTypeFilter, setCompletedClaimTypeFilter] = useState<string>("all");
  const [completedLobFilter, setCompletedLobFilter] = useState<string>("all");
  const [completedSubTypeFilter, setCompletedSubTypeFilter] = useState<string>("all");
  const [completedCohortFilter, setCompletedCohortFilter] = useState<string>("all");
  const [completedEscalationFilter, setCompletedEscalationFilter] = useState<string>("all");
  const [completedSortBy, setCompletedSortBy] = useState<string>("date-desc");
  const [completedSearchQuery, setCompletedSearchQuery] = useState<string>("");
  const [selectedTask, setSelectedTask] = useState<Task | CompletedTask | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [globalSearchQuery, setGlobalSearchQuery] = useState<string>("");
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [searchedClaim, setSearchedClaim] = useState<(Task | CompletedTask) | null>(null);
  const [advancedSearch, setAdvancedSearch] = useState({
    phone: "",
    email: "",
    patientUHID: "",
    patientName: "",
    customerName: "",
  });

  const applyFilterCondition = (task: Task, condition: FilterCondition): boolean => {
    const { column, operator, value } = condition;
    if (!value) return true;

    const getTaskValue = (col: string): string => {
      switch (col) {
        case "claimId": return task.id;
        case "priority": return task.priority?.toString() || "";
        case "status": return task.taskStatus;
        case "sla": return task.slaBreachStatus;
        case "ageing": return task.ageing.toString();
        case "lob": return task.lobType;
        case "claimType": return task.claimType;
        case "subType": return task.claimSubType;
        case "requestType": return task.cashlessRequestType;
        case "admission": return task.admissionType;
        case "assignedTo": return task.assignedTo || "";
        case "escalation": return task.escalation;
        case "cohort": return task.customerCohort;
        default: return "";
      }
    };

    const taskValue = getTaskValue(column).toLowerCase();
    const filterValue = value.toLowerCase();

    switch (operator) {
      case "contains": return taskValue.includes(filterValue);
      case "doesNotContain": return !taskValue.includes(filterValue);
      case "equals": return taskValue === filterValue;
      case "doesNotEqual": return taskValue !== filterValue;
      case "startsWith": return taskValue.startsWith(filterValue);
      case "endsWith": return taskValue.endsWith(filterValue);
      case "isEmpty": return taskValue === "";
      case "isNotEmpty": return taskValue !== "";
      default: return true;
    }
  };

  const filteredTasks = useMemo(() => {
    return tasks
      .filter((task) => {
        // Search filter
        if (searchQuery.trim() !== "") {
          const query = searchQuery.toLowerCase();
          const matchesId = task.id.toLowerCase().includes(query);
          const matchesAssignedTo = task.assignedTo?.toLowerCase().includes(query);
          if (!matchesId && !matchesAssignedTo) return false;
        }
        
        // Apply advanced filter conditions
        for (const condition of filterConditions) {
          if (!applyFilterCondition(task, condition)) {
            return false;
          }
        }
        
        // Quick filters
        if (taskStatusFilter !== "all" && task.taskStatus !== taskStatusFilter)
          return false;
        if (slaFilter !== "all" && task.slaBreachStatus !== slaFilter)
          return false;
        if (escalationFilter !== "all" && task.escalation !== escalationFilter)
          return false;
        if (lobFilter !== "all" && task.lobType !== lobFilter) return false;
        if (claimTypeFilter !== "all" && task.claimType !== claimTypeFilter)
          return false;
        if (claimSubTypeFilter !== "all" && task.claimSubType !== claimSubTypeFilter)
          return false;
        if (requestTypeFilter !== "all" && task.cashlessRequestType !== requestTypeFilter)
          return false;
        if (cohortFilter !== "all" && task.customerCohort !== cohortFilter)
          return false;
        return true;
      })
      .sort((a, b) => {
        if (!sortColumn) {
          // Default sorting
          if (a.priority === undefined && b.priority !== undefined) return -1;
          if (a.priority !== undefined && b.priority === undefined) return 1;
          if (a.skipQueue && !b.skipQueue) return -1;
          if (!a.skipQueue && b.skipQueue) return 1;
          if (a.priority !== undefined && b.priority !== undefined) {
            return a.priority - b.priority;
          }
          return 0;
        }

        const direction = sortDirection === 'asc' ? 1 : -1;
        
        switch (sortColumn) {
          case 'id':
            return direction * a.id.localeCompare(b.id);
          case 'priority':
            if (a.priority === undefined && b.priority === undefined) return 0;
            if (a.priority === undefined) return 1;
            if (b.priority === undefined) return -1;
            return direction * (a.priority - b.priority);
          case 'status':
            return direction * a.taskStatus.localeCompare(b.taskStatus);
          case 'sla':
            return direction * a.slaBreachStatus.localeCompare(b.slaBreachStatus);
          case 'ageing':
            return direction * (a.ageing - b.ageing);
          case 'lob':
            return direction * a.lobType.localeCompare(b.lobType);
          case 'claimType':
            return direction * a.claimType.localeCompare(b.claimType);
          case 'subType':
            return direction * a.claimSubType.localeCompare(b.claimSubType);
          case 'requestType':
            return direction * a.cashlessRequestType.localeCompare(b.cashlessRequestType);
          case 'admission':
            return direction * a.admissionType.localeCompare(b.admissionType);
          case 'assignedTo':
            const aAssigned = a.assignedTo || '';
            const bAssigned = b.assignedTo || '';
            return direction * aAssigned.localeCompare(bAssigned);
          case 'escalation':
            return direction * a.escalation.localeCompare(b.escalation);
          case 'cohort':
            return direction * a.customerCohort.localeCompare(b.customerCohort);
          default:
            return 0;
        }
      });
  }, [tasks, filterConditions, taskStatusFilter, slaFilter, escalationFilter, lobFilter, claimTypeFilter, claimSubTypeFilter, requestTypeFilter, cohortFilter, sortBy, searchQuery, sortColumn, sortDirection]);

  const addFilterCondition = () => {
    setFilterConditions([
      ...filterConditions,
      { id: Date.now().toString(), column: "claimId", operator: "contains", value: "" }
    ]);
  };

  const removeFilterCondition = (id: string) => {
    setFilterConditions(filterConditions.filter(c => c.id !== id));
  };

  const updateFilterCondition = (id: string, field: keyof FilterCondition, value: string) => {
    setFilterConditions(filterConditions.map(c => 
      c.id === id ? { ...c, [field]: value } : c
    ));
  };

  const clearFilters = () => {
    setFilterConditions([]);
    setTaskStatusFilter("all");
    setSlaFilter("all");
    setEscalationFilter("all");
    setLobFilter("all");
    setClaimTypeFilter("all");
    setClaimSubTypeFilter("all");
    setRequestTypeFilter("all");
    setCohortFilter("all");
    setSortBy("default");
    setSearchQuery("");
  };

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      if (sortDirection === 'asc') {
        setSortDirection('desc');
      } else {
        setSortColumn(null);
        setSortDirection('asc');
      }
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const getSortIcon = (column: string) => {
    if (sortColumn === column) {
      return sortDirection === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />;
    }
    return <ArrowUpDown className="h-4 w-4 opacity-50" />;
  };

  const getSLABadgeVariant = (status: string) => {
    switch (status) {
      case "On track":
        return "default";
      case "Near Breach":
        return "secondary";
      case "Breached":
        return "destructive";
      default:
        return "outline";
    }
  };

  const getTaskStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "Assigned":
        return "default";
      case "Pending assignment":
        return "secondary";
      case "Needs Review":
        return "outline";
      default:
        return "outline";
    }
  };

  const updateTaskEscalation = (taskId: string, newEscalation: "Not escalated" | "Escalated") => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId ? { ...task, escalation: newEscalation } : task
      )
    );
  };

  const updateTaskCohort = (taskId: string, newCohort: "Privileged" | "General") => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId ? { ...task, customerCohort: newCohort } : task
      )
    );
  };

  const toggleSkipQueue = (taskId: string) => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId ? { ...task, skipQueue: !task.skipQueue } : task
      )
    );
  };

  const filteredCompletedTasks = useMemo(() => {
    return completedTasks
      .filter((task) => {
        // Search filter
        if (completedSearchQuery.trim() !== "") {
          const query = completedSearchQuery.toLowerCase();
          const matchesId = task.id.toLowerCase().includes(query);
          const matchesCompletedBy = task.completedBy?.toLowerCase().includes(query);
          if (!matchesId && !matchesCompletedBy) return false;
        }

        if (completedSlaFilter !== "all" && task.slaStatus !== completedSlaFilter)
          return false;
        if (completedClaimTypeFilter !== "all" && task.claimType !== completedClaimTypeFilter)
          return false;
        if (completedLobFilter !== "all" && task.lobType !== completedLobFilter)
          return false;
        if (completedSubTypeFilter !== "all" && task.claimSubType !== completedSubTypeFilter)
          return false;
        if (completedCohortFilter !== "all" && task.customerCohort !== completedCohortFilter)
          return false;
        if (completedEscalationFilter !== "all" && task.escalation !== completedEscalationFilter)
          return false;
        return true;
      })
      .sort((a, b) => {
        if (completedSortBy === "date-asc") {
          return a.completedDate.localeCompare(b.completedDate);
        } else if (completedSortBy === "date-desc") {
          return b.completedDate.localeCompare(a.completedDate);
        }
        return 0;
      });
  }, [completedTasks, completedSlaFilter, completedClaimTypeFilter, completedLobFilter, completedSubTypeFilter, completedCohortFilter, completedSortBy, completedSearchQuery]);

  const clearCompletedFilters = () => {
    setCompletedSlaFilter("all");
    setCompletedClaimTypeFilter("all");
    setCompletedLobFilter("all");
    setCompletedSubTypeFilter("all");
    setCompletedCohortFilter("all");
    setCompletedEscalationFilter("all");
    setCompletedSortBy("date-desc");
    setCompletedSearchQuery("");
  };

  const handleTaskClick = (task: Task | CompletedTask) => {
    setSelectedTask(task);
    setIsDetailOpen(true);
  };

  const handleGlobalSearch = () => {
    // Check if basic search has value
    if (globalSearchQuery.trim()) {
      const searchTerm = globalSearchQuery.trim().toUpperCase().replace(/^CLM-/i, '');
      
      // Search in active tasks
      const foundTask = tasks.find(task => task.id.toUpperCase() === searchTerm);
      if (foundTask) {
        setSearchedClaim(foundTask);
        return;
      }

      // Search in completed tasks
      const foundCompletedTask = completedTasks.find(task => task.id.toUpperCase() === searchTerm);
      if (foundCompletedTask) {
        setSearchedClaim(foundCompletedTask);
        return;
      }

      setSearchedClaim(null);
      alert(`Claim ID "${globalSearchQuery}" not found in the system.`);
      return;
    }

    // Advanced search
    const hasAdvancedFilters = Object.values(advancedSearch).some(val => val.trim() !== "");
    if (!hasAdvancedFilters) {
      alert("Please enter search criteria");
      return;
    }

    const matchesAdvanced = (task: Task | CompletedTask) => {
      if (advancedSearch.phone && !task.phone?.includes(advancedSearch.phone)) return false;
      if (advancedSearch.email && !task.email?.toLowerCase().includes(advancedSearch.email.toLowerCase())) return false;
      if (advancedSearch.patientUHID && !task.patientUHID?.toLowerCase().includes(advancedSearch.patientUHID.toLowerCase())) return false;
      if (advancedSearch.patientName && !task.patientName?.toLowerCase().includes(advancedSearch.patientName.toLowerCase())) return false;
      if (advancedSearch.customerName && !task.customerName?.toLowerCase().includes(advancedSearch.customerName.toLowerCase())) return false;
      return true;
    };

    // Search in active tasks
    const foundTasks = tasks.filter(matchesAdvanced);
    const foundCompletedTasks = completedTasks.filter(matchesAdvanced);
    
    if (foundTasks.length > 0) {
      setSearchedClaim(foundTasks[0]);
      return;
    }
    
    if (foundCompletedTasks.length > 0) {
      setSearchedClaim(foundCompletedTasks[0]);
      return;
    }

    setSearchedClaim(null);
    alert("No tasks found matching the search criteria.");
  };

  const clearAdvancedSearch = () => {
    setAdvancedSearch({
      phone: "",
      email: "",
      patientUHID: "",
      patientName: "",
      customerName: "",
    });
    setGlobalSearchQuery("");
  };

  const getTaskTimeline = (taskId: string) => {
    // Mock timeline data - in real app this would come from API
    return [
      {
        timestamp: "2025-10-21 09:15:23",
        action: "Task Created",
        user: "System",
        description: "Task automatically generated from claim submission",
      },
      {
        timestamp: "2025-10-21 09:20:45",
        action: "Priority Assigned",
        user: "Allocation Engine",
        description: "Priority score calculated and assigned",
      },
      {
        timestamp: "2025-10-21 09:25:10",
        action: "Task Assigned",
        user: "System",
        description: "Assigned to available agent based on workload",
      },
      {
        timestamp: "2025-10-21 10:15:30",
        action: "Status Updated",
        user: selectedTask && 'assignedTo' in selectedTask ? selectedTask.assignedTo : "Agent",
        description: "Task status changed to In Progress",
      },
      {
        timestamp: "2025-10-21 11:45:00",
        action: "Documents Reviewed",
        user: selectedTask && 'assignedTo' in selectedTask ? selectedTask.assignedTo : "Agent",
        description: "Medical documents and claim details reviewed",
      },
    ];
  };

  const getClaimDetails = (taskId: string) => {
    // Mock claim data - in real app this would come from API
    return {
      claimId: `CLM-${taskId}`,
      customerName: "Rajesh Kumar",
      policyNumber: "POL-2024-12345",
      hospitalName: "Apollo Hospital",
      admissionDate: "2025-10-18",
      dischargeDate: "2025-10-20",
      claimAmount: "₹2,45,000",
      treatmentType: "Cardiac Surgery",
      diagnosisCode: "I25.1",
      roomCategory: "Single AC",
    };
  };

  const handleRefresh = () => {
    setLastRefreshed(new Date());
    setKey(prev => prev + 1);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <h1 className="text-3xl font-bold">Common Task Pool</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            className="h-8"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-muted-foreground">
            View and manage all tasks in the common pool
          </p>
          <p className="text-sm text-muted-foreground">
            Auto-refreshed last at {format(lastRefreshed, "hh:mm:ss a")}
          </p>
        </div>
      </div>

      {/* Global Claim Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="flex gap-3 items-center">
              <div className="relative flex-1 max-w-2xl">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search by Claim ID (e.g., CLM-T001 or T001)..."
                  value={globalSearchQuery}
                  onChange={(e) => setGlobalSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleGlobalSearch();
                    }
                  }}
                  className="pl-10 h-12 text-base"
                  disabled={showAdvancedSearch}
                />
              </div>
              <Button 
                variant="outline"
                size="lg"
                className="h-12"
                onClick={() => {
                  setShowAdvancedSearch(!showAdvancedSearch);
                  if (showAdvancedSearch) {
                    clearAdvancedSearch();
                  }
                }}
              >
                <SlidersHorizontal className="h-5 w-5 mr-2" />
                Advanced Search
              </Button>
              <Button 
                onClick={handleGlobalSearch}
                size="lg"
                className="h-12"
              >
                <Search className="h-5 w-5 mr-2" />
                Search
              </Button>
            </div>

            {showAdvancedSearch && (
              <div className="border rounded-lg p-4 space-y-4 bg-muted/30">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-sm">Advanced Search Filters</h3>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={clearAdvancedSearch}
                  >
                    Clear All
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1.5 block">Phone Number</label>
                    <Input
                      placeholder="Enter phone number"
                      value={advancedSearch.phone}
                      onChange={(e) => setAdvancedSearch({ ...advancedSearch, phone: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1.5 block">Email</label>
                    <Input
                      placeholder="Enter email"
                      value={advancedSearch.email}
                      onChange={(e) => setAdvancedSearch({ ...advancedSearch, email: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1.5 block">Patient UHID</label>
                    <Input
                      placeholder="Enter patient UHID"
                      value={advancedSearch.patientUHID}
                      onChange={(e) => setAdvancedSearch({ ...advancedSearch, patientUHID: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1.5 block">Patient Name</label>
                    <Input
                      placeholder="Enter patient name"
                      value={advancedSearch.patientName}
                      onChange={(e) => setAdvancedSearch({ ...advancedSearch, patientName: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1.5 block">Customer Name</label>
                    <Input
                      placeholder="Enter customer name"
                      value={advancedSearch.customerName}
                      onChange={(e) => setAdvancedSearch({ ...advancedSearch, customerName: e.target.value })}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Search Results Card */}
      {searchedClaim && (
        <Card className="border-primary/50 bg-primary/5">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Claim Found: CLM-{searchedClaim.id}
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSearchedClaim(null)}
              >
                ✕
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Patient Name</p>
                <p className="font-medium">{searchedClaim.patientName || "N/A"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Patient UHID</p>
                <p className="font-medium">{searchedClaim.patientUHID || "N/A"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Phone</p>
                <p className="font-medium">{searchedClaim.phone || "N/A"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="font-medium">{searchedClaim.email || "N/A"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Claim Type</p>
                <Badge>{searchedClaim.claimType}</Badge>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">LOB Type</p>
                <Badge variant="outline">{searchedClaim.lobType}</Badge>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">SLA Status</p>
                <Badge
                  variant={
                    "slaBreachStatus" in searchedClaim
                      ? searchedClaim.slaBreachStatus === "On track"
                        ? "default"
                        : searchedClaim.slaBreachStatus === "Near Breach"
                        ? "secondary"
                        : "destructive"
                      : "slaStatus" in searchedClaim
                      ? searchedClaim.slaStatus === "Met"
                        ? "default"
                        : "destructive"
                      : "secondary"
                  }
                >
                  {"slaBreachStatus" in searchedClaim
                    ? searchedClaim.slaBreachStatus
                    : "slaStatus" in searchedClaim
                    ? searchedClaim.slaStatus
                    : "N/A"}
                </Badge>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Customer Cohort</p>
                <Badge variant="secondary">{searchedClaim.customerCohort}</Badge>
              </div>
            </div>
            <Separator />
            <div className="flex justify-end">
              <Link to={`/claim/${searchedClaim.id}`}>
                <Button>
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View Full Details
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="taskpool" className="w-full">
        <TabsList>
          <TabsTrigger value="taskpool">Task Pool</TabsTrigger>
          <TabsTrigger value="completed">Completed Tasks</TabsTrigger>
        </TabsList>

        <TabsContent value="taskpool">
          <Card>
            <CardHeader>
              <CardTitle>Task Pool ({filteredTasks.length} tasks)</CardTitle>
            </CardHeader>
            <CardContent>
          <div className="space-y-4 mb-6">
            {/* Search, Sort, Filter Toolbar */}
            <div className="flex gap-3 items-center">
              {/* Search */}
                  <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by Claim ID or Agent Name"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>

              {/* Filter Button */}
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="gap-2">
                    <Filter className="h-4 w-4" />
                    Filter
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80" align="end">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-sm">Filters</h4>
                      <Button onClick={clearFilters} variant="ghost" size="sm">
                        Clear All
                      </Button>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Task Status</label>
                        <Select value={taskStatusFilter} onValueChange={setTaskStatusFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Status</SelectItem>
                            <SelectItem value="Assigned">Assigned</SelectItem>
                            <SelectItem value="Pending assignment">Pending assignment</SelectItem>
                            <SelectItem value="Needs Review">Needs Review</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">SLA Breach</label>
                        <Select value={slaFilter} onValueChange={setSlaFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All SLA" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All SLA</SelectItem>
                            <SelectItem value="On track">On track</SelectItem>
                            <SelectItem value="Near Breach">Near Breach</SelectItem>
                            <SelectItem value="Breached">Breached</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Claim Type</label>
                        <Select value={claimTypeFilter} onValueChange={setClaimTypeFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Claims" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Claims</SelectItem>
                            <SelectItem value="Cashless">Cashless</SelectItem>
                            <SelectItem value="Reimbursement">Reimbursement</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Escalation</label>
                        <Select value={escalationFilter} onValueChange={setEscalationFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Escalation" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Escalation</SelectItem>
                            <SelectItem value="Not escalated">Not escalated</SelectItem>
                            <SelectItem value="Escalated">Escalated</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Line of Business</label>
                        <Select value={lobFilter} onValueChange={setLobFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All LoB" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All LoB</SelectItem>
                            <SelectItem value="Retail">Retail</SelectItem>
                            <SelectItem value="GMC">GMC</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Claim Sub Type</label>
                        <Select value={claimSubTypeFilter} onValueChange={setClaimSubTypeFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Sub Types" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Sub Types</SelectItem>
                            <SelectItem value="IPD">IPD</SelectItem>
                            <SelectItem value="OPD">OPD</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Request Type</label>
                        <Select value={requestTypeFilter} onValueChange={setRequestTypeFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Request Types" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Request Types</SelectItem>
                            <SelectItem value="Initial">Initial</SelectItem>
                            <SelectItem value="Enhancement">Enhancement</SelectItem>
                            <SelectItem value="Final">Final</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Customer Cohort</label>
                        <Select value={cohortFilter} onValueChange={setCohortFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Cohorts" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Cohorts</SelectItem>
                            <SelectItem value="Privileged">Privileged</SelectItem>
                            <SelectItem value="General">General</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
            </div>

            {/* Quick Filters */}
            <div className="flex items-center gap-3">
              <span className="text-sm font-medium text-muted-foreground">Quick Filters:</span>
              <div className="flex gap-2">
                <Button
                  variant={taskStatusFilter === "Pending assignment" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    if (taskStatusFilter === "Pending assignment") {
                      setTaskStatusFilter("all");
                    } else {
                      setTaskStatusFilter("Pending assignment");
                    }
                  }}
                >
                  Pending Assignment
                </Button>
                <Button
                  variant={slaFilter === "Near Breach" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    if (slaFilter === "Near Breach") {
                      setSlaFilter("all");
                    } else {
                      setSlaFilter("Near Breach");
                    }
                  }}
                >
                  Near Breach
                </Button>
                <Button
                  variant={escalationFilter === "Escalated" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    if (escalationFilter === "Escalated") {
                      setEscalationFilter("all");
                    } else {
                      setEscalationFilter("Escalated");
                    }
                  }}
                >
                  Escalations
                </Button>
              </div>
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>Claim ID</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('id');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('id');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Input
                                  placeholder="Filter by Claim ID..."
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    const existing = filterConditions.find(c => c.column === 'claimId');
                                    if (existing) {
                                      updateFilterCondition(existing.id, 'value', value);
                                    } else if (value) {
                                      setFilterConditions([...filterConditions, {
                                        id: Date.now().toString(),
                                        column: 'claimId',
                                        operator: 'contains',
                                        value
                                      }]);
                                    }
                                  }}
                                  className="h-8"
                                />
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="flex items-center gap-1">
                              Priority <Info className="h-3 w-3" />
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">Priority order is decided by the final priority score calculated by the allocation engine.</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('priority');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('priority');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Input
                                  placeholder="Filter by Priority..."
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    const existing = filterConditions.find(c => c.column === 'priority');
                                    if (existing) {
                                      updateFilterCondition(existing.id, 'value', value);
                                    } else if (value) {
                                      setFilterConditions([...filterConditions, {
                                        id: Date.now().toString(),
                                        column: 'priority',
                                        operator: 'contains',
                                        value
                                      }]);
                                    }
                                  }}
                                  className="h-8"
                                />
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>Status</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('status');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('status');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Select
                                  value={taskStatusFilter}
                                  onValueChange={setTaskStatusFilter}
                                >
                                  <SelectTrigger className="h-8">
                                    <SelectValue placeholder="All Status" />
                                  </SelectTrigger>
                                  <SelectContent className="bg-background">
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="Pending assignment">Pending assignment</SelectItem>
                                    <SelectItem value="In Progress">In Progress</SelectItem>
                                    <SelectItem value="Query Raised">Query Raised</SelectItem>
                                  </SelectContent>
                                </Select>
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>SLA Breach</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('sla');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('sla');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Select value={slaFilter} onValueChange={setSlaFilter}>
                                  <SelectTrigger className="h-8">
                                    <SelectValue placeholder="All SLA" />
                                  </SelectTrigger>
                                  <SelectContent className="bg-background">
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="Met">Met</SelectItem>
                                    <SelectItem value="Near Breach">Near Breach</SelectItem>
                                    <SelectItem value="Breached">Breached</SelectItem>
                                  </SelectContent>
                                </Select>
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>Ageing</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('ageing');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('ageing');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Input
                                  placeholder="Filter by Ageing..."
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    const existing = filterConditions.find(c => c.column === 'ageing');
                                    if (existing) {
                                      updateFilterCondition(existing.id, 'value', value);
                                    } else if (value) {
                                      setFilterConditions([...filterConditions, {
                                        id: Date.now().toString(),
                                        column: 'ageing',
                                        operator: 'equals',
                                        value
                                      }]);
                                    }
                                  }}
                                  className="h-8"
                                />
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>LoB</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('lob');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('lob');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Select value={lobFilter} onValueChange={setLobFilter}>
                                  <SelectTrigger className="h-8">
                                    <SelectValue placeholder="All LoB" />
                                  </SelectTrigger>
                                  <SelectContent className="bg-background">
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="Retail">Retail</SelectItem>
                                    <SelectItem value="GMC">GMC</SelectItem>
                                    <SelectItem value="GPA">GPA</SelectItem>
                                  </SelectContent>
                                </Select>
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>Claim Type</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('claimType');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('claimType');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Select value={claimTypeFilter} onValueChange={setClaimTypeFilter}>
                                  <SelectTrigger className="h-8">
                                    <SelectValue placeholder="All Types" />
                                  </SelectTrigger>
                                  <SelectContent className="bg-background">
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="Cashless">Cashless</SelectItem>
                                    <SelectItem value="Reimbursement">Reimbursement</SelectItem>
                                  </SelectContent>
                                </Select>
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>Sub Type</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('subType');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('subType');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Select value={claimSubTypeFilter} onValueChange={setClaimSubTypeFilter}>
                                  <SelectTrigger className="h-8">
                                    <SelectValue placeholder="All Sub Types" />
                                  </SelectTrigger>
                                  <SelectContent className="bg-background">
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="IPD">IPD</SelectItem>
                                    <SelectItem value="OPD">OPD</SelectItem>
                                    <SelectItem value="Maternity">Maternity</SelectItem>
                                  </SelectContent>
                                </Select>
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>Request Type</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('requestType');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('requestType');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Select value={requestTypeFilter} onValueChange={setRequestTypeFilter}>
                                  <SelectTrigger className="h-8">
                                    <SelectValue placeholder="All Request Types" />
                                  </SelectTrigger>
                                  <SelectContent className="bg-background">
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="Pre-Authorization">Pre-Authorization</SelectItem>
                                    <SelectItem value="Enhancement">Enhancement</SelectItem>
                                    <SelectItem value="Final Bill">Final Bill</SelectItem>
                                  </SelectContent>
                                </Select>
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>Admission</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('admission');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('admission');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Input
                                  placeholder="Filter by Admission..."
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    const existing = filterConditions.find(c => c.column === 'admission');
                                    if (existing) {
                                      updateFilterCondition(existing.id, 'value', value);
                                    } else if (value) {
                                      setFilterConditions([...filterConditions, {
                                        id: Date.now().toString(),
                                        column: 'admission',
                                        operator: 'contains',
                                        value
                                      }]);
                                    }
                                  }}
                                  className="h-8"
                                />
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>Assigned To</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('assignedTo');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('assignedTo');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Input
                                  placeholder="Filter by name..."
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    const existing = filterConditions.find(c => c.column === 'assignedTo');
                                    if (existing) {
                                      updateFilterCondition(existing.id, 'value', value);
                                    } else if (value) {
                                      setFilterConditions([...filterConditions, {
                                        id: Date.now().toString(),
                                        column: 'assignedTo',
                                        operator: 'contains',
                                        value
                                      }]);
                                    }
                                  }}
                                  className="h-8"
                                />
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>Escalation</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('escalation');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('escalation');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Select value={escalationFilter} onValueChange={setEscalationFilter}>
                                  <SelectTrigger className="h-8">
                                    <SelectValue placeholder="All Escalation" />
                                  </SelectTrigger>
                                  <SelectContent className="bg-background">
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="Not escalated">Not escalated</SelectItem>
                                    <SelectItem value="Escalated">Escalated</SelectItem>
                                  </SelectContent>
                                </Select>
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center justify-between gap-1">
                      <span>Cohort</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-48 bg-background">
                          <div className="p-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('cohort');
                                setSortDirection('asc');
                              }}
                            >
                              <ArrowUp className="h-4 w-4 mr-2" />
                              Sort by ASC
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full justify-start"
                              onClick={() => {
                                setSortColumn('cohort');
                                setSortDirection('desc');
                              }}
                            >
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Sort by DESC
                            </Button>
                            <Separator className="my-1" />
                            <Collapsible>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="sm" className="w-full justify-start">
                                  <Filter className="h-4 w-4 mr-2" />
                                  Filter
                                </Button>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="p-2">
                                <Select value={cohortFilter} onValueChange={setCohortFilter}>
                                  <SelectTrigger className="h-8">
                                    <SelectValue placeholder="All Cohorts" />
                                  </SelectTrigger>
                                  <SelectContent className="bg-background">
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="Privileged">Privileged</SelectItem>
                                    <SelectItem value="General">General</SelectItem>
                                  </SelectContent>
                                </Select>
                              </CollapsibleContent>
                            </Collapsible>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTasks.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={14} className="text-center py-8">
                      No tasks found matching the selected filters
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTasks.map((task) => (
                    <TableRow 
                      key={task.id} 
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => handleTaskClick(task)}
                    >
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          CLM-{task.id}
                          {task.skipQueue && (
                            <Badge variant="destructive" className="text-xs">
                              <Zap className="h-3 w-3 mr-1" />
                              Priority
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{task.priority ?? "-"}</TableCell>
                      <TableCell>
                        <Badge variant={getTaskStatusBadgeVariant(task.taskStatus)}>
                          {task.taskStatus}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getSLABadgeVariant(task.slaBreachStatus)}>
                          {task.slaBreachStatus}
                        </Badge>
                      </TableCell>
                      <TableCell>{task.ageing} days</TableCell>
                      <TableCell>{task.lobType}</TableCell>
                      <TableCell>{task.claimType}</TableCell>
                      <TableCell>{task.claimSubType}</TableCell>
                      <TableCell>{task.claimType === "Reimbursement" ? "-" : task.cashlessRequestType}</TableCell>
                      <TableCell>{task.claimType === "Reimbursement" ? "-" : task.admissionType}</TableCell>
                      <TableCell>{task.assignedTo || "-"}</TableCell>
                      <TableCell>
                        <Select
                          value={task.escalation}
                          onValueChange={(value) => updateTaskEscalation(task.id, value as "Not escalated" | "Escalated")}
                        >
                          <SelectTrigger className="w-[140px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Not escalated">Not escalated</SelectItem>
                            <SelectItem value="Escalated">Escalated</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Select
                          value={task.customerCohort}
                          onValueChange={(value) => updateTaskCohort(task.id, value as "Privileged" | "General")}
                        >
                          <SelectTrigger className="w-[140px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Privileged">Privileged</SelectItem>
                            <SelectItem value="General">General</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant={task.skipQueue ? "destructive" : "outline"}
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleSkipQueue(task.id);
                          }}
                          disabled={task.priority === undefined}
                        >
                          {task.skipQueue ? (
                            <>
                              <Zap className="h-4 w-4 mr-1" />
                              Skip Active
                            </>
                          ) : (
                            "Skip Queue"
                          )}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
        </TabsContent>

        <TabsContent value="completed">
          <Card>
            <CardHeader>
              <CardTitle>Completed Tasks ({filteredCompletedTasks.length} tasks)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 mb-6">
                {/* Search, Sort, Filter Toolbar */}
                <div className="flex gap-3 items-center">
                  {/* Search */}
                  <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search"
                      value={completedSearchQuery}
                      onChange={(e) => setCompletedSearchQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>

                  {/* Sort Button */}
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="gap-2">
                        <SlidersHorizontal className="h-4 w-4" />
                        Sort
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-56" align="end">
                      <div className="space-y-2">
                        <h4 className="font-medium text-sm">Sort By</h4>
                        <Select value={completedSortBy} onValueChange={setCompletedSortBy}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select sort order" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="date-desc">Date (Newest First)</SelectItem>
                            <SelectItem value="date-asc">Date (Oldest First)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </PopoverContent>
                  </Popover>

                  {/* Filter Button */}
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="gap-2">
                        <Filter className="h-4 w-4" />
                        Filter
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-80" align="end">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-sm">Filters</h4>
                          <Button onClick={clearCompletedFilters} variant="ghost" size="sm">
                            Clear All
                          </Button>
                        </div>
                        
                        <div className="space-y-3">
                          <div>
                            <label className="text-xs text-muted-foreground mb-1.5 block">SLA Status</label>
                            <Select value={completedSlaFilter} onValueChange={setCompletedSlaFilter}>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="All SLA" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="all">All SLA</SelectItem>
                                <SelectItem value="Met">Met</SelectItem>
                                <SelectItem value="Breached">Breached</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div>
                            <label className="text-xs text-muted-foreground mb-1.5 block">Claim Type</label>
                            <Select value={completedClaimTypeFilter} onValueChange={setCompletedClaimTypeFilter}>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="All Claims" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="all">All Claims</SelectItem>
                                <SelectItem value="Cashless">Cashless</SelectItem>
                                <SelectItem value="Reimbursement">Reimbursement</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div>
                            <label className="text-xs text-muted-foreground mb-1.5 block">Line of Business</label>
                            <Select value={completedLobFilter} onValueChange={setCompletedLobFilter}>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="All LoB" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="all">All LoB</SelectItem>
                                <SelectItem value="Retail">Retail</SelectItem>
                                <SelectItem value="GMC">GMC</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div>
                            <label className="text-xs text-muted-foreground mb-1.5 block">Claim Sub Type</label>
                            <Select value={completedSubTypeFilter} onValueChange={setCompletedSubTypeFilter}>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="All Sub Types" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="all">All Sub Types</SelectItem>
                                <SelectItem value="IPD">IPD</SelectItem>
                                <SelectItem value="OPD">OPD</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div>
                            <label className="text-xs text-muted-foreground mb-1.5 block">Customer Cohort</label>
                            <Select value={completedCohortFilter} onValueChange={setCompletedCohortFilter}>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="All Cohorts" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="all">All Cohorts</SelectItem>
                                <SelectItem value="Privileged">Privileged</SelectItem>
                                <SelectItem value="General">General</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div>
                            <label className="text-xs text-muted-foreground mb-1.5 block">Escalation</label>
                            <Select value={completedEscalationFilter} onValueChange={setCompletedEscalationFilter}>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="All Escalation" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="all">All Escalation</SelectItem>
                                <SelectItem value="Not escalated">Not escalated</SelectItem>
                                <SelectItem value="Escalated">Escalated</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>
                    </PopoverContent>
                  </Popover>
                </div>

                {/* Quick Filters */}
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium text-muted-foreground">Quick Filters:</span>
                  <div className="flex gap-2">
                    <Button
                      variant={completedSlaFilter === "Breached" ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        if (completedSlaFilter === "Breached") {
                          setCompletedSlaFilter("all");
                        } else {
                          setCompletedSlaFilter("Breached");
                        }
                      }}
                    >
                      SLA Breached
                    </Button>
                    <Button
                      variant={completedEscalationFilter === "Escalated" ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        if (completedEscalationFilter === "Escalated") {
                          setCompletedEscalationFilter("all");
                        } else {
                          setCompletedEscalationFilter("Escalated");
                        }
                      }}
                    >
                      Escalations
                    </Button>
                  </div>
                </div>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Claim ID</TableHead>
                      <TableHead>Completed Date</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>SLA Status</TableHead>
                      <TableHead>Admission</TableHead>
                      <TableHead>Claim Type</TableHead>
                      <TableHead>LoB</TableHead>
                      <TableHead>Sub Type</TableHead>
                      <TableHead>Cohort</TableHead>
                      <TableHead>Trust Score</TableHead>
                      <TableHead>Request Type</TableHead>
                      <TableHead>Escalation</TableHead>
                      <TableHead>Completed By</TableHead>
                      <TableHead>Total Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCompletedTasks.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={13} className="text-center py-8">
                          No completed tasks found matching the selected filters
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredCompletedTasks.map((task) => (
                        <TableRow 
                          key={task.id}
                          className="cursor-pointer hover:bg-muted/50"
                          onClick={() => handleTaskClick(task)}
                        >
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              <CheckCircle className="h-4 w-4 text-green-600" />
                              CLM-{task.id}
                            </div>
                          </TableCell>
                          <TableCell>{task.completedDate}</TableCell>
                          <TableCell>{task.completionTime}</TableCell>
                          <TableCell>
                            <Badge variant={task.slaStatus === "Met" ? "default" : "destructive"}>
                              {task.slaStatus}
                            </Badge>
                          </TableCell>
                          <TableCell>{task.claimType === "Reimbursement" ? "-" : task.admissionType}</TableCell>
                          <TableCell>{task.claimType}</TableCell>
                          <TableCell>{task.lobType}</TableCell>
                          <TableCell>{task.claimSubType}</TableCell>
                          <TableCell>{task.customerCohort}</TableCell>
                          <TableCell>{task.trustScore}</TableCell>
                          <TableCell>{task.claimType === "Reimbursement" ? "-" : task.cashlessRequestType}</TableCell>
                          <TableCell>
                            <Badge variant={task.escalation === "Escalated" ? "destructive" : "secondary"}>
                              {task.escalation}
                            </Badge>
                          </TableCell>
                          <TableCell>{task.completedBy}</TableCell>
                          <TableCell>{task.totalTime}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Sheet open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <SheetContent className="w-[600px] sm:max-w-[600px] overflow-y-auto">
          {selectedTask && (
            <>
              <SheetHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <SheetTitle className="flex items-center gap-2">
                      <FileText className="h-5 w-5" />
                      Task Details: CLM-{selectedTask.id}
                    </SheetTitle>
                    <SheetDescription>
                      View comprehensive task and claim information
                    </SheetDescription>
                  </div>
                  <Link to={`/case-search?claimId=CLM-${selectedTask.id}`}>
                    <Button variant="outline" size="sm" className="gap-2">
                      View more details
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </SheetHeader>

              <div className="mt-6 space-y-6">
                {/* Task Details Section */}
                <div>
                  <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                    <Info className="h-4 w-4" />
                    Task Information
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Claim ID</p>
                      <p className="font-medium">CLM-{selectedTask.id}</p>
                    </div>
                    {'taskStatus' in selectedTask && (
                      <div>
                        <p className="text-sm text-muted-foreground">Status</p>
                        <Badge variant={getTaskStatusBadgeVariant(selectedTask.taskStatus)}>
                          {selectedTask.taskStatus}
                        </Badge>
                      </div>
                    )}
                    {'slaStatus' in selectedTask && (
                      <div>
                        <p className="text-sm text-muted-foreground">SLA Status</p>
                        <Badge variant={selectedTask.slaStatus === "Met" ? "default" : "destructive"}>
                          {selectedTask.slaStatus}
                        </Badge>
                      </div>
                    )}
                    {'slaBreachStatus' in selectedTask && (
                      <div>
                        <p className="text-sm text-muted-foreground">SLA Status</p>
                        <Badge variant={getSLABadgeVariant(selectedTask.slaBreachStatus)}>
                          {selectedTask.slaBreachStatus}
                        </Badge>
                      </div>
                    )}
                    <div>
                      <p className="text-sm text-muted-foreground">Admission Type</p>
                      <p className="font-medium">{selectedTask.admissionType}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Claim Type</p>
                      <p className="font-medium">{selectedTask.claimType}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">LoB Type</p>
                      <p className="font-medium">{selectedTask.lobType}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Claim Sub Type</p>
                      <p className="font-medium">{selectedTask.claimSubType}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Customer Cohort</p>
                      <p className="font-medium">{selectedTask.customerCohort}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Trust Score</p>
                      <p className="font-medium">{selectedTask.trustScore}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Request Type</p>
                      <p className="font-medium">{selectedTask.cashlessRequestType}</p>
                    </div>
                    {'assignedTo' in selectedTask && selectedTask.assignedTo && (
                      <div>
                        <p className="text-sm text-muted-foreground">Assigned To</p>
                        <p className="font-medium">{selectedTask.assignedTo}</p>
                      </div>
                    )}
                    {'completedBy' in selectedTask && (
                      <div>
                        <p className="text-sm text-muted-foreground">Completed By</p>
                        <p className="font-medium">{selectedTask.completedBy}</p>
                      </div>
                    )}
                    {'ageing' in selectedTask && (
                      <div>
                        <p className="text-sm text-muted-foreground">Ageing</p>
                        <p className="font-medium">{selectedTask.ageing} days</p>
                      </div>
                    )}
                    {'totalTime' in selectedTask && (
                      <div>
                        <p className="text-sm text-muted-foreground">Total Time</p>
                        <p className="font-medium">{selectedTask.totalTime}</p>
                      </div>
                    )}
                  </div>
                </div>

                <Separator />

                {/* Claim Details Section */}
                <div>
                  <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Claim Details
                  </h3>
                  {(() => {
                    const claimDetails = getClaimDetails(selectedTask.id);
                    return (
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Claim ID</p>
                          <p className="font-medium">{claimDetails.claimId}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Customer Name</p>
                          <p className="font-medium">{claimDetails.customerName}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Policy Number</p>
                          <p className="font-medium">{claimDetails.policyNumber}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Hospital Name</p>
                          <p className="font-medium">{claimDetails.hospitalName}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Admission Date</p>
                          <p className="font-medium">{claimDetails.admissionDate}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Discharge Date</p>
                          <p className="font-medium">{claimDetails.dischargeDate}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Claim Amount</p>
                          <p className="font-medium text-lg">{claimDetails.claimAmount}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Treatment Type</p>
                          <p className="font-medium">{claimDetails.treatmentType}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Diagnosis Code</p>
                          <p className="font-medium">{claimDetails.diagnosisCode}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Room Category</p>
                          <p className="font-medium">{claimDetails.roomCategory}</p>
                        </div>
                      </div>
                    );
                  })()}
                </div>

                <Separator />

                {/* Timeline Section */}
                <div>
                  <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Activity Timeline
                  </h3>
                  <div className="space-y-4">
                    {getTaskTimeline(selectedTask.id).map((event, index) => (
                      <div key={index} className="flex gap-3 relative">
                        {index !== getTaskTimeline(selectedTask.id).length - 1 && (
                          <div className="absolute left-[11px] top-8 bottom-0 w-[2px] bg-border" />
                        )}
                        <div className="mt-1 flex-shrink-0">
                          <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center">
                            <div className="h-2 w-2 rounded-full bg-primary" />
                          </div>
                        </div>
                        <div className="flex-1 pb-4">
                          <div className="flex items-center justify-between mb-1">
                            <p className="font-medium text-sm">{event.action}</p>
                            <p className="text-xs text-muted-foreground">{event.timestamp}</p>
                          </div>
                          <p className="text-sm text-muted-foreground mb-1">{event.description}</p>
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <User className="h-3 w-3" />
                            {event.user}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
};

export default CommonTaskPool;
