import { useState, useMemo } from "react";
import { ClipboardList, CheckCircle, Clock, TrendingUp, CalendarIcon, ArrowUp, ArrowDown, Target, AlertCircle, Activity, Timer, Coffee, Info, X, RefreshCw, UserCheck } from "lucide-react";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, ResponsiveContainer } from "recharts";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";
import { OverviewMetrics } from "@/components/OverviewMetrics";
import { AgentLiveStatus } from "@/components/AgentLiveStatus";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const Performance = () => {
  const [timeFilter, setTimeFilter] = useState("today");
  const [fromDate, setFromDate] = useState<Date>();
  const [toDate, setToDate] = useState<Date>();
  const [selectedShifts, setSelectedShifts] = useState<string[]>(["all"]);
  const [shiftPopoverOpen, setShiftPopoverOpen] = useState(false);
  const [taskDetailsOpen, setTaskDetailsOpen] = useState(false);
  const [selectedAgentTasks, setSelectedAgentTasks] = useState<any>(null);
  const [selectedAgent, setSelectedAgent] = useState<string>("all");
  const [skillsDialogOpen, setSkillsDialogOpen] = useState(false);
  const [trendDialogOpen, setTrendDialogOpen] = useState(false);
  const [trendDialogData, setTrendDialogData] = useState<{ title: string; data: any[] }>({ title: "", data: [] });
  
  // Filter states
  const [selectedLoB, setSelectedLoB] = useState<string>("all");
  const [selectedClaimType, setSelectedClaimType] = useState<string>("all");
  const [selectedClaimSubType, setSelectedClaimSubType] = useState<string>("all");
  const [selectedPreauthType, setSelectedPreauthType] = useState<string>("all");

  const shifts = [
    { id: "morning", label: "Morning (6 AM - 2 PM)" },
    { id: "afternoon", label: "Afternoon (2 PM - 10 PM)" },
    { id: "night", label: "Night (10 PM - 6 AM)" },
  ];

  const handleShiftToggle = (shiftId: string) => {
    if (shiftId === "all") {
      setSelectedShifts(["all"]);
    } else {
      setSelectedShifts((prev) => {
        const newShifts = prev.filter((id) => id !== "all");
        if (newShifts.includes(shiftId)) {
          const filtered = newShifts.filter((id) => id !== shiftId);
          return filtered.length === 0 ? ["all"] : filtered;
        } else {
          return [...newShifts, shiftId];
        }
      });
    }
  };

  const getShiftLabel = () => {
    if (selectedShifts.includes("all")) return "All Shifts";
    if (selectedShifts.length === 1) {
      const shift = shifts.find((s) => s.id === selectedShifts[0]);
      return shift?.label || "Select Shifts";
    }
    return `${selectedShifts.length} Shifts Selected`;
  };

  // Dynamic data based on time filter
  const getMetricsData = () => {
    switch (timeFilter) {
      case "today":
        return {
          totalClaimsReceived: "145",
          claimsCompleted: "92",
          claimsPending: "53",
          slaBreach: "4%",
          avgProcessingTime: "35",
          reworkRate: "4.2%",
          deficiencyRate: "3.8%",
          reassignmentCount: "12",
          stickinessCompliance: "92%",
          trends: {
            totalClaimsReceived: "+8%",
            claimsCompleted: "+12%",
            slaBreach: "-25%",
            avgProcessingTime: "-8%",
            reworkRate: "-15%",
            deficiencyRate: "-10%",
            reassignmentCount: "-5%",
            stickinessCompliance: "+4%",
          }
        };
      case "week":
        return {
          totalClaimsReceived: "980",
          claimsCompleted: "655",
          claimsPending: "325",
          slaBreach: "6%",
          avgProcessingTime: "38",
          reworkRate: "5.1%",
          deficiencyRate: "4.5%",
          reassignmentCount: "78",
          stickinessCompliance: "89%",
          trends: {
            totalClaimsReceived: "+5%",
            claimsCompleted: "+8%",
            slaBreach: "-20%",
            avgProcessingTime: "-5%",
            reworkRate: "-12%",
            deficiencyRate: "-8%",
            reassignmentCount: "-8%",
            stickinessCompliance: "+3%",
          }
        };
      case "month":
        return {
          totalClaimsReceived: "4,250",
          claimsCompleted: "2,890",
          claimsPending: "1,360",
          slaBreach: "3%",
          avgProcessingTime: "32",
          reworkRate: "3.5%",
          deficiencyRate: "3.2%",
          reassignmentCount: "285",
          stickinessCompliance: "94%",
          trends: {
            totalClaimsReceived: "+12%",
            claimsCompleted: "+15%",
            slaBreach: "-30%",
            avgProcessingTime: "-10%",
            reworkRate: "-18%",
            deficiencyRate: "-15%",
            reassignmentCount: "-12%",
            stickinessCompliance: "+6%",
          }
        };
      case "custom":
        return {
          totalClaimsReceived: "620",
          claimsCompleted: "415",
          claimsPending: "205",
          slaBreach: "7%",
          avgProcessingTime: "40",
          reworkRate: "5.8%",
          deficiencyRate: "5.2%",
          reassignmentCount: "48",
          stickinessCompliance: "88%",
          trends: {
            totalClaimsReceived: "+4%",
            claimsCompleted: "+6%",
            slaBreach: "-15%",
            avgProcessingTime: "-3%",
            reworkRate: "-8%",
            deficiencyRate: "-6%",
            reassignmentCount: "-4%",
            stickinessCompliance: "+2%",
          }
        };
      default:
        return {
          totalClaimsReceived: "145",
          claimsCompleted: "92",
          claimsPending: "53",
          slaBreach: "4%",
          avgProcessingTime: "35",
          reworkRate: "4.2%",
          deficiencyRate: "3.8%",
          reassignmentCount: "12",
          stickinessCompliance: "92%",
          trends: {
            totalClaimsReceived: "+8%",
            claimsCompleted: "+12%",
            slaBreach: "-25%",
            avgProcessingTime: "-8%",
            reworkRate: "-15%",
            deficiencyRate: "-10%",
            reassignmentCount: "-5%",
            stickinessCompliance: "+4%",
          }
        };
    }
  };

  const metricsData = useMemo(() => getMetricsData(), [timeFilter, fromDate, toDate]);

  // Get comparison period text based on time filter
  const getComparisonPeriodText = () => {
    switch (timeFilter) {
      case "today":
        return "from yesterday";
      case "week":
        return "from last week";
      case "month":
        return "from last month";
      case "custom":
        if (fromDate && toDate) {
          const daysDiff = Math.ceil((toDate.getTime() - fromDate.getTime()) / (1000 * 60 * 60 * 24));
          return daysDiff <= 7 ? "from previous week" : "from previous month";
        }
        return "from previous period";
      default:
        return "from yesterday";
    }
  };

  const comparisonText = getComparisonPeriodText();

  // Get trend color based on metric type and value
  const getTrendColor = (metricType: string, trendValue: string, isPositive: boolean) => {
    const percentageMatch = trendValue.match(/(\d+\.?\d*)/);
    const percentage = percentageMatch ? parseFloat(percentageMatch[1]) : 0;
    
    // Stickiness Compliance should always be green when increasing
    if (metricType === 'stickinessCompliance' && isPositive) {
      return { text: 'text-green-600 dark:text-green-400', icon: 'text-green-600 dark:text-green-400' };
    }
    
    // Define which metrics are better when higher
    const higherIsBetter = ['totalClaimsReceived', 'claimsCompleted', 'stickinessCompliance'];
    const lowerIsBetter = ['avgProcessingTime', 'reworkRate', 'deficiencyRate', 'reassignmentCount', 'slaBreach'];
    
    let isGoodTrend = false;
    let isBadTrend = false;
    
    if (higherIsBetter.includes(metricType)) {
      isGoodTrend = isPositive && percentage >= 5;
      isBadTrend = !isPositive && percentage >= 5;
    } else if (lowerIsBetter.includes(metricType)) {
      isGoodTrend = !isPositive && percentage >= 5;
      isBadTrend = isPositive && percentage >= 5;
    }
    
    if (isGoodTrend) {
      return { text: 'text-green-600 dark:text-green-400', icon: 'text-green-600 dark:text-green-400' };
    } else if (isBadTrend) {
      return { text: 'text-red-600 dark:text-red-400', icon: 'text-red-600 dark:text-red-400' };
    } else {
      return { text: 'text-orange-500 dark:text-orange-400', icon: 'text-orange-500 dark:text-orange-400' };
    }
  };

  // Generate trend data for line charts
  const generateTrendData = (metricType: string, currentValue: number) => {
    const points = 7;
    const data = [];
    let value = currentValue * 0.75; // Start at 75% of current value
    
    for (let i = 0; i < points; i++) {
      const variation = Math.random() * 0.15 + 0.05; // 5-15% increase per point
      value = value * (1 + variation);
      data.push({ 
        period: i === points - 1 ? 'Now' : `Day ${i + 1}`, 
        value: Math.round(value * 100) / 100 
      });
    }
    
    return data;
  };

  const handleViewTrend = (metricName: string, metricType: string, currentValue: string) => {
    const numericValue = parseFloat(currentValue.replace(/[^0-9.]/g, ''));
    const trendData = generateTrendData(metricType, numericValue);
    setTrendDialogData({ title: metricName, data: trendData });
    setTrendDialogOpen(true);
  };

  // Dynamic agent data based on filters
  const getAgentData = () => {
    const baseAgents = [
      { id: 2, name: "Priya Sharma", shift: "morning" },
      { id: 4, name: "Rajesh Patel", shift: "afternoon" },
      { id: 5, name: "Deepika Mehta", shift: "morning" },
      { id: 6, name: "Arjun Singh", shift: "night" },
      { id: 7, name: "Sneha Agarwal", shift: "afternoon" },
    ];

    // Filter agents by selected shifts
    let filteredAgents = baseAgents;
    if (!selectedShifts.includes("all")) {
      filteredAgents = baseAgents.filter(agent => selectedShifts.includes(agent.shift));
    }

    // Adjust metrics based on time filter
    const multiplier = timeFilter === "today" ? 1 : timeFilter === "week" ? 7 : timeFilter === "month" ? 30 : 10;
    
    return filteredAgents.map(agent => ({
      ...agent,
      tasksCompleted: Math.floor((35 + agent.id * 5) * multiplier),
      avgTime: `${Math.floor(4 + agent.id * 0.3)}:${Math.floor(20 + agent.id * 10) % 60}`,
    }));
  };

  const agentData = useMemo(() => getAgentData(), [timeFilter, selectedShifts]);

  // Calculate metrics for selected agent
  const getAgentMetrics = () => {
    if (selectedAgent === "all") {
      // Aggregate metrics for all agents
      const totalTasks = agentData.reduce((sum, agent) => sum + agent.tasksCompleted, 0);
      const avgCompletionTime = agentData.length > 0 
        ? Math.floor(agentData.reduce((sum, agent) => sum + parseFloat(agent.avgTime.split(':')[0]) * 60 + parseFloat(agent.avgTime.split(':')[1]), 0) / agentData.length)
        : 0;
      
      const totalAvailableHours = agentData.reduce((sum, agent) => sum + (7 + (agent.id % 3) * 0.5), 0);
      const totalUnavailableHours = agentData.reduce((sum, agent) => sum + (1 + (agent.id % 4) * 0.3), 0);
      
      return {
        tasksCompleted: totalTasks,
        avgCompletionTime: `${Math.floor(avgCompletionTime / 60)}:${(avgCompletionTime % 60).toString().padStart(2, '0')}`,
        reworkRate: "4.2%",
        utilizationRate: "87%",
        availableHours: totalAvailableHours.toFixed(1),
        unavailableHours: totalUnavailableHours.toFixed(1)
      };
    } else {
      // Metrics for specific agent
      const agent = agentData.find(a => a.id.toString() === selectedAgent);
      if (!agent) {
        return {
          tasksCompleted: 0,
          avgCompletionTime: "0:00",
          reworkRate: "0%",
          utilizationRate: "0%",
          availableHours: "0",
          unavailableHours: "0"
        };
      }
      
      const availableHours = 7 + (agent.id % 3) * 0.5;
      const unavailableHours = 1 + (agent.id % 4) * 0.3;
      
      return {
        tasksCompleted: agent.tasksCompleted,
        avgCompletionTime: agent.avgTime,
        reworkRate: `${(3 + Math.random() * 3).toFixed(1)}%`,
        utilizationRate: `${(82 + Math.floor(Math.random() * 15))}%`,
        availableHours: availableHours.toFixed(1),
        unavailableHours: unavailableHours.toFixed(1)
      };
    }
  };

  // Calculate team averages and bests for benchmarking
  const getTeamBenchmarks = () => {
    if (agentData.length === 0) return null;
    
    const totalTasks = agentData.reduce((sum, agent) => sum + agent.tasksCompleted, 0);
    const avgTasks = Math.floor(totalTasks / agentData.length);
    const maxTasks = Math.max(...agentData.map(a => a.tasksCompleted));
    
    const avgTimeInMinutes = agentData.reduce((sum, agent) => {
      const [mins, secs] = agent.avgTime.split(':').map(Number);
      return sum + (mins * 60 + secs);
    }, 0) / agentData.length;
    
    const minTimeInMinutes = Math.min(...agentData.map(agent => {
      const [mins, secs] = agent.avgTime.split(':').map(Number);
      return mins * 60 + secs;
    }));
    
    // Calculate available and unavailable hours
    const availableHoursList = agentData.map(agent => 7 + (agent.id % 3) * 0.5);
    const unavailableHoursList = agentData.map(agent => 1 + (agent.id % 4) * 0.3);
    
    const avgAvailableHours = availableHoursList.reduce((sum, h) => sum + h, 0) / agentData.length;
    const maxAvailableHours = Math.max(...availableHoursList);
    const avgUnavailableHours = unavailableHoursList.reduce((sum, h) => sum + h, 0) / agentData.length;
    const minUnavailableHours = Math.min(...unavailableHoursList);
    
    return {
      avgTasks,
      maxTasks,
      avgCompletionTime: `${Math.floor(avgTimeInMinutes / 60)}:${Math.floor(avgTimeInMinutes % 60).toString().padStart(2, '0')}`,
      bestCompletionTime: `${Math.floor(minTimeInMinutes / 60)}:${Math.floor(minTimeInMinutes % 60).toString().padStart(2, '0')}`,
      avgReworkRate: "4.5%",
      bestReworkRate: "2.8%",
      avgUtilizationRate: "87%",
      bestUtilizationRate: "95%",
      avgAvailableHours: avgAvailableHours.toFixed(1),
      bestAvailableHours: maxAvailableHours.toFixed(1),
      avgUnavailableHours: avgUnavailableHours.toFixed(1),
      bestUnavailableHours: minUnavailableHours.toFixed(1)
    };
  };

  const agentMetrics = useMemo(() => getAgentMetrics(), [selectedAgent, agentData]);
  const teamBenchmarks = useMemo(() => getTeamBenchmarks(), [agentData]);

  // Calculate performance score and rank agents
  const getRankedAgents = () => {
    return agentData.map(agent => {
      const avgTimeMinutes = parseFloat(agent.avgTime.split(':')[0]) * 60 + parseFloat(agent.avgTime.split(':')[1]);
      const reworkRate = 3 + Math.random() * 3;
      const utilizationRate = 82 + Math.floor(Math.random() * 15);
      
      // Performance score: higher is better
      // Tasks completed (40%), Speed (30%), Low rework (20%), Utilization (10%)
      const tasksScore = agent.tasksCompleted / 100; // Normalize
      const speedScore = Math.max(0, 100 - avgTimeMinutes) / 10; // Lower time is better
      const reworkScore = Math.max(0, 10 - reworkRate) * 2; // Lower rework is better
      const utilizationScore = utilizationRate / 10;
      
      const performanceScore = (tasksScore * 0.4) + (speedScore * 0.3) + (reworkScore * 0.2) + (utilizationScore * 0.1);
      
      return {
        ...agent,
        reworkRate: `${reworkRate.toFixed(1)}%`,
        utilizationRate: `${utilizationRate}%`,
        performanceScore: parseFloat(performanceScore.toFixed(2))
      };
    }).sort((a, b) => b.performanceScore - a.performanceScore);
  };

  const rankedAgents = useMemo(() => getRankedAgents(), [agentData]);

  // Generate tasks for an agent
  const generateAgentTasks = (agent: any) => {
    const lobs = ["Retail", "GMC"];
    const claimTypes = ["Cashless", "Reimbursement"];
    const subTypes = ["IPD", "OPD"];
    const requestTypes = ["Preauth Initial", "Preauth Enhancement", "Preauth Final"];
    
    const tasks = [];
    for (let i = 0; i < agent.tasksCompleted; i++) {
      const claimType = claimTypes[Math.floor(Math.random() * claimTypes.length)];
      tasks.push({
        id: `TSK-${agent.id}${String(i + 1).padStart(3, '0')}`,
        lob: lobs[Math.floor(Math.random() * lobs.length)],
        claimType: claimType,
        subType: subTypes[Math.floor(Math.random() * subTypes.length)],
        requestType: claimType === "Cashless" 
          ? requestTypes[Math.floor(Math.random() * requestTypes.length)]
          : "-",
        completedAt: new Date(Date.now() - Math.random() * 86400000 * (timeFilter === "today" ? 1 : timeFilter === "week" ? 7 : 30)).toLocaleString(),
        timeTaken: `${Math.floor(Math.random() * 3 + 2)}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`,
      });
    }
    return tasks;
  };

  const handleViewDetails = (agent: any) => {
    const tasks = generateAgentTasks(agent);
    setSelectedAgentTasks({ agent, tasks });
    setTaskDetailsOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="px-6 py-4 space-y-4">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold">Performance Analytics</h1>
            <div className="flex items-center gap-3">
              {/* Shift Selector */}
              <Popover open={shiftPopoverOpen} onOpenChange={setShiftPopoverOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-[220px] justify-between"
                  >
                    {getShiftLabel()}
                    <CalendarIcon className="ml-2 h-4 w-4 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[280px] p-4 bg-background z-50" align="end">
                  <div className="space-y-3">
                    <h4 className="font-medium text-sm">Select Shifts</h4>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="shift-all"
                          checked={selectedShifts.includes("all")}
                          onCheckedChange={() => handleShiftToggle("all")}
                        />
                        <label
                          htmlFor="shift-all"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                        >
                          All Shifts
                        </label>
                      </div>
                      {shifts.map((shift) => (
                        <div key={shift.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={`shift-${shift.id}`}
                            checked={selectedShifts.includes(shift.id)}
                            onCheckedChange={() => handleShiftToggle(shift.id)}
                          />
                          <label
                            htmlFor={`shift-${shift.id}`}
                            className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                          >
                            {shift.label}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                </PopoverContent>
              </Popover>

              {/* Time Filter */}
              <Select value={timeFilter} onValueChange={setTimeFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background z-50">
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {timeFilter === "custom" && (
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">From:</span>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-[200px] justify-start text-left font-normal",
                        !fromDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {fromDate ? format(fromDate, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={fromDate}
                      onSelect={setFromDate}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">To:</span>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-[200px] justify-start text-left font-normal",
                        !toDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {toDate ? format(toDate, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={toDate}
                      onSelect={setToDate}
                      disabled={(date) => fromDate ? date < fromDate : false}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          )}
        </div>
      </header>

      <main className="p-6 space-y-6">
        {/* Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview" className="px-6 py-2">Claim Performance</TabsTrigger>
            <TabsTrigger value="agent" className="px-6 py-2">Agent Performance</TabsTrigger>
            <TabsTrigger value="team" className="px-6 py-2">Team Level Summary</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Performance Dashboard Metrics */}
            <div className="space-y-6">
              <div className="flex flex-col gap-4">
                <div className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-primary" />
                  <h3 className="text-xl font-semibold">Claims Performance Metrics</h3>
                </div>
                
                {/* Filters */}
                <div className="flex flex-wrap items-center gap-3">
                  <Select value={selectedLoB} onValueChange={setSelectedLoB}>
                    <SelectTrigger className="w-[160px] bg-background">
                      <SelectValue placeholder="LoB" />
                    </SelectTrigger>
                    <SelectContent className="bg-background z-50">
                      <SelectItem value="all">All LoB</SelectItem>
                      <SelectItem value="Retail">Retail</SelectItem>
                      <SelectItem value="GMC">GMC</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select 
                    value={selectedClaimType} 
                    onValueChange={(value) => {
                      setSelectedClaimType(value);
                      // Reset preauth type when claim type changes
                      if (value !== "Cashless") {
                        setSelectedPreauthType("all");
                      }
                    }}
                  >
                    <SelectTrigger className="w-[180px] bg-background">
                      <SelectValue placeholder="Claim Type" />
                    </SelectTrigger>
                    <SelectContent className="bg-background z-50">
                      <SelectItem value="all">All Claim Types</SelectItem>
                      <SelectItem value="Cashless">Cashless</SelectItem>
                      <SelectItem value="Reimbursement">Reimbursement</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select 
                    value={selectedClaimSubType} 
                    onValueChange={(value) => {
                      setSelectedClaimSubType(value);
                      // Reset preauth type when OPD is selected
                      if (value === "OPD") {
                        setSelectedPreauthType("all");
                      }
                    }}
                  >
                    <SelectTrigger className="w-[180px] bg-background">
                      <SelectValue placeholder="Claim Sub Type" />
                    </SelectTrigger>
                    <SelectContent className="bg-background z-50">
                      <SelectItem value="all">All Sub Types</SelectItem>
                      <SelectItem value="IPD">IPD</SelectItem>
                      <SelectItem value="OPD">OPD</SelectItem>
                    </SelectContent>
                  </Select>

                  {selectedClaimType === "Cashless" && selectedClaimSubType !== "OPD" && (
                    <Select value={selectedPreauthType} onValueChange={setSelectedPreauthType}>
                      <SelectTrigger className="w-[180px] bg-background">
                        <SelectValue placeholder="Preauth Type" />
                      </SelectTrigger>
                      <SelectContent className="bg-background z-50">
                        <SelectItem value="all">All Preauth Types</SelectItem>
                        <SelectItem value="Preauth Initial">Preauth Initial</SelectItem>
                        <SelectItem value="Preauth Enhancement">Preauth Enhancement</SelectItem>
                        <SelectItem value="Preauth Final">Preauth Final</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                  
                  {(selectedLoB !== "all" || selectedClaimType !== "all" || selectedClaimSubType !== "all" || selectedPreauthType !== "all") && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-9"
                      onClick={() => {
                        setSelectedLoB("all");
                        setSelectedClaimType("all");
                        setSelectedClaimSubType("all");
                        setSelectedPreauthType("all");
                      }}
                    >
                      Clear Filters
                    </Button>
                  )}
                </div>
              </div>
              
              {/* Volume Metrics */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 px-1">
                  <ClipboardList className="w-4 h-4 text-primary" />
                  <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Volume Metrics</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Total Claims Received */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Claims Received</CardTitle>
                    <ClipboardList className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{metricsData.totalClaimsReceived}</div>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      {(() => {
                        const isPositive = metricsData.trends.totalClaimsReceived.startsWith('+');
                        const colors = getTrendColor('totalClaimsReceived', metricsData.trends.totalClaimsReceived, isPositive);
                        return isPositive ? (
                          <>
                            <ArrowUp className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.totalClaimsReceived}</span>
                          </>
                        ) : (
                          <>
                            <ArrowDown className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.totalClaimsReceived}</span>
                          </>
                        );
                      })()}
                      <span>{comparisonText}</span>
                    </p>
                    <Button
                      variant="link"
                      size="sm"
                      className="h-auto p-0 text-xs mt-2"
                      onClick={() => handleViewTrend("Total Claims Received", "totalClaimsReceived", metricsData.totalClaimsReceived)}
                    >
                      View Trend
                    </Button>
                  </CardContent>
                </Card>

                {/* Claims Processed */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Claims Processed</CardTitle>
                    <CheckCircle className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{metricsData.claimsCompleted}</div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Completed: {metricsData.claimsCompleted} | Pending: {metricsData.claimsPending}
                    </p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      {(() => {
                        const isPositive = metricsData.trends.claimsCompleted.startsWith('+');
                        const colors = getTrendColor('claimsCompleted', metricsData.trends.claimsCompleted, isPositive);
                        return isPositive ? (
                          <>
                            <ArrowUp className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.claimsCompleted}</span>
                          </>
                        ) : (
                          <>
                            <ArrowDown className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.claimsCompleted}</span>
                          </>
                        );
                      })()}
                      <span>{comparisonText}</span>
                    </p>
                    <Button
                      variant="link"
                      size="sm"
                      className="h-auto p-0 text-xs mt-2"
                      onClick={() => handleViewTrend("Claims Processed", "claimsCompleted", metricsData.claimsCompleted)}
                    >
                      View Trend
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Quality Metrics */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 px-1">
                <AlertCircle className="w-4 h-4 text-orange-500" />
                <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Quality Metrics</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* SLA Breach */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">SLA Breach</CardTitle>
                    <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{metricsData.slaBreach}</div>
                    <p className="text-xs text-muted-foreground">Claims missing SLA targets</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      {(() => {
                        const isPositive = metricsData.trends.slaBreach.startsWith('+');
                        const colors = getTrendColor('slaBreach', metricsData.trends.slaBreach, isPositive);
                        return isPositive ? (
                          <>
                            <ArrowUp className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.slaBreach}</span>
                          </>
                        ) : (
                          <>
                            <ArrowDown className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.slaBreach}</span>
                          </>
                        );
                      })()}
                      <span>{comparisonText}</span>
                    </p>
                    <Button
                      variant="link"
                      size="sm"
                      className="h-auto p-0 text-xs mt-2"
                      onClick={() => handleViewTrend("SLA Breach", "slaBreach", metricsData.slaBreach)}
                    >
                      View Trend
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Efficiency Metrics */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 px-1">
                <Clock className="w-4 h-4 text-blue-500" />
                <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Efficiency Metrics</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Average Processing Time */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Avg Processing Time</CardTitle>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{metricsData.avgProcessingTime} mins</div>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      {(() => {
                        const isPositive = metricsData.trends.avgProcessingTime.startsWith('+');
                        const colors = getTrendColor('avgProcessingTime', metricsData.trends.avgProcessingTime, isPositive);
                        return isPositive ? (
                          <>
                            <ArrowUp className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.avgProcessingTime}</span>
                          </>
                        ) : (
                          <>
                            <ArrowDown className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.avgProcessingTime}</span>
                          </>
                        );
                      })()}
                      <span>{comparisonText}</span>
                    </p>
                    <Button
                      variant="link"
                      size="sm"
                      className="h-auto p-0 text-xs mt-2"
                      onClick={() => handleViewTrend("Avg Processing Time", "avgProcessingTime", metricsData.avgProcessingTime)}
                    >
                      View Trend
                    </Button>
                  </CardContent>
                </Card>

                {/* Reassignment Count */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Reassignment Count</CardTitle>
                    <RefreshCw className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{metricsData.reassignmentCount}</div>
                    <p className="text-xs text-muted-foreground">Claims transferred between agents</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      {(() => {
                        const isPositive = metricsData.trends.reassignmentCount.startsWith('+');
                        const colors = getTrendColor('reassignmentCount', metricsData.trends.reassignmentCount, isPositive);
                        return isPositive ? (
                          <>
                            <ArrowUp className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.reassignmentCount}</span>
                          </>
                        ) : (
                          <>
                            <ArrowDown className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.reassignmentCount}</span>
                          </>
                        );
                      })()}
                      <span>{comparisonText}</span>
                    </p>
                    <Button
                      variant="link"
                      size="sm"
                      className="h-auto p-0 text-xs mt-2"
                      onClick={() => handleViewTrend("Reassignment Count", "reassignmentCount", metricsData.reassignmentCount)}
                    >
                      View Trend
                    </Button>
                  </CardContent>
                </Card>

                {/* Stickiness Compliance */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Stickiness Compliance</CardTitle>
                    <UserCheck className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{metricsData.stickinessCompliance}</div>
                    <p className="text-xs text-muted-foreground">Claims reallocated to same agent</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      {(() => {
                        const isPositive = metricsData.trends.stickinessCompliance.startsWith('+');
                        const colors = getTrendColor('stickinessCompliance', metricsData.trends.stickinessCompliance, isPositive);
                        return isPositive ? (
                          <>
                            <ArrowUp className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.stickinessCompliance}</span>
                          </>
                        ) : (
                          <>
                            <ArrowDown className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.stickinessCompliance}</span>
                          </>
                        );
                      })()}
                      <span>{comparisonText}</span>
                    </p>
                    <Button
                      variant="link"
                      size="sm"
                      className="h-auto p-0 text-xs mt-2"
                      onClick={() => handleViewTrend("Stickiness Compliance", "stickinessCompliance", metricsData.stickinessCompliance)}
                    >
                      View Trend
                    </Button>
                  </CardContent>
                </Card>

                {/* Rework Rate */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Rework Rate</CardTitle>
                    <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{metricsData.reworkRate}</div>
                    <p className="text-xs text-muted-foreground">Claims sent back for corrections</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      {(() => {
                        const isPositive = metricsData.trends.reworkRate.startsWith('+');
                        const colors = getTrendColor('reworkRate', metricsData.trends.reworkRate, isPositive);
                        return isPositive ? (
                          <>
                            <ArrowUp className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.reworkRate}</span>
                          </>
                        ) : (
                          <>
                            <ArrowDown className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.reworkRate}</span>
                          </>
                        );
                      })()}
                      <span>{comparisonText}</span>
                    </p>
                    <Button
                      variant="link"
                      size="sm"
                      className="h-auto p-0 text-xs mt-2"
                      onClick={() => handleViewTrend("Rework Rate", "reworkRate", metricsData.reworkRate)}
                    >
                      View Trend
                    </Button>
                  </CardContent>
                </Card>

                {/* Deficiency Cases */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Deficiency Cases</CardTitle>
                    <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{metricsData.deficiencyRate}</div>
                    <p className="text-xs text-muted-foreground">Claims with missing documents</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      {(() => {
                        const isPositive = metricsData.trends.deficiencyRate.startsWith('+');
                        const colors = getTrendColor('deficiencyRate', metricsData.trends.deficiencyRate, isPositive);
                        return isPositive ? (
                          <>
                            <ArrowUp className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.deficiencyRate}</span>
                          </>
                        ) : (
                          <>
                            <ArrowDown className={`h-3 w-3 ${colors.icon}`} />
                            <span className={colors.text}>{metricsData.trends.deficiencyRate}</span>
                          </>
                        );
                      })()}
                      <span>{comparisonText}</span>
                    </p>
                    <Button
                      variant="link"
                      size="sm"
                      className="h-auto p-0 text-xs mt-2"
                      onClick={() => handleViewTrend("Deficiency Cases", "deficiencyRate", metricsData.deficiencyRate)}
                    >
                      View Trend
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
          </TabsContent>

          <TabsContent value="agent" className="space-y-6">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold">Agent Performance Details</h2>
                
                {/* Agent Selector */}
                <Select value={selectedAgent} onValueChange={setSelectedAgent}>
                  <SelectTrigger className="w-[250px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="all">All Agents</SelectItem>
                    {agentData.map((agent) => (
                      <SelectItem key={agent.id} value={agent.id.toString()}>
                        {agent.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Tasks Completed */}
                <Card className="border-l-4 border-l-primary hover:shadow-lg transition-all duration-300 hover-scale">
                  <CardContent className="p-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <CheckCircle className="h-5 w-5 text-primary" />
                        </div>
                        <div className="text-sm font-semibold text-foreground">Tasks Completed</div>
                      </div>
                    </div>
                    <div className="text-4xl font-bold text-primary">{agentMetrics.tasksCompleted}</div>
                    {selectedAgent !== "all" && teamBenchmarks && (
                      <div className="pt-3 border-t space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Avg</span>
                          <span className="font-medium">{teamBenchmarks.avgTasks}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Best</span>
                          <span className="font-medium text-primary">{teamBenchmarks.maxTasks}</span>
                        </div>
                      </div>
                    )}
                    {selectedAgent === "all" && (
                      <p className="text-xs text-muted-foreground">Total tasks finished by team</p>
                    )}
                  </CardContent>
                </Card>

                {/* Average Task Completion Time */}
                <Card className="border-l-4 border-l-blue-500 hover:shadow-lg transition-all duration-300 hover-scale">
                  <CardContent className="p-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-500/10 rounded-lg">
                          <Clock className="h-5 w-5 text-blue-500" />
                        </div>
                        <div className="text-sm font-semibold text-foreground">Avg Completion Time</div>
                      </div>
                    </div>
                    <div className="text-4xl font-bold text-blue-500">{agentMetrics.avgCompletionTime}</div>
                    {selectedAgent !== "all" && teamBenchmarks && (
                      <div className="pt-3 border-t space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Avg</span>
                          <span className="font-medium">{teamBenchmarks.avgCompletionTime}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Best</span>
                          <span className="font-medium text-blue-500">{teamBenchmarks.bestCompletionTime}</span>
                        </div>
                      </div>
                    )}
                    {selectedAgent === "all" && (
                      <p className="text-xs text-muted-foreground">Average time per claim</p>
                    )}
                  </CardContent>
                </Card>

                {/* Rework Rate */}
                <Card className="border-l-4 border-l-orange-500 hover:shadow-lg transition-all duration-300 hover-scale">
                  <CardContent className="p-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-orange-500/10 rounded-lg">
                          <AlertCircle className="h-5 w-5 text-orange-500" />
                        </div>
                        <div className="text-sm font-semibold text-foreground">Rework Rate</div>
                      </div>
                    </div>
                    <div className="text-4xl font-bold text-orange-500">{agentMetrics.reworkRate}</div>
                    {selectedAgent !== "all" && teamBenchmarks && (
                      <div className="pt-3 border-t space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Avg</span>
                          <span className="font-medium">{teamBenchmarks.avgReworkRate}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Best</span>
                          <span className="font-medium text-green-500">{teamBenchmarks.bestReworkRate}</span>
                        </div>
                      </div>
                    )}
                    {selectedAgent === "all" && (
                      <p className="text-xs text-muted-foreground">Claims requiring corrections</p>
                    )}
                  </CardContent>
                </Card>

                {/* Utilization Rate */}
                <Card className="border-l-4 border-l-purple-500 hover:shadow-lg transition-all duration-300 hover-scale">
                  <CardContent className="p-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-purple-500/10 rounded-lg">
                          <Activity className="h-5 w-5 text-purple-500" />
                        </div>
                        <div className="text-sm font-semibold text-foreground">Utilization Rate</div>
                      </div>
                    </div>
                    <div className="text-4xl font-bold text-purple-500">{agentMetrics.utilizationRate}</div>
                    {selectedAgent !== "all" && teamBenchmarks && (
                      <div className="pt-3 border-t space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Avg</span>
                          <span className="font-medium">{teamBenchmarks.avgUtilizationRate}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Best</span>
                          <span className="font-medium text-purple-500">{teamBenchmarks.bestUtilizationRate}</span>
                        </div>
                      </div>
                    )}
                    {selectedAgent === "all" && (
                      <p className="text-xs text-muted-foreground">Based on login activity</p>
                    )}
                  </CardContent>
                </Card>

                {/* Available Hours */}
                <Card className="border-l-4 border-l-green-500 hover:shadow-lg transition-all duration-300 hover-scale">
                  <CardContent className="p-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-green-500/10 rounded-lg">
                          <Timer className="h-5 w-5 text-green-500" />
                        </div>
                        <div className="text-sm font-semibold text-foreground">Available Hours</div>
                      </div>
                    </div>
                    <div className="text-4xl font-bold text-green-500">{agentMetrics.availableHours}h</div>
                    {selectedAgent !== "all" && teamBenchmarks && (
                      <div className="pt-3 border-t space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Avg</span>
                          <span className="font-medium">{teamBenchmarks.avgAvailableHours}h</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Best</span>
                          <span className="font-medium text-green-500">{teamBenchmarks.bestAvailableHours}h</span>
                        </div>
                      </div>
                    )}
                    {selectedAgent === "all" && (
                      <p className="text-xs text-muted-foreground">Total working time logged</p>
                    )}
                  </CardContent>
                </Card>

                {/* Unavailable + Leave Hours */}
                <Card className="border-l-4 border-l-amber-500 hover:shadow-lg transition-all duration-300 hover-scale">
                  <CardContent className="p-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-amber-500/10 rounded-lg">
                          <Coffee className="h-5 w-5 text-amber-500" />
                        </div>
                        <div className="text-sm font-semibold text-foreground">Unavailable + Leave</div>
                      </div>
                    </div>
                    <div className="text-4xl font-bold text-amber-500">{agentMetrics.unavailableHours}h</div>
                    {selectedAgent !== "all" && teamBenchmarks && (
                      <div className="pt-3 border-t space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Avg</span>
                          <span className="font-medium">{teamBenchmarks.avgUnavailableHours}h</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Team Best</span>
                          <span className="font-medium text-green-500">{teamBenchmarks.bestUnavailableHours}h</span>
                        </div>
                      </div>
                    )}
                    {selectedAgent === "all" && (
                      <p className="text-xs text-muted-foreground">Breaks and time off tracked</p>
                    )}
                  </CardContent>
                </Card>
              </div>

            </div>
          </TabsContent>

          <TabsContent value="team" className="space-y-6">
            {/* Shift Coverage Section */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-primary" />
                <h3 className="text-xl font-semibold">Shift Coverage</h3>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Shift Coverage & Readiness
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {/* Overall Coverage - Hero Metric */}
                    <div className="text-center py-3 bg-primary/5 rounded-lg border border-primary/20">
                      <p className="text-xs font-medium text-muted-foreground mb-1">Overall Coverage Rate</p>
                      <div className="text-3xl font-bold text-primary">
                        {selectedShifts.includes("all") ? "95%" : `${85 + selectedShifts.length * 3}%`}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Shift coverage across all teams</p>
                    </div>

                    {/* Key Metrics Grid */}
                    <div className="grid grid-cols-2 gap-4">
                      {/* Agent Staffing */}
                      <div className="p-4 rounded-lg border bg-card hover:shadow-md transition-shadow">
                        <div className="flex items-center gap-2 mb-3">
                          <div className="p-2 rounded-full bg-blue-500/10">
                            <UserCheck className="h-4 w-4 text-blue-600" />
                          </div>
                          <span className="text-sm font-semibold">Agent Staffing</span>
                        </div>
                        <div className="text-3xl font-bold text-foreground">
                          {agentData.length} <span className="text-muted-foreground text-xl">/ {selectedShifts.includes("all") ? "15" : Math.ceil(agentData.length * 1.5)}</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          Agents on shift vs required
                        </p>
                      </div>

                      {/* Skills Coverage */}
                      <div className="p-4 rounded-lg border bg-card hover:shadow-md transition-shadow">
                        <div className="flex items-center gap-2 mb-3">
                          <div className="p-2 rounded-full bg-purple-500/10">
                            <ClipboardList className="h-4 w-4 text-purple-600" />
                          </div>
                          <span className="text-sm font-semibold">Skills Coverage</span>
                        </div>
                        <div className="text-3xl font-bold text-foreground">
                          {selectedShifts.includes("all") ? "4" : Math.max(4, agentData.length * 2)} <span className="text-muted-foreground text-xl">/ {selectedShifts.includes("all") ? "6" : Math.max(6, agentData.length * 2 + 2)}</span>
                        </div>
                        <div className="flex gap-3 mt-3">
                          <div className="flex items-center gap-1 text-xs">
                            <CheckCircle className="h-3.5 w-3.5 text-green-600" />
                            <span className="font-medium">{selectedShifts.includes("all") ? "4" : Math.max(4, agentData.length * 2)}</span>
                          </div>
                          <div className="flex items-center gap-1 text-xs">
                            <AlertCircle className="h-3.5 w-3.5 text-amber-600" />
                            <span className="font-medium">{selectedShifts.includes("all") ? "2" : Math.max(2, Math.ceil(agentData.length * 0.5))}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* CTA Button */}
                    <Button 
                      variant="outline" 
                      onClick={() => setSkillsDialogOpen(true)}
                      className="w-full justify-center gap-2 h-11 text-base font-medium hover:bg-primary/5 hover:text-primary hover:border-primary"
                    >
                      <TrendingUp className="h-4 w-4" />
                      View Detailed Skills Breakdown
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Team Level Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Agent Performance Rankings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[80px]">Rank</TableHead>
                      <TableHead>Agent Name</TableHead>
                      <TableHead className="text-right">Tasks Completed</TableHead>
                      <TableHead className="text-right">Avg Time</TableHead>
                      <TableHead className="text-right">Rework Rate</TableHead>
                      <TableHead className="text-right">Utilization</TableHead>
                      <TableHead className="text-right">Score</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rankedAgents.map((agent, index) => (
                      <TableRow key={agent.id} className={index === 0 ? "bg-primary/5" : ""}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {index === 0 && <span className="text-xl">🏆</span>}
                            {index === 1 && <span className="text-xl">🥈</span>}
                            {index === 2 && <span className="text-xl">🥉</span>}
                            <span className="font-medium">#{index + 1}</span>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">{agent.name}</TableCell>
                        <TableCell className="text-right">{agent.tasksCompleted}</TableCell>
                        <TableCell className="text-right">{agent.avgTime}</TableCell>
                        <TableCell className="text-right">{agent.reworkRate}</TableCell>
                        <TableCell className="text-right">{agent.utilizationRate}</TableCell>
                        <TableCell className="text-right">
                          <Badge variant={index === 0 ? "default" : "secondary"}>
                            {agent.performanceScore.toFixed(2)}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

        </Tabs>
      </main>

      {/* Task Details Dialog */}
      <Dialog open={taskDetailsOpen} onOpenChange={setTaskDetailsOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedAgentTasks?.agent.name} - Tasks Completed
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground">
              Total Tasks: {selectedAgentTasks?.tasks.length || 0}
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Claim ID</TableHead>
                  <TableHead>LoB</TableHead>
                  <TableHead>Claim Type</TableHead>
                  <TableHead>Sub Type</TableHead>
                  <TableHead>Request Type</TableHead>
                  <TableHead>Time Taken</TableHead>
                  <TableHead>Completed At</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedAgentTasks?.tasks.map((task: any) => (
                  <TableRow key={task.id}>
                    <TableCell className="font-medium">{task.id}</TableCell>
                    <TableCell>{task.lob}</TableCell>
                    <TableCell>{task.claimType}</TableCell>
                    <TableCell>{task.subType}</TableCell>
                    <TableCell>{task.requestType}</TableCell>
                    <TableCell>{task.timeTaken}</TableCell>
                    <TableCell>{task.completedAt}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>

      {/* Trend Dialog */}
      <Dialog open={trendDialogOpen} onOpenChange={setTrendDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{trendDialogData.title} - Trend</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={trendDialogData.data}>
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--primary))", r: 4 }}
                  />
                  <text x="50%" y="20" textAnchor="middle" className="text-sm font-medium fill-foreground">
                    {trendDialogData.title}
                  </text>
                  {trendDialogData.data.map((entry, index) => (
                    <text
                      key={index}
                      x={`${(index / (trendDialogData.data.length - 1)) * 100}%`}
                      y="290"
                      textAnchor="middle"
                      className="text-xs fill-muted-foreground"
                    >
                      {entry.period}
                    </text>
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
              <div>
                <p className="text-xs text-muted-foreground">Starting Value</p>
                <p className="text-lg font-semibold">{trendDialogData.data[0]?.value.toFixed(2) || "-"}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Current Value</p>
                <p className="text-lg font-semibold">{trendDialogData.data[trendDialogData.data.length - 1]?.value.toFixed(2) || "-"}</p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Skills Details Dialog */}
      <Dialog open={skillsDialogOpen} onOpenChange={setSkillsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ClipboardList className="h-5 w-5" />
              Skills Coverage Details
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 mt-4">
            {/* Agents in Current Shift */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <UserCheck className="h-5 w-5 text-blue-500" />
                <h3 className="font-semibold text-lg">Agents on Duty ({agentData.length})</h3>
              </div>
              <div className="grid grid-cols-1 gap-3">
                {agentData.map((agent) => {
                  const agentSkills = [
                    { name: "Claims Processing", level: agent.id % 2 === 0 ? "Expert" : "Intermediate" },
                    { name: "Customer Support", level: agent.id % 3 === 0 ? "Expert" : "Beginner" },
                    ...(agent.id % 2 === 0 ? [{ name: "Policy Review", level: "Intermediate" }] : []),
                    ...(agent.id % 3 === 0 ? [{ name: "Technical Support", level: "Expert" }] : []),
                  ];
                  return (
                    <Card key={agent.id} className="border-l-4 border-l-blue-500">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <p className="font-semibold text-base">{agent.name}</p>
                            <p className="text-xs text-muted-foreground capitalize">{agent.shift} Shift</p>
                          </div>
                          <Badge variant="outline" className="bg-blue-50 dark:bg-blue-950/20 text-blue-700 dark:text-blue-400">
                            {agentSkills.length} Skills
                          </Badge>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {agentSkills.map((skill, idx) => (
                            <Badge 
                              key={idx} 
                              variant="secondary"
                              className={cn(
                                "text-xs",
                                skill.level === "Expert" && "bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-400",
                                skill.level === "Intermediate" && "bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400",
                                skill.level === "Beginner" && "bg-orange-100 dark:bg-orange-900/20 text-orange-700 dark:text-orange-400"
                              )}
                            >
                              {skill.name} • {skill.level}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* Skills Summary */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Activity className="h-5 w-5 text-purple-500" />
                <h3 className="font-semibold text-lg">Skills Summary</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Card className="bg-purple-50 dark:bg-purple-950/20 border-purple-200 dark:border-purple-900">
                  <CardContent className="p-4">
                    <p className="text-sm text-muted-foreground mb-1">Total Unique Skills</p>
                    <p className="text-2xl font-bold text-purple-700 dark:text-purple-400">
                      {selectedShifts.includes("all") ? "4" : Math.max(4, agentData.length * 2)}
                    </p>
                  </CardContent>
                </Card>
                <Card className="bg-indigo-50 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-900">
                  <CardContent className="p-4">
                    <p className="text-sm text-muted-foreground mb-1">Avg Skills per Agent</p>
                    <p className="text-2xl font-bold text-indigo-700 dark:text-indigo-400">
                      {(agentData.length > 0 ? (2.8).toFixed(1) : "0")}
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Available Skills */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle className="h-5 w-5 text-green-500" />
                <h3 className="font-semibold text-lg">Available Skills ({selectedShifts.includes("all") ? "4" : Math.max(4, agentData.length * 2)})</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <Card className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-900">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-medium">Claims Processing</p>
                        <p className="text-xs text-muted-foreground mt-1">3 agents certified</p>
                      </div>
                      <Badge variant="outline" className="bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-400 border-green-300 dark:border-green-800">
                        Active
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-900">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-medium">Customer Support</p>
                        <p className="text-xs text-muted-foreground mt-1">5 agents certified</p>
                      </div>
                      <Badge variant="outline" className="bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-400 border-green-300 dark:border-green-800">
                        Active
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-900">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-medium">Policy Review</p>
                        <p className="text-xs text-muted-foreground mt-1">2 agents certified</p>
                      </div>
                      <Badge variant="outline" className="bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-400 border-green-300 dark:border-green-800">
                        Active
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-900">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-medium">Technical Support</p>
                        <p className="text-xs text-muted-foreground mt-1">4 agents certified</p>
                      </div>
                      <Badge variant="outline" className="bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-400 border-green-300 dark:border-green-800">
                        Active
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Skill Gaps / Required Skills */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <AlertCircle className="h-5 w-5 text-amber-500" />
                <h3 className="font-semibold text-lg">Skills Required ({selectedShifts.includes("all") ? "2" : Math.max(2, Math.ceil(agentData.length * 0.5))})</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <Card className="bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium">Fraud Investigation</p>
                        <p className="text-xs text-muted-foreground mt-1">0 agents available</p>
                      </div>
                      <Badge variant="outline" className="bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400 border-amber-300 dark:border-amber-800">
                        Critical
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">Need 2-3 trained agents</p>
                  </CardContent>
                </Card>
                <Card className="bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium">Compliance Review</p>
                        <p className="text-xs text-muted-foreground mt-1">0 agents available</p>
                      </div>
                      <Badge variant="outline" className="bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400 border-amber-300 dark:border-amber-800">
                        High Priority
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">Need 1-2 trained agents</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Performance;
