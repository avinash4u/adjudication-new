import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import * as XLSX from 'xlsx';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Plus, Filter, ArrowUpDown, Search, CalendarDays, Clock, MoreVertical, Pencil, X, LayoutGrid, List, Upload, FileSpreadsheet, Download } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Agent {
  id: string;
  name: string;
  email: string;
  initials: string;
  avatarColor: string;
  status: "Training" | "Online" | "Meeting" | "Offline";
  role: "Senior" | "Lead" | "Junior";
  proposals: number;
  todaysTasks: number;
  languages: string[];
  moreLanguages?: number;
  skills: string[];
  moreSkills?: number;
  team: string[];
  moreTeams?: number;
  lastActive: string;
}

const mockAgents: Agent[] = [
  {
    id: "1",
    name: "Sneha Singh",
    email: "sneha.singh@acko.com",
    initials: "SS",
    avatarColor: "hsl(217, 91%, 60%)",
    status: "Training",
    role: "Senior",
    proposals: 52,
    todaysTasks: 6,
    languages: ["English", "Hindi"],
    moreLanguages: 1,
    skills: ["ACKO_Existing", "VIP cases"],
    moreSkills: 2,
    team: ["Retail", "GMC"],
    moreTeams: 1,
    lastActive: "30 min ago",
  },
  {
    id: "2",
    name: "Priya Sharma",
    email: "priya.sharma@acko.com",
    initials: "PS",
    avatarColor: "hsl(217, 91%, 60%)",
    status: "Online",
    role: "Senior",
    proposals: 45,
    todaysTasks: 8,
    languages: ["English", "Hindi"],
    moreLanguages: 1,
    skills: ["Bill Entry", "Adjudication"],
    moreSkills: 1,
    team: ["Cashless", "Reimbursement"],
    moreTeams: 0,
    lastActive: "2 min ago",
  },
  {
    id: "3",
    name: "Amit Patel",
    email: "amit.patel@acko.com",
    initials: "AP",
    avatarColor: "hsl(217, 91%, 60%)",
    status: "Meeting",
    role: "Lead",
    proposals: 38,
    todaysTasks: 12,
    languages: ["English", "Hindi"],
    moreLanguages: 1,
    skills: ["CRM", "ACKO_Existing", "VIP cases"],
    moreSkills: 0,
    team: ["IPD", "OPD", "Retail"],
    moreTeams: 0,
    lastActive: "1 hour ago",
  },
];

export default function AgentManagement() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isBulkUploadDialogOpen, setIsBulkUploadDialogOpen] = useState(false);
  const [editingStatusId, setEditingStatusId] = useState<string | null>(null);
  const [deactivateAgentId, setDeactivateAgentId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [parsedAgents, setParsedAgents] = useState<any[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Onboarding state
  const [onboardingSearch, setOnboardingSearch] = useState("");
  const [selectedAgent, setSelectedAgent] = useState<any>(null);
  const [onboardingData, setOnboardingData] = useState({
    seniority: "Junior",
    primarySkills: {
      languages: [] as { language: string; proficiency: number }[],
      tags: [] as string[],
      competencies: [] as string[],
    },
    secondarySkills: {
      languages: [] as { language: string; proficiency: number }[],
      tags: [] as string[],
      competencies: [] as string[],
    },
    performanceRating: "",
  });
  const [newPrimaryLanguage, setNewPrimaryLanguage] = useState("");
  const [newPrimaryProficiency, setNewPrimaryProficiency] = useState("3");
  const [newSecondaryLanguage, setNewSecondaryLanguage] = useState("");
  const [newSecondaryProficiency, setNewSecondaryProficiency] = useState("3");

  const getStatusColor = (status: Agent["status"]) => {
    switch (status) {
      case "Training":
        return "bg-primary text-primary-foreground";
      case "Online":
        return "bg-status-on-track text-status-on-track-foreground";
      case "Meeting":
        return "bg-[hsl(25,95%,53%)] text-white";
      case "Offline":
        return "bg-muted text-muted-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getRoleColor = (role: Agent["role"]) => {
    switch (role) {
      case "Lead":
        return "bg-[hsl(0,84%,60%)] text-white";
      case "Senior":
        return "bg-primary text-primary-foreground";
      case "Junior":
        return "bg-muted text-muted-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const filteredAgents = mockAgents.filter((agent) => {
    const matchesSearch =
      agent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      agent.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || agent.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Mock data for agents that exist in system but aren't onboarded
  const existingAgents = [
    { id: "101", name: "Rahul Kumar", phone: "+91 98765 43210", email: "rahul.kumar@acko.com" },
    { id: "102", name: "Anjali Desai", phone: "+91 98765 43211", email: "anjali.desai@acko.com" },
    { id: "103", name: "Vikram Singh", phone: "+91 98765 43212", email: "vikram.singh@acko.com" },
  ];

  const searchResults = existingAgents.filter(agent => 
    onboardingSearch.length >= 2 && (
      agent.name.toLowerCase().includes(onboardingSearch.toLowerCase()) ||
      agent.phone.includes(onboardingSearch) ||
      agent.email.toLowerCase().includes(onboardingSearch.toLowerCase())
    )
  );

  const handleOnboardAgent = () => {
    if (!selectedAgent) {
      toast({
        title: "No Agent Selected",
        description: "Please search and select an agent to onboard",
        variant: "destructive",
      });
      return;
    }
    
    console.log("Onboarding agent:", selectedAgent, onboardingData);
    
    toast({
      title: "Agent Onboarded",
      description: `Successfully onboarded ${selectedAgent.name}`,
    });
    
    // Reset state
    setIsAddDialogOpen(false);
    setOnboardingSearch("");
    setSelectedAgent(null);
    setOnboardingData({
      seniority: "Junior",
      primarySkills: {
        languages: [],
        tags: [],
        competencies: [],
      },
      secondarySkills: {
        languages: [],
        tags: [],
        competencies: [],
      },
      performanceRating: "",
    });
    setNewPrimaryLanguage("");
    setNewPrimaryProficiency("3");
    setNewSecondaryLanguage("");
    setNewSecondaryProficiency("3");
  };

  // Primary Skills Functions
  const addPrimaryLanguage = () => {
    if (newPrimaryLanguage && !onboardingData.primarySkills.languages.some(l => l.language === newPrimaryLanguage)) {
      setOnboardingData({ 
        ...onboardingData, 
        primarySkills: {
          ...onboardingData.primarySkills,
          languages: [...onboardingData.primarySkills.languages, { language: newPrimaryLanguage, proficiency: parseInt(newPrimaryProficiency) }] 
        }
      });
      setNewPrimaryLanguage("");
      setNewPrimaryProficiency("3");
    }
  };

  const removePrimaryLanguage = (language: string) => {
    setOnboardingData({ 
      ...onboardingData, 
      primarySkills: {
        ...onboardingData.primarySkills,
        languages: onboardingData.primarySkills.languages.filter(l => l.language !== language)
      }
    });
  };

  const addPrimaryTag = (tag: string) => {
    if (!onboardingData.primarySkills.tags.includes(tag)) {
      setOnboardingData({ 
        ...onboardingData, 
        primarySkills: {
          ...onboardingData.primarySkills,
          tags: [...onboardingData.primarySkills.tags, tag]
        }
      });
    }
  };

  const removePrimaryTag = (tag: string) => {
    setOnboardingData({ 
      ...onboardingData, 
      primarySkills: {
        ...onboardingData.primarySkills,
        tags: onboardingData.primarySkills.tags.filter(t => t !== tag)
      }
    });
  };

  const addPrimaryCompetency = (competency: string) => {
    if (!onboardingData.primarySkills.competencies.includes(competency)) {
      setOnboardingData({ 
        ...onboardingData, 
        primarySkills: {
          ...onboardingData.primarySkills,
          competencies: [...onboardingData.primarySkills.competencies, competency]
        }
      });
    }
  };

  const removePrimaryCompetency = (competency: string) => {
    setOnboardingData({ 
      ...onboardingData, 
      primarySkills: {
        ...onboardingData.primarySkills,
        competencies: onboardingData.primarySkills.competencies.filter(c => c !== competency)
      }
    });
  };

  // Secondary Skills Functions
  const addSecondaryLanguage = () => {
    if (newSecondaryLanguage && !onboardingData.secondarySkills.languages.some(l => l.language === newSecondaryLanguage)) {
      setOnboardingData({ 
        ...onboardingData, 
        secondarySkills: {
          ...onboardingData.secondarySkills,
          languages: [...onboardingData.secondarySkills.languages, { language: newSecondaryLanguage, proficiency: parseInt(newSecondaryProficiency) }] 
        }
      });
      setNewSecondaryLanguage("");
      setNewSecondaryProficiency("3");
    }
  };

  const removeSecondaryLanguage = (language: string) => {
    setOnboardingData({ 
      ...onboardingData, 
      secondarySkills: {
        ...onboardingData.secondarySkills,
        languages: onboardingData.secondarySkills.languages.filter(l => l.language !== language)
      }
    });
  };

  const addSecondaryTag = (tag: string) => {
    if (!onboardingData.secondarySkills.tags.includes(tag)) {
      setOnboardingData({ 
        ...onboardingData, 
        secondarySkills: {
          ...onboardingData.secondarySkills,
          tags: [...onboardingData.secondarySkills.tags, tag]
        }
      });
    }
  };

  const removeSecondaryTag = (tag: string) => {
    setOnboardingData({ 
      ...onboardingData, 
      secondarySkills: {
        ...onboardingData.secondarySkills,
        tags: onboardingData.secondarySkills.tags.filter(t => t !== tag)
      }
    });
  };

  const addSecondaryCompetency = (competency: string) => {
    if (!onboardingData.secondarySkills.competencies.includes(competency)) {
      setOnboardingData({ 
        ...onboardingData, 
        secondarySkills: {
          ...onboardingData.secondarySkills,
          competencies: [...onboardingData.secondarySkills.competencies, competency]
        }
      });
    }
  };

  const removeSecondaryCompetency = (competency: string) => {
    setOnboardingData({ 
      ...onboardingData, 
      secondarySkills: {
        ...onboardingData.secondarySkills,
        competencies: onboardingData.secondarySkills.competencies.filter(c => c !== competency)
      }
    });
  };

  const statusOptions = [
    { label: "Online", color: "bg-status-on-track" },
    { label: "Meeting", color: "bg-[hsl(25,95%,53%)]" },
    { label: "Training", color: "bg-primary" },
    { label: "Lunch", color: "bg-[hsl(25,95%,53%)]" },
    { label: "Tea/coffee", color: "bg-[hsl(25,95%,53%)]" },
    { label: "Personal break", color: "bg-muted" },
    { label: "Offline", color: "bg-destructive" },
  ];

  const handleStatusChange = (agentId: string, newStatus: string) => {
    // Handle status change logic here
    console.log(`Changing agent ${agentId} status to ${newStatus}`);
    setEditingStatusId(null);
    toast({
      title: "Status Updated",
      description: `Agent status changed to ${newStatus}`,
    });
  };

  const handleDeactivate = () => {
    if (deactivateAgentId) {
      // Handle deactivate logic here
      console.log(`Deactivating agent ${deactivateAgentId}`);
      toast({
        title: "Agent Deactivated",
        description: "The agent has been deactivated successfully",
        variant: "destructive",
      });
      setDeactivateAgentId(null);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      toast({
        title: "Invalid File",
        description: "Please upload an Excel file (.xlsx or .xls)",
        variant: "destructive",
      });
      return;
    }

    setUploadedFile(file);
    setIsProcessing(true);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        // Validate and parse the data
        const agents = jsonData.map((row: any, index: number) => ({
          rowNumber: index + 2, // Excel rows start at 1, header at 1, data at 2
          fullName: row['Full Name'] || row['Name'] || '',
          email: row['Email'] || '',
          phone: row['Phone'] || row['Mobile'] || '',
          seniority: row['Seniority'] || row['Role'] || 'Junior',
          languages: row['Languages']?.split(',').map((l: string) => l.trim()) || [],
          skills: row['Skills']?.split(',').map((s: string) => s.trim()) || [],
          team: row['Team']?.split(',').map((t: string) => t.trim()) || [],
        }));

        setParsedAgents(agents);
        setIsProcessing(false);

        toast({
          title: "File Parsed",
          description: `Successfully parsed ${agents.length} agent records`,
        });
      } catch (error) {
        console.error('Error parsing Excel file:', error);
        setIsProcessing(false);
        toast({
          title: "Parse Error",
          description: "Failed to parse the Excel file. Please check the format.",
          variant: "destructive",
        });
      }
    };

    reader.readAsBinaryString(file);
  };

  const handleBulkUpload = () => {
    if (parsedAgents.length === 0) {
      toast({
        title: "No Data",
        description: "Please upload an Excel file first",
        variant: "destructive",
      });
      return;
    }

    // Handle bulk upload logic here
    console.log("Uploading agents:", parsedAgents);
    
    toast({
      title: "Agents Added",
      description: `Successfully added ${parsedAgents.length} agents`,
    });

    // Reset state
    setIsBulkUploadDialogOpen(false);
    setUploadedFile(null);
    setParsedAgents([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const downloadTemplate = () => {
    // Create a sample template
    const template = [
      {
        'Full Name': 'John Doe',
        'Email': 'john.doe@example.com',
        'Phone': '+1-555-0123',
        'Seniority': 'Senior',
        'Languages': 'English, Hindi, Marathi',
        'Skills': 'CRM, Bill Entry, Adjudication',
        'Team': 'Retail, GMC',
      },
    ];

    const worksheet = XLSX.utils.json_to_sheet(template);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Agents Template');
    XLSX.writeFile(workbook, 'agents_template.xlsx');

    toast({
      title: "Template Downloaded",
      description: "Excel template has been downloaded",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Agent Management</h1>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2" onClick={() => setIsBulkUploadDialogOpen(true)}>
              <Upload className="w-4 h-4" />
              Bulk Upload
            </Button>
            <Button className="gap-2" onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="w-4 h-4" />
              Onboard Agent
            </Button>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search agents by name or email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Filters" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="Online">Online</SelectItem>
              <SelectItem value="Training">Training</SelectItem>
              <SelectItem value="Meeting">Meeting</SelectItem>
              <SelectItem value="Offline">Offline</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[150px]">
              <ArrowUpDown className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Sort" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Name</SelectItem>
              <SelectItem value="proposals">Proposals</SelectItem>
              <SelectItem value="tasks">Tasks</SelectItem>
              <SelectItem value="lastActive">Last Active</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex items-center gap-2 border rounded-md px-3 py-2">
            <LayoutGrid className={`w-4 h-4 ${viewMode === "grid" ? "text-primary" : "text-muted-foreground"}`} />
            <Switch
              checked={viewMode === "list"}
              onCheckedChange={(checked) => setViewMode(checked ? "list" : "grid")}
            />
            <List className={`w-4 h-4 ${viewMode === "list" ? "text-primary" : "text-muted-foreground"}`} />
          </div>
        </div>

        {/* Agent Grid View */}
        {viewMode === "grid" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAgents.map((agent) => (
              <Card key={agent.id} className="relative">
                <CardContent className="p-6 space-y-4">
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div
                        className="w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold relative"
                        style={{ backgroundColor: agent.avatarColor }}
                      >
                        {agent.initials}
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-status-on-track border-2 border-card rounded-full" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{agent.name}</h3>
                        <Badge className={`${getStatusColor(agent.status)} mt-1`}>{agent.status}</Badge>
                        <Badge className={`${getRoleColor(agent.role)} mt-1`}>{agent.role}</Badge>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => navigate(`/agents/${agent.id}/profile`)}>
                          View Profile
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => navigate(`/agents/${agent.id}/edit`)}>
                          Edit Details
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className="text-destructive"
                          onClick={() => setDeactivateAgentId(agent.id)}
                        >
                          Deactivate
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  {/* Metrics */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-2xl font-bold">
                        <CalendarDays className="w-5 h-5 text-[hsl(25,95%,53%)]" />
                        {agent.proposals}
                      </div>
                      <p className="text-sm text-muted-foreground">Tasks in last week</p>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-2xl font-bold">
                        <Clock className="w-5 h-5 text-muted-foreground" />
                        {agent.todaysTasks}
                      </div>
                      <p className="text-sm text-muted-foreground">Today's Tasks</p>
                    </div>
                  </div>

                  {/* Primary Skills */}
                  <div className="space-y-3 p-3 border rounded-lg bg-muted/20">
                    <p className="text-sm font-semibold">Primary Skills</p>
                    
                    {/* Primary Languages */}
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1.5">Languages:</p>
                      <div className="flex flex-wrap gap-1.5">
                        {agent.languages.slice(0, 2).map((lang, idx) => (
                          <Badge key={idx} variant="outline" className="bg-background text-xs">
                            {lang}
                          </Badge>
                        ))}
                        {agent.moreLanguages && agent.moreLanguages > 0 && (
                          <Badge variant="outline" className="bg-background text-xs">
                            +{agent.moreLanguages}
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Primary Skills/Tags */}
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1.5">Tags:</p>
                      <div className="flex flex-wrap gap-1.5">
                        {agent.skills.slice(0, 2).map((skill, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Primary Competencies */}
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1.5">Competencies:</p>
                      <div className="flex flex-wrap gap-1.5">
                        {agent.team.slice(0, 2).map((comp, idx) => (
                          <Badge key={idx} variant="outline" className="bg-primary/5 text-xs">
                            {comp}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Secondary Skills */}
                  <div className="space-y-3 p-3 border rounded-lg bg-muted/10">
                    <p className="text-sm font-semibold">Secondary Skills</p>
                    
                    {/* Secondary Languages */}
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1.5">Languages:</p>
                      <div className="flex flex-wrap gap-1.5">
                        {agent.languages.length > 2 && agent.languages.slice(2, 3).map((lang, idx) => (
                          <Badge key={idx} variant="outline" className="bg-background text-xs">
                            {lang}
                          </Badge>
                        ))}
                        {agent.languages.length <= 2 && (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                      </div>
                    </div>

                    {/* Secondary Skills/Tags */}
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1.5">Tags:</p>
                      <div className="flex flex-wrap gap-1.5">
                        {agent.skills.length > 2 && agent.skills.slice(2, 3).map((skill, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {agent.skills.length <= 2 && (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                        {(agent.moreSkills ?? 0) > 0 && (
                          <Badge variant="secondary" className="text-xs">
                            +{agent.moreSkills}
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Secondary Competencies */}
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1.5">Competencies:</p>
                      <div className="flex flex-wrap gap-1.5">
                        {agent.team.length > 2 && agent.team.slice(2, 3).map((comp, idx) => (
                          <Badge key={idx} variant="outline" className="bg-primary/5 text-xs">
                            {comp}
                          </Badge>
                        ))}
                        {agent.team.length <= 2 && (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                        {(agent.moreTeams ?? 0) > 0 && (
                          <Badge variant="outline" className="bg-primary/5 text-xs">
                            +{agent.moreTeams}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Last Active */}
                  <div className="pt-2 border-t">
                    <p className="text-xs text-muted-foreground text-center">
                      Last Active: {agent.lastActive}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Agent List View */}
        {viewMode === "list" && (
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Agent</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Tasks (Week)</TableHead>
                  <TableHead>Today's Tasks</TableHead>
                  <TableHead>Languages</TableHead>
                  <TableHead>Skills</TableHead>
                  <TableHead>Team</TableHead>
                  <TableHead>Last Active</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAgents.map((agent) => (
                  <TableRow key={agent.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold text-sm relative"
                          style={{ backgroundColor: agent.avatarColor }}
                        >
                          {agent.initials}
                          <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-status-on-track border-2 border-card rounded-full" />
                        </div>
                        <div>
                          <p className="font-medium">{agent.name}</p>
                          <p className="text-xs text-muted-foreground">{agent.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(agent.status)}>{agent.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={getRoleColor(agent.role)}>{agent.role}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <CalendarDays className="w-4 h-4 text-[hsl(25,95%,53%)]" />
                        <span className="font-semibold">{agent.proposals}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span className="font-semibold">{agent.todaysTasks}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {agent.languages.slice(0, 2).map((lang, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {lang}
                          </Badge>
                        ))}
                        {agent.moreLanguages && agent.moreLanguages > 0 && (
                          <Badge variant="outline" className="text-xs">
                            +{agent.moreLanguages}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {agent.skills.slice(0, 2).map((skill, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {(agent.moreSkills ?? 0) > 0 && (
                          <Badge variant="outline" className="text-xs">
                            +{agent.moreSkills}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {agent.team.slice(0, 2).map((teamItem, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {teamItem}
                          </Badge>
                        ))}
                        {(agent.moreTeams ?? 0) > 0 && (
                          <Badge variant="outline" className="text-xs">
                            +{agent.moreTeams}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-xs text-muted-foreground">{agent.lastActive}</span>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => navigate(`/agents/${agent.id}/profile`)}>
                            View Profile
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => navigate(`/agents/${agent.id}/edit`)}>
                            Edit Details
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            className="text-destructive"
                            onClick={() => setDeactivateAgentId(agent.id)}
                          >
                            Deactivate
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        )}

        {filteredAgents.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No agents found matching your criteria.</p>
          </div>
        )}
      </div>

      {/* Onboard Agent Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="text-2xl">Onboard Agent</DialogTitle>
            <DialogDescription>Search for an agent and complete their onboarding details.</DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4 overflow-y-auto">
            {/* Search Section */}
            <div className="space-y-4 pb-4 border-b">
              <div className="space-y-2">
                <label className="text-sm font-medium">Search Agent</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by name, phone, or email..."
                    value={onboardingSearch}
                    onChange={(e) => setOnboardingSearch(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Search Results */}
              {onboardingSearch.length >= 2 && searchResults.length > 0 && !selectedAgent && (
                <div className="space-y-2 max-h-48 overflow-y-auto border rounded-lg p-2">
                  {searchResults.map((agent) => (
                    <button
                      key={agent.id}
                      onClick={() => {
                        setSelectedAgent(agent);
                        setOnboardingSearch("");
                      }}
                      className="w-full text-left p-3 hover:bg-accent rounded-md transition-colors"
                    >
                      <p className="font-medium">{agent.name}</p>
                      <p className="text-xs text-muted-foreground">{agent.email}</p>
                      <p className="text-xs text-muted-foreground">{agent.phone}</p>
                    </button>
                  ))}
                </div>
              )}

              {onboardingSearch.length >= 2 && searchResults.length === 0 && !selectedAgent && (
                <p className="text-sm text-muted-foreground text-center py-2">No agents found</p>
              )}

              {/* Selected Agent Display */}
              {selectedAgent && (
                <div className="p-4 border rounded-lg bg-muted/20">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-semibold text-lg">{selectedAgent.name}</p>
                      <p className="text-sm text-muted-foreground">{selectedAgent.email}</p>
                      <p className="text-sm text-muted-foreground">{selectedAgent.phone}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setSelectedAgent(null)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* Onboarding Form - Only show if agent is selected */}
            {selectedAgent && (
              <>
                <h3 className="font-semibold text-lg">Onboarding Details</h3>

                {/* Seniority and Performance Rating */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Seniority</label>
                    <Select value={onboardingData.seniority} onValueChange={(value) => setOnboardingData({ ...onboardingData, seniority: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Junior">Junior</SelectItem>
                        <SelectItem value="Senior">Senior</SelectItem>
                        <SelectItem value="Lead">Lead</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Performance Rating</label>
                    <Select value={onboardingData.performanceRating} onValueChange={(value) => setOnboardingData({ ...onboardingData, performanceRating: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select performance rating" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Excellent">Excellent</SelectItem>
                        <SelectItem value="Good">Good</SelectItem>
                        <SelectItem value="Average">Average</SelectItem>
                        <SelectItem value="Below Average">Below Average</SelectItem>
                        <SelectItem value="Poor">Poor</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </>
            )}

            {/* Primary Skills Section */}
            {selectedAgent && (
              <div className="space-y-4 p-4 border rounded-lg">
                <h3 className="font-semibold text-lg">Primary Skills</h3>
                
                {/* Primary Languages with Proficiency */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Languages & Proficiency</label>
                  <p className="text-xs text-muted-foreground">Add languages with proficiency level (1-5)</p>
                  <div className="flex gap-2">
                    <Select value={newPrimaryLanguage} onValueChange={setNewPrimaryLanguage}>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="English">English</SelectItem>
                        <SelectItem value="Hindi">Hindi</SelectItem>
                        <SelectItem value="Tamil">Tamil</SelectItem>
                        <SelectItem value="Telugu">Telugu</SelectItem>
                        <SelectItem value="Bengali">Bengali</SelectItem>
                        <SelectItem value="Kannada">Kannada</SelectItem>
                        <SelectItem value="Malayalam">Malayalam</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={newPrimaryProficiency} onValueChange={setNewPrimaryProficiency}>
                      <SelectTrigger className="w-24">
                        <SelectValue placeholder="Level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="5">5</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button type="button" variant="outline" onClick={addPrimaryLanguage} disabled={!newPrimaryLanguage}>
                      Add
                    </Button>
                  </div>
                  {onboardingData.primarySkills.languages.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {onboardingData.primarySkills.languages.map((lang) => (
                        <Badge key={lang.language} variant="outline" className="bg-background gap-1">
                          {lang.language} - {lang.proficiency}
                          <button
                            type="button"
                            onClick={() => removePrimaryLanguage(lang.language)}
                            className="ml-1 hover:text-destructive"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                {/* Primary Tags */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Tags</label>
                  <p className="text-xs text-muted-foreground">Special designations and categories</p>
                  <Select onValueChange={addPrimaryTag}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select tags to add" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACKO_existing">ACKO_existing</SelectItem>
                      <SelectItem value="VIP">VIP</SelectItem>
                    </SelectContent>
                  </Select>
                  {onboardingData.primarySkills.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {onboardingData.primarySkills.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="gap-1">
                          {tag}
                          <button
                            type="button"
                            onClick={() => removePrimaryTag(tag)}
                            className="ml-1 hover:text-destructive"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                {/* Primary Competencies */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Competencies</label>
                  <p className="text-xs text-muted-foreground">Core skills and capabilities</p>
                  <Select onValueChange={addPrimaryCompetency}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select competencies to add" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Bill Entry">Bill Entry</SelectItem>
                      <SelectItem value="Adjudication">Adjudication</SelectItem>
                      <SelectItem value="CRM">CRM</SelectItem>
                    </SelectContent>
                  </Select>
                  {onboardingData.primarySkills.competencies.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {onboardingData.primarySkills.competencies.map((comp) => (
                        <Badge key={comp} variant="outline" className="bg-primary/5 gap-1">
                          {comp}
                          <button
                            type="button"
                            onClick={() => removePrimaryCompetency(comp)}
                            className="ml-1 hover:text-destructive"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Secondary Skills Section */}
            {selectedAgent && (
              <div className="space-y-4 p-4 border rounded-lg">
                <h3 className="font-semibold text-lg">Secondary Skills</h3>
                
                {/* Secondary Languages with Proficiency */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Languages & Proficiency</label>
                  <p className="text-xs text-muted-foreground">Add languages with proficiency level (1-5)</p>
                  <div className="flex gap-2">
                    <Select value={newSecondaryLanguage} onValueChange={setNewSecondaryLanguage}>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="English">English</SelectItem>
                        <SelectItem value="Hindi">Hindi</SelectItem>
                        <SelectItem value="Tamil">Tamil</SelectItem>
                        <SelectItem value="Telugu">Telugu</SelectItem>
                        <SelectItem value="Bengali">Bengali</SelectItem>
                        <SelectItem value="Kannada">Kannada</SelectItem>
                        <SelectItem value="Malayalam">Malayalam</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={newSecondaryProficiency} onValueChange={setNewSecondaryProficiency}>
                      <SelectTrigger className="w-24">
                        <SelectValue placeholder="Level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="5">5</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button type="button" variant="outline" onClick={addSecondaryLanguage} disabled={!newSecondaryLanguage}>
                      Add
                    </Button>
                  </div>
                  {onboardingData.secondarySkills.languages.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {onboardingData.secondarySkills.languages.map((lang) => (
                        <Badge key={lang.language} variant="outline" className="bg-background gap-1">
                          {lang.language} - {lang.proficiency}
                          <button
                            type="button"
                            onClick={() => removeSecondaryLanguage(lang.language)}
                            className="ml-1 hover:text-destructive"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                {/* Secondary Tags */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Tags</label>
                  <p className="text-xs text-muted-foreground">Special designations and categories</p>
                  <Select onValueChange={addSecondaryTag}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select tags to add" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACKO_existing">ACKO_existing</SelectItem>
                      <SelectItem value="VIP">VIP</SelectItem>
                    </SelectContent>
                  </Select>
                  {onboardingData.secondarySkills.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {onboardingData.secondarySkills.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="gap-1">
                          {tag}
                          <button
                            type="button"
                            onClick={() => removeSecondaryTag(tag)}
                            className="ml-1 hover:text-destructive"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                {/* Secondary Competencies */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Competencies</label>
                  <p className="text-xs text-muted-foreground">Core skills and capabilities</p>
                  <Select onValueChange={addSecondaryCompetency}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select competencies to add" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Bill Entry">Bill Entry</SelectItem>
                      <SelectItem value="Adjudication">Adjudication</SelectItem>
                      <SelectItem value="CRM">CRM</SelectItem>
                    </SelectContent>
                  </Select>
                  {onboardingData.secondarySkills.competencies.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {onboardingData.secondarySkills.competencies.map((comp) => (
                        <Badge key={comp} variant="outline" className="bg-primary/5 gap-1">
                          {comp}
                          <button
                            type="button"
                            onClick={() => removeSecondaryCompetency(comp)}
                            className="ml-1 hover:text-destructive"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Footer Buttons */}
          <div className="flex justify-end gap-3 pt-4 border-t mt-4">
            <Button variant="outline" onClick={() => {
              setIsAddDialogOpen(false);
              setSelectedAgent(null);
              setOnboardingSearch("");
            }}>
              Cancel
            </Button>
            <Button onClick={handleOnboardAgent} disabled={!selectedAgent}>
              Complete Onboarding
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Bulk Upload Dialog */}
      <Dialog open={isBulkUploadDialogOpen} onOpenChange={setIsBulkUploadDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Bulk Upload Agents</DialogTitle>
            <DialogDescription>
              Upload an Excel file with agent data to add multiple agents at once
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Template Download */}
            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div className="flex items-center gap-3">
                <FileSpreadsheet className="w-8 h-8 text-primary" />
                <div>
                  <h4 className="font-semibold">Need a template?</h4>
                  <p className="text-sm text-muted-foreground">Download our Excel template to get started</p>
                </div>
              </div>
              <Button variant="outline" onClick={downloadTemplate}>
                <Download className="w-4 h-4 mr-2" />
                Download Template
              </Button>
            </div>

            {/* File Upload */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Upload Excel File</label>
              <div className="flex items-center gap-4">
                <Input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileUpload}
                  className="flex-1"
                />
                {uploadedFile && (
                  <Badge variant="outline" className="gap-2">
                    <FileSpreadsheet className="w-4 h-4" />
                    {uploadedFile.name}
                  </Badge>
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                Supported formats: .xlsx, .xls
              </p>
            </div>

            {/* Preview Table */}
            {isProcessing && (
              <div className="flex items-center justify-center py-8">
                <div className="text-center space-y-2">
                  <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="text-sm text-muted-foreground">Processing file...</p>
                </div>
              </div>
            )}

            {!isProcessing && parsedAgents.length > 0 && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Preview ({parsedAgents.length} agents)</label>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Row</TableHead>
                        <TableHead>Full Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Phone</TableHead>
                        <TableHead>Seniority</TableHead>
                        <TableHead>Languages</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {parsedAgents.slice(0, 10).map((agent, index) => (
                        <TableRow key={index}>
                          <TableCell>{agent.rowNumber}</TableCell>
                          <TableCell className="font-medium">{agent.fullName}</TableCell>
                          <TableCell>{agent.email}</TableCell>
                          <TableCell>{agent.phone}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{agent.seniority}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1 flex-wrap">
                              {agent.languages.slice(0, 2).map((lang: string, i: number) => (
                                <Badge key={i} variant="secondary" className="text-xs">
                                  {lang}
                                </Badge>
                              ))}
                              {agent.languages.length > 2 && (
                                <Badge variant="secondary" className="text-xs">
                                  +{agent.languages.length - 2}
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  {parsedAgents.length > 10 && (
                    <div className="p-2 text-center text-sm text-muted-foreground bg-muted">
                      Showing 10 of {parsedAgents.length} agents
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Expected Format Info */}
            {!uploadedFile && (
              <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                <h4 className="font-semibold text-sm">Expected Excel Format:</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  <li><strong>Email</strong>: Agent's email address</li>
                  <li><strong>Phone</strong>: Contact number</li>
                  <li><strong>Seniority</strong>: Junior, Senior, or Lead</li>
                  <li><strong>Languages</strong>: Comma-separated list (e.g., "English, Hindi")</li>
                  <li><strong>Skills</strong>: Comma-separated list (e.g., "CRM, Adjudication")</li>
                  <li><strong>Team</strong>: Comma-separated list (e.g., "Retail, GMC")</li>
                </ul>
              </div>
            )}
          </div>

          {/* Footer Buttons */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button 
              variant="outline" 
              onClick={() => {
                setIsBulkUploadDialogOpen(false);
                setUploadedFile(null);
                setParsedAgents([]);
                if (fileInputRef.current) {
                  fileInputRef.current.value = '';
                }
              }}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleBulkUpload}
              disabled={parsedAgents.length === 0 || isProcessing}
            >
              Upload {parsedAgents.length > 0 && `(${parsedAgents.length})`} Agents
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Deactivate Agent Confirmation */}
      <AlertDialog open={!!deactivateAgentId} onOpenChange={() => setDeactivateAgentId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Deactivate Agent</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to deactivate this agent? They will no longer be able to access the system or be assigned new tasks.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeactivate} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Deactivate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
