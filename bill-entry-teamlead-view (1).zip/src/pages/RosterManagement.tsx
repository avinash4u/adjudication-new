import { useState, useRef } from "react";
import { Calendar, Clock, Users, ChevronLeft, ChevronRight, Upload, Download, FileText, Info, Search, Filter, CalendarDays, User, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import * as XLSX from "xlsx";
import { useToast } from "@/hooks/use-toast";

// Mock data for shifts
const shifts = [
  { 
    id: 1, 
    name: "Morning Shift", 
    time: "08:00 - 16:00", 
    agents: 8, 
    required: 10,
    skillsCovered: ["Spanish", "Claims Processing", "Technical Support"],
    skillsNeeded: ["French", "Escalations"]
  },
  { 
    id: 2, 
    name: "Afternoon Shift", 
    time: "12:00 - 20:00", 
    agents: 12, 
    required: 12,
    skillsCovered: ["Spanish", "French", "Claims Processing", "Technical Support", "Escalations"],
    skillsNeeded: []
  },
  { 
    id: 3, 
    name: "Evening Shift", 
    time: "16:00 - 00:00", 
    agents: 7, 
    required: 10,
    skillsCovered: ["Spanish", "Claims Processing"],
    skillsNeeded: ["French", "Technical Support", "Escalations"]
  },
  { 
    id: 4, 
    name: "Night Shift", 
    time: "00:00 - 08:00", 
    agents: 4, 
    required: 5,
    skillsCovered: ["Claims Processing", "Technical Support"],
    skillsNeeded: ["Spanish", "Escalations"]
  },
];

const agents = [
  { id: 1, name: "Sarah Johnson", status: "Available", shift: "Morning Shift", hours: 40, hoursLastWeek: 38, skills: ["Spanish", "Claims Processing"] },
  { id: 2, name: "Mike Chen", status: "On Leave", shift: "Afternoon Shift", hours: 32, hoursLastWeek: 40, skills: ["French", "Technical Support"] },
  { id: 3, name: "Priya Sharma", status: "Available", shift: "Evening Shift", hours: 38, hoursLastWeek: 35, skills: ["Spanish", "Claims Processing"] },
  { id: 4, name: "David Kim", status: "Available", shift: "Night Shift", hours: 35, hoursLastWeek: 32, skills: ["Technical Support", "Escalations"] },
  { id: 5, name: "Emma Wilson", status: "Available", shift: "Morning Shift", hours: 40, hoursLastWeek: 40, skills: ["Spanish", "Technical Support"] },
  { id: 6, name: "James Brown", status: "Sick Leave", shift: "Afternoon Shift", hours: 24, hoursLastWeek: 38, skills: ["French", "Escalations"] },
  { id: 7, name: "Lisa Anderson", status: "Available", shift: "Morning Shift", hours: 40, hoursLastWeek: 38, skills: ["Claims Processing", "Technical Support"] },
  { id: 8, name: "Robert Taylor", status: "Available", shift: "Morning Shift", hours: 38, hoursLastWeek: 40, skills: ["Spanish", "Claims Processing"] },
  { id: 9, name: "Maria Garcia", status: "Available", shift: "Morning Shift", hours: 40, hoursLastWeek: 40, skills: ["Spanish", "Technical Support"] },
  { id: 10, name: "John Smith", status: "Available", shift: "Morning Shift", hours: 40, hoursLastWeek: 38, skills: ["Claims Processing", "Escalations"] },
  { id: 11, name: "Jennifer Lee", status: "Available", shift: "Morning Shift", hours: 38, hoursLastWeek: 40, skills: ["Spanish", "Technical Support"] },
  { id: 12, name: "Michael Brown", status: "Available", shift: "Morning Shift", hours: 40, hoursLastWeek: 40, skills: ["Claims Processing", "French"] },
  { id: 13, name: "Amy Chen", status: "Available", shift: "Afternoon Shift", hours: 40, hoursLastWeek: 38, skills: ["Spanish", "Escalations"] },
  { id: 14, name: "Daniel Wilson", status: "Available", shift: "Afternoon Shift", hours: 38, hoursLastWeek: 40, skills: ["French", "Technical Support"] },
  { id: 15, name: "Sofia Martinez", status: "Available", shift: "Afternoon Shift", hours: 40, hoursLastWeek: 38, skills: ["Spanish", "Claims Processing"] },
  { id: 16, name: "Chris Davis", status: "Available", shift: "Afternoon Shift", hours: 40, hoursLastWeek: 40, skills: ["Technical Support", "Escalations"] },
  { id: 17, name: "Rachel Kim", status: "Available", shift: "Afternoon Shift", hours: 38, hoursLastWeek: 38, skills: ["French", "Claims Processing"] },
  { id: 18, name: "Tom Anderson", status: "Available", shift: "Afternoon Shift", hours: 40, hoursLastWeek: 40, skills: ["Spanish", "Technical Support"] },
  { id: 19, name: "Nina Patel", status: "Available", shift: "Afternoon Shift", hours: 40, hoursLastWeek: 38, skills: ["French", "Escalations"] },
  { id: 20, name: "Kevin Lee", status: "Available", shift: "Afternoon Shift", hours: 38, hoursLastWeek: 40, skills: ["Claims Processing", "Spanish"] },
  { id: 21, name: "Jessica Wang", status: "Available", shift: "Afternoon Shift", hours: 40, hoursLastWeek: 40, skills: ["French", "Technical Support"] },
  { id: 22, name: "Mark Johnson", status: "Available", shift: "Afternoon Shift", hours: 40, hoursLastWeek: 38, skills: ["Spanish", "Escalations"] },
  { id: 23, name: "Anna Rodriguez", status: "Available", shift: "Evening Shift", hours: 38, hoursLastWeek: 40, skills: ["Spanish", "Claims Processing"] },
  { id: 24, name: "Brian Taylor", status: "Available", shift: "Evening Shift", hours: 40, hoursLastWeek: 38, skills: ["Claims Processing", "Technical Support"] },
  { id: 25, name: "Sandra Miller", status: "Available", shift: "Evening Shift", hours: 40, hoursLastWeek: 40, skills: ["Spanish", "Claims Processing"] },
  { id: 26, name: "Paul Harris", status: "Available", shift: "Evening Shift", hours: 38, hoursLastWeek: 38, skills: ["Claims Processing", "Spanish"] },
  { id: 27, name: "Laura Martinez", status: "Available", shift: "Evening Shift", hours: 40, hoursLastWeek: 40, skills: ["Spanish", "Claims Processing"] },
  { id: 28, name: "Steven Clark", status: "Available", shift: "Evening Shift", hours: 40, hoursLastWeek: 38, skills: ["Claims Processing", "Spanish"] },
  { id: 29, name: "Catherine Brown", status: "Available", shift: "Night Shift", hours: 38, hoursLastWeek: 40, skills: ["Claims Processing", "Technical Support"] },
  { id: 30, name: "George Wilson", status: "Available", shift: "Night Shift", hours: 40, hoursLastWeek: 38, skills: ["Technical Support", "Claims Processing"] },
  { id: 31, name: "Patricia Davis", status: "Available", shift: "Night Shift", hours: 40, hoursLastWeek: 40, skills: ["Claims Processing", "Escalations"] },
];

const weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const RosterManagement = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [isManageRosterOpen, setIsManageRosterOpen] = useState(false);
  const [isManageShiftsOpen, setIsManageShiftsOpen] = useState(false);
  const [isShiftTimingsOpen, setIsShiftTimingsOpen] = useState(false);
  const [selectedShift, setSelectedShift] = useState<typeof shifts[0] | null>(null);
  const [selectedDay, setSelectedDay] = useState<string>("");
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [filterShift, setFilterShift] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [searchAgent, setSearchAgent] = useState<string>("");
  const [selectedAgentId, setSelectedAgentId] = useState<string>("");
  const [calendarDate, setCalendarDate] = useState<Date | undefined>(new Date());
  const [dateRange, setDateRange] = useState<string>("week");
  const [searchAgentAvailability, setSearchAgentAvailability] = useState<string>("");
  const [filterShiftAvailability, setFilterShiftAvailability] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("name");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [newShift, setNewShift] = useState({ name: "", startTime: "", endTime: "", required: 0 });
  const [editingShift, setEditingShift] = useState<number | null>(null);
  const [assignShiftId, setAssignShiftId] = useState<number | null>(null);
  const [selectedAgentsForShift, setSelectedAgentsForShift] = useState<number[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const downloadTemplate = () => {
    // Create template data
    const templateData = [
      {
        "Agent Name": "John Doe",
        "Status": "Available",
        "Shift": "Morning Shift",
        "Date": "2025-01-01",
        "Hours": 8
      },
      {
        "Agent Name": "Jane Smith",
        "Status": "Available",
        "Shift": "Afternoon Shift",
        "Date": "2025-01-01",
        "Hours": 8
      },
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Roster Template");
    
    // Generate and download the file
    XLSX.writeFile(workbook, "roster_template.xlsx");
    
    toast({
      title: "Template Downloaded",
      description: "The roster template has been downloaded successfully.",
    });
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: "array" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        console.log("Uploaded roster data:", jsonData);
        
        toast({
          title: "Roster Uploaded",
          description: `Successfully uploaded ${jsonData.length} roster entries.`,
        });
        
        setIsUploadDialogOpen(false);
        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }
      } catch (error) {
        toast({
          title: "Upload Failed",
          description: "Failed to parse the Excel file. Please check the format.",
          variant: "destructive",
        });
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const getStatusColor = (agents: number, required: number) => {
    const percentage = (agents / required) * 100;
    if (percentage >= 100) return "text-status-on-track";
    if (percentage >= 80) return "text-status-at-risk";
    return "text-status-breached";
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Available":
        return <Badge className="bg-status-on-track/10 text-status-on-track border-status-on-track/20">Available</Badge>;
      case "On Leave":
        return <Badge className="bg-status-at-risk/10 text-status-at-risk border-status-at-risk/20">On Leave</Badge>;
      case "Sick Leave":
        return <Badge className="bg-status-breached/10 text-status-breached border-status-breached/20">Sick Leave</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="flex items-center justify-between px-6 py-4">
          <h1 className="text-2xl font-semibold">Roster Management</h1>
          <div className="flex items-center gap-4">
            <Button variant="outline" className="gap-2" onClick={() => setIsManageRosterOpen(true)}>
              <Settings className="w-4 h-4" />
              Manage Roster
            </Button>
            
            <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Upload className="w-4 h-4" />
                  Upload Monthly Roster
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Upload className="w-5 h-5" />
                    Upload Monthly Roster
                  </DialogTitle>
                </DialogHeader>
                
                <div className="space-y-6 py-4">
                  {/* Info Alert */}
                  <Alert className="bg-muted/50">
                    <Info className="h-4 w-4" />
                    <AlertDescription className="ml-2">
                      Download the CSV template first to ensure proper formatting.
                      <button
                        onClick={downloadTemplate}
                        className="ml-2 text-primary hover:underline inline-flex items-center gap-1 font-medium"
                      >
                        <Download className="w-4 h-4" />
                        Download Template
                      </button>
                    </AlertDescription>
                  </Alert>

                  {/* Drop Zone */}
                  <div className="border-2 border-dashed border-border rounded-lg bg-muted/30 p-12 text-center space-y-6">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleFileUpload}
                      className="hidden"
                      id="roster-upload"
                    />
                    
                    <label
                      htmlFor="roster-upload"
                      className="cursor-pointer flex flex-col items-center gap-4"
                    >
                      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                        <FileText className="w-8 h-8 text-muted-foreground" />
                      </div>
                      <div className="space-y-2">
                        <p className="text-lg font-medium">Drop your CSV file here</p>
                        <p className="text-sm text-muted-foreground">or click to browse files</p>
                      </div>
                    </label>

                    <Button
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      className="mt-4"
                    >
                      Select CSV File
                    </Button>
                  </div>

                  {/* Format Requirements */}
                  <div className="space-y-4">
                    <h4 className="font-semibold text-base">CSV Format Requirements:</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex gap-2">
                        <span className="text-foreground">•</span>
                        <span>Include headers: Agent ID, Email, Phone, Week Start Date</span>
                      </li>
                      <li className="flex gap-2">
                        <span className="text-foreground">•</span>
                        <span>Shift formats: Morning (9-17), Evening (17-1), Night (1-9), Off</span>
                      </li>
                      <li className="flex gap-2">
                        <span className="text-foreground">•</span>
                        <span>Leave types: Sick Leave, Planned Leave, First Half, Second Half</span>
                      </li>
                      <li className="flex gap-2">
                        <span className="text-foreground">•</span>
                        <span>Date format: YYYY-MM-DD</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <DialogFooter className="gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsUploadDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button onClick={() => fileInputRef.current?.click()}>
                    Upload Roster
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Manage Roster Dialog - Agent Assignment */}
            <Dialog open={isManageRosterOpen} onOpenChange={setIsManageRosterOpen}>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Settings className="w-5 h-5" />
                    Manage Roster - Agent Assignment
                  </DialogTitle>
                  <DialogDescription>
                    Assign agents to shifts. For shift management and timings, use the buttons below.
                  </DialogDescription>
                </DialogHeader>

                <div className="space-y-4">
                  {/* CTAs for less frequent actions */}
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      className="flex-1"
                      onClick={() => setIsManageShiftsOpen(true)}
                    >
                      Manage Shifts
                    </Button>
                    <Button 
                      variant="outline" 
                      className="flex-1"
                      onClick={() => setIsShiftTimingsOpen(true)}
                    >
                      Shift Timings
                    </Button>
                  </div>

                  <Separator />

                  {/* Agent Assignment Section */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Assign Agents to Shift</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label>Select Shift</Label>
                        <Select
                          value={assignShiftId?.toString() || ""}
                          onValueChange={(value) => {
                            const shiftId = parseInt(value);
                            setAssignShiftId(shiftId);
                            // Pre-select agents already in this shift
                            const agentsInShift = agents
                              .filter(a => a.shift === shifts.find(s => s.id === shiftId)?.name)
                              .map(a => a.id);
                            setSelectedAgentsForShift(agentsInShift);
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Choose a shift" />
                          </SelectTrigger>
                          <SelectContent>
                            {shifts.map((shift) => (
                              <SelectItem key={shift.id} value={shift.id.toString()}>
                                {shift.name} ({shift.agents})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {assignShiftId && (
                        <>
                          <Separator />
                          <div className="space-y-2">
                            <Label>Available Agents</Label>
                            <div className="border rounded-lg max-h-[300px] overflow-y-auto">
                              <Table>
                                <TableHeader className="sticky top-0 bg-background">
                                  <TableRow>
                                    <TableHead className="w-12"></TableHead>
                                    <TableHead>Agent Name</TableHead>
                                    <TableHead>Current Shift</TableHead>
                                    <TableHead>Status</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {agents.map((agent) => (
                                    <TableRow key={agent.id}>
                                      <TableCell>
                                        <Checkbox
                                          checked={selectedAgentsForShift.includes(agent.id)}
                                          onCheckedChange={(checked) => {
                                            if (checked) {
                                              setSelectedAgentsForShift([...selectedAgentsForShift, agent.id]);
                                            } else {
                                              setSelectedAgentsForShift(selectedAgentsForShift.filter(id => id !== agent.id));
                                            }
                                          }}
                                        />
                                      </TableCell>
                                      <TableCell className="font-medium">{agent.name}</TableCell>
                                      <TableCell>{agent.shift}</TableCell>
                                      <TableCell>{getStatusBadge(agent.status)}</TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                            <span className="text-sm font-medium">
                              Selected: {selectedAgentsForShift.length} agents
                            </span>
                            <Button 
                              onClick={() => {
                                toast({
                                  title: "Assignments Updated",
                                  description: `${selectedAgentsForShift.length} agents have been assigned to ${shifts.find(s => s.id === assignShiftId)?.name}.`,
                                });
                                setAssignShiftId(null);
                                setSelectedAgentsForShift([]);
                              }}
                            >
                              Save Assignments
                            </Button>
                          </div>
                        </>
                      )}
                    </CardContent>
                  </Card>
                </div>

                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsManageRosterOpen(false)}>
                    Close
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Manage Shifts Dialog */}
            <Dialog open={isManageShiftsOpen} onOpenChange={setIsManageShiftsOpen}>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Settings className="w-5 h-5" />
                    Manage Shifts
                  </DialogTitle>
                  <DialogDescription>
                    Create new shifts and manage existing ones.
                  </DialogDescription>
                </DialogHeader>

                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Create New Shift</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="shift-name">Shift Name</Label>
                          <Input
                            id="shift-name"
                            placeholder="e.g., Morning Shift"
                            value={newShift.name}
                            onChange={(e) => setNewShift({ ...newShift, name: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="required-agents">Required Agents</Label>
                          <Input
                            id="required-agents"
                            type="number"
                            placeholder="0"
                            value={newShift.required || ""}
                            onChange={(e) => setNewShift({ ...newShift, required: parseInt(e.target.value) || 0 })}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="start-time">Start Time</Label>
                          <Input
                            id="start-time"
                            type="time"
                            value={newShift.startTime}
                            onChange={(e) => setNewShift({ ...newShift, startTime: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="end-time">End Time</Label>
                          <Input
                            id="end-time"
                            type="time"
                            value={newShift.endTime}
                            onChange={(e) => setNewShift({ ...newShift, endTime: e.target.value })}
                          />
                        </div>
                      </div>
                      <Button 
                        onClick={() => {
                          if (newShift.name && newShift.startTime && newShift.endTime && newShift.required > 0) {
                            toast({
                              title: "Shift Created",
                              description: `${newShift.name} has been created successfully.`,
                            });
                            setNewShift({ name: "", startTime: "", endTime: "", required: 0 });
                          } else {
                            toast({
                              title: "Error",
                              description: "Please fill in all fields.",
                              variant: "destructive",
                            });
                          }
                        }}
                        className="w-full"
                      >
                        Create Shift
                      </Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Existing Shifts</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Shift Name</TableHead>
                            <TableHead>Time</TableHead>
                            <TableHead>Current Agents</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {shifts.map((shift) => (
                            <TableRow key={shift.id}>
                              <TableCell className="font-medium">{shift.name}</TableCell>
                              <TableCell>{shift.time}</TableCell>
                              <TableCell>
                                <span className={getStatusColor(shift.agents, shift.required)}>
                                  {shift.agents}
                                </span>
                              </TableCell>
                              <TableCell className="text-right">
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => {
                                    setEditingShift(shift.id);
                                    setIsManageShiftsOpen(false);
                                    setIsShiftTimingsOpen(true);
                                  }}
                                >
                                  Edit
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                </div>

                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsManageShiftsOpen(false)}>
                    Close
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Shift Timings Dialog */}
            <Dialog open={isShiftTimingsOpen} onOpenChange={setIsShiftTimingsOpen}>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Shift Timings
                  </DialogTitle>
                  <DialogDescription>
                    Update shift timings and required agent counts.
                  </DialogDescription>
                </DialogHeader>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Edit Shift Timings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>Select Shift</Label>
                      <Select
                        value={editingShift?.toString() || ""}
                        onValueChange={(value) => setEditingShift(parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a shift to edit" />
                        </SelectTrigger>
                        <SelectContent>
                          {shifts.map((shift) => (
                            <SelectItem key={shift.id} value={shift.id.toString()}>
                              {shift.name} - {shift.time}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {editingShift && (
                      <>
                        <Separator />
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Start Time</Label>
                            <Input
                              type="time"
                              defaultValue={shifts.find(s => s.id === editingShift)?.time.split(" - ")[0]}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>End Time</Label>
                            <Input
                              type="time"
                              defaultValue={shifts.find(s => s.id === editingShift)?.time.split(" - ")[1]}
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label>Required Agents</Label>
                          <Input
                            type="number"
                            defaultValue={shifts.find(s => s.id === editingShift)?.required}
                          />
                        </div>
                        <Button 
                          onClick={() => {
                            toast({
                              title: "Timing Updated",
                              description: "Shift timing has been updated successfully.",
                            });
                            setEditingShift(null);
                          }}
                          className="w-full"
                        >
                          Update Shift Timing
                        </Button>
                      </>
                    )}
                  </CardContent>
                </Card>

                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsShiftTimingsOpen(false)}>
                    Close
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <main className="p-6">
        <Tabs defaultValue="today" className="space-y-6">
          <TabsList>
            <TabsTrigger value="today">Today</TabsTrigger>
            <TabsTrigger value="weekly">Weekly</TabsTrigger>
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
            <TabsTrigger value="agents">Agent Availability</TabsTrigger>
            <TabsTrigger value="agent-calendar">Agent Calendar</TabsTrigger>
          </TabsList>

          <TabsContent value="today" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Agent Availability Today
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Filters */}
                <div className="flex flex-wrap gap-4 mb-4">
                  <div className="relative flex-1 min-w-[200px]">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder="Search agents..."
                      value={searchAgent}
                      onChange={(e) => setSearchAgent(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={filterShift} onValueChange={setFilterShift}>
                    <SelectTrigger className="w-[180px]">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue placeholder="Filter by shift" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover z-50">
                      <SelectItem value="all">All Shifts</SelectItem>
                      {shifts.map((shift) => (
                        <SelectItem key={shift.id} value={shift.name}>
                          {shift.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-[180px]">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover z-50">
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="Available">Available</SelectItem>
                      <SelectItem value="On Leave">On Leave</SelectItem>
                      <SelectItem value="Sick Leave">Sick Leave</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Agent Name</TableHead>
                      <TableHead>Assigned Shift</TableHead>
                      <TableHead>Shift Time</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {agents
                      .filter(agent => {
                        const matchesSearch = agent.name.toLowerCase().includes(searchAgent.toLowerCase());
                        const matchesShift = filterShift === "all" || agent.shift === filterShift;
                        const matchesStatus = filterStatus === "all" || agent.status === filterStatus;
                        return matchesSearch && matchesShift && matchesStatus;
                      })
                      .map((agent) => (
                        <TableRow key={agent.id}>
                          <TableCell className="font-medium">{agent.name}</TableCell>
                          <TableCell>{agent.shift}</TableCell>
                          <TableCell className="text-muted-foreground">
                            {shifts.find(s => s.name === agent.shift)?.time}
                          </TableCell>
                          <TableCell>
                            <Badge variant={agent.status === "Available" ? "default" : "secondary"}>
                              {agent.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="weekly" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Schedule</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Shift</TableHead>
                        {weekDays.map((day) => (
                          <TableHead key={day} className="text-center">{day}</TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {shifts.map((shift) => (
                        <TableRow key={shift.id}>
                          <TableCell className="font-medium">{shift.name} ({shift.time})</TableCell>
                          {weekDays.map((day) => (
                            <TableCell key={day} className="text-center">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-auto py-1 px-2 font-semibold"
                                onClick={() => {
                                  setSelectedShift(shift);
                                  setSelectedDay(day);
                                }}
                              >
                                {shift.agents}
                              </Button>
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monthly" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-2 mb-4">
                  {weekDays.map((day) => (
                    <div key={day} className="text-center text-sm font-medium text-muted-foreground p-2">
                      {day}
                    </div>
                  ))}
                  {Array.from({ length: 35 }, (_, i) => {
                    const dayNum = i - 2; // Starting offset
                    const isCurrentMonth = dayNum > 0 && dayNum <= 30;
                    const dayName = weekDays[i % 7];
                    return (
                      <button
                        key={i}
                        className={`aspect-square border rounded-lg p-2 text-left ${
                          isCurrentMonth 
                            ? "bg-card border-border hover:bg-accent cursor-pointer transition-colors" 
                            : "bg-muted/30 border-transparent cursor-default"
                        }`}
                        onClick={() => {
                          if (isCurrentMonth) {
                            setSelectedDate(`${dayName}, Day ${dayNum}`);
                            setSelectedShift(null);
                          }
                        }}
                        disabled={!isCurrentMonth}
                      >
                        {isCurrentMonth && (
                          <>
                            <div className="text-xs font-medium mb-1">{dayNum}</div>
                            <div className="text-xs text-status-on-track">✓</div>
                          </>
                        )}
                      </button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="agents" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Agent Availability
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Filters and Sort */}
                <div className="flex flex-wrap gap-4 mb-4">
                  <div className="relative flex-1 min-w-[200px]">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder="Search agents..."
                      value={searchAgentAvailability}
                      onChange={(e) => setSearchAgentAvailability(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={filterShiftAvailability} onValueChange={setFilterShiftAvailability}>
                    <SelectTrigger className="w-[180px]">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue placeholder="Filter by shift" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover z-50">
                      <SelectItem value="all">All Shifts</SelectItem>
                      {shifts.map((shift) => (
                        <SelectItem key={shift.id} value={shift.name}>
                          {shift.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover z-50">
                      <SelectItem value="name">Name</SelectItem>
                      <SelectItem value="hoursThisWeek">Hours This Week</SelectItem>
                      <SelectItem value="hoursLastWeek">Hours Last Week</SelectItem>
                      <SelectItem value="trend">Trend</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
                    className="w-10"
                  >
                    {sortOrder === "asc" ? "↑" : "↓"}
                  </Button>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Agent Name</TableHead>
                      <TableHead>Assigned Shift</TableHead>
                      <TableHead className="text-right">Hours This Week</TableHead>
                      <TableHead className="text-right">Hours Last Week</TableHead>
                      <TableHead className="text-right">Trend</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {agents
                      .filter(agent => {
                        const matchesSearch = agent.name.toLowerCase().includes(searchAgentAvailability.toLowerCase());
                        const matchesShift = filterShiftAvailability === "all" || agent.shift === filterShiftAvailability;
                        return matchesSearch && matchesShift;
                      })
                      .sort((a, b) => {
                        let compareValue = 0;
                        switch (sortBy) {
                          case "name":
                            compareValue = a.name.localeCompare(b.name);
                            break;
                          case "hoursThisWeek":
                            compareValue = a.hours - b.hours;
                            break;
                          case "hoursLastWeek":
                            compareValue = a.hoursLastWeek - b.hoursLastWeek;
                            break;
                          case "trend":
                            const trendA = a.hours - a.hoursLastWeek;
                            const trendB = b.hours - b.hoursLastWeek;
                            compareValue = trendA - trendB;
                            break;
                        }
                        return sortOrder === "asc" ? compareValue : -compareValue;
                      })
                      .map((agent) => {
                        const trend = agent.hours - agent.hoursLastWeek;
                        const trendPercent = agent.hoursLastWeek > 0 ? ((trend / agent.hoursLastWeek) * 100).toFixed(0) : '0';
                        return (
                          <TableRow key={agent.id}>
                            <TableCell className="font-medium">{agent.name}</TableCell>
                            <TableCell>{agent.shift}</TableCell>
                            <TableCell className="text-right">{agent.hours}h</TableCell>
                            <TableCell className="text-right text-muted-foreground">{agent.hoursLastWeek}h</TableCell>
                            <TableCell className="text-right">
                              <span className={`inline-flex items-center gap-1 text-sm ${
                                trend > 0 ? 'text-status-on-track' : trend < 0 ? 'text-destructive' : 'text-muted-foreground'
                              }`}>
                                {trend > 0 ? '↑' : trend < 0 ? '↓' : '→'} {Math.abs(trend)}h ({trend > 0 ? '+' : ''}{trendPercent}%)
                              </span>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="agent-calendar" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CalendarDays className="w-5 h-5" />
                  Agent Calendar View
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Agent Selection */}
                <div className="space-y-4">
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-medium">Select Agent</label>
                    <Select value={selectedAgentId} onValueChange={setSelectedAgentId}>
                      <SelectTrigger className="w-full max-w-md">
                        <User className="w-4 h-4 mr-2" />
                        <SelectValue placeholder="Choose an agent to view availability" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover z-50">
                        {agents.map((agent) => (
                          <SelectItem key={agent.id} value={agent.id.toString()}>
                            {agent.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedAgentId && (
                    <>
                      {/* Agent Details */}
                      <Card className="bg-muted/20">
                        <CardContent className="pt-6">
                          <div className="flex items-start justify-between">
                            <div className="space-y-2">
                              <h3 className="text-lg font-semibold">
                                {agents.find(a => a.id.toString() === selectedAgentId)?.name}
                              </h3>
                              <div className="flex flex-wrap gap-3 text-sm">
                                <div className="flex items-center gap-1">
                                  <Clock className="w-4 h-4 text-muted-foreground" />
                                  <span>{agents.find(a => a.id.toString() === selectedAgentId)?.shift}</span>
                                </div>
                                <Badge variant={
                                  agents.find(a => a.id.toString() === selectedAgentId)?.status === "Available" 
                                    ? "default" 
                                    : "secondary"
                                }>
                                  {agents.find(a => a.id.toString() === selectedAgentId)?.status}
                                </Badge>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-2xl font-bold">
                                {agents.find(a => a.id.toString() === selectedAgentId)?.hours}h
                              </p>
                              <p className="text-sm text-muted-foreground">This Week</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Calendar View */}
                      <div className="space-y-4">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                          <h4 className="font-semibold">Availability Calendar</h4>
                          <div className="flex flex-wrap items-center gap-2">
                            {/* Date Range Selector */}
                            <Select value={dateRange} onValueChange={setDateRange}>
                              <SelectTrigger className="w-[140px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-popover z-50">
                                <SelectItem value="day">1 Day</SelectItem>
                                <SelectItem value="week">1 Week</SelectItem>
                                <SelectItem value="month">1 Month</SelectItem>
                              </SelectContent>
                            </Select>
                            
                            {/* Date Picker */}
                            <Popover>
                              <PopoverTrigger asChild>
                                <Button variant="outline" className="w-[240px] justify-start text-left">
                                  <CalendarDays className="mr-2 h-4 w-4" />
                                  {calendarDate ? format(calendarDate, "PPP") : <span>Pick a date</span>}
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0 z-50" align="start">
                                <CalendarComponent
                                  mode="single"
                                  selected={calendarDate}
                                  onSelect={setCalendarDate}
                                  initialFocus
                                  className={cn("p-3 pointer-events-auto")}
                                />
                              </PopoverContent>
                            </Popover>
                          </div>
                        </div>

                        {/* Dynamic Schedule View */}
                        <div className={`grid gap-2 ${
                          dateRange === "day" ? "grid-cols-1" : 
                          dateRange === "week" ? "grid-cols-7" : 
                          "grid-cols-7"
                        }`}>
                          {(() => {
                            const agent = agents.find(a => a.id.toString() === selectedAgentId);
                            const isAvailable = agent?.status === "Available";
                            const shiftTime = shifts.find(s => s.name === agent?.shift)?.time;
                            
                            // Generate days based on selected range
                            const getDaysToShow = () => {
                              if (dateRange === "day") {
                                return [{ day: format(calendarDate || new Date(), "EEEE"), date: format(calendarDate || new Date(), "d") }];
                              } else if (dateRange === "week") {
                                return weekDays.map((day, index) => ({ day, date: (index + 1).toString() }));
                              } else {
                                // Month view - show 4 weeks
                                const daysInRange = [];
                                for (let i = 0; i < 28; i++) {
                                  const dayName = weekDays[i % 7];
                                  daysInRange.push({ day: dayName, date: (i + 1).toString() });
                                }
                                return daysInRange;
                              }
                            };

                            return getDaysToShow().map((dayInfo, index) => (
                              <Card key={index} className="overflow-hidden">
                                <CardHeader className={`pb-2 pt-3 px-3 ${dateRange === "day" ? "text-center" : ""}`}>
                                  <div className={`text-xs font-medium ${dateRange === "day" ? "text-lg" : "text-center"}`}>
                                    {dayInfo.day}
                                  </div>
                                  <div className={`text-lg font-bold ${dateRange === "day" ? "text-2xl" : "text-center"}`}>
                                    {dayInfo.date}
                                  </div>
                                </CardHeader>
                                <CardContent className="px-3 pb-3">
                                  <div className="space-y-2">
                                    <Badge 
                                      variant={isAvailable ? "default" : "secondary"}
                                      className="w-full justify-center text-xs"
                                    >
                                      {isAvailable ? "Available" : agent?.status}
                                    </Badge>
                                    {isAvailable && shiftTime && (
                                      <div className="text-xs text-center text-muted-foreground">
                                        {shiftTime}
                                      </div>
                                    )}
                                    {dateRange === "day" && (
                                      <div className="mt-3 space-y-1 text-sm">
                                        <div className="flex justify-between">
                                          <span className="text-muted-foreground">Hours Today:</span>
                                          <span className="font-semibold">8h</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-muted-foreground">Shift:</span>
                                          <span className="font-semibold">{agent?.shift}</span>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                </CardContent>
                              </Card>
                            ));
                          })()}
                        </div>

                        {/* Summary Card */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-base">
                              {dateRange === "day" ? "Day" : dateRange === "week" ? "Week" : "Month"} Summary
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                              <div className="space-y-1">
                                <p className="text-sm text-muted-foreground">Total Hours</p>
                                <p className="text-2xl font-bold">
                                  {dateRange === "day" ? "8" : dateRange === "week" ? "40" : agents.find(a => a.id.toString() === selectedAgentId)?.hours}h
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-sm text-muted-foreground">Days Available</p>
                                <p className="text-2xl font-bold text-status-on-track">
                                  {dateRange === "day" ? "1" : dateRange === "week" ? "7" : "28"}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-sm text-muted-foreground">Leave Days</p>
                                <p className="text-2xl font-bold text-muted-foreground">
                                  {dateRange === "day" ? "0" : dateRange === "week" ? "0" : "2"}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-sm text-muted-foreground">Shift Type</p>
                                <Badge variant="outline" className="mt-1">
                                  {agents.find(a => a.id.toString() === selectedAgentId)?.shift}
                                </Badge>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </>
                  )}

                  {!selectedAgentId && (
                    <Alert>
                      <Info className="h-4 w-4" />
                      <AlertDescription>
                        Select an agent above to view their availability calendar across weeks and months.
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Shift Details Dialog */}
        <Dialog open={!!selectedShift} onOpenChange={() => setSelectedShift(null)}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                {selectedShift?.name} - {selectedDay}
              </DialogTitle>
              <DialogDescription>
                {selectedShift?.time} | {selectedShift?.agents} agents assigned
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              {/* Skills Overview */}
              <div>
                <h4 className="font-semibold mb-2 text-sm flex items-center gap-2">
                  Skills Covered
                </h4>
                <div className="flex flex-wrap gap-1">
                  {selectedShift?.skillsCovered && selectedShift.skillsCovered.length > 0 ? (
                    selectedShift.skillsCovered.map((skill, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs bg-status-on-track/10 text-status-on-track border-status-on-track/20">
                        {skill}
                      </Badge>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No skills covered</p>
                  )}
                </div>
              </div>

              {/* Assigned Agents */}
              <div>
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Assigned Agents ({selectedShift?.agents})
                </h4>
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {agents
                    .filter(agent => agent.shift === selectedShift?.name)
                    .map(agent => (
                      <div key={agent.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <p className="font-medium">{agent.name}</p>
                          <p className="text-sm text-muted-foreground">{agent.hours}h this week</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {agent.skills.map((skill, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <Badge variant={agent.status === "Available" ? "default" : "secondary"}>
                          {agent.status}
                        </Badge>
                      </div>
                    ))}
                </div>
              </div>

              {/* Fully Staffed Message */}
              {selectedShift && selectedShift.agents >= selectedShift.required && (
                <Alert>
                  <AlertDescription className="text-status-on-track">
                    ✓ This shift is fully staffed
                  </AlertDescription>
                </Alert>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedShift(null)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* All Shifts for Date Dialog */}
        <Dialog open={!!selectedDate} onOpenChange={() => setSelectedDate("")}>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                All Shifts - {selectedDate}
              </DialogTitle>
              <DialogDescription>
                Overview of all shifts and their coverage for this date
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 max-h-[500px] overflow-y-auto">
              {shifts.map((shift) => {
                const shiftAgents = agents.filter(agent => agent.shift === shift.name);
                return (
                  <Card key={shift.id}>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          {shift.name}
                        </div>
                        <span className="text-sm font-bold">
                          {shift.agents} agents
                        </span>
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">{shift.time}</p>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {/* Skills Section */}
                        <div className="pb-2 border-b">
                          <p className="text-xs text-muted-foreground mb-1">Skills Covered</p>
                          <div className="flex flex-wrap gap-1">
                            {shift.skillsCovered.length > 0 ? (
                              shift.skillsCovered.slice(0, 2).map((skill, idx) => (
                                <Badge key={idx} variant="outline" className="text-xs bg-status-on-track/10 text-status-on-track border-status-on-track/20">
                                  {skill}
                                </Badge>
                              ))
                            ) : (
                              <span className="text-xs text-muted-foreground">None</span>
                            )}
                            {shift.skillsCovered.length > 2 && (
                              <Badge variant="outline" className="text-xs">+{shift.skillsCovered.length - 2}</Badge>
                            )}
                          </div>
                        </div>
                        
                        {/* Agents Section */}
                        <div>
                          <p className="text-sm font-medium mb-2">Assigned Agents:</p>
                          <div className="space-y-1.5">
                            {shiftAgents.slice(0, 3).map(agent => (
                              <div key={agent.id} className="flex items-center justify-between text-sm p-2 border rounded">
                                <span>{agent.name}</span>
                                <Badge variant={agent.status === "Available" ? "default" : "secondary"} className="text-xs">
                                  {agent.status}
                                </Badge>
                              </div>
                            ))}
                            {shiftAgents.length > 3 && (
                              <p className="text-xs text-muted-foreground text-center py-1">
                                +{shiftAgents.length - 3} more agents
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedDate("")}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
};

export default RosterManagement;
