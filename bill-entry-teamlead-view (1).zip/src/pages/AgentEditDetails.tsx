import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AgentEditDetails() {
  const navigate = useNavigate();
  const { agentId } = useParams();
  const { toast } = useToast();

  // Mock data - in real app, fetch based on agentId
  const [agentData, setAgentData] = useState({
    fullName: "Priya Sharma",
    phone: "+91 98765 43210",
    email: "priya.sharma@acko.com",
    seniority: "Senior",
    primarySkills: {
      languages: [
        { language: "English", proficiency: 4 },
        { language: "Hindi", proficiency: 5 },
      ],
      tags: ["ACKO_existing", "VIP"],
      competencies: ["Bill Entry", "Adjudication"],
    },
    secondarySkills: {
      languages: [
        { language: "Tamil", proficiency: 3 },
      ],
      tags: [],
      competencies: ["CRM"],
    },
    performanceRating: "Excellent",
  });

  const [newPrimaryLanguage, setNewPrimaryLanguage] = useState("");
  const [newPrimaryProficiency, setNewPrimaryProficiency] = useState("3");
  const [newSecondaryLanguage, setNewSecondaryLanguage] = useState("");
  const [newSecondaryProficiency, setNewSecondaryProficiency] = useState("3");

  // Primary Skills Functions
  const addPrimaryLanguage = () => {
    if (newPrimaryLanguage && !agentData.primarySkills.languages.some(l => l.language === newPrimaryLanguage)) {
      setAgentData({ 
        ...agentData, 
        primarySkills: {
          ...agentData.primarySkills,
          languages: [...agentData.primarySkills.languages, { language: newPrimaryLanguage, proficiency: parseInt(newPrimaryProficiency) }] 
        }
      });
      setNewPrimaryLanguage("");
      setNewPrimaryProficiency("3");
    }
  };

  const removePrimaryLanguage = (language: string) => {
    setAgentData({ 
      ...agentData, 
      primarySkills: {
        ...agentData.primarySkills,
        languages: agentData.primarySkills.languages.filter(l => l.language !== language)
      }
    });
  };

  const addPrimaryTag = (tag: string) => {
    if (!agentData.primarySkills.tags.includes(tag)) {
      setAgentData({ 
        ...agentData, 
        primarySkills: {
          ...agentData.primarySkills,
          tags: [...agentData.primarySkills.tags, tag]
        }
      });
    }
  };

  const removePrimaryTag = (tag: string) => {
    setAgentData({ 
      ...agentData, 
      primarySkills: {
        ...agentData.primarySkills,
        tags: agentData.primarySkills.tags.filter(t => t !== tag)
      }
    });
  };

  const addPrimaryCompetency = (competency: string) => {
    if (!agentData.primarySkills.competencies.includes(competency)) {
      setAgentData({ 
        ...agentData, 
        primarySkills: {
          ...agentData.primarySkills,
          competencies: [...agentData.primarySkills.competencies, competency]
        }
      });
    }
  };

  const removePrimaryCompetency = (competency: string) => {
    setAgentData({ 
      ...agentData, 
      primarySkills: {
        ...agentData.primarySkills,
        competencies: agentData.primarySkills.competencies.filter(c => c !== competency)
      }
    });
  };

  // Secondary Skills Functions
  const addSecondaryLanguage = () => {
    if (newSecondaryLanguage && !agentData.secondarySkills.languages.some(l => l.language === newSecondaryLanguage)) {
      setAgentData({ 
        ...agentData, 
        secondarySkills: {
          ...agentData.secondarySkills,
          languages: [...agentData.secondarySkills.languages, { language: newSecondaryLanguage, proficiency: parseInt(newSecondaryProficiency) }] 
        }
      });
      setNewSecondaryLanguage("");
      setNewSecondaryProficiency("3");
    }
  };

  const removeSecondaryLanguage = (language: string) => {
    setAgentData({ 
      ...agentData, 
      secondarySkills: {
        ...agentData.secondarySkills,
        languages: agentData.secondarySkills.languages.filter(l => l.language !== language)
      }
    });
  };

  const addSecondaryTag = (tag: string) => {
    if (!agentData.secondarySkills.tags.includes(tag)) {
      setAgentData({ 
        ...agentData, 
        secondarySkills: {
          ...agentData.secondarySkills,
          tags: [...agentData.secondarySkills.tags, tag]
        }
      });
    }
  };

  const removeSecondaryTag = (tag: string) => {
    setAgentData({ 
      ...agentData, 
      secondarySkills: {
        ...agentData.secondarySkills,
        tags: agentData.secondarySkills.tags.filter(t => t !== tag)
      }
    });
  };

  const addSecondaryCompetency = (competency: string) => {
    if (!agentData.secondarySkills.competencies.includes(competency)) {
      setAgentData({ 
        ...agentData, 
        secondarySkills: {
          ...agentData.secondarySkills,
          competencies: [...agentData.secondarySkills.competencies, competency]
        }
      });
    }
  };

  const removeSecondaryCompetency = (competency: string) => {
    setAgentData({ 
      ...agentData, 
      secondarySkills: {
        ...agentData.secondarySkills,
        competencies: agentData.secondarySkills.competencies.filter(c => c !== competency)
      }
    });
  };

  const handleSave = () => {
    // Handle save logic here
    console.log("Saving agent data:", agentData);
    toast({
      title: "Success",
      description: "Agent details updated successfully",
    });
    navigate(`/agents/${agentId}/profile`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(`/agents/${agentId}/profile`)}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-3xl font-bold">Edit Agent Details</h1>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => navigate(`/agents/${agentId}/profile`)}>
              Cancel
            </Button>
            <Button onClick={handleSave}>
              Save Changes
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Agent Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Full Name */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Full Name</label>
              <Input
                placeholder="Enter full name"
                value={agentData.fullName}
                disabled
              />
            </div>

            {/* Phone and Email */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Phone</label>
                <Input
                  placeholder="+91 XXXXX XXXXX"
                  value={agentData.phone}
                  disabled
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Email</label>
                <Input
                  type="email"
                  placeholder="email@acko.com"
                  value={agentData.email}
                  disabled
                />
              </div>
            </div>

            {/* Seniority and Performance Rating */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Seniority</label>
                <Select value={agentData.seniority} onValueChange={(value) => setAgentData({ ...agentData, seniority: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Junior">Junior</SelectItem>
                    <SelectItem value="Senior">Senior</SelectItem>
                    <SelectItem value="Lead">Lead</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Performance Rating</label>
                <Select value={agentData.performanceRating} onValueChange={(value) => setAgentData({ ...agentData, performanceRating: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Excellent">Excellent</SelectItem>
                    <SelectItem value="Good">Good</SelectItem>
                    <SelectItem value="Average">Average</SelectItem>
                    <SelectItem value="Below Average">Below Average</SelectItem>
                    <SelectItem value="Poor">Poor</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Primary Skills Section */}
            <div className="space-y-4 p-4 border rounded-lg">
              <h3 className="font-semibold text-lg">Primary Skills</h3>
              
              {/* Primary Languages with Proficiency */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Languages & Proficiency</label>
                <p className="text-xs text-muted-foreground">Add languages with proficiency level (1-5)</p>
                <div className="flex gap-2">
                  <Select value={newPrimaryLanguage} onValueChange={setNewPrimaryLanguage}>
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="English">English</SelectItem>
                      <SelectItem value="Hindi">Hindi</SelectItem>
                      <SelectItem value="Tamil">Tamil</SelectItem>
                      <SelectItem value="Telugu">Telugu</SelectItem>
                      <SelectItem value="Bengali">Bengali</SelectItem>
                      <SelectItem value="Kannada">Kannada</SelectItem>
                      <SelectItem value="Malayalam">Malayalam</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={newPrimaryProficiency} onValueChange={setNewPrimaryProficiency}>
                    <SelectTrigger className="w-24">
                      <SelectValue placeholder="Level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1</SelectItem>
                      <SelectItem value="2">2</SelectItem>
                      <SelectItem value="3">3</SelectItem>
                      <SelectItem value="4">4</SelectItem>
                      <SelectItem value="5">5</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button type="button" variant="outline" onClick={addPrimaryLanguage} disabled={!newPrimaryLanguage}>
                    Add
                  </Button>
                </div>
                {agentData.primarySkills.languages.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {agentData.primarySkills.languages.map((lang) => (
                      <Badge key={lang.language} variant="outline" className="bg-background gap-1">
                        {lang.language} - {lang.proficiency}
                        <button
                          type="button"
                          onClick={() => removePrimaryLanguage(lang.language)}
                          className="ml-1 hover:text-destructive"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              {/* Primary Tags */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Tags</label>
                <p className="text-xs text-muted-foreground">Special designations and categories</p>
                <Select onValueChange={addPrimaryTag}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select tags to add" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ACKO_existing">ACKO_existing</SelectItem>
                    <SelectItem value="VIP">VIP</SelectItem>
                  </SelectContent>
                </Select>
                {agentData.primarySkills.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {agentData.primarySkills.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="gap-1">
                        {tag}
                        <button
                          type="button"
                          onClick={() => removePrimaryTag(tag)}
                          className="ml-1 hover:text-destructive"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              {/* Primary Competencies */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Competencies</label>
                <p className="text-xs text-muted-foreground">Core skills and capabilities</p>
                <Select onValueChange={addPrimaryCompetency}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select competencies to add" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Bill Entry">Bill Entry</SelectItem>
                    <SelectItem value="Adjudication">Adjudication</SelectItem>
                    <SelectItem value="CRM">CRM</SelectItem>
                  </SelectContent>
                </Select>
                {agentData.primarySkills.competencies.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {agentData.primarySkills.competencies.map((comp) => (
                      <Badge key={comp} variant="outline" className="bg-primary/5 gap-1">
                        {comp}
                        <button
                          type="button"
                          onClick={() => removePrimaryCompetency(comp)}
                          className="ml-1 hover:text-destructive"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Secondary Skills Section */}
            <div className="space-y-4 p-4 border rounded-lg">
              <h3 className="font-semibold text-lg">Secondary Skills</h3>
              
              {/* Secondary Languages with Proficiency */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Languages & Proficiency</label>
                <p className="text-xs text-muted-foreground">Add languages with proficiency level (1-5)</p>
                <div className="flex gap-2">
                  <Select value={newSecondaryLanguage} onValueChange={setNewSecondaryLanguage}>
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="English">English</SelectItem>
                      <SelectItem value="Hindi">Hindi</SelectItem>
                      <SelectItem value="Tamil">Tamil</SelectItem>
                      <SelectItem value="Telugu">Telugu</SelectItem>
                      <SelectItem value="Bengali">Bengali</SelectItem>
                      <SelectItem value="Kannada">Kannada</SelectItem>
                      <SelectItem value="Malayalam">Malayalam</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={newSecondaryProficiency} onValueChange={setNewSecondaryProficiency}>
                    <SelectTrigger className="w-24">
                      <SelectValue placeholder="Level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1</SelectItem>
                      <SelectItem value="2">2</SelectItem>
                      <SelectItem value="3">3</SelectItem>
                      <SelectItem value="4">4</SelectItem>
                      <SelectItem value="5">5</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button type="button" variant="outline" onClick={addSecondaryLanguage} disabled={!newSecondaryLanguage}>
                    Add
                  </Button>
                </div>
                {agentData.secondarySkills.languages.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {agentData.secondarySkills.languages.map((lang) => (
                      <Badge key={lang.language} variant="outline" className="bg-background gap-1">
                        {lang.language} - {lang.proficiency}
                        <button
                          type="button"
                          onClick={() => removeSecondaryLanguage(lang.language)}
                          className="ml-1 hover:text-destructive"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              {/* Secondary Tags */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Tags</label>
                <p className="text-xs text-muted-foreground">Special designations and categories</p>
                <Select onValueChange={addSecondaryTag}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select tags to add" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ACKO_existing">ACKO_existing</SelectItem>
                    <SelectItem value="VIP">VIP</SelectItem>
                  </SelectContent>
                </Select>
                {agentData.secondarySkills.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {agentData.secondarySkills.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="gap-1">
                        {tag}
                        <button
                          type="button"
                          onClick={() => removeSecondaryTag(tag)}
                          className="ml-1 hover:text-destructive"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              {/* Secondary Competencies */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Competencies</label>
                <p className="text-xs text-muted-foreground">Core skills and capabilities</p>
                <Select onValueChange={addSecondaryCompetency}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select competencies to add" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Bill Entry">Bill Entry</SelectItem>
                    <SelectItem value="Adjudication">Adjudication</SelectItem>
                    <SelectItem value="CRM">CRM</SelectItem>
                  </SelectContent>
                </Select>
                {agentData.secondarySkills.competencies.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {agentData.secondarySkills.competencies.map((comp) => (
                      <Badge key={comp} variant="outline" className="bg-primary/5 gap-1">
                        {comp}
                        <button
                          type="button"
                          onClick={() => removeSecondaryCompetency(comp)}
                          className="ml-1 hover:text-destructive"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
