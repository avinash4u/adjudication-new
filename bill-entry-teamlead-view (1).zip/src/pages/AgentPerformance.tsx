import { useNavigate, useParams } from "react-router-dom";
import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ArrowLeft, TrendingUp, TrendingDown, Award, Target, Clock, CheckCircle2, AlertCircle, Info, Activity, CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import MetricTasksTable from "@/components/MetricTasksTable";

export default function AgentPerformance() {
  const navigate = useNavigate();
  const { agentId } = useParams();
  const [timeRange, setTimeRange] = useState("last-week");
  const [selectedMetric, setSelectedMetric] = useState<string | null>(null);
  const [showAchievements, setShowAchievements] = useState(false);
  const [showDateRangePicker, setShowDateRangePicker] = useState(false);
  const [dateRange, setDateRange] = useState<{ from: Date | undefined; to: Date | undefined }>({
    from: undefined,
    to: undefined,
  });

  // Mock data - in real app, fetch based on agentId
  const agent = {
    id: agentId,
    name: "Priya Sharma",
    initials: "PS",
    avatarColor: "hsl(217, 91%, 60%)",
    role: "Senior",
    performanceRating: "Excellent",
  };

  // Metric definitions for tooltips
  const definitions = {
    tasksAssigned: "Total number of tasks assigned to the agent in the selected time period",
    tasksCompleted: "Number of tasks successfully completed by the agent",
    avgTimeTaken: "Average time taken to complete a task from assignment to closure",
    slaCompliance: "Percentage of tasks completed within the defined Service Level Agreement timeframe",
    slaBreaches: "Number of tasks that exceeded the SLA deadline",
    productivityRate: "Ratio of tasks completed to tasks assigned, indicating overall efficiency",
    utilizationRate: "Percentage of working time spent on productive tasks",
    idleTime: "Percentage of time when agent is logged in but not actively working on tasks",
    breakTime: "Percentage of time spent on breaks during working hours",
  };

  // Dynamic metrics based on time range
  const metrics = useMemo(() => {
    const baseMetrics = {
      today: {
        tasksAssigned: { value: 12, change: "+5%", trend: "up" },
        tasksCompleted: { value: 11, change: "+10%", trend: "up" },
        avgTimeTaken: { value: "2.1 hrs", change: "-5%", trend: "up" },
        slaCompliance: { value: "92%", change: "+2%", trend: "up" },
        slaBreaches: { value: 1, change: "0%", trend: "neutral" },
        productivityRate: { value: "92%", change: "+3%", trend: "up" },
        utilizationRate: { value: "85%", change: "+1%", trend: "up" },
        idleTime: { value: "10%", change: "-2%", trend: "up" },
        breakTime: { value: "5%", change: "0%", trend: "neutral" },
      },
      "last-week": {
        tasksAssigned: { value: 145, change: "+8%", trend: "up" },
        tasksCompleted: { value: 138, change: "+12%", trend: "up" },
        avgTimeTaken: { value: "2.3 hrs", change: "-8%", trend: "up" },
        slaCompliance: { value: "96%", change: "+3%", trend: "up" },
        slaBreaches: { value: 6, change: "-15%", trend: "up" },
        productivityRate: { value: "95%", change: "+5%", trend: "up" },
        utilizationRate: { value: "87%", change: "+2%", trend: "up" },
        idleTime: { value: "8%", change: "-3%", trend: "up" },
        breakTime: { value: "5%", change: "0%", trend: "neutral" },
      },
      "last-month": {
        tasksAssigned: { value: 620, change: "+15%", trend: "up" },
        tasksCompleted: { value: 595, change: "+18%", trend: "up" },
        avgTimeTaken: { value: "2.5 hrs", change: "-12%", trend: "up" },
        slaCompliance: { value: "94%", change: "+5%", trend: "up" },
        slaBreaches: { value: 25, change: "-20%", trend: "up" },
        productivityRate: { value: "96%", change: "+8%", trend: "up" },
        utilizationRate: { value: "89%", change: "+4%", trend: "up" },
        idleTime: { value: "7%", change: "-5%", trend: "up" },
        breakTime: { value: "4%", change: "-1%", trend: "up" },
      },
      custom: {
        tasksAssigned: { value: 0, change: "0%", trend: "neutral" },
        tasksCompleted: { value: 0, change: "0%", trend: "neutral" },
        avgTimeTaken: { value: "0 hrs", change: "0%", trend: "neutral" },
        slaCompliance: { value: "0%", change: "0%", trend: "neutral" },
        slaBreaches: { value: 0, change: "0%", trend: "neutral" },
        productivityRate: { value: "0%", change: "0%", trend: "neutral" },
        utilizationRate: { value: "0%", change: "0%", trend: "neutral" },
        idleTime: { value: "0%", change: "0%", trend: "neutral" },
        breakTime: { value: "0%", change: "0%", trend: "neutral" },
      },
    };
    return baseMetrics[timeRange as keyof typeof baseMetrics] || baseMetrics["last-week"];
  }, [timeRange]);

  const weeklyPerformance = [
    { day: "Mon", tasks: 12, quality: 95 },
    { day: "Tue", tasks: 15, quality: 92 },
    { day: "Wed", tasks: 10, quality: 96 },
    { day: "Thu", tasks: 13, quality: 94 },
    { day: "Fri", tasks: 11, quality: 93 },
  ];

  const achievements = [
    { title: "Top Performer", description: "Highest task completion rate this month", date: "Feb 2024" },
    { title: "Quality Excellence", description: "Maintained 95%+ quality score for 3 months", date: "Jan 2024" },
  ];

  const getMetricTasks = (metricKey: string) => {
    const tasksMap: Record<string, any[]> = {
      tasksAssigned: [
        { id: "T-1234", title: "Policy renewal inquiry", customer: "John Smith", priority: "High", status: "In Progress", assignedDate: "2024-02-15 09:30", slaStatus: "Pending" },
        { id: "T-1235", title: "Claim status update", customer: "Sarah Johnson", priority: "Critical", status: "Assigned", assignedDate: "2024-02-15 10:15", slaStatus: "Pending" },
        { id: "T-1236", title: "Coverage expansion request", customer: "Mike Davis", priority: "Medium", status: "In Progress", assignedDate: "2024-02-15 11:00", slaStatus: "Pending" },
        { id: "T-1237", title: "Premium payment query", customer: "Emma Wilson", priority: "Low", status: "Waiting", assignedDate: "2024-02-15 13:20", slaStatus: "Pending" },
        { id: "T-1238", title: "Beneficiary change", customer: "Robert Brown", priority: "High", status: "In Progress", assignedDate: "2024-02-15 14:45", slaStatus: "Pending" },
      ],
      tasksCompleted: [
        { id: "T-1230", title: "Document verification", customer: "Alice Cooper", priority: "High", status: "Completed", assignedDate: "2024-02-14 08:00", completedDate: "2024-02-14 10:30", timeTaken: "2.5h", slaStatus: "Met" },
        { id: "T-1231", title: "Policy cancellation", customer: "Tom Harris", priority: "Medium", status: "Completed", assignedDate: "2024-02-14 09:30", completedDate: "2024-02-14 11:45", timeTaken: "2.25h", slaStatus: "Met" },
        { id: "T-1232", title: "Claim approval", customer: "Lisa Anderson", priority: "Critical", status: "Completed", assignedDate: "2024-02-14 10:00", completedDate: "2024-02-14 14:00", timeTaken: "4h", slaStatus: "Breached" },
        { id: "T-1233", title: "Coverage inquiry", customer: "David Miller", priority: "Low", status: "Completed", assignedDate: "2024-02-14 11:00", completedDate: "2024-02-14 11:45", timeTaken: "0.75h", slaStatus: "Met" },
      ],
      avgTimeTaken: [
        { id: "T-1228", title: "Quick inquiry", customer: "Peter Pan", priority: "Low", status: "Completed", assignedDate: "2024-02-13", completedDate: "2024-02-13", timeTaken: "0.5h", slaStatus: "Met" },
        { id: "T-1229", title: "Standard claim", customer: "Mary Jane", priority: "Medium", status: "Completed", assignedDate: "2024-02-13", completedDate: "2024-02-13", timeTaken: "2.3h", slaStatus: "Met" },
        { id: "T-1230", title: "Complex case", customer: "Bruce Wayne", priority: "High", status: "Completed", assignedDate: "2024-02-13", completedDate: "2024-02-14", timeTaken: "5.2h", slaStatus: "Breached" },
      ],
      slaCompliance: [
        { id: "T-1225", title: "Routine verification", customer: "Clark Kent", priority: "Medium", status: "Completed", assignedDate: "2024-02-12", completedDate: "2024-02-12", timeTaken: "1.5h", slaStatus: "Met" },
        { id: "T-1226", title: "Policy update", customer: "Diana Prince", priority: "High", status: "Completed", assignedDate: "2024-02-12", completedDate: "2024-02-12", timeTaken: "2h", slaStatus: "Met" },
        { id: "T-1227", title: "Emergency claim", customer: "Barry Allen", priority: "Critical", status: "Completed", assignedDate: "2024-02-12", completedDate: "2024-02-12", timeTaken: "3h", slaStatus: "Met" },
      ],
      slaBreaches: [
        { id: "T-1220", title: "Complex claim processing", customer: "Tony Stark", priority: "Critical", status: "Completed", assignedDate: "2024-02-10", completedDate: "2024-02-12", timeTaken: "26h", slaStatus: "Breached" },
        { id: "T-1221", title: "Document collection delay", customer: "Steve Rogers", priority: "High", status: "Completed", assignedDate: "2024-02-11", completedDate: "2024-02-13", timeTaken: "30h", slaStatus: "Breached" },
      ],
      productivityRate: [
        { id: "T-1216", title: "Quick resolution", customer: "Natasha Romanoff", priority: "Medium", status: "Completed", assignedDate: "2024-02-09", completedDate: "2024-02-09", timeTaken: "1h", slaStatus: "Met" },
        { id: "T-1217", title: "Standard processing", customer: "Clint Barton", priority: "Low", status: "Completed", assignedDate: "2024-02-09", completedDate: "2024-02-09", timeTaken: "2h", slaStatus: "Met" },
      ],
      utilizationRate: [
        { id: "T-1212", title: "Active task", customer: "Thor Odinson", priority: "High", status: "In Progress", assignedDate: "2024-02-15", timeTaken: "3h" },
        { id: "T-1213", title: "Completed task", customer: "Loki Laufeyson", priority: "Medium", status: "Completed", assignedDate: "2024-02-15", completedDate: "2024-02-15", timeTaken: "2h" },
      ],
      idleTime: [
        { id: "T-1208", title: "Waiting for docs", customer: "Stephen Strange", priority: "High", status: "Waiting", assignedDate: "2024-02-14", timeTaken: "N/A" },
        { id: "T-1209", title: "Customer callback", customer: "Wanda Maximoff", priority: "Medium", status: "Waiting", assignedDate: "2024-02-14", timeTaken: "N/A" },
      ],
      breakTime: [
        { id: "N/A", title: "Scheduled breaks", customer: "N/A", priority: "Low", status: "Break", assignedDate: "2024-02-15", timeTaken: "N/A" },
      ],
    };
    return tasksMap[metricKey] || [];
  };

  const getMetricDetails = (metricKey: string) => {
    const detailsMap: Record<string, { calculation: string; breakdown: string[] }> = {
      tasksAssigned: {
        calculation: "Total count of all tasks assigned to the agent during the selected time period",
        breakdown: [
          `New assignments: ${typeof metrics.tasksAssigned.value === 'number' ? Math.floor(metrics.tasksAssigned.value * 0.7) : 0}`,
          `Reassigned tasks: ${typeof metrics.tasksAssigned.value === 'number' ? Math.floor(metrics.tasksAssigned.value * 0.2) : 0}`,
          `Escalated tasks: ${typeof metrics.tasksAssigned.value === 'number' ? Math.floor(metrics.tasksAssigned.value * 0.1) : 0}`,
        ],
      },
      tasksCompleted: {
        calculation: "Tasks marked as completed/closed by the agent",
        breakdown: [
          `Resolved successfully: ${typeof metrics.tasksCompleted.value === 'number' ? Math.floor(metrics.tasksCompleted.value * 0.85) : 0}`,
          `Closed as duplicate: ${typeof metrics.tasksCompleted.value === 'number' ? Math.floor(metrics.tasksCompleted.value * 0.1) : 0}`,
          `Closed as won't fix: ${typeof metrics.tasksCompleted.value === 'number' ? Math.floor(metrics.tasksCompleted.value * 0.05) : 0}`,
        ],
      },
      avgTimeTaken: {
        calculation: "(Sum of time taken for all completed tasks) / (Total completed tasks)",
        breakdown: [
          "Includes time from task assignment to completion",
          "Excludes time when task was in 'Waiting' status",
          "Calculated only for completed tasks",
        ],
      },
      slaCompliance: {
        calculation: "(Tasks completed within SLA / Total completed tasks) × 100",
        breakdown: [
          `Within SLA: ${typeof metrics.tasksCompleted.value === 'number' ? Math.floor(metrics.tasksCompleted.value * 0.96) : 0}`,
          `Breached SLA: ${metrics.slaBreaches.value}`,
          "SLA time varies by task priority",
        ],
      },
      slaBreaches: {
        calculation: "Count of tasks where completion time exceeded defined SLA",
        breakdown: [
          `Critical priority breaches: ${typeof metrics.slaBreaches.value === 'number' ? Math.floor(metrics.slaBreaches.value * 0.3) : 0}`,
          `High priority breaches: ${typeof metrics.slaBreaches.value === 'number' ? Math.floor(metrics.slaBreaches.value * 0.5) : 0}`,
          `Medium priority breaches: ${typeof metrics.slaBreaches.value === 'number' ? Math.floor(metrics.slaBreaches.value * 0.2) : 0}`,
        ],
      },
      productivityRate: {
        calculation: "(Tasks completed / Tasks assigned) × 100",
        breakdown: [
          `Assigned: ${metrics.tasksAssigned.value}`,
          `Completed: ${metrics.tasksCompleted.value}`,
          "Higher rate indicates better efficiency",
        ],
      },
      utilizationRate: {
        calculation: "(Productive time / Total logged time) × 100",
        breakdown: [
          "Productive time includes active task work",
          "Excludes idle time and breaks",
          "Target utilization: 85-90%",
        ],
      },
      idleTime: {
        calculation: "(Idle time / Total logged time) × 100",
        breakdown: [
          "Time logged in but not working on tasks",
          "Includes transitions between tasks",
          "Lower is better",
        ],
      },
      breakTime: {
        calculation: "(Break time / Total logged time) × 100",
        breakdown: [
          "Scheduled and unscheduled breaks",
          "Lunch breaks included",
          "Within acceptable range",
        ],
      },
    };
    return detailsMap[metricKey];
  };

  const MetricCard = ({ 
    icon: Icon, 
    value, 
    label, 
    change, 
    trend, 
    definition,
    metricKey
  }: { 
    icon: any; 
    value: string | number; 
    label: string; 
    change: string; 
    trend: string; 
    definition: string;
    metricKey: string;
  }) => (
    <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setSelectedMetric(metricKey)}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-2">
          <Icon className="w-5 h-5 text-primary" />
          <div className="flex items-center gap-2">
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="w-4 h-4 text-muted-foreground cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>{definition}</p>
              </TooltipContent>
            </Tooltip>
            {trend === "up" ? (
              <TrendingUp className="w-4 h-4 text-status-on-track" />
            ) : trend === "down" ? (
              <TrendingDown className="w-4 h-4 text-destructive" />
            ) : null}
          </div>
        </div>
        <div className="text-3xl font-bold">{value}</div>
        <p className="text-sm text-muted-foreground mt-1">{label}</p>
        <div className={`text-xs mt-2 ${trend === "up" ? "text-status-on-track" : trend === "down" ? "text-destructive" : "text-muted-foreground"}`}>
          {change} from previous period
        </div>
      </CardContent>
    </Card>
  );

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-background">
        <div className="container mx-auto p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/agents")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-4 flex-1">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold"
                style={{ backgroundColor: agent.avatarColor }}
              >
                {agent.initials}
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold">{agent.name}</h1>
                <p className="text-muted-foreground">Performance Overview</p>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowAchievements(true)}
                className="flex items-center gap-2"
              >
                <Award className="w-4 h-4" />
                View Achievements
              </Button>
            </div>
            <Select 
              value={timeRange} 
              onValueChange={(value) => {
                setTimeRange(value);
                if (value === "custom") {
                  setShowDateRangePicker(true);
                }
              }}
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="last-week">Last Week</SelectItem>
                <SelectItem value="last-month">Last Month</SelectItem>
                <SelectItem value="custom">
                  {dateRange.from && dateRange.to 
                    ? `${format(dateRange.from, "MMM dd")} - ${format(dateRange.to, "MMM dd, yyyy")}`
                    : "Custom Range"}
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Key Metrics - Grouped */}
          <div className="space-y-8">
            {/* Task Metrics */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Target className="w-5 h-5 text-primary" />
                <h2 className="text-lg font-semibold">Task Metrics</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <MetricCard
                  icon={Target}
                  value={metrics.tasksAssigned.value}
                  label="Tasks Assigned"
                  change={metrics.tasksAssigned.change}
                  trend={metrics.tasksAssigned.trend}
                  definition={definitions.tasksAssigned}
                  metricKey="tasksAssigned"
                />
                <MetricCard
                  icon={CheckCircle2}
                  value={metrics.tasksCompleted.value}
                  label="Tasks Completed"
                  change={metrics.tasksCompleted.change}
                  trend={metrics.tasksCompleted.trend}
                  definition={definitions.tasksCompleted}
                  metricKey="tasksCompleted"
                />
                <MetricCard
                  icon={Clock}
                  value={metrics.avgTimeTaken.value}
                  label="Average Time Taken"
                  change={metrics.avgTimeTaken.change}
                  trend={metrics.avgTimeTaken.trend}
                  definition={definitions.avgTimeTaken}
                  metricKey="avgTimeTaken"
                />
              </div>
            </div>

            {/* Productivity Metrics */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Activity className="w-5 h-5 text-primary" />
                <h2 className="text-lg font-semibold">Productivity & Efficiency</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <MetricCard
                  icon={Target}
                  value={metrics.utilizationRate.value}
                  label="Utilization Rate"
                  change={metrics.utilizationRate.change}
                  trend={metrics.utilizationRate.trend}
                  definition={definitions.utilizationRate}
                  metricKey="utilizationRate"
                />
              </div>
            </div>

            {/* Time Management */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Clock className="w-5 h-5 text-primary" />
                <h2 className="text-lg font-semibold">Time Management</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <MetricCard
                  icon={Clock}
                  value={metrics.idleTime.value}
                  label="Idle Time"
                  change={metrics.idleTime.change}
                  trend={metrics.idleTime.trend}
                  definition={definitions.idleTime}
                  metricKey="idleTime"
                />
                <MetricCard
                  icon={Clock}
                  value={metrics.breakTime.value}
                  label="Break Time"
                  change={metrics.breakTime.change}
                  trend={metrics.breakTime.trend}
                  definition={definitions.breakTime}
                  metricKey="breakTime"
                />
              </div>
            </div>
          </div>

          {/* Metric Details Dialog */}
          <Dialog open={!!selectedMetric} onOpenChange={(open) => !open && setSelectedMetric(null)}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
              <DialogHeader>
                <DialogTitle>
                  {selectedMetric && selectedMetric.replace(/([A-Z])/g, ' $1').replace(/^./, (str) => str.toUpperCase())}
                </DialogTitle>
                <DialogDescription>
                  Detailed breakdown and calculation methodology
                </DialogDescription>
              </DialogHeader>
              {selectedMetric && (
                <Tabs defaultValue="overview" className="w-full flex-1 flex flex-col overflow-hidden">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="tasks">Task Details</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview" className="space-y-6 overflow-y-auto flex-1 pr-2">
                    <div>
                      <h3 className="font-semibold mb-2">Current Value</h3>
                      <div className="text-4xl font-bold text-primary">
                        {metrics[selectedMetric as keyof typeof metrics]?.value}
                      </div>
                      <div className={`text-sm mt-1 ${metrics[selectedMetric as keyof typeof metrics]?.trend === "up" ? "text-status-on-track" : "text-destructive"}`}>
                        {metrics[selectedMetric as keyof typeof metrics]?.change} from previous period
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="font-semibold mb-2">Calculation Method</h3>
                      <p className="text-sm text-muted-foreground bg-muted p-3 rounded-md">
                        {getMetricDetails(selectedMetric)?.calculation}
                      </p>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-2">Breakdown</h3>
                      <ul className="space-y-2">
                        {getMetricDetails(selectedMetric)?.breakdown.map((item, idx) => (
                          <li key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                            <span className="text-primary mt-1">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="pt-4 border-t">
                      <p className="text-xs text-muted-foreground">
                        Data shown for: <span className="font-semibold">{timeRange === "last-week" ? "Last Week" : timeRange === "last-month" ? "Last Month" : timeRange === "today" ? "Today" : "Custom Range"}</span>
                      </p>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="tasks" className="overflow-y-auto flex-1">
                    <div className="space-y-4 pr-2">
                      <div>
                        <h3 className="font-semibold mb-2">Related Tasks</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          Individual tasks contributing to this metric
                        </p>
                      </div>
                      <MetricTasksTable 
                        tasks={getMetricTasks(selectedMetric)} 
                        metricType={selectedMetric}
                      />
                    </div>
                  </TabsContent>
                </Tabs>
              )}
            </DialogContent>
          </Dialog>

        {/* Achievements Dialog */}
        <Dialog open={showAchievements} onOpenChange={setShowAchievements}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-[hsl(25,95%,53%)]" />
                Achievements & Recognition
              </DialogTitle>
              <DialogDescription>
                Recognition and milestones achieved by {agent.name}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {achievements.map((achievement, idx) => (
                <div key={idx} className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                  <div className="w-10 h-10 rounded-full bg-[hsl(25,95%,53%)] flex items-center justify-center flex-shrink-0">
                    <Award className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold">{achievement.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{achievement.description}</p>
                    <Badge variant="outline" className="mt-2 bg-background">
                      {achievement.date}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>

        {/* Date Range Picker Dialog */}
        <Dialog open={showDateRangePicker} onOpenChange={setShowDateRangePicker}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Select Custom Date Range</DialogTitle>
              <DialogDescription>
                Choose a start and end date to view performance metrics
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">From Date</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !dateRange.from && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateRange.from ? format(dateRange.from, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateRange.from}
                      onSelect={(date) => setDateRange({ ...dateRange, from: date })}
                      disabled={(date) => date > new Date()}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">To Date</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !dateRange.to && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateRange.to ? format(dateRange.to, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateRange.to}
                      onSelect={(date) => setDateRange({ ...dateRange, to: date })}
                      disabled={(date) => 
                        date > new Date() || (dateRange.from ? date < dateRange.from : false)
                      }
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowDateRangePicker(false);
                  setTimeRange("last-week");
                  setDateRange({ from: undefined, to: undefined });
                }}
              >
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  if (dateRange.from && dateRange.to) {
                    setShowDateRangePicker(false);
                  }
                }}
                disabled={!dateRange.from || !dateRange.to}
              >
                Apply Date Range
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        </div>
      </div>
    </TooltipProvider>
  );
}
