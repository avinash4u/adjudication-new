import { useParams, Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, FileText, User, Calendar, DollarSign, Building, AlertCircle } from "lucide-react";

const ClaimDetails = () => {
  const { claimId } = useParams();

  // Mock data - in a real app, fetch from API based on claimId
  const claimData = {
    claimId: claimId || "CLM-T001",
    status: "Under Review",
    customerName: "Rajesh Kumar",
    patientName: "Rajesh Kumar",
    patientUHID: "UHID001",
    phone: "9876543210",
    email: "rajesh.kumar@example.com",
    policyNumber: "POL-2024-12345",
    hospitalName: "Apollo Hospital",
    hospitalAddress: "Greams Road, Chennai, Tamil Nadu 600006",
    admissionDate: "2025-10-18",
    dischargeDate: "2025-10-20",
    claimAmount: "₹2,45,000",
    approvedAmount: "₹2,20,000",
    treatmentType: "Cardiac Surgery",
    diagnosisCode: "I25.1",
    diagnosisDescription: "Atherosclerotic heart disease of native coronary artery",
    roomCategory: "Single AC",
    claimType: "Cashless",
    lobType: "Retail",
    claimSubType: "IPD",
    customerCohort: "General",
    trustScore: "40-70",
    admissionType: "Planned",
    escalation: "Not escalated",
    slaBreachStatus: "On track",
    ageing: 2,
    assignedTo: "David Lee",
    documents: [
      { name: "Discharge Summary", status: "Verified" },
      { name: "Medical Bills", status: "Verified" },
      { name: "Prescription", status: "Pending" },
      { name: "Lab Reports", status: "Verified" },
    ],
    timeline: [
      { date: "2025-10-18", event: "Claim Submitted" },
      { date: "2025-10-19", event: "Documents Verified" },
      { date: "2025-10-20", event: "Under Medical Review" },
      { date: "2025-10-21", event: "Assigned to Processor" },
    ],
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/proposals">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Claim Details</h1>
            <p className="text-muted-foreground">Complete information for {claimData.claimId}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Link to={`/bill-entry/${claimId}`}>
            <Button variant="outline">
              <FileText className="h-4 w-4 mr-2" />
              Bill Entry
            </Button>
          </Link>
          <Badge variant={claimData.status === "Under Review" ? "default" : "secondary"}>
            {claimData.status}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Patient Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Patient Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Patient Name</p>
                  <p className="font-medium">{claimData.patientName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Patient UHID</p>
                  <p className="font-medium">{claimData.patientUHID}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Phone</p>
                  <p className="font-medium">{claimData.phone}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium">{claimData.email}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Customer Name</p>
                  <p className="font-medium">{claimData.customerName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Policy Number</p>
                  <p className="font-medium">{claimData.policyNumber}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Hospital & Treatment Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                Hospital & Treatment Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Hospital Name</p>
                <p className="font-medium">{claimData.hospitalName}</p>
                <p className="text-sm text-muted-foreground">{claimData.hospitalAddress}</p>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Admission Date</p>
                  <p className="font-medium">{claimData.admissionDate}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Discharge Date</p>
                  <p className="font-medium">{claimData.dischargeDate}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Treatment Type</p>
                  <p className="font-medium">{claimData.treatmentType}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Room Category</p>
                  <p className="font-medium">{claimData.roomCategory}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-sm text-muted-foreground">Diagnosis</p>
                  <p className="font-medium">{claimData.diagnosisCode} - {claimData.diagnosisDescription}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Financial Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Financial Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Claimed Amount</p>
                  <p className="text-2xl font-bold">{claimData.claimAmount}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Approved Amount</p>
                  <p className="text-2xl font-bold text-green-600">{claimData.approvedAmount}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Documents */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Documents
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {claimData.documents.map((doc, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span>{doc.name}</span>
                    </div>
                    <Badge variant={doc.status === "Verified" ? "default" : "secondary"}>
                      {doc.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Claim Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Claim Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-sm text-muted-foreground">Claim Type</p>
                <p className="font-medium">{claimData.claimType}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">LOB Type</p>
                <p className="font-medium">{claimData.lobType}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Claim Sub Type</p>
                <p className="font-medium">{claimData.claimSubType}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Customer Cohort</p>
                <p className="font-medium">{claimData.customerCohort}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Trust Score</p>
                <p className="font-medium">{claimData.trustScore}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Admission Type</p>
                <p className="font-medium">{claimData.admissionType}</p>
              </div>
            </CardContent>
          </Card>

          {/* Task Information */}
          <Card>
            <CardHeader>
              <CardTitle>Task Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-sm text-muted-foreground">Assigned To</p>
                <p className="font-medium">{claimData.assignedTo}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Escalation Status</p>
                <Badge variant={claimData.escalation === "Not escalated" ? "secondary" : "destructive"}>
                  {claimData.escalation}
                </Badge>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">SLA Status</p>
                <Badge variant={claimData.slaBreachStatus === "On track" ? "default" : "destructive"}>
                  {claimData.slaBreachStatus}
                </Badge>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Ageing</p>
                <p className="font-medium">{claimData.ageing} days</p>
              </div>
            </CardContent>
          </Card>

          {/* Timeline */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {claimData.timeline.map((item, index) => (
                  <div key={index} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className="h-2 w-2 rounded-full bg-primary" />
                      {index < claimData.timeline.length - 1 && (
                        <div className="h-full w-px bg-border mt-1" />
                      )}
                    </div>
                    <div className="flex-1 pb-4">
                      <p className="text-sm font-medium">{item.event}</p>
                      <p className="text-xs text-muted-foreground">{item.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ClaimDetails;
