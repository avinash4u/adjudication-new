import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Mail, Phone, Calendar, Users, Award, Star, TrendingUp } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function AgentProfile() {
  const navigate = useNavigate();
  const { agentId } = useParams();
  const [isPerformanceDialogOpen, setIsPerformanceDialogOpen] = useState(false);
  const [taskFilter, setTaskFilter] = useState("all");

  // Mock data - in real app, fetch based on agentId
  const agent = {
    id: agentId,
    name: "Priya Sharma",
    email: "priya.sharma@acko.com",
    phone: "+91 98765 43210",
    initials: "PS",
    avatarColor: "hsl(217, 91%, 60%)",
    status: "Online",
    role: "Senior",
    joinDate: "Jan 15, 2023",
    languages: ["English", "Hindi", "Tamil"],
    skills: ["Bill Entry", "Adjudication", "CRM"],
    secondarySkills: ["VIP cases", "ACKO_Existing"],
    team: ["Cashless", "Reimbursement"],
    performanceRating: "Excellent",
    tasksLastWeek: 45,
    todaysTasks: 8,
    totalCompleted: 1250,
    averageRating: 4.8,
  };

  // Mock task history data
  const taskHistory = [
    { id: "1", caseId: "CASE-2024-001", type: "Bill Entry", claimType: "Cashless", completedAt: "2024-10-21 14:30" },
    { id: "2", caseId: "CASE-2024-002", type: "Adjudication", claimType: "Reimbursement", completedAt: "2024-10-21 11:15" },
    { id: "3", caseId: "CASE-2024-003", type: "Bill Entry", claimType: "Cashless", completedAt: "2024-10-20 16:45" },
    { id: "4", caseId: "CASE-2024-004", type: "CRM", claimType: "Cashless", completedAt: "2024-10-20 10:20" },
    { id: "5", caseId: "CASE-2024-005", type: "Bill Entry", claimType: "Reimbursement", completedAt: "2024-10-19 15:00" },
    { id: "6", caseId: "CASE-2024-006", type: "Adjudication", claimType: "Cashless", completedAt: "2024-10-18 13:30" },
    { id: "7", caseId: "CASE-2024-007", type: "Bill Entry", claimType: "Reimbursement", completedAt: "2024-10-17 09:45" },
    { id: "8", caseId: "CASE-2024-008", type: "CRM", claimType: "Cashless", completedAt: "2024-10-16 14:10" },
  ];

  // Mock ratings history
  const ratingsHistory = [
    { period: "Week 42 (Oct 14-20)", averageRating: 4.8, tasksCompleted: 45, excellentCount: 38, goodCount: 7 },
    { period: "Week 41 (Oct 7-13)", averageRating: 4.7, tasksCompleted: 42, excellentCount: 35, goodCount: 7 },
    { period: "Week 40 (Sep 30-Oct 6)", averageRating: 4.9, tasksCompleted: 48, excellentCount: 43, goodCount: 5 },
    { period: "Week 39 (Sep 23-29)", averageRating: 4.6, tasksCompleted: 40, excellentCount: 32, goodCount: 8 },
  ];

  const filteredTasks = taskFilter === "all" 
    ? taskHistory 
    : taskHistory.filter(task => task.type === taskFilter);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/agents")}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-3xl font-bold">Agent Profile</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Profile Card */}
          <Card className="lg:col-span-1">
            <CardContent className="p-6 space-y-6">
              <div className="flex flex-col items-center text-center">
                <div
                  className="w-24 h-24 rounded-full flex items-center justify-center text-white font-bold text-2xl mb-4"
                  style={{ backgroundColor: agent.avatarColor }}
                >
                  {agent.initials}
                </div>
                <h2 className="text-2xl font-bold">{agent.name}</h2>
                <div className="flex gap-2 mt-2">
                  <Badge className="bg-status-on-track text-status-on-track-foreground">
                    {agent.status}
                  </Badge>
                  <Badge className="bg-primary text-primary-foreground">{agent.role}</Badge>
                </div>
              </div>

              <div className="space-y-4 pt-4 border-t">
                <div className="flex items-center gap-3 text-sm">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <span>{agent.email}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span>{agent.phone}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span>Joined {agent.joinDate}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Award className="w-4 h-4 text-muted-foreground" />
                  <span>Rating: {agent.performanceRating}</span>
                </div>
              </div>

              <div className="pt-4 border-t">
                <Button className="w-full" onClick={() => navigate(`/agents/${agentId}/edit`)}>
                  Edit Profile
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Details Cards */}
          <div className="lg:col-span-2 space-y-6">
            {/* Languages */}
            <Card>
              <CardHeader>
                <CardTitle>Languages</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {agent.languages.map((lang, idx) => (
                    <Badge key={idx} variant="outline" className="bg-background">
                      {lang}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Skills */}
            <Card>
              <CardHeader>
                <CardTitle>Primary Skills</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {agent.skills.map((skill, idx) => (
                    <Badge key={idx} variant="outline" className="bg-background">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Secondary Skills */}
            <Card>
              <CardHeader>
                <CardTitle>Secondary Skills</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {agent.secondarySkills.map((skill, idx) => (
                    <Badge key={idx} variant="outline" className="bg-background">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Team */}
            <Card>
              <CardHeader>
                <CardTitle>Team Assignments</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {agent.team.map((teamItem, idx) => (
                    <Badge key={idx} variant="outline" className="bg-background">
                      {teamItem}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Performance Details Dialog */}
        <Dialog open={isPerformanceDialogOpen} onOpenChange={setIsPerformanceDialogOpen}>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Performance Details - {agent.name}</DialogTitle>
              <DialogDescription>
                View detailed task completion history and performance ratings
              </DialogDescription>
            </DialogHeader>

            <Tabs defaultValue="tasks" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="tasks">Task History</TabsTrigger>
                <TabsTrigger value="ratings">Ratings History</TabsTrigger>
              </TabsList>

              <TabsContent value="tasks" className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="grid grid-cols-3 gap-4 flex-1">
                    <div className="text-center p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-primary">{agent.tasksLastWeek}</div>
                      <p className="text-xs text-muted-foreground mt-1">Last Week</p>
                    </div>
                    <div className="text-center p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-status-on-track">{agent.todaysTasks}</div>
                      <p className="text-xs text-muted-foreground mt-1">Today</p>
                    </div>
                    <div className="text-center p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold">{agent.totalCompleted}</div>
                      <p className="text-xs text-muted-foreground mt-1">Total</p>
                    </div>
                  </div>
                  <Select value={taskFilter} onValueChange={setTaskFilter}>
                    <SelectTrigger className="w-[180px] ml-4">
                      <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Tasks</SelectItem>
                      <SelectItem value="Bill Entry">Bill Entry</SelectItem>
                      <SelectItem value="Adjudication">Adjudication</SelectItem>
                      <SelectItem value="CRM">CRM</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Case ID</TableHead>
                        <TableHead>Task Type</TableHead>
                        <TableHead>Claim Type</TableHead>
                        <TableHead>Completed At</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredTasks.map((task) => (
                        <TableRow key={task.id}>
                          <TableCell className="font-medium">{task.caseId}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{task.type}</Badge>
                          </TableCell>
                          <TableCell>{task.claimType}</TableCell>
                          <TableCell className="text-muted-foreground">{task.completedAt}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="ratings" className="space-y-4">
                <div className="flex items-center gap-2 p-4 bg-muted rounded-lg">
                  <TrendingUp className="w-5 h-5 text-status-on-track" />
                  <div>
                    <div className="text-lg font-bold">{agent.averageRating} Average Rating</div>
                    <p className="text-sm text-muted-foreground">Overall performance score</p>
                  </div>
                </div>

                <div className="border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Period</TableHead>
                        <TableHead>Tasks Completed</TableHead>
                        <TableHead>Average Rating</TableHead>
                        <TableHead>Excellent (5★)</TableHead>
                        <TableHead>Good (4★)</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {ratingsHistory.map((period, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="font-medium">{period.period}</TableCell>
                          <TableCell>{period.tasksCompleted}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 fill-[hsl(25,95%,53%)] text-[hsl(25,95%,53%)]" />
                              <span className="font-semibold">{period.averageRating}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className="bg-status-on-track text-status-on-track-foreground">
                              {period.excellentCount}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{period.goodCount}</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
