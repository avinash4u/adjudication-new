import { useState } from "react";
import { Search, Filter, FileText, User, Calendar } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

const CaseSearch = () => {
  const [searchQuery, setSearchQuery] = useState("");
  
  // Mock data for all tasks
  const allTasks = [
    {
      id: 1,
      taskId: "TSK001234",
      agentName: "Sarah Johnson",
      customerMobile: "+1-555-0123",
      customerEmail: "john.doe@email.com",
      claimId: "CLM456789",
      status: "Active",
      date: "2024-01-15",
    },
    {
      id: 2,
      taskId: "TSK005678",
      agentName: "Michael Chen",
      customerMobile: "+1-555-0456",
      customerEmail: "jane.smith@email.com",
      claimId: "CLM123456",
      status: "Processing",
      date: "2024-01-14",
    },
    {
      id: 3,
      taskId: "TSK002345",
      agentName: "Emily Davis",
      customerMobile: "+1-555-0789",
      customerEmail: "bob.johnson@email.com",
      claimId: "CLM789012",
      status: "Pending",
      date: "2024-01-13",
    },
    {
      id: 4,
      taskId: "TSK009876",
      agentName: "David Wilson",
      customerMobile: "+1-555-0321",
      customerEmail: "alice.brown@email.com",
      claimId: "CLM345678",
      status: "Completed",
      date: "2024-01-12",
    },
    {
      id: 5,
      taskId: "TSK007654",
      agentName: "Sarah Johnson",
      customerMobile: "+1-555-0654",
      customerEmail: "charlie.green@email.com",
      claimId: "CLM901234",
      status: "Active",
      date: "2024-01-11",
    }
  ];

  // Filter results based on search query
  const searchResults = searchQuery.trim() === "" 
    ? allTasks 
    : allTasks.filter(task => 
        task.taskId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        task.agentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        task.customerMobile.includes(searchQuery) ||
        task.customerEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
        task.claimId.toLowerCase().includes(searchQuery.toLowerCase())
      );

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
        return "bg-primary text-primary-foreground";
      case "processing":
        return "bg-muted text-muted-foreground";
      case "pending":
        return "bg-muted text-muted-foreground";
      case "completed":
        return "bg-status-on-track text-status-on-track-foreground";
      default:
        return "bg-secondary text-secondary-foreground";
    }
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Page Title */}
        <h1 className="text-4xl font-bold text-foreground">Task Search</h1>

        {/* Advanced Search Section */}
        <Card className="p-8">
          <h2 className="text-3xl font-bold text-foreground mb-6">Advanced Search</h2>
          
          <div className="flex items-center gap-4 mb-6">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
              <Input
                type="text"
                placeholder="Search by mobile, email, claim id"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-14 text-base border-2 border-primary rounded-xl"
              />
            </div>

            {/* Search Button */}
            <Button size="lg" className="h-14 px-8 rounded-xl">
              <Search className="h-5 w-5 mr-2" />
              Search
            </Button>

            {/* Filters Button */}
            <Button variant="outline" size="lg" className="h-14 px-8 rounded-xl">
              <Filter className="h-5 w-5 mr-2" />
              Filters
            </Button>
          </div>

          {/* Filter Chips */}
          <div className="flex gap-4">
            <span className="text-base text-foreground font-medium">Last 30 days</span>
            <span className="text-base text-foreground font-medium">All statuses</span>
          </div>
        </Card>

        {/* Search Results Section */}
        <div className="space-y-6">
          <h2 className="text-3xl font-bold text-foreground">Search Results</h2>

          <div className="space-y-4">
            {searchResults.length === 0 ? (
              <Card className="p-12 bg-secondary/30">
                <p className="text-center text-muted-foreground text-lg">
                  No results found. Try adjusting your search criteria.
                </p>
              </Card>
            ) : (
              searchResults.map((result) => (
                <Card key={result.id} className="p-6 bg-secondary/30">
                  <div className="flex items-center gap-6">
                    {/* Icon */}
                    <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center flex-shrink-0">
                      <FileText className="h-8 w-8 text-primary-foreground" />
                    </div>

                    {/* Claim ID and Agent Name */}
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-foreground mb-1">
                        {result.claimId}
                      </h3>
                      <p className="text-base text-muted-foreground">
                        {result.agentName}
                      </p>
                    </div>

                    {/* Status Badge */}
                    <Badge className={`${getStatusColor(result.status)} px-6 py-2 text-base rounded-full`}>
                      {result.status}
                    </Badge>

                    {/* Date */}
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-5 w-5" />
                      <span className="text-base">{result.date}</span>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CaseSearch;
