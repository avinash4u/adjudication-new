import { OverviewMetrics } from "@/components/OverviewMetrics";
import { AgentLiveStatus } from "@/components/AgentLiveStatus";
import { TrendingUp, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { format } from "date-fns";

const CommandCenter = () => {
  const [lastRefreshed, setLastRefreshed] = useState(new Date());
  const [key, setKey] = useState(0);

  const handleRefresh = () => {
    setLastRefreshed(new Date());
    setKey(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-background">
      <main className="p-6 space-y-6">
        {/* Today's Traffic Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Current Snapshot
              </h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleRefresh}
                className="h-8"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              Auto-refreshed last at {format(lastRefreshed, "hh:mm:ss a")}
            </p>
          </div>
          <OverviewMetrics key={key} />
        </div>

        {/* Agent Live Status Section */}
        <div className="space-y-4">
          <AgentLiveStatus />
        </div>
      </main>
    </div>
  );
};

export default CommandCenter;
