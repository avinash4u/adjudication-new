import { Users, TrendingUp, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useState } from "react";
import { LineChart, Line, ResponsiveContainer } from "recharts";

export function AgentLiveStatus() {
  const [agentDialogOpen, setAgentDialogOpen] = useState(false);
  const [agentDialogData, setAgentDialogData] = useState<{
    title: string;
    agents: any[];
  }>({
    title: "",
    agents: [],
  });

  const [completionDialogOpen, setCompletionDialogOpen] = useState(false);
  const [completionDialogData, setCompletionDialogData] = useState<{
    title: string;
    isCashlessIPD: boolean;
    tasks: Array<{
      taskId: string;
      agentName: string;
      timeTaken: number;
      completedAt: string;
      requestType?: string;
    }>;
  }>({
    title: "",
    isCashlessIPD: false,
    tasks: [],
  });

  // Mock data for filtering
  const mockTaskData = [
    { lob: "Retail", claimType: "Cashless", claimSubType: "IPD", preauthType: "Preauth Final", avgCompletionTime: 19.8 },
    { lob: "Retail", claimType: "Cashless", claimSubType: "OPD", preauthType: "Preauth Initial", avgCompletionTime: 15.2 },
    { lob: "Retail", claimType: "Reimbursement", claimSubType: "IPD", preauthType: null, avgCompletionTime: 32.1 },
    { lob: "Retail", claimType: "Reimbursement", claimSubType: "OPD", preauthType: null, avgCompletionTime: 18.7 },
    { lob: "GMC", claimType: "Cashless", claimSubType: "IPD", preauthType: "Preauth Initial", avgCompletionTime: 26.4 },
    { lob: "GMC", claimType: "Cashless", claimSubType: "OPD", preauthType: "Preauth Enhancement", avgCompletionTime: 14.9 },
    { lob: "GMC", claimType: "Reimbursement", claimSubType: "IPD", preauthType: null, avgCompletionTime: 29.6 },
    { lob: "GMC", claimType: "Reimbursement", claimSubType: "OPD", preauthType: null, avgCompletionTime: 16.3 },
  ];

  // Agent Live Status Metrics
  const agentMetrics = {
    totalInShift: 45,
    available: 28,
    unavailable: 5,
    idle: 8,
    onLeave: 4,
    avgCompletionTime: 24.5,
    activeHours: 315,
    totalAvailableHours: 360
  };

  const utilizationRate = ((agentMetrics.activeHours / agentMetrics.totalAvailableHours) * 100).toFixed(1);

  const generateCompletionTasks = (lob: string, claimType: string, claimSubType: string, avgTime: number) => {
    const agentNames = ["Sarah Johnson", "Michael Chen", "Emma Wilson", "David Kumar", "Lisa Anderson"];
    const requestTypes = ["Preauth Initial", "Preauth Enhancement", "Preauth Final"];
    const taskCount = Math.floor(Math.random() * 8) + 5;
    const isCashlessIPD = claimType === "Cashless" && claimSubType === "IPD";
    
    return Array.from({ length: taskCount }, (_, i) => ({
      taskId: `TSK-${Math.floor(Math.random() * 90000) + 10000}`,
      agentName: agentNames[Math.floor(Math.random() * agentNames.length)],
      timeTaken: Math.round(avgTime * (0.7 + Math.random() * 0.6)),
      completedAt: new Date(Date.now() - Math.random() * 8 * 60 * 60 * 1000).toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
      }),
      ...(isCashlessIPD && { requestType: requestTypes[Math.floor(Math.random() * requestTypes.length)] })
    }));
  };

  const handleCompletionTimeClick = (item: any) => {
    const tasks = generateCompletionTasks(item.lob, item.claimType, item.claimSubType, item.avgCompletionTime);
    setCompletionDialogData({
      title: `${item.lob} - ${item.claimType} - ${item.claimSubType}`,
      isCashlessIPD: item.claimType === "Cashless" && item.claimSubType === "IPD",
      tasks
    });
    setCompletionDialogOpen(true);
  };

  const generateMockAgents = (count: number, status: string) => {
    const agentNames = ["Priya Singh", "Raj Patel", "Anita Kumar", "David Lee", "Jane Smith", "Mike Johnson", "John Doe", "Sarah Williams", "Tom Brown", "Lisa Anderson", "Kevin Chen", "Maria Garcia", "James Wilson", "Emily Taylor"];
    return Array.from({ length: count }, (_, i) => {
      // 30% chance of no tasks completed yet (showing "-")
      const hasCompletedTasks = Math.random() > 0.3;
      
      return {
        agentId: `AGT-${String(i + 1).padStart(3, '0')}`,
        name: agentNames[i % agentNames.length],
        status: status,
        currentTask: status === "On Leave" || status === "Idle" || status === "Unavailable" ? "-" : `CLM-T${String(Math.floor(Math.random() * 999) + 1).padStart(3, '0')}`,
        tasksCompleted: (status === "On Leave" || !hasCompletedTasks) ? "-" : Math.floor(Math.random() * 20) + 5,
        shiftTime: "9:00 AM - 5:00 PM",
      };
    });
  };

  const handleAgentStatusClick = (status: string, count: number) => {
    const agents = generateMockAgents(count, status);
    setAgentDialogData({ 
      title: `${status} Agents (${count})`, 
      agents 
    });
    setAgentDialogOpen(true);
  };

  // Generate trend data for sparklines
  const generateTrendData = (baseValue: number, trend: 'up' | 'down' | 'stable') => {
    const points = 7;
    const data = [];
    let currentValue = baseValue * 0.8;
    
    for (let i = 0; i < points; i++) {
      const variation = trend === 'up' 
        ? Math.random() * 0.15 + 0.05
        : trend === 'down'
        ? Math.random() * -0.10 - 0.05
        : Math.random() * 0.10 - 0.05;
      
      currentValue = currentValue * (1 + variation);
      data.push({ value: Math.max(0, currentValue) });
    }
    
    return data;
  };

  return (
    <>
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
          <Users className="w-5 h-5 text-primary" />
          Agent Status
        </h3>
        
        {/* First Row: Current Availability & Utilization and Completion Time Table */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Agent Current Availability & Utilization */}
          <div className="space-y-3 p-5 rounded-lg border bg-card/50 backdrop-blur-sm hover:shadow-md transition-all duration-300">
            <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
              <div className="p-2 rounded-md bg-primary/10">
                <Users className="w-4 h-4 text-primary" />
              </div>
              Current Availability & Utilization
            </div>
            <div className="space-y-3">
              <div>
                <span className="text-2xl font-bold tracking-tight">{agentMetrics.totalInShift}</span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm pt-2 border-t">
                <div className="flex justify-between items-center p-2 rounded bg-background/30">
                  <span className="text-muted-foreground">Available:</span>
                  <Button
                    variant="ghost"
                    className="text-lg font-bold text-status-on-track h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                    onClick={() => handleAgentStatusClick("Available", agentMetrics.available)}
                  >
                    {agentMetrics.available}
                  </Button>
                </div>
                <div className="flex justify-between items-center p-2 rounded bg-background/30">
                  <span className="text-muted-foreground">Available but Idle:</span>
                  <Button
                    variant="ghost"
                    className="text-lg font-bold h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                    onClick={() => handleAgentStatusClick("Idle", agentMetrics.idle)}
                  >
                    {agentMetrics.idle}
                  </Button>
                </div>
                <div className="flex justify-between items-center p-2 rounded bg-background/30">
                  <span className="text-muted-foreground">Unavailable:</span>
                  <Button
                    variant="ghost"
                    className="text-lg font-bold text-status-breached h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                    onClick={() => handleAgentStatusClick("Unavailable", agentMetrics.unavailable)}
                  >
                    {agentMetrics.unavailable}
                  </Button>
                </div>
                <div className="flex justify-between items-center p-2 rounded bg-background/30">
                  <span className="text-muted-foreground">On Leave:</span>
                  <Button
                    variant="ghost"
                    className="text-lg font-bold text-muted-foreground h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                    onClick={() => handleAgentStatusClick("On Leave", agentMetrics.onLeave)}
                  >
                    {agentMetrics.onLeave}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Task Completion Time Table */}
          <div className="space-y-3 p-5 rounded-lg border bg-card/50 backdrop-blur-sm hover:shadow-md transition-all duration-300">
            <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
              <div className="p-2 rounded-md bg-primary/10">
                <Clock className="w-4 h-4 text-primary" />
              </div>
              Avg Completion Time by LoB
            </div>
            
            <div className="space-y-4">
              {/* Retail Group */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-primary bg-primary/5 px-3 py-1.5 rounded">Retail</div>
                <div className="grid grid-cols-2 gap-2 pl-3">
                  {mockTaskData.filter(item => item.lob === "Retail").map((item, index) => (
                    <div key={index} className="flex justify-between items-center text-xs p-2 rounded bg-background/50 hover:bg-background transition-colors">
                      <span className="text-muted-foreground">{item.claimType} - {item.claimSubType}</span>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-auto p-0 font-bold hover:text-primary"
                        onClick={() => handleCompletionTimeClick(item)}
                      >
                        {item.avgCompletionTime} min
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              {/* GMC Group */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-primary bg-primary/5 px-3 py-1.5 rounded">GMC</div>
                <div className="grid grid-cols-2 gap-2 pl-3">
                  {mockTaskData.filter(item => item.lob === "GMC").map((item, index) => (
                    <div key={index} className="flex justify-between items-center text-xs p-2 rounded bg-background/50 hover:bg-background transition-colors">
                      <span className="text-muted-foreground">{item.claimType} - {item.claimSubType}</span>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-auto p-0 font-bold hover:text-primary"
                        onClick={() => handleCompletionTimeClick(item)}
                      >
                        {item.avgCompletionTime} min
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Agent Status Dialog */}
      <Dialog open={agentDialogOpen} onOpenChange={setAgentDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>{agentDialogData.title}</DialogTitle>
          </DialogHeader>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Agent ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Current Task</TableHead>
                <TableHead>Tasks Completed</TableHead>
                <TableHead>Shift Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {agentDialogData.agents.map((agent) => (
                <TableRow key={agent.agentId}>
                  <TableCell>{agent.agentId}</TableCell>
                  <TableCell>{agent.name}</TableCell>
                  <TableCell>{agent.status}</TableCell>
                  <TableCell>{agent.currentTask}</TableCell>
                  <TableCell>{agent.tasksCompleted}</TableCell>
                  <TableCell>{agent.shiftTime}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </DialogContent>
      </Dialog>

      {/* Completion Time Dialog */}
      <Dialog open={completionDialogOpen} onOpenChange={setCompletionDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>Task Completion Details - {completionDialogData.title}</DialogTitle>
          </DialogHeader>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Claim ID</TableHead>
                <TableHead>Agent Name</TableHead>
                {completionDialogData.isCashlessIPD && <TableHead>Request Type</TableHead>}
                <TableHead>Time Taken (min)</TableHead>
                <TableHead>Completed At</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {completionDialogData.tasks.map((task) => (
                <TableRow key={task.taskId}>
                  <TableCell>{task.taskId}</TableCell>
                  <TableCell>{task.agentName}</TableCell>
                  {completionDialogData.isCashlessIPD && <TableCell>{task.requestType}</TableCell>}
                  <TableCell>{task.timeTaken}</TableCell>
                  <TableCell>{task.completedAt}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </DialogContent>
      </Dialog>
    </>
  );
}
