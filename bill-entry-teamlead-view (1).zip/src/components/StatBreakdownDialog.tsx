import { useState, useMemo } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Info, Search, Filter, SlidersHorizontal, Zap } from "lucide-react";

interface Task {
  claimId: string;
  status: string;
  priority?: number;
  slaBreach: string;
  escalation: string;
  admission: string;
  claimType: string;
  lob: string;
  subType: string;
  cohort: string;
  trustScore: string;
  requestType: string;
  ageing: string;
  assignedTo?: string;
  skipQueue?: boolean;
}

interface StatBreakdownDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  tasks: Task[];
  statusType?: "escalated" | "breached" | "at-risk" | "on-track" | "unassigned" | "pending";
  onUpdateEscalation?: (claimId: string, escalation: "Not escalated" | "Escalated") => void;
  onUpdateCohort?: (claimId: string, cohort: "Privileged" | "General") => void;
  onToggleSkipQueue?: (claimId: string) => void;
}

export function StatBreakdownDialog({
  open,
  onOpenChange,
  title,
  tasks,
  statusType,
  onUpdateEscalation,
  onUpdateCohort,
  onToggleSkipQueue,
}: StatBreakdownDialogProps) {
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [taskStatusFilter, setTaskStatusFilter] = useState<string>("all");
  const [slaFilter, setSlaFilter] = useState<string>("all");
  const [escalationFilter, setEscalationFilter] = useState<string>("all");
  const [lobFilter, setLobFilter] = useState<string>("all");
  const [claimTypeFilter, setClaimTypeFilter] = useState<string>("all");
  const [claimSubTypeFilter, setClaimSubTypeFilter] = useState<string>("all");
  const [requestTypeFilter, setRequestTypeFilter] = useState<string>("all");
  const [cohortFilter, setCohortFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("default");

  const getStatusColor = () => {
    switch (statusType) {
      case "escalated":
        return "text-status-escalated";
      case "breached":
        return "text-status-breached";
      case "at-risk":
        return "text-status-at-risk";
      case "on-track":
        return "text-status-on-track";
      default:
        return "text-foreground";
    }
  };

  const filteredTasks = useMemo(() => {
    return tasks
      .filter((task) => {
        // Search filter
        if (searchQuery.trim() !== "") {
          const query = searchQuery.toLowerCase();
          const matchesId = task.claimId.toLowerCase().includes(query);
          const matchesAssignedTo = task.assignedTo?.toLowerCase().includes(query);
          if (!matchesId && !matchesAssignedTo) return false;
        }
        
        if (taskStatusFilter !== "all" && task.status !== taskStatusFilter)
          return false;
        if (slaFilter !== "all" && task.slaBreach !== slaFilter)
          return false;
        if (escalationFilter !== "all" && task.escalation !== escalationFilter)
          return false;
        if (lobFilter !== "all" && task.lob !== lobFilter) return false;
        if (claimTypeFilter !== "all" && task.claimType !== claimTypeFilter)
          return false;
        if (claimSubTypeFilter !== "all" && task.subType !== claimSubTypeFilter)
          return false;
        if (requestTypeFilter !== "all" && task.requestType !== requestTypeFilter)
          return false;
        if (cohortFilter !== "all" && task.cohort !== cohortFilter)
          return false;
        return true;
      })
      .sort((a, b) => {
        if (sortBy === "priority-asc") {
          if (a.priority === undefined && b.priority === undefined) return 0;
          if (a.priority === undefined) return 1;
          if (b.priority === undefined) return -1;
          return a.priority - b.priority;
        } else if (sortBy === "priority-desc") {
          if (a.priority === undefined && b.priority === undefined) return 0;
          if (a.priority === undefined) return 1;
          if (b.priority === undefined) return -1;
          return b.priority - a.priority;
        } else if (sortBy === "ageing-asc") {
          return parseInt(a.ageing) - parseInt(b.ageing);
        } else if (sortBy === "ageing-desc") {
          return parseInt(b.ageing) - parseInt(a.ageing);
        }
        return 0;
      });
  }, [tasks, taskStatusFilter, slaFilter, escalationFilter, lobFilter, claimTypeFilter, claimSubTypeFilter, requestTypeFilter, cohortFilter, sortBy, searchQuery]);

  const clearFilters = () => {
    setTaskStatusFilter("all");
    setSlaFilter("all");
    setEscalationFilter("all");
    setLobFilter("all");
    setClaimTypeFilter("all");
    setClaimSubTypeFilter("all");
    setRequestTypeFilter("all");
    setCohortFilter("all");
    setSortBy("default");
    setSearchQuery("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">
              <span className={getStatusColor()}>{title}</span>
            </DialogTitle>
          </DialogHeader>
          
          <div className="mt-4 space-y-4">
            {/* Search, Sort, Filter Toolbar */}
            <div className="flex gap-3 items-center">
              {/* Search */}
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by Claim ID or Agent Name"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>

              {/* Sort Button */}
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="gap-2">
                    <SlidersHorizontal className="h-4 w-4" />
                    Sort
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-56" align="end">
                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">Sort By</h4>
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select sort order" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="default">Default Order</SelectItem>
                        <SelectItem value="priority-asc">Priority (Low to High)</SelectItem>
                        <SelectItem value="priority-desc">Priority (High to Low)</SelectItem>
                        <SelectItem value="ageing-asc">Ageing (Low to High)</SelectItem>
                        <SelectItem value="ageing-desc">Ageing (High to Low)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </PopoverContent>
              </Popover>

              {/* Filter Button */}
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="gap-2">
                    <Filter className="h-4 w-4" />
                    Filter
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80" align="end">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-sm">Filters</h4>
                      <Button onClick={clearFilters} variant="ghost" size="sm">
                        Clear All
                      </Button>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Task Status</label>
                        <Select value={taskStatusFilter} onValueChange={setTaskStatusFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Status</SelectItem>
                            <SelectItem value="Assigned">Assigned</SelectItem>
                            <SelectItem value="Pending assignment">Pending assignment</SelectItem>
                            <SelectItem value="Needs Review">Needs Review</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">SLA Breach</label>
                        <Select value={slaFilter} onValueChange={setSlaFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All SLA" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All SLA</SelectItem>
                            <SelectItem value="On track">On track</SelectItem>
                            <SelectItem value="Near Breach">Near Breach</SelectItem>
                            <SelectItem value="Breached">Breached</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Claim Type</label>
                        <Select value={claimTypeFilter} onValueChange={setClaimTypeFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Claims" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Claims</SelectItem>
                            <SelectItem value="Cashless">Cashless</SelectItem>
                            <SelectItem value="Reimbursement">Reimbursement</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Escalation</label>
                        <Select value={escalationFilter} onValueChange={setEscalationFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Escalation" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Escalation</SelectItem>
                            <SelectItem value="Not escalated">Not escalated</SelectItem>
                            <SelectItem value="Escalated">Escalated</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Line of Business</label>
                        <Select value={lobFilter} onValueChange={setLobFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All LoB" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All LoB</SelectItem>
                            <SelectItem value="Retail">Retail</SelectItem>
                            <SelectItem value="GMC">GMC</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Claim Sub Type</label>
                        <Select value={claimSubTypeFilter} onValueChange={setClaimSubTypeFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Sub Types" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Sub Types</SelectItem>
                            <SelectItem value="IPD">IPD</SelectItem>
                            <SelectItem value="OPD">OPD</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Request Type</label>
                        <Select value={requestTypeFilter} onValueChange={setRequestTypeFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Request Types" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Request Types</SelectItem>
                            <SelectItem value="Initial">Initial</SelectItem>
                            <SelectItem value="Enhancement">Enhancement</SelectItem>
                            <SelectItem value="Final">Final</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-xs text-muted-foreground mb-1.5 block">Customer Cohort</label>
                        <Select value={cohortFilter} onValueChange={setCohortFilter}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Cohorts" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Cohorts</SelectItem>
                            <SelectItem value="Privileged">Privileged</SelectItem>
                            <SelectItem value="General">General</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
            </div>

            {/* Quick Filters */}
            <div className="flex gap-2">
              <Button
                variant={taskStatusFilter === "Pending assignment" ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  if (taskStatusFilter === "Pending assignment") {
                    setTaskStatusFilter("all");
                  } else {
                    setTaskStatusFilter("Pending assignment");
                  }
                }}
              >
                Pending Assignment
              </Button>
              <Button
                variant={slaFilter === "Near Breach" ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  if (slaFilter === "Near Breach") {
                    setSlaFilter("all");
                  } else {
                    setSlaFilter("Near Breach");
                  }
                }}
              >
                Near Breach
              </Button>
              <Button
                variant={escalationFilter === "Escalated" ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  if (escalationFilter === "Escalated") {
                    setEscalationFilter("all");
                  } else {
                    setEscalationFilter("Escalated");
                  }
                }}
              >
                Escalations
              </Button>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Claim ID</TableHead>
                    <TableHead>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger className="flex items-center gap-1 cursor-help">
                            Priority <Info className="h-3 w-3" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">Priority order is decided by the final priority score calculated by the allocation engine.</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>SLA Breach</TableHead>
                    <TableHead>Ageing</TableHead>
                    <TableHead>LoB</TableHead>
                    <TableHead>Claim Type</TableHead>
                    <TableHead>Sub Type</TableHead>
                    <TableHead>Request Type</TableHead>
                    <TableHead>Admission</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead>Escalation</TableHead>
                    <TableHead>Cohort</TableHead>
                    {(statusType === "unassigned" || statusType === "pending") && <TableHead>Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTasks.length > 0 ? (
                    filteredTasks.map((task) => (
                      <TableRow key={task.claimId}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            {task.claimId}
                            {task.skipQueue && (
                              <Badge variant="destructive" className="text-xs">
                                <Zap className="h-3 w-3 mr-1" />
                                Priority
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{task.priority ?? "-"}</TableCell>
                        <TableCell>
                          <Badge variant={task.status === "Assigned" ? "default" : "secondary"}>
                            {task.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={task.slaBreach === "On track" ? "default" : task.slaBreach === "Breached" ? "destructive" : "secondary"}>
                            {task.slaBreach}
                          </Badge>
                        </TableCell>
                        <TableCell>{task.ageing}</TableCell>
                        <TableCell>{task.lob}</TableCell>
                        <TableCell>{task.claimType}</TableCell>
                        <TableCell>{task.subType}</TableCell>
                        <TableCell>{task.requestType}</TableCell>
                        <TableCell>{task.admission}</TableCell>
                        <TableCell>{task.assignedTo || "-"}</TableCell>
                        <TableCell>
                          {(statusType === "unassigned" || statusType === "pending") && onUpdateEscalation ? (
                            <Select
                              value={task.escalation}
                              onValueChange={(value) =>
                                onUpdateEscalation(task.claimId, value as "Not escalated" | "Escalated")
                              }
                            >
                              <SelectTrigger className="w-[150px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Not escalated">Not escalated</SelectItem>
                                <SelectItem value="Escalated">Escalated</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            task.escalation
                          )}
                        </TableCell>
                        <TableCell>
                          {(statusType === "unassigned" || statusType === "pending") && onUpdateCohort ? (
                            <Select
                              value={task.cohort}
                              onValueChange={(value) =>
                                onUpdateCohort(task.claimId, value as "Privileged" | "General")
                              }
                            >
                              <SelectTrigger className="w-[130px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Privileged">Privileged</SelectItem>
                                <SelectItem value="General">General</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            task.cohort
                          )}
                        </TableCell>
                        {(statusType === "unassigned" || statusType === "pending") && (
                          <TableCell>
                            {onToggleSkipQueue && (
                              <Button
                                size="sm"
                                variant={task.skipQueue ? "destructive" : "outline"}
                                onClick={() => onToggleSkipQueue(task.claimId)}
                                disabled={task.priority === undefined}
                              >
                                {task.skipQueue ? (
                                  <>
                                    <Zap className="h-4 w-4 mr-1" />
                                    Skip Active
                                  </>
                                ) : (
                                  "Skip Queue"
                                )}
                              </Button>
                            )}
                          </TableCell>
                        )}
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={(statusType === "unassigned" || statusType === "pending") ? 14 : 13} className="text-center text-muted-foreground py-8">
                        No tasks matching the selected filters
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </DialogContent>
      </Dialog>
  );
}
