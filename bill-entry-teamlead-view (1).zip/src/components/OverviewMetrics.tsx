import { Users, TrendingUp, AlertCircle, Activity, UserX, Target, CheckCircle, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatBreakdownDialog } from "./StatBreakdownDialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { LineChart, Line, ResponsiveContainer } from "recharts";

interface OverviewMetricsProps {
  timeFilter?: string;
}

export function OverviewMetrics({ timeFilter = "today" }: OverviewMetricsProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogData, setDialogData] = useState<{ 
    title: string; 
    tasks: any[]; 
    statusType?: "at-risk" | "breached" | "escalated" | "on-track" | "unassigned" | "pending" 
  }>({
    title: "",
    tasks: [],
  });

  const [agentDialogOpen, setAgentDialogOpen] = useState(false);
  const [agentDialogData, setAgentDialogData] = useState<{
    title: string;
    agents: any[];
  }>({
    title: "",
    agents: [],
  });

  const [completionDialogOpen, setCompletionDialogOpen] = useState(false);
  const [completionDialogData, setCompletionDialogData] = useState<{
    title: string;
    isCashlessIPD: boolean;
    tasks: Array<{
      claimId: string;
      agentName: string;
      timeTaken: number;
      completedAt: string;
      requestType?: string;
    }>;
  }>({
    title: "",
    isCashlessIPD: false,
    tasks: [],
  });

  // Filter states
  const [selectedLoB, setSelectedLoB] = useState<string>("all");
  const [selectedClaimType, setSelectedClaimType] = useState<string>("all");
  const [selectedClaimSubType, setSelectedClaimSubType] = useState<string>("all");
  const [selectedPreauthType, setSelectedPreauthType] = useState<string>("all");

  // Generate trend data for sparklines
  const generateTrendData = (baseValue: number, trend: 'up' | 'down' | 'stable') => {
    const points = 7; // 7 data points for the trend
    const data = [];
    let currentValue = baseValue * 0.8; // Start at 80% of current value
    
    for (let i = 0; i < points; i++) {
      const variation = trend === 'up' 
        ? Math.random() * 0.15 + 0.05 // Upward trend: 5-20% increase
        : trend === 'down'
        ? Math.random() * -0.10 - 0.05 // Downward trend: 5-15% decrease
        : Math.random() * 0.10 - 0.05; // Stable: -5% to +5%
      
      currentValue = currentValue * (1 + variation);
      data.push({ value: Math.max(0, currentValue) });
    }
    
    return data;
  };

  // Mock data for filtering - adjusted based on time period
  const getTaskMultiplier = () => {
    switch (timeFilter) {
      case "week": return 5;
      case "month": return 20;
      case "custom": return 10;
      default: return 1; // today
    }
  };

  const multiplier = getTaskMultiplier();
  
  const mockTaskData = [
    { lob: "Retail", claimType: "Cashless", claimSubType: "IPD", preauthType: "Preauth Final", onTrack: 28 * multiplier, atRisk: 6 * multiplier, breached: 1 * multiplier, unassigned: 1 * multiplier, escalated: 0 * multiplier, skipQueue: 0, avgCompletionTime: 19.8 },
    { lob: "Retail", claimType: "Cashless", claimSubType: "OPD", preauthType: "Preauth Initial", onTrack: 23 * multiplier, atRisk: 5 * multiplier, breached: 2 * multiplier, unassigned: 1 * multiplier, escalated: 1 * multiplier, skipQueue: 0, avgCompletionTime: 15.2 },
    { lob: "Retail", claimType: "Reimbursement", claimSubType: "IPD", preauthType: null, onTrack: 38 * multiplier, atRisk: 9 * multiplier, breached: 4 * multiplier, unassigned: 2 * multiplier, escalated: 2 * multiplier, skipQueue: 1 * multiplier, avgCompletionTime: 32.1 },
    { lob: "Retail", claimType: "Reimbursement", claimSubType: "OPD", preauthType: null, onTrack: 25 * multiplier, atRisk: 4 * multiplier, breached: 1 * multiplier, unassigned: 1 * multiplier, escalated: 0 * multiplier, skipQueue: 0, avgCompletionTime: 18.7 },
    { lob: "GMC", claimType: "Cashless", claimSubType: "IPD", preauthType: "Preauth Initial", onTrack: 34 * multiplier, atRisk: 7 * multiplier, breached: 3 * multiplier, unassigned: 3 * multiplier, escalated: 1 * multiplier, skipQueue: 1 * multiplier, avgCompletionTime: 26.4 },
    { lob: "GMC", claimType: "Cashless", claimSubType: "OPD", preauthType: "Preauth Enhancement", onTrack: 20 * multiplier, atRisk: 3 * multiplier, breached: 2 * multiplier, unassigned: 1 * multiplier, escalated: 1 * multiplier, skipQueue: 0, avgCompletionTime: 14.9 },
    { lob: "GMC", claimType: "Reimbursement", claimSubType: "IPD", preauthType: null, onTrack: 29 * multiplier, atRisk: 6 * multiplier, breached: 2 * multiplier, unassigned: 2 * multiplier, escalated: 1 * multiplier, skipQueue: 1 * multiplier, avgCompletionTime: 29.6 },
    { lob: "GMC", claimType: "Reimbursement", claimSubType: "OPD", preauthType: null, onTrack: 18 * multiplier, atRisk: 4 * multiplier, breached: 1 * multiplier, unassigned: 1 * multiplier, escalated: 0 * multiplier, skipQueue: 0, avgCompletionTime: 16.3 },
  ];

  // Generate mock completion tasks
  const generateCompletionTasks = (lob: string, claimType: string, claimSubType: string, avgTime: number) => {
    const agentNames = ["Sarah Johnson", "Michael Chen", "Emma Wilson", "David Kumar", "Lisa Anderson"];
    const requestTypes = ["Preauth Initial", "Preauth Enhancement", "Preauth Final"];
    const taskCount = Math.floor(Math.random() * 8) + 5;
    const isCashlessIPD = claimType === "Cashless" && claimSubType === "IPD";
    
    return Array.from({ length: taskCount }, (_, i) => ({
      claimId: `CLM-${Math.floor(Math.random() * 90000) + 10000}`,
      agentName: agentNames[Math.floor(Math.random() * agentNames.length)],
      timeTaken: Math.round(avgTime * (0.7 + Math.random() * 0.6)), // Vary around average
      completedAt: new Date(Date.now() - Math.random() * 8 * 60 * 60 * 1000).toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
      }),
      ...(isCashlessIPD && { requestType: requestTypes[Math.floor(Math.random() * requestTypes.length)] })
    }));
  };

  const handleCompletionTimeClick = (item: any) => {
    const tasks = generateCompletionTasks(item.lob, item.claimType, item.claimSubType, item.avgCompletionTime);
    setCompletionDialogData({
      title: `${item.lob} - ${item.claimType} - ${item.claimSubType}`,
      isCashlessIPD: item.claimType === "Cashless" && item.claimSubType === "IPD",
      tasks
    });
    setCompletionDialogOpen(true);
  };

  // Filter data based on selections
  const filteredTaskData = mockTaskData.filter((item) => {
    if (selectedLoB !== "all" && item.lob !== selectedLoB) return false;
    if (selectedClaimType !== "all" && item.claimType !== selectedClaimType) return false;
    if (selectedClaimSubType !== "all" && item.claimSubType !== selectedClaimSubType) return false;
    if (selectedPreauthType !== "all" && item.preauthType !== selectedPreauthType) return false;
    return true;
  });

  // Calculate aggregated metrics from filtered data
  const aggregatedMetrics = filteredTaskData.reduce(
    (acc, item) => ({
      onTrack: acc.onTrack + item.onTrack,
      atRisk: acc.atRisk + item.atRisk,
      breached: acc.breached + item.breached,
      unassigned: acc.unassigned + item.unassigned,
      escalated: acc.escalated + item.escalated,
      skipQueue: acc.skipQueue + item.skipQueue,
    }),
    { onTrack: 0, atRisk: 0, breached: 0, unassigned: 0, escalated: 0, skipQueue: 0 }
  );

  // Dynamic Traffic Metrics based on timeFilter
  // Equation: spillover + enteredToday = completed + currentInPool
  // Note: currentInPool (Total Pending) = regularPending + escalated + skipQueue
  const getTrafficMetrics = () => {
    switch (timeFilter) {
      case "today":
        return {
          spillover: 25,
          enteredToday: 64,
          completed: 50,
          currentInPool: 39, // Total Pending: 25 + 64 = 50 + 39
          regularPending: 27, // 39 - 8 - 4
          totalReceived: 387,
          onTrack: 245,
          atRisk: 52,
          breached: 18,
          unassigned: 15,
          escalated: 8,
          skipQueue: 4,
          // Historical data
          yesterday: {
            spillover: 22,
            enteredToday: 58,
            completed: 45,
            currentInPool: 35,
            regularPending: 26, // 35 - 6 - 3
            escalated: 6,
            skipQueue: 3
          },
          lastWeekThisDay: {
            spillover: 28,
            enteredToday: 61,
            completed: 52,
            currentInPool: 37,
            regularPending: 25, // 37 - 7 - 5
            escalated: 7,
            skipQueue: 5
          }
        };
      case "week":
        return {
          spillover: 108,
          enteredToday: 448,
          completed: 400,
          currentInPool: 156, // 108 + 448 = 400 + 156
          regularPending: 90, // 156 - 43 - 23
          totalReceived: 2156,
          onTrack: 1645,
          atRisk: 278,
          breached: 89,
          unassigned: 78,
          escalated: 43,
          skipQueue: 23,
          // Historical data
          yesterday: {
            spillover: 95,
            enteredToday: 420,
            completed: 380,
            currentInPool: 135,
            regularPending: 77, // 135 - 38 - 20
            escalated: 38,
            skipQueue: 20
          },
          lastWeekThisDay: {
            spillover: 115,
            enteredToday: 455,
            completed: 410,
            currentInPool: 160,
            regularPending: 90, // 160 - 45 - 25
            escalated: 45,
            skipQueue: 25
          }
        };
      case "month":
        return {
          spillover: 344,
          enteredToday: 1890,
          completed: 2000,
          currentInPool: 234, // 344 + 1890 = 2000 + 234
          regularPending: -30, // 234 - 167 - 97
          totalReceived: 9450,
          onTrack: 7234,
          atRisk: 1156,
          breached: 378,
          unassigned: 298,
          escalated: 167,
          skipQueue: 97,
          // Historical data
          yesterday: {
            spillover: 320,
            enteredToday: 1750,
            completed: 1850,
            currentInPool: 220,
            regularPending: -25, // 220 - 155 - 90
            escalated: 155,
            skipQueue: 90
          },
          lastWeekThisDay: {
            spillover: 365,
            enteredToday: 1820,
            completed: 1950,
            currentInPool: 235,
            regularPending: -35, // 235 - 170 - 100
            escalated: 170,
            skipQueue: 100
          }
        };
      case "custom":
        return {
          spillover: 233,
          enteredToday: 890,
          completed: 1000,
          currentInPool: 123, // 233 + 890 = 1000 + 123
          regularPending: 0, // 123 - 78 - 45
          totalReceived: 4567,
          onTrack: 3456,
          atRisk: 589,
          breached: 189,
          unassigned: 145,
          escalated: 78,
          skipQueue: 45,
          // Historical data
          yesterday: {
            spillover: 215,
            enteredToday: 850,
            completed: 920,
            currentInPool: 145,
            regularPending: 35, // 145 - 70 - 40
            escalated: 70,
            skipQueue: 40
          },
          lastWeekThisDay: {
            spillover: 240,
            enteredToday: 910,
            completed: 1050,
            currentInPool: 100,
            regularPending: -30, // 100 - 82 - 48
            escalated: 82,
            skipQueue: 48
          }
        };
      default:
        return {
          spillover: 25,
          enteredToday: 64,
          completed: 50,
          currentInPool: 39, // 25 + 64 = 50 + 39
          regularPending: 27, // 39 - 8 - 4
          totalReceived: 387,
          onTrack: 245,
          atRisk: 52,
          breached: 18,
          unassigned: 15,
          escalated: 8,
          skipQueue: 4,
          // Historical data
          yesterday: {
            spillover: 22,
            enteredToday: 58,
            completed: 45,
            currentInPool: 35,
            regularPending: 26, // 35 - 6 - 3
            escalated: 6,
            skipQueue: 3
          },
          lastWeekThisDay: {
            spillover: 28,
            enteredToday: 61,
            completed: 52,
            currentInPool: 37,
            regularPending: 25, // 37 - 7 - 5
            escalated: 7,
            skipQueue: 5
          }
        };
    }
  };

  const trafficMetrics = getTrafficMetrics();

  const totalTasks = aggregatedMetrics.onTrack + aggregatedMetrics.atRisk + aggregatedMetrics.breached + aggregatedMetrics.unassigned;
  const completionRate = ((trafficMetrics.completed / trafficMetrics.totalReceived) * 100).toFixed(1);

  // Agent Live Status Metrics
  const agentMetrics = {
    totalInShift: 45,
    available: 28,
    unavailable: 5,
    idle: 8,
    onLeave: 4,
    avgCompletionTime: 24.5, // minutes
    activeHours: 315,
    totalAvailableHours: 360
  };

  const utilizationRate = ((agentMetrics.activeHours / agentMetrics.totalAvailableHours) * 100).toFixed(1);

  const generateMockTasks = (count: number, type: string) => {
    return Array.from({ length: count }, (_, i) => ({
      claimId: `C-${String(i + 1).padStart(3, '0')}`,
      status: type.includes("Unassigned") ? "Pending assignment" : type.includes("Assigned") ? "Assigned" : "Needs Review",
      priority: type.includes("Unassigned") ? i + 1 : undefined, // Priority only for unassigned tasks
      slaBreach: type.includes("Breached") ? "Breached" : type.includes("At Risk") ? "Near Breach" : "On track",
      escalation: type.includes("Escalated") ? "Escalated" : "Not escalated",
      admission: ["Planned", "Emergency", "-"][i % 3],
      claimType: ["Cashless", "Reimbursement"][i % 2],
      lob: ["Retail", "GMC"][i % 2],
      subType: ["IPD", "OPD"][i % 2],
      cohort: ["General", "Privileged"][i % 2],
      trustScore: ["40-70", ">80", "0-40"][i % 3],
      requestType: ["Initial", "Final", "-"][i % 3],
      ageing: `${Math.floor(Math.random() * 10) + 1} days`,
      assignedTo: type.includes("Unassigned") ? undefined : ["David Lee", "Jane Smith", "Mike Johnson", "John Doe"][i % 4],
      skipQueue: false,
    }));
  };

  const handleUpdateEscalation = (claimId: string, escalation: "Not escalated" | "Escalated") => {
    setDialogData(prevData => ({
      ...prevData,
      tasks: prevData.tasks.map(task =>
        task.claimId === claimId ? { ...task, escalation } : task
      )
    }));
  };

  const handleUpdateCohort = (claimId: string, cohort: "Privileged" | "General") => {
    setDialogData(prevData => ({
      ...prevData,
      tasks: prevData.tasks.map(task =>
        task.claimId === claimId ? { ...task, cohort } : task
      )
    }));
  };

  const handleToggleSkipQueue = (claimId: string) => {
    setDialogData(prevData => ({
      ...prevData,
      tasks: prevData.tasks.map(task =>
        task.claimId === claimId ? { ...task, skipQueue: !task.skipQueue } : task
      )
    }));
  };

  const generateMockAgents = (count: number, status: string) => {
    const agentNames = ["Priya Singh", "Raj Patel", "Anita Kumar", "David Lee", "Jane Smith", "Mike Johnson", "John Doe", "Sarah Williams", "Tom Brown", "Lisa Anderson", "Kevin Chen", "Maria Garcia", "James Wilson", "Emily Taylor"];
    return Array.from({ length: count }, (_, i) => ({
      agentId: `AGT-${String(i + 1).padStart(3, '0')}`,
      name: agentNames[i % agentNames.length],
      status: status,
      currentTask: status === "Available" ? "-" : status === "On Leave" ? "-" : `Task T-${Math.floor(Math.random() * 999) + 1}`,
      tasksCompleted: Math.floor(Math.random() * 20) + 5,
      shiftTime: "9:00 AM - 5:00 PM",
    }));
  };

  const handleAgentStatusClick = (status: string, count: number) => {
    const agents = generateMockAgents(count, status);
    setAgentDialogData({ 
      title: `${status} Agents (${count})`, 
      agents 
    });
    setAgentDialogOpen(true);
  };

  const handleMetricClick = (
    title: string, 
    count: number, 
    statusType?: "at-risk" | "breached" | "escalated" | "on-track" | "unassigned" | "pending"
  ) => {
    const tasks = generateMockTasks(count, title);
    setDialogData({ title, tasks, statusType });
    setDialogOpen(true);
  };

  return (
    <Card className="bg-gradient-to-br from-card via-card to-muted/20">
      <CardContent className="space-y-8 pt-6">
        {/* Section 1: Today's Traffic */}
        <div className="space-y-4">
          {/* Throughput Metrics Group - Full Width */}
          <div className="p-5 rounded-lg border bg-card/50 backdrop-blur-sm">
            <h4 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              Throughput Metrics
            </h4>
            
            <div className="grid grid-cols-6 gap-4">
                {/* Previous Spillover */}
                <div className="space-y-2">
                  <div className="text-xs font-medium text-muted-foreground">Previous Spillover</div>
                  <Button
                    variant="ghost"
                    className="text-2xl font-bold tracking-tight h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                    onClick={() => handleMetricClick("Previous Spillover", trafficMetrics.spillover, undefined)}
                  >
                    {trafficMetrics.spillover}
                  </Button>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div className="flex justify-between">
                      <span>Yesterday:</span>
                      <span className="font-medium">{trafficMetrics.yesterday.spillover}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Same day last week:</span>
                      <span className="font-medium">{trafficMetrics.lastWeekThisDay.spillover}</span>
                    </div>
                  </div>
                </div>

                {/* Received Today */}
                <div className="space-y-2">
                  <div className="text-xs font-medium text-muted-foreground">Received Today</div>
                  <Button
                    variant="ghost"
                    className="text-2xl font-bold tracking-tight h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                    onClick={() => handleMetricClick("Received Today", trafficMetrics.enteredToday, undefined)}
                  >
                    {trafficMetrics.enteredToday}
                  </Button>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div className="flex justify-between">
                      <span>Yesterday:</span>
                      <span className="font-medium">{trafficMetrics.yesterday.enteredToday}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Same day last week:</span>
                      <span className="font-medium">{trafficMetrics.lastWeekThisDay.enteredToday}</span>
                    </div>
                  </div>
                </div>

                {/* Completed */}
                <div className="space-y-2">
                  <div className="text-xs font-medium text-muted-foreground">Completed</div>
                  <Button
                    variant="ghost"
                    className="text-2xl font-bold tracking-tight text-status-on-track h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                    onClick={() => handleMetricClick("Completed Tasks", trafficMetrics.completed, "on-track")}
                  >
                    {trafficMetrics.completed}
                  </Button>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div className="flex justify-between">
                      <span>Yesterday:</span>
                      <span className="font-medium">{trafficMetrics.yesterday.completed}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Same day last week:</span>
                      <span className="font-medium">{trafficMetrics.lastWeekThisDay.completed}</span>
                    </div>
                  </div>
                </div>

                {/* Pending */}
                <div className="space-y-2">
                  <div className="text-xs font-medium text-muted-foreground">Pending</div>
                  <Button
                    variant="ghost"
                    className="text-2xl font-bold tracking-tight h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                    onClick={() => handleMetricClick("Pending Tasks", trafficMetrics.currentInPool, "pending")}
                  >
                    {trafficMetrics.currentInPool}
                  </Button>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div className="flex justify-between">
                      <span>Yesterday:</span>
                      <span className="font-medium">{trafficMetrics.yesterday.currentInPool}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Same day last week:</span>
                      <span className="font-medium">{trafficMetrics.lastWeekThisDay.currentInPool}</span>
                    </div>
                  </div>
                </div>

                {/* Escalations */}
                <div className="space-y-2">
                  <div className="text-xs font-medium text-muted-foreground">
                    Escalations <span className="text-[10px]">(of Pending)</span>
                  </div>
                  <Button
                    variant="ghost"
                    className="text-2xl font-bold tracking-tight h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                    onClick={() => handleMetricClick("Escalations", trafficMetrics.escalated, undefined)}
                  >
                    {trafficMetrics.escalated}
                  </Button>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div className="flex justify-between">
                      <span>Yesterday:</span>
                      <span className="font-medium">{trafficMetrics.yesterday.escalated}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Same day last week:</span>
                      <span className="font-medium">{trafficMetrics.lastWeekThisDay.escalated}</span>
                    </div>
                  </div>
                </div>

                {/* Skip Queue */}
                <div className="space-y-2">
                  <div className="text-xs font-medium text-muted-foreground">
                    Skip Queue <span className="text-[10px]">(of Pending)</span>
                  </div>
                  <Button
                    variant="ghost"
                    className="text-2xl font-bold tracking-tight h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                    onClick={() => handleMetricClick("Skip Queue", trafficMetrics.skipQueue, undefined)}
                  >
                    {trafficMetrics.skipQueue}
                  </Button>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div className="flex justify-between">
                      <span>Yesterday:</span>
                      <span className="font-medium">{trafficMetrics.yesterday.skipQueue}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Same day last week:</span>
                      <span className="font-medium">{trafficMetrics.lastWeekThisDay.skipQueue}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          {/* SLA Status Breakdown */}
          <div className="p-5 rounded-lg border bg-card/50 backdrop-blur-sm space-y-4">
            {/* Main SLA Metrics */}
            <div>
              <div className="flex flex-col gap-4 mb-4">
              <h4 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Activity className="w-4 h-4 text-primary" />
                SLA Status Summary
              </h4>
                
                {/* Filters */}
                <div className="flex flex-wrap items-center gap-3">
                  <Select value={selectedLoB} onValueChange={setSelectedLoB}>
                    <SelectTrigger className="w-[160px] bg-background">
                      <SelectValue placeholder="LoB" />
                    </SelectTrigger>
                    <SelectContent className="bg-background z-50">
                      <SelectItem value="all">All LoB</SelectItem>
                      <SelectItem value="Retail">Retail</SelectItem>
                      <SelectItem value="GMC">GMC</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select 
                    value={selectedClaimType} 
                    onValueChange={(value) => {
                      setSelectedClaimType(value);
                      // Reset preauth type when claim type changes
                      if (value !== "Cashless") {
                        setSelectedPreauthType("all");
                      }
                    }}
                  >
                    <SelectTrigger className="w-[180px] bg-background">
                      <SelectValue placeholder="Claim Type" />
                    </SelectTrigger>
                    <SelectContent className="bg-background z-50">
                      <SelectItem value="all">All Claim Types</SelectItem>
                      <SelectItem value="Cashless">Cashless</SelectItem>
                      <SelectItem value="Reimbursement">Reimbursement</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select 
                    value={selectedClaimSubType} 
                    onValueChange={(value) => {
                      setSelectedClaimSubType(value);
                      // Reset preauth type when OPD is selected
                      if (value === "OPD") {
                        setSelectedPreauthType("all");
                      }
                    }}
                  >
                    <SelectTrigger className="w-[180px] bg-background">
                      <SelectValue placeholder="Claim Sub Type" />
                    </SelectTrigger>
                    <SelectContent className="bg-background z-50">
                      <SelectItem value="all">All Sub Types</SelectItem>
                      <SelectItem value="IPD">IPD</SelectItem>
                      <SelectItem value="OPD">OPD</SelectItem>
                    </SelectContent>
                  </Select>

                  {selectedClaimType === "Cashless" && selectedClaimSubType !== "OPD" && (
                    <Select value={selectedPreauthType} onValueChange={setSelectedPreauthType}>
                      <SelectTrigger className="w-[180px] bg-background">
                        <SelectValue placeholder="Preauth Type" />
                      </SelectTrigger>
                      <SelectContent className="bg-background z-50">
                        <SelectItem value="all">All Preauth Types</SelectItem>
                        <SelectItem value="Preauth Initial">Preauth Initial</SelectItem>
                        <SelectItem value="Preauth Enhancement">Preauth Enhancement</SelectItem>
                        <SelectItem value="Preauth Final">Preauth Final</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                  
                  {(selectedLoB !== "all" || selectedClaimType !== "all" || selectedClaimSubType !== "all" || selectedPreauthType !== "all") && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-9"
                      onClick={() => {
                        setSelectedLoB("all");
                        setSelectedClaimType("all");
                        setSelectedClaimSubType("all");
                        setSelectedPreauthType("all");
                      }}
                    >
                      Clear Filters
                    </Button>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                {/* Assigned Section */}
                <div className="space-y-3">
                  <h5 className="text-sm font-semibold text-foreground">Assigned</h5>
                  <div className="space-y-2">
                    {/* Assigned - Within SLA */}
                    <div className="p-3 rounded-lg border bg-background/50">
                      <div className="flex justify-between items-center">
                        <div className="text-xs font-medium text-muted-foreground">Within SLA</div>
                        <Button
                          variant="ghost"
                          className="text-lg font-bold text-status-on-track h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                          onClick={() => handleMetricClick("Assigned Within SLA", Math.floor(aggregatedMetrics.onTrack * 0.85), "on-track")}
                        >
                          {Math.floor(aggregatedMetrics.onTrack * 0.85)}
                        </Button>
                      </div>
                    </div>
                    
                    {/* Assigned - At Risk */}
                    <div className="p-3 rounded-lg border bg-background/50">
                      <div className="flex justify-between items-center">
                        <div className="text-xs font-medium text-muted-foreground">At Risk</div>
                        <Button
                          variant="ghost"
                          className="text-lg font-bold text-status-at-risk h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                          onClick={() => handleMetricClick("Assigned At Risk", Math.floor(aggregatedMetrics.atRisk * 0.9), "at-risk")}
                        >
                          {Math.floor(aggregatedMetrics.atRisk * 0.9)}
                        </Button>
                      </div>
                    </div>
                    
                    {/* Assigned - Breached */}
                    <div className="p-3 rounded-lg border bg-background/50">
                      <div className="flex justify-between items-center">
                        <div className="text-xs font-medium text-muted-foreground">Breached</div>
                        <Button
                          variant="ghost"
                          className="text-lg font-bold text-status-breached h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                          onClick={() => handleMetricClick("Assigned Breached", Math.floor(aggregatedMetrics.breached * 0.88), "breached")}
                        >
                          {Math.floor(aggregatedMetrics.breached * 0.88)}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Unassigned Section */}
                <div className="space-y-3">
                  <h5 className="text-sm font-semibold text-foreground">Unassigned</h5>
                  <div className="space-y-2">
                    {/* Unassigned - Within SLA */}
                    <div className="p-3 rounded-lg border bg-background/50">
                      <div className="flex justify-between items-center">
                        <div className="text-xs font-medium text-muted-foreground">Within SLA</div>
                        <Button
                          variant="ghost"
                          className="text-lg font-bold text-status-on-track h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                          onClick={() => handleMetricClick("Unassigned Within SLA", Math.floor(aggregatedMetrics.onTrack * 0.15), "unassigned")}
                        >
                          {Math.floor(aggregatedMetrics.onTrack * 0.15)}
                        </Button>
                      </div>
                    </div>
                    
                    {/* Unassigned - At Risk */}
                    <div className="p-3 rounded-lg border bg-background/50">
                      <div className="flex justify-between items-center">
                        <div className="text-xs font-medium text-muted-foreground">At Risk</div>
                        <Button
                          variant="ghost"
                          className="text-lg font-bold text-status-at-risk h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                          onClick={() => handleMetricClick("Unassigned At Risk", Math.floor(aggregatedMetrics.atRisk * 0.1), "unassigned")}
                        >
                          {Math.floor(aggregatedMetrics.atRisk * 0.1)}
                        </Button>
                      </div>
                    </div>
                    
                    {/* Unassigned - Breached */}
                    <div className="p-3 rounded-lg border bg-background/50">
                      <div className="flex justify-between items-center">
                        <div className="text-xs font-medium text-muted-foreground">Breached</div>
                        <Button
                          variant="ghost"
                          className="text-lg font-bold text-status-breached h-auto p-0 hover:bg-transparent hover:text-primary transition-colors"
                          onClick={() => handleMetricClick("Unassigned Breached", Math.floor(aggregatedMetrics.breached * 0.12), "unassigned")}
                        >
                          {Math.floor(aggregatedMetrics.breached * 0.12)}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </CardContent>

      <StatBreakdownDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title={dialogData.title}
        tasks={dialogData.tasks}
        statusType={dialogData.statusType}
        onUpdateEscalation={dialogData.statusType === "unassigned" || dialogData.statusType === "pending" ? handleUpdateEscalation : undefined}
        onUpdateCohort={dialogData.statusType === "unassigned" || dialogData.statusType === "pending" ? handleUpdateCohort : undefined}
        onToggleSkipQueue={dialogData.statusType === "unassigned" || dialogData.statusType === "pending" ? handleToggleSkipQueue : undefined}
      />

      {/* Agent List Dialog */}
      <Dialog open={agentDialogOpen} onOpenChange={setAgentDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">{agentDialogData.title}</DialogTitle>
          </DialogHeader>
          
          <div className="mt-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Agent ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Current Task</TableHead>
                  <TableHead>Tasks Completed Today</TableHead>
                  <TableHead>Shift Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {agentDialogData.agents.length > 0 ? (
                  agentDialogData.agents.map((agent) => (
                    <TableRow key={agent.agentId}>
                      <TableCell className="font-medium">{agent.agentId}</TableCell>
                      <TableCell>{agent.name}</TableCell>
                      <TableCell>
                        <Badge variant={agent.status === "Available" ? "default" : agent.status === "Unavailable" ? "destructive" : "secondary"}>
                          {agent.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{agent.currentTask}</TableCell>
                      <TableCell>{agent.tasksCompleted}</TableCell>
                      <TableCell>{agent.shiftTime}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      No agents to display
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>

      {/* Completion Tasks Dialog */}
      <Dialog open={completionDialogOpen} onOpenChange={setCompletionDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl">Task Completion Details - {completionDialogData.title}</DialogTitle>
          </DialogHeader>
          
          <div className="mt-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Claim ID</TableHead>
                  <TableHead>Agent Name</TableHead>
                  {completionDialogData.isCashlessIPD && <TableHead>Request Type</TableHead>}
                  <TableHead>Time Taken</TableHead>
                  <TableHead>Completed At</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {completionDialogData.tasks.length > 0 ? (
                  completionDialogData.tasks.map((task) => (
                    <TableRow key={task.claimId}>
                      <TableCell className="font-medium">{task.claimId}</TableCell>
                      <TableCell>{task.agentName}</TableCell>
                      {completionDialogData.isCashlessIPD && (
                        <TableCell>
                          <Badge variant="outline">{task.requestType}</Badge>
                        </TableCell>
                      )}
                      <TableCell>
                        <Badge variant="secondary">{task.timeTaken} min</Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{task.completedAt}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={completionDialogData.isCashlessIPD ? 5 : 4} className="text-center text-muted-foreground py-8">
                      No tasks to display
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
