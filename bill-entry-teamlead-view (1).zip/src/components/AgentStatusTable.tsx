import { Users, X } from "lucide-react";
import { useState, useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { StatBreakdownDialog } from "./StatBreakdownDialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Agent {
  initials: string;
  name: string;
  statusColor: string;
  lob: string;
  claimType: string;
  claimSubType: string;
  assigned: number;
  onTrack: number;
  atRisk: number;
  breached: number;
  connRate: string;
  utilizationRate: string;
}

const mockAgents: Agent[] = [
  {
    initials: "PS",
    name: "Priya Singh",
    statusColor: "bg-status-on-call",
    lob: "Retail",
    claimType: "Cashless",
    claimSubType: "IPD",
    assigned: 8,
    onTrack: 5,
    atRisk: 2,
    breached: 1,
    connRate: "85%",
    utilizationRate: "92%",
  },
  {
    initials: "RP",
    name: "Raj Patel",
    statusColor: "bg-status-idle",
    lob: "GMC",
    claimType: "Reimbursement",
    claimSubType: "OPD",
    assigned: 5,
    onTrack: 4,
    atRisk: 1,
    breached: 0,
    connRate: "92%",
    utilizationRate: "88%",
  },
  {
    initials: "AK",
    name: "Anita Kumar",
    statusColor: "bg-status-wrap-up",
    lob: "Retail",
    claimType: "Cashless",
    claimSubType: "IPD",
    assigned: 12,
    onTrack: 7,
    atRisk: 3,
    breached: 2,
    connRate: "78%",
    utilizationRate: "95%",
  },
];

export function AgentStatusTable() {
  const [lobFilter, setLobFilter] = useState<string>("all");
  const [claimTypeFilter, setClaimTypeFilter] = useState<string>("all");
  const [claimSubTypeFilter, setClaimSubTypeFilter] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogData, setDialogData] = useState<{
    title: string;
    tasks: any[];
    statusType?: "escalated" | "breached" | "at-risk" | "on-track" | "unassigned";
  }>({ title: "", tasks: [] });

  const filteredAgents = useMemo(() => {
    return mockAgents.filter((agent) => {
      if (lobFilter !== "all" && agent.lob !== lobFilter) return false;
      if (claimTypeFilter !== "all" && agent.claimType !== claimTypeFilter) return false;
      if (claimSubTypeFilter !== "all" && agent.claimSubType !== claimSubTypeFilter) return false;
      return true;
    });
  }, [lobFilter, claimTypeFilter, claimSubTypeFilter]);

  const hasActiveFilters = lobFilter !== "all" || claimTypeFilter !== "all" || claimSubTypeFilter !== "all";

  const clearFilters = () => {
    setLobFilter("all");
    setClaimTypeFilter("all");
    setClaimSubTypeFilter("all");
  };

  const generateMockTasks = (agent: Agent, count: number, status: string) => {
    return Array.from({ length: count }, (_, i) => ({
      taskId: `TSK-${Math.floor(Math.random() * 10000)}`,
      customerName: `Customer ${i + 1}`,
      claimId: `CLM-${Math.floor(Math.random() * 10000)}`,
      assignedTo: agent.name,
      timeRemaining: status === "breached" ? "Overdue" : `${Math.floor(Math.random() * 24)}h ${Math.floor(Math.random() * 60)}m`,
      priority: Math.random() > 0.5 ? "High" : "Medium",
    }));
  };

  const handleStatClick = (agent: Agent, type: "assigned" | "onTrack" | "atRisk" | "breached") => {
    const statusMap = {
      assigned: { title: `${agent.name} - All Assigned Tasks (${agent.assigned})`, count: agent.assigned, statusType: undefined },
      onTrack: { title: `${agent.name} - On Track Tasks (${agent.onTrack})`, count: agent.onTrack, statusType: "on-track" as const },
      atRisk: { title: `${agent.name} - At Risk Tasks (${agent.atRisk})`, count: agent.atRisk, statusType: "at-risk" as const },
      breached: { title: `${agent.name} - Breached Tasks (${agent.breached})`, count: agent.breached, statusType: "breached" as const },
    };

    const { title, count, statusType } = statusMap[type];
    const tasks = generateMockTasks(agent, count, type);
    setDialogData({ title, tasks, statusType });
    setDialogOpen(true);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center gap-2 mb-4">
        <Users className="w-5 h-5 text-status-on-track" />
        <h2 className="text-lg font-semibold">
          Live Agent Status ({filteredAgents.length} agents)
        </h2>
      </div>

      <div className="flex flex-wrap items-center gap-3 mb-4">
        <Select value={lobFilter} onValueChange={setLobFilter}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="LoB" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All LoB</SelectItem>
            <SelectItem value="Retail">Retail</SelectItem>
            <SelectItem value="GMC">GMC</SelectItem>
          </SelectContent>
        </Select>

        <Select value={claimTypeFilter} onValueChange={setClaimTypeFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Claim Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Claim Types</SelectItem>
            <SelectItem value="Cashless">Cashless</SelectItem>
            <SelectItem value="Reimbursement">Reimbursement</SelectItem>
          </SelectContent>
        </Select>

        <Select value={claimSubTypeFilter} onValueChange={setClaimSubTypeFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Claim Sub Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sub Types</SelectItem>
            <SelectItem value="IPD">IPD</SelectItem>
            <SelectItem value="OPD">OPD</SelectItem>
          </SelectContent>
        </Select>

        {hasActiveFilters && (
          <Button variant="ghost" size="sm" onClick={clearFilters} className="gap-2">
            <X className="w-4 h-4" />
            Clear Filters
          </Button>
        )}

        {hasActiveFilters && (
          <div className="flex gap-2">
            {lobFilter !== "all" && (
              <Badge variant="secondary">{lobFilter}</Badge>
            )}
            {claimTypeFilter !== "all" && (
              <Badge variant="secondary">{claimTypeFilter}</Badge>
            )}
            {claimSubTypeFilter !== "all" && (
              <Badge variant="secondary">{claimSubTypeFilter}</Badge>
            )}
          </div>
        )}
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Agent</TableHead>
            <TableHead className="text-center">Assigned</TableHead>
            <TableHead className="text-center">On Track</TableHead>
            <TableHead className="text-center">At Risk</TableHead>
            <TableHead className="text-center">Breached</TableHead>
            <TableHead className="text-center">SLA Compliance Rate</TableHead>
            <TableHead className="text-center">Productivity Rate</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredAgents.length > 0 ? (
            filteredAgents.map((agent) => (
            <TableRow key={agent.name}>
              <TableCell>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-xs font-medium relative">
                    {agent.initials}
                    <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-card ${agent.statusColor}`} />
                  </div>
                  <span className="font-medium">{agent.name}</span>
                </div>
              </TableCell>
              <TableCell className="text-center">
                <button 
                  onClick={() => handleStatClick(agent, "assigned")}
                  className="font-semibold hover:underline cursor-pointer"
                >
                  {agent.assigned}
                </button>
              </TableCell>
              <TableCell className="text-center">
                <button 
                  onClick={() => handleStatClick(agent, "onTrack")}
                  className="text-status-on-track font-semibold hover:underline cursor-pointer"
                >
                  {agent.onTrack}
                </button>
              </TableCell>
              <TableCell className="text-center">
                <button 
                  onClick={() => handleStatClick(agent, "atRisk")}
                  className="text-status-at-risk font-semibold hover:underline cursor-pointer"
                >
                  {agent.atRisk}
                </button>
              </TableCell>
              <TableCell className="text-center">
                <button 
                  onClick={() => handleStatClick(agent, "breached")}
                  className="text-status-breached font-semibold hover:underline cursor-pointer"
                >
                  {agent.breached}
                </button>
              </TableCell>
              <TableCell className="text-center font-semibold">{agent.connRate}</TableCell>
              <TableCell className="text-center font-semibold">{agent.utilizationRate}</TableCell>
            </TableRow>
          ))
          ) : (
            <TableRow>
              <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                No agents match the selected filters
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      <StatBreakdownDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title={dialogData.title}
        tasks={dialogData.tasks}
        statusType={dialogData.statusType}
      />
    </div>
  );
}
