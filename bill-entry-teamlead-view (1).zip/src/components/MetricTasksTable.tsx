import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

interface Task {
  id: string;
  title: string;
  customer: string;
  priority: "Critical" | "High" | "Medium" | "Low";
  status: string;
  assignedDate: string;
  completedDate?: string;
  timeTaken?: string;
  slaStatus?: "Met" | "Breached" | "Pending";
}

interface MetricTasksTableProps {
  tasks: Task[];
  metricType: string;
}

export default function MetricTasksTable({ tasks, metricType }: MetricTasksTableProps) {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Critical": return "destructive";
      case "High": return "default";
      case "Medium": return "secondary";
      case "Low": return "outline";
      default: return "outline";
    }
  };

  const getSlaStatusColor = (status: string) => {
    switch (status) {
      case "Met": return "text-status-on-track";
      case "Breached": return "text-destructive";
      case "Pending": return "text-muted-foreground";
      default: return "text-muted-foreground";
    }
  };

  return (
    <div className="border rounded-lg">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Claim ID</TableHead>
            <TableHead>Title</TableHead>
            <TableHead>Customer</TableHead>
            <TableHead>Priority</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Assigned</TableHead>
            {metricType.includes("completed") && <TableHead>Completed</TableHead>}
            {metricType.includes("time") && <TableHead>Time Taken</TableHead>}
            {metricType.includes("sla") && <TableHead>SLA Status</TableHead>}
            <TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {tasks.map((task) => (
            <TableRow key={task.id}>
              <TableCell className="font-mono text-sm">{task.id}</TableCell>
              <TableCell className="max-w-xs truncate">{task.title}</TableCell>
              <TableCell>{task.customer}</TableCell>
              <TableCell>
                <Badge variant={getPriorityColor(task.priority)}>{task.priority}</Badge>
              </TableCell>
              <TableCell>{task.status}</TableCell>
              <TableCell className="text-sm text-muted-foreground">{task.assignedDate}</TableCell>
              {metricType.includes("completed") && (
                <TableCell className="text-sm text-muted-foreground">{task.completedDate || "-"}</TableCell>
              )}
              {metricType.includes("time") && (
                <TableCell className="text-sm font-medium">{task.timeTaken || "-"}</TableCell>
              )}
              {metricType.includes("sla") && task.slaStatus && (
                <TableCell className={`text-sm font-medium ${getSlaStatusColor(task.slaStatus)}`}>
                  {task.slaStatus}
                </TableCell>
              )}
              <TableCell>
                <Button variant="ghost" size="sm">
                  <ExternalLink className="w-4 h-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
