interface StatusMetricsProps {
  escalated: number;
  breached: number;
  atRisk: number;
  onTrack: number;
}

export function StatusMetrics({ escalated, breached, atRisk, onTrack }: StatusMetricsProps) {
  return (
    <div className="grid grid-cols-4 gap-4">
      <div className="text-center">
        <p className="text-xs font-medium text-muted-foreground mb-2">Escalated</p>
        <p className="text-2xl font-bold text-status-escalated">{escalated}</p>
      </div>
      <div className="text-center">
        <p className="text-xs font-medium text-muted-foreground mb-2">Breached</p>
        <p className="text-2xl font-bold text-status-breached">{breached}</p>
      </div>
      <div className="text-center">
        <p className="text-xs font-medium text-muted-foreground mb-2">At Risk</p>
        <p className="text-2xl font-bold text-status-at-risk">{atRisk}</p>
      </div>
      <div className="text-center">
        <p className="text-xs font-medium text-muted-foreground mb-2">On Track</p>
        <p className="text-2xl font-bold text-status-on-track">{onTrack}</p>
      </div>
    </div>
  );
}
