import { PhoneOutgoing, Filter } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { StatBreakdownDialog } from "./StatBreakdownDialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface CallData {
  type: string;
  escalated: number;
  breached: number;
  atRisk: number;
  onTrack: number;
}

const mockData: CallData[] = [
  { type: "Member Exclusion", escalated: 1, breached: 1, atRisk: 0, onTrack: 1 },
  { type: "Reproposal", escalated: 0, breached: 0, atRisk: 1, onTrack: 0 },
  { type: "Rejection", escalated: 0, breached: 0, atRisk: 1, onTrack: 0 },
];

export function InitiatedCallsTable() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogData, setDialogData] = useState<{
    title: string;
    tasks: any[];
    statusType?: "escalated" | "breached" | "at-risk" | "on-track";
  }>({ title: "", tasks: [] });

  const totalCalls = mockData.reduce(
    (acc, item) => acc + item.escalated + item.breached + item.atRisk + item.onTrack,
    0
  );

  const generateMockTasks = (row: CallData, count: number, status: string) => {
    return Array.from({ length: count }, (_, i) => ({
      taskId: `TSK-${Math.floor(Math.random() * 10000)}`,
      customerName: `Customer ${i + 1}`,
      claimId: `CLM-${Math.floor(Math.random() * 10000)}`,
      assignedTo: `Agent ${i + 1}`,
      timeRemaining: status === "breached" ? "Overdue" : `${Math.floor(Math.random() * 24)}h ${Math.floor(Math.random() * 60)}m`,
      priority: Math.random() > 0.5 ? "High" : "Medium",
    }));
  };

  const handleStatClick = (row: CallData, type: "escalated" | "breached" | "atRisk" | "onTrack") => {
    const statusMap = {
      escalated: { title: `${row.type} - Escalated (${row.escalated})`, count: row.escalated, statusType: "escalated" as const },
      breached: { title: `${row.type} - Breached (${row.breached})`, count: row.breached, statusType: "breached" as const },
      atRisk: { title: `${row.type} - At Risk (${row.atRisk})`, count: row.atRisk, statusType: "at-risk" as const },
      onTrack: { title: `${row.type} - On Track (${row.onTrack})`, count: row.onTrack, statusType: "on-track" as const },
    };

    const { title, count, statusType } = statusMap[type];
    const tasks = generateMockTasks(row, count, type);
    setDialogData({ title, tasks, statusType });
    setDialogOpen(true);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <PhoneOutgoing className="w-5 h-5 text-status-escalated" />
          <h2 className="text-lg font-semibold">
            ACKO Initiated Calls ({totalCalls})
          </h2>
        </div>
        <Button variant="outline" size="sm" className="gap-2">
          <Filter className="w-4 h-4" />
          Agents (All)
        </Button>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Type</TableHead>
            <TableHead className="text-center">Escalated</TableHead>
            <TableHead className="text-center">Breached</TableHead>
            <TableHead className="text-center">At Risk</TableHead>
            <TableHead className="text-center">On Track</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {mockData.map((row) => (
            <TableRow key={row.type}>
              <TableCell className="font-medium">{row.type}</TableCell>
              <TableCell className="text-center">
                <button 
                  onClick={() => handleStatClick(row, "escalated")}
                  className="text-status-escalated font-semibold hover:underline cursor-pointer"
                >
                  {row.escalated}
                </button>
              </TableCell>
              <TableCell className="text-center">
                <button 
                  onClick={() => handleStatClick(row, "breached")}
                  className="text-status-breached font-semibold hover:underline cursor-pointer"
                >
                  {row.breached}
                </button>
              </TableCell>
              <TableCell className="text-center">
                <button 
                  onClick={() => handleStatClick(row, "atRisk")}
                  className="text-status-at-risk font-semibold hover:underline cursor-pointer"
                >
                  {row.atRisk}
                </button>
              </TableCell>
              <TableCell className="text-center">
                <button 
                  onClick={() => handleStatClick(row, "onTrack")}
                  className="text-status-on-track font-semibold hover:underline cursor-pointer"
                >
                  {row.onTrack}
                </button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <StatBreakdownDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title={dialogData.title}
        tasks={dialogData.tasks}
        statusType={dialogData.statusType}
      />
    </div>
  );
}
