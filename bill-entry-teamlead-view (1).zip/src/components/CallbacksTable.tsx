import { ClipboardList, X } from "lucide-react";
import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { StatBreakdownDialog } from "./StatBreakdownDialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

interface CallbackData {
  lob: string;
  claimType: string;
  claimSubType: string;
  assigned: boolean;
  agent: string;
  unassigned: number;
  breached: number;
  atRisk: number;
  onTrack: number;
  escalated: number;
}

const mockData: CallbackData[] = [
  { lob: "Retail", claimType: "Cashless", claimSubType: "IPD", assigned: true, agent: "Priya Singh", unassigned: 2, breached: 1, atRisk: 3, onTrack: 8, escalated: 2 },
  { lob: "Retail", claimType: "Cashless", claimSubType: "OPD", assigned: false, agent: "Unassigned", unassigned: 3, breached: 0, atRisk: 2, onTrack: 5, escalated: 0 },
  { lob: "Retail", claimType: "Reimbursement", claimSubType: "IPD", assigned: true, agent: "Raj Patel", unassigned: 1, breached: 2, atRisk: 1, onTrack: 4, escalated: 1 },
  { lob: "Retail", claimType: "Reimbursement", claimSubType: "OPD", assigned: false, agent: "Unassigned", unassigned: 2, breached: 1, atRisk: 0, onTrack: 3, escalated: 0 },
  { lob: "GMC", claimType: "Cashless", claimSubType: "IPD", assigned: true, agent: "Anita Kumar", unassigned: 4, breached: 2, atRisk: 4, onTrack: 12, escalated: 3 },
  { lob: "GMC", claimType: "Cashless", claimSubType: "OPD", assigned: true, agent: "Priya Singh", unassigned: 1, breached: 0, atRisk: 1, onTrack: 6, escalated: 0 },
  { lob: "GMC", claimType: "Reimbursement", claimSubType: "IPD", assigned: false, agent: "Unassigned", unassigned: 3, breached: 1, atRisk: 2, onTrack: 7, escalated: 1 },
  { lob: "GMC", claimType: "Reimbursement", claimSubType: "OPD", assigned: true, agent: "Raj Patel", unassigned: 0, breached: 0, atRisk: 1, onTrack: 4, escalated: 0 },
];

export function CallbacksTable() {
  const [lobFilter, setLobFilter] = useState<string>("all");
  const [claimTypeFilter, setClaimTypeFilter] = useState<string>("all");
  const [claimSubTypeFilter, setClaimSubTypeFilter] = useState<string>("all");
  const [assignedFilter, setAssignedFilter] = useState<string>("all");
  const [agentFilter, setAgentFilter] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogData, setDialogData] = useState<{
    title: string;
    tasks: any[];
    statusType?: "escalated" | "breached" | "at-risk" | "on-track" | "unassigned";
  }>({ title: "", tasks: [] });

  const filteredData = useMemo(() => {
    return mockData.filter((item) => {
      if (lobFilter !== "all" && item.lob !== lobFilter) return false;
      if (claimTypeFilter !== "all" && item.claimType !== claimTypeFilter) return false;
      if (claimSubTypeFilter !== "all" && item.claimSubType !== claimSubTypeFilter) return false;
      if (assignedFilter === "assigned" && !item.assigned) return false;
      if (assignedFilter === "unassigned" && item.assigned) return false;
      if (agentFilter !== "all" && item.agent !== agentFilter) return false;
      return true;
    });
  }, [lobFilter, claimTypeFilter, claimSubTypeFilter, assignedFilter, agentFilter]);

  const totalCallbacks = filteredData.reduce(
    (acc, item) => acc + item.unassigned + item.breached + item.atRisk + item.onTrack,
    0
  );

  const hasActiveFilters = lobFilter !== "all" || claimTypeFilter !== "all" || claimSubTypeFilter !== "all" || assignedFilter !== "all" || agentFilter !== "all";

  const clearFilters = () => {
    setLobFilter("all");
    setClaimTypeFilter("all");
    setClaimSubTypeFilter("all");
    setAssignedFilter("all");
    setAgentFilter("all");
  };

  const generateMockTasks = (row: CallbackData, count: number, status: string) => {
    return Array.from({ length: count }, (_, i) => ({
      taskId: `TSK-${Math.floor(Math.random() * 10000)}`,
      customerName: `Customer ${i + 1}`,
      claimId: `CLM-${Math.floor(Math.random() * 10000)}`,
      assignedTo: status === "unassigned" ? undefined : (row.assigned ? row.agent : undefined),
      timeRemaining: status === "breached" ? "Overdue" : `${Math.floor(Math.random() * 24)}h ${Math.floor(Math.random() * 60)}m`,
      priority: status === "unassigned" ? i + 1 : Math.random() > 0.5 ? "High" : "Medium",
      skipQueue: false,
      status: status === "unassigned" ? "Pending assignment" : "Assigned",
      slaBreach: status === "breached" ? "Breached" : status === "atRisk" ? "Near Breach" : "On track",
      escalation: status === "escalated" ? "Escalated" : "Not escalated",
      admission: ["Planned", "Emergency", "-"][i % 3],
      claimType: row.claimType,
      lob: row.lob,
      subType: row.claimSubType,
      cohort: ["General", "Privileged"][i % 2],
      trustScore: ["40-70", ">80", "0-40"][i % 3],
      requestType: ["Initial", "Final", "-"][i % 3],
      ageing: `${Math.floor(Math.random() * 10) + 1} days`,
    }));
  };

  const handleUpdateEscalation = (claimId: string, escalation: "Not escalated" | "Escalated") => {
    setDialogData(prevData => ({
      ...prevData,
      tasks: prevData.tasks.map(task =>
        task.claimId === claimId ? { ...task, escalation } : task
      )
    }));
  };

  const handleUpdateCohort = (claimId: string, cohort: "Privileged" | "General") => {
    setDialogData(prevData => ({
      ...prevData,
      tasks: prevData.tasks.map(task =>
        task.claimId === claimId ? { ...task, cohort } : task
      )
    }));
  };

  const handleToggleSkipQueue = (claimId: string) => {
    setDialogData(prevData => ({
      ...prevData,
      tasks: prevData.tasks.map(task =>
        task.claimId === claimId ? { ...task, skipQueue: !task.skipQueue } : task
      )
    }));
  };

  const handleStatClick = (row: CallbackData, type: "unassigned" | "breached" | "atRisk" | "onTrack" | "escalated") => {
    const statusMap = {
      unassigned: { title: `${row.lob} - ${row.claimType} - Unassigned Tasks (${row.unassigned})`, count: row.unassigned, statusType: "unassigned" as const },
      breached: { title: `${row.lob} - ${row.claimType} - Breached Tasks (${row.breached})`, count: row.breached, statusType: "breached" as const },
      atRisk: { title: `${row.lob} - ${row.claimType} - At Risk Tasks (${row.atRisk})`, count: row.atRisk, statusType: "at-risk" as const },
      onTrack: { title: `${row.lob} - ${row.claimType} - On Track Tasks (${row.onTrack})`, count: row.onTrack, statusType: "on-track" as const },
      escalated: { title: `${row.lob} - ${row.claimType} - Escalated Tasks (${row.escalated})`, count: row.escalated, statusType: "escalated" as const },
    };

    const { title, count, statusType } = statusMap[type];
    const tasks = generateMockTasks(row, count, type);
    setDialogData({ title, tasks, statusType });
    setDialogOpen(true);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <ClipboardList className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-semibold">
            Live Task Status ({totalCallbacks})
          </h2>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 mb-4">
        <Select value={lobFilter} onValueChange={setLobFilter}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="LoB" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All LoB</SelectItem>
            <SelectItem value="Retail">Retail</SelectItem>
            <SelectItem value="GMC">GMC</SelectItem>
          </SelectContent>
        </Select>

        <Select value={claimTypeFilter} onValueChange={setClaimTypeFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Claim Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Claim Types</SelectItem>
            <SelectItem value="Cashless">Cashless</SelectItem>
            <SelectItem value="Reimbursement">Reimbursement</SelectItem>
          </SelectContent>
        </Select>

        <Select value={claimSubTypeFilter} onValueChange={setClaimSubTypeFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Claim Sub Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sub Types</SelectItem>
            <SelectItem value="IPD">IPD</SelectItem>
            <SelectItem value="OPD">OPD</SelectItem>
          </SelectContent>
        </Select>

        <Select value={assignedFilter} onValueChange={setAssignedFilter}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Assignment" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="assigned">Assigned</SelectItem>
            <SelectItem value="unassigned">Unassigned</SelectItem>
          </SelectContent>
        </Select>

        <Select value={agentFilter} onValueChange={setAgentFilter}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Agent" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Agents</SelectItem>
            <SelectItem value="Priya Singh">Priya Singh</SelectItem>
            <SelectItem value="Raj Patel">Raj Patel</SelectItem>
            <SelectItem value="Anita Kumar">Anita Kumar</SelectItem>
            <SelectItem value="Unassigned">Unassigned</SelectItem>
          </SelectContent>
        </Select>

        {hasActiveFilters && (
          <Button variant="ghost" size="sm" onClick={clearFilters} className="gap-2">
            <X className="w-4 h-4" />
            Clear Filters
          </Button>
        )}

        {hasActiveFilters && (
          <div className="flex gap-2">
            {lobFilter !== "all" && (
              <Badge variant="secondary">{lobFilter}</Badge>
            )}
            {claimTypeFilter !== "all" && (
              <Badge variant="secondary">{claimTypeFilter}</Badge>
            )}
            {claimSubTypeFilter !== "all" && (
              <Badge variant="secondary">{claimSubTypeFilter}</Badge>
            )}
            {assignedFilter !== "all" && (
              <Badge variant="secondary">{assignedFilter === "assigned" ? "Assigned" : "Unassigned"}</Badge>
            )}
            {agentFilter !== "all" && (
              <Badge variant="secondary">{agentFilter}</Badge>
            )}
          </div>
        )}
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead rowSpan={2} className="align-middle">LoB</TableHead>
            <TableHead rowSpan={2} className="align-middle">Claim Type</TableHead>
            <TableHead rowSpan={2} className="align-middle">Claim Sub Type</TableHead>
            <TableHead colSpan={4} className="text-center border-b">Total Tasks</TableHead>
            <TableHead rowSpan={2} className="text-center align-middle">Escalated</TableHead>
          </TableRow>
          <TableRow>
            <TableHead className="text-center">Unassigned</TableHead>
            <TableHead className="text-center">Breached</TableHead>
            <TableHead className="text-center">At Risk</TableHead>
            <TableHead className="text-center">On Track</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredData.length > 0 ? (
            filteredData.map((row, index) => (
              <TableRow key={index}>
                <TableCell className="font-medium">{row.lob}</TableCell>
                <TableCell>{row.claimType}</TableCell>
                <TableCell>{row.claimSubType}</TableCell>
                <TableCell className="text-center">
                  <button 
                    onClick={() => handleStatClick(row, "unassigned")}
                    className="text-muted-foreground font-semibold hover:underline cursor-pointer"
                  >
                    {row.unassigned}
                  </button>
                </TableCell>
                <TableCell className="text-center">
                  <button 
                    onClick={() => handleStatClick(row, "breached")}
                    className="text-status-breached font-semibold hover:underline cursor-pointer"
                  >
                    {row.breached}
                  </button>
                </TableCell>
                <TableCell className="text-center">
                  <button 
                    onClick={() => handleStatClick(row, "atRisk")}
                    className="text-status-at-risk font-semibold hover:underline cursor-pointer"
                  >
                    {row.atRisk}
                  </button>
                </TableCell>
                <TableCell className="text-center">
                  <button 
                    onClick={() => handleStatClick(row, "onTrack")}
                    className="text-status-on-track font-semibold hover:underline cursor-pointer"
                  >
                    {row.onTrack}
                  </button>
                </TableCell>
                <TableCell className="text-center">
                  <button 
                    onClick={() => handleStatClick(row, "escalated")}
                    className="text-status-escalated font-semibold hover:underline cursor-pointer"
                  >
                    {row.escalated}
                  </button>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                No data matches the selected filters
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      <StatBreakdownDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title={dialogData.title}
        tasks={dialogData.tasks}
        statusType={dialogData.statusType}
        onUpdateEscalation={dialogData.statusType === "unassigned" ? handleUpdateEscalation : undefined}
        onUpdateCohort={dialogData.statusType === "unassigned" ? handleUpdateCohort : undefined}
        onToggleSkipQueue={dialogData.statusType === "unassigned" ? handleToggleSkipQueue : undefined}
      />
    </div>
  );
}
